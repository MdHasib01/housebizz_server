import { errorNotify, infoNotify, validateExamType } from "@/services";
import {
  useAddExamTypeMutation,
  useDeleteExamTypeMutation,
  useGetExamTypeListsQuery,
  useUpdateExamTypeMutation,
} from "@/store/modules/superAdmin/global/examType/api";
import {
  addExamTypList,
  closeExamTypeModal,
  removeExamTypeList,
  setExamTypePageData,
  setSelectedExamType,
  updateExamTypeList,
  updateSelectedExamType,
} from "@/store/modules/superAdmin/global/examType/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export const useExamType = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.saExamType
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetExamTypeListsQuery({
    page: currentPage,
    limit: pageSize,
  });

  const [updateExamType, { isLoading: isUpdating }] =
    useUpdateExamTypeMutation();
  const [deleteExamType, { isLoading: isDeleting }] =
    useDeleteExamTypeMutation();

  const handleInput = (event) => {
    dispatch(updateSelectedExamType(event.target));
  };

  const handleSelect = (value) => {
    dispatch(setSelectedExamType(value));
  };

  const updatePage = (value) => {
    dispatch(setExamTypePageData(value));
  };

  const closeModal = () => {
    dispatch(closeExamTypeModal());
    dispatch(setSelectedExamType({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const updateSelectedData = () => {
    const error = validateExamType(selectedData);
    if (error) {
      return errorNotify(error);
    } else {
      const submitData = new FormData();
      submitData.append("data", JSON.stringify(selectedData));
      updateExamType({ data: submitData, id: selectedData?._id })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateExamTypeList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeExamType = () => {
    dispatch(closeExamTypeModal());
    deleteExamType(selectedData?._id)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeExamTypeList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    pageData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeExamType,
    currentPage,
    pageSize,
    totalPages,
  };
};

export const useAddExamType = () => {
  const dispatch = useDispatch();
  const [addExamType, { isLoading }] = useAddExamTypeMutation();
  const [name, setName] = useState("");

  const onSubmit = (event) => {
    event.preventDefault();

    if (name?.trim() === "") {
      errorNotify("Exam Type is required");
      return;
    }
    const data = {
      global_exam_type_name: name,
    };
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));

    addExamType(submitData)
      .unwrap()
      .then((res) => {
        setName("");
        dispatch(addExamTypList(res?.data));
      })
      .catch((error) => {
        errorNotify(error.data.message);
      });
  };
  return {
    onSubmit,
    isLoading,
    name,
    setName,
  };
};
