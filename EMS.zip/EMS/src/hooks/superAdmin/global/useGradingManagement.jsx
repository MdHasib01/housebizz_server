import {
  checkValidation,
  errorNotify,
  gradeSchema,
  infoNotify,
  validateGradingManagement,
} from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import {
  useAddGradingMutation,
  useDeleteGradingMutation,
  useGetGradingListsQuery,
  useUpdateGradingMutation,
} from "@/store/modules/superAdmin/global/gradingManagement/api";
import {
  addGradingList,
  closeGradingModal,
  removeGradingList,
  setGradingPageData,
  setSelectedGrading,
  updateGradingList,
  updateSelectedGrading,
  updateSelectedGradingClass,
} from "@/store/modules/superAdmin/global/gradingManagement/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useGradingManagement = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.saGradingManagement
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetGradingListsQuery({
    page: currentPage,
    limit: pageSize,
  });

  const [updateGrading, { isLoading: isUpdating }] = useUpdateGradingMutation();
  const [deleteGrading, { isLoading: isDeleting }] = useDeleteGradingMutation();

  const handleInput = (event) => {
    dispatch(updateSelectedGrading(event.target));
  };

  const handleSelect = (value) => {
    dispatch(setSelectedGrading(value));
  };

  const handleSelectClass = (value) => {
    dispatch(updateSelectedGradingClass(value));
  };


  const updatePage = (value) => {
    dispatch(setGradingPageData(value));
  };

  const closeModal = () => {
    dispatch(closeGradingModal());
    dispatch(setSelectedGrading({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const updateSelectedData = () => {
    const data = {
      ...selectedData,
      global_grade_point: Number(selectedData?.global_grade_point),
      global_grade_lowest_mark: Number(selectedData?.global_grade_lowest_mark),
      global_grade_highest_mark: Number(
        selectedData?.global_grade_highest_mark
      ),
    };
    const error = validateGradingManagement(data);
    if (error) {
      return errorNotify(error);
    } else {
      const submitData = new FormData();
      submitData.append("data", JSON.stringify(data));
      updateGrading({ data: submitData, id: selectedData?._id })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateGradingList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeGrading = () => {
    dispatch(closeGradingModal());
    deleteGrading(selectedData?._id)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeGradingList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    handleSelectClass,
    dataLists,
    selectedData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeGrading,
    currentPage,
    pageSize,
    totalPages,
  };
};

export const useAddGradingManagement = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [addGrading, { isLoading }] = useAddGradingMutation();
  const [errors, setErrors] = useState({});

  const handleNavigate = () => {
    navigate(superAdminRoutes.gradingManagement.path);
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());

    const data = {
      ...entries,
      global_grade_point: Number(entries?.global_grade_point),
      global_grade_lowest_mark: Number(entries?.global_grade_lowest_mark),
      global_grade_highest_mark: Number(entries?.global_grade_highest_mark),
    };
    
    const results = gradeSchema.safeParse(data);
    const { error, isError } = checkValidation(results);
    if (isError) {
      setErrors(error);
      return;
    } else {
      setErrors({});
      const submitData = new FormData();
      submitData.append("data", JSON.stringify(data));
      addGrading(submitData)
        .unwrap()
        .then((res) => {
          dispatch(addGradingList(res?.data));
          form.reset();
          handleNavigate();
          infoNotify(res?.message);
        })
        .catch((error) => {
          errorNotify(error.data.message);
        });
    }
  };
  return {
    errors,
    onSubmit,
    isLoading,
    handleNavigate,
  };
};
