import {
  boardSchema,
  checkValidation,
  errorNotify,
  infoNotify,
  validateBoardManagement,
} from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import {
  useAddBoardMutation,
  useDeleteBoardMutation,
  useGetBoardsQuery,
  useUpdateBoardMutation,
} from "@/store/modules/superAdmin/global/boardManagement/api";
import {
  addBoardList,
  closeBoardModal,
  removeBoardList,
  setBoardPageData,
  setSelectedBoard,
  updateBoardList,
  updateSelectedBoard,
} from "@/store/modules/superAdmin/global/boardManagement/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useBoardManagement = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.saBoardManagement
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetBoardsQuery({
    page: currentPage,
    limit: pageSize,
  });

  const [updateBoard, { isLoading: isUpdating }] = useUpdateBoardMutation();
  const [deleteBoard, { isLoading: isDeleting }] = useDeleteBoardMutation();

  const handleInput = (event) => {
    dispatch(updateSelectedBoard(event.target));
  };

  const handleSelect = (value) => {
    dispatch(setSelectedBoard(value));
  };

  const updatePage = (value) => {
    dispatch(setBoardPageData(value));
  };

  const closeModal = () => {
    dispatch(closeBoardModal());
    dispatch(setSelectedBoard({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const updateSelectedData = () => {
    const error = validateBoardManagement(selectedData);
    if (error) {
      return errorNotify(error);
    } else {
      const submitData = new FormData();
      submitData.append(
        "data",
        JSON.stringify({
          ...selectedData,
          global_board_code: Number(selectedData?.global_board_code) || null,
        })
      );
      updateBoard({ data: submitData, id: selectedData?._id })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateBoardList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeBoard = () => {
    dispatch(closeBoardModal());
    deleteBoard(selectedData?._id)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeBoardList("delete"));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    pageData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeBoard,
    currentPage,
    pageSize,
    totalPages,
  };
};

export const useAddBoardManagement = () => {
  const navigate = useNavigate();
  const [addBoard, { isLoading }] = useAddBoardMutation();
  const dispatch = useDispatch();
  const [errors, setErrors] = useState({});

  const navigateToBoardManagement = () => {
    navigate(superAdminRoutes.boardManagement.path);
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());
    const result = boardSchema.safeParse({
      ...entries,
      global_board_code: Number(entries?.global_board_code) || null,
    });
    const { isError, error, data } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    }
    setErrors({});
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));
    addBoard(submitData)
      .unwrap()
      .then((res) => {
        form.reset();
        dispatch(addBoardList(res?.data));
        navigateToBoardManagement();
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error.data.message);
      });
  };
  return {
    onSubmit,
    isLoading,
    navigateToBoardManagement,
    errors,
  };
};
