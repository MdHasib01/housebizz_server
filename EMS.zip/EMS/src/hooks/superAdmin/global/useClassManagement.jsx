import { errorNotify, infoNotify } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { validateClassManagement } from "@/services/validation/superAdmin/global/classManagement";
import {
  useAddClassMutation,
  useDeleteClassMutation,
  useGetClassListsQuery,
  useUpdateClassMutation,
} from "@/store/modules/superAdmin/global/classManagement/api";
import {
  addClassList,
  closeClassModal,
  removeClassList,
  setClassPageData,
  setSelectedClass,
  updateClassList,
  updateSelectedClass,
} from "@/store/modules/superAdmin/global/classManagement/slice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useClassManagement = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.saClassManagement
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetClassListsQuery({
    page: currentPage,
    limit: pageSize,
  });

  const [updateClass, { isLoading: isUpdating }] = useUpdateClassMutation();
  const [deleteClass, { isLoading: isDeleting }] = useDeleteClassMutation();

  const handleInput = (event) => {
    dispatch(updateSelectedClass(event.target));
  };

  const handleSelect = (value) => {
    dispatch(setSelectedClass(value));
  };


  const updatePage = (value) => {
    dispatch(setClassPageData(value));
  };

  const closeModal = () => {
    dispatch(closeClassModal());
    dispatch(setSelectedClass({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const updateSelectedData = () => {
    const error = validateClassManagement(selectedData);
    if (error) {
      return errorNotify(error);
    } else {
      const submitData = new FormData();
      submitData.append(
        "data",
        JSON.stringify({
          ...selectedData,
          global_class_code: Number(selectedData?.global_class_code),
        })
      );
      updateClass({ data: submitData, id: selectedData?._id })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateClassList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeClass = () => {
    dispatch(closeClassModal());
    deleteClass(selectedData?._id)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeClassList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    pageData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeClass,
    currentPage,
    pageSize,
    totalPages,
  };
};

export const useAddClassManagement = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [addClass, { isLoading }] = useAddClassMutation();

  const handleNavigate = () => {
    navigate(superAdminRoutes.classManagement.path);
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    const error = validateClassManagement(data);
    if (error) {
      errorNotify(error);
      return;
    }
    const submitData = new FormData();
    submitData.append(
      "data",
      JSON.stringify({
        ...data,
        global_class_code: Number(data?.global_class_code),
      })
    );
    addClass(submitData)
      .unwrap()
      .then((res) => {
        dispatch(addClassList(res?.data));
        handleNavigate();
        form.reset();
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error.data.message);
      });
  };
  return {
    onSubmit,
    isLoading,
    handleNavigate,
  };
};
