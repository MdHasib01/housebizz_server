import { errorNotify, infoNotify } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { validateSessionYear } from "@/services/validation/superAdmin/global/sessionType";
import {
  useAddSessionYearMutation,
  useDeleteSessionYearMutation,
  useGetSessionYearListsQuery,
  useUpdateSessionYearMutation,
} from "@/store/modules/superAdmin/global/sessionYear/api";
import {
  addSessionYearList,
  closeSessionYearModal,
  removeSessionYearList,
  setSelectedSessionYear,
  setSessionYearPageData,
  setSessionYearSelectors,
  updateSelectedSessionYear,
  updateSessionYearList,
} from "@/store/modules/superAdmin/global/sessionYear/slice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useSessionYear = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.saSessionYear
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetSessionYearListsQuery({
    page: currentPage,
    limit: pageSize,
  });

  const [updateSessionYear, { isLoading: isUpdating }] =
    useUpdateSessionYearMutation();
  const [deleteSessionYear, { isLoading: isDeleting }] =
    useDeleteSessionYearMutation();

  const handleInput = (values) => {
    dispatch(updateSelectedSessionYear(values));
  };

  const handleSelect = (value) => {
    dispatch(setSelectedSessionYear(value));
  };

  const updatePage = (value) => {
    dispatch(setSessionYearPageData(value));
  };

  const closeModal = () => {
    dispatch(closeSessionYearModal());
    dispatch(setSelectedSessionYear({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const updateSelectedData = () => {
    const error = validateSessionYear(selectedData);
    if (error) {
      return errorNotify(error);
    } else {
      const submitData = new FormData();
      submitData.append("data", JSON.stringify(selectedData));
      updateSessionYear({ data: submitData, id: selectedData?._id })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateSessionYearList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeSessionYear = () => {
    dispatch(closeSessionYearModal());
    deleteSessionYear(selectedData?._id)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeSessionYearList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeSessionYear,
    currentPage,
    pageSize,
    totalPages,
  };
};

export const useAddSessionYear = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { selectors } = useSelector((state) => state.saSessionYear);
  const [addSessionYear, { isLoading }] = useAddSessionYearMutation();

  const handleNavigate = () => {
    navigate(superAdminRoutes.sessionYear.path);
  };

  const setSelectors = (values) => {
    dispatch(setSessionYearSelectors(values));
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    const error = validateSessionYear(data);
    if (error) {
      errorNotify(error);
      return;
    }
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));
    addSessionYear(submitData)
      .unwrap()
      .then((res) => {
        dispatch(addSessionYearList(res.data));
        setSelectors({
          institute_type: "",
          global_academic_year: "",
        });
        handleNavigate();
        infoNotify(res.message);
      })
      .catch((error) => {
        errorNotify(error.data.message);
      });
  };
  return {
    onSubmit,
    isLoading,
    handleNavigate,
    selectors,
    setSelectors,
  };
};
