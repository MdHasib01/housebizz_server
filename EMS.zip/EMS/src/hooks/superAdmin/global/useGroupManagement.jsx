import { errorNotify, infoNotify, validateGroupManagement } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import {
  useAddGroupMutation,
  useDeleteGroupMutation,
  useGetGroupListsQuery,
  useUpdateGroupMutation,
} from "@/store/modules/superAdmin/global/groupManagement/api";
import {
  addGroupList,
  closeGroupModal,
  removeGroupList,
  setGlobalSelectors,
  setGroupPageData,
  setSelectedGroup,
  updateGroupList,
  updateSelectedGroup,
  updateSelectedGroupClass,
} from "@/store/modules/superAdmin/global/groupManagement/slice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useGroupManagement = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.saGroupManagement
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetGroupListsQuery({
    page: currentPage,
    limit: pageSize,
  });

  const [updateGroup, { isLoading: isUpdating }] = useUpdateGroupMutation();
  const [deleteGroup, { isLoading: isDeleting }] = useDeleteGroupMutation();

  const handleInput = (event) => {
    dispatch(updateSelectedGroup(event.target));
  };

  const handleSelectClass = (value) => {
    dispatch(updateSelectedGroupClass(value));
  };

  const handleSelect = (item) => {
    dispatch(
      setSelectedGroup({
        ...item,
        class_id: item?.global_class_id?._id,
      })
    );
  };

  const updatePage = (value) => {
    dispatch(setGroupPageData(value));
  };

  const closeModal = () => {
    dispatch(closeGroupModal());
    dispatch(setSelectedGroup({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const updateSelectedData = () => {
    const error = validateGroupManagement(selectedData);
    if (error) {
      return errorNotify(error);
    } else {
      const submitData = new FormData();
      submitData.append(
        "data",
        JSON.stringify({
          global_group_name: selectedData.global_group_name,
          global_class_id: selectedData.class_id,
        })
      );
      updateGroup({ data: submitData, id: selectedData?._id })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateGroupList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeGroup = () => {
    dispatch(closeGroupModal());
    deleteGroup(selectedData?._id)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeGroupList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    handleSelectClass,
    dataLists,
    selectedData,
    pageData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeGroup,
    currentPage,
    pageSize,
    totalPages,
  };
};

export const useAddGroupManagement = () => {
  const navigate = useNavigate();
  const [addGroup, { isLoading }] = useAddGroupMutation();
  const { selectors } = useSelector((state) => state.saGroupManagement);
  const dispatch = useDispatch();

  const handleNavigate = () => {
    navigate(superAdminRoutes.groupManagement.path);
  };

  const setSelctors = (values) => {
    dispatch(setGlobalSelectors(values));
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const global_group_name = form.global_group_name.value;
    const data = {
      global_group_name,
      global_class_id: selectors?.global_class_id,
    };
    const error = validateGroupManagement(data);
    if (error) {
      errorNotify(error);
      return;
    }
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));
    addGroup(submitData)
      .unwrap()
      .then((res) => {
        dispatch(addGroupList(res?.data));
        setSelctors({ global_class_id: "" });
        form.reset();
        handleNavigate();
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error.data.message);
      });
  };
  return {
    onSubmit,
    isLoading,
    handleNavigate,
    selectors,
    setSelctors,
  };
};
