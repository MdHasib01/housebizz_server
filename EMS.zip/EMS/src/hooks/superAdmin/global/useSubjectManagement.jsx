import {
  checkValidation,
  errorNotify,
  filterUndefined,
  getClassCode,
  infoNotify,
  subjectSchema,
  validateSubjectManagement,
} from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import {
  useAddSubjectMutation,
  useDeleteSubjectMutation,
  useGetFilteredSubjectListsQuery,
  useUpdateSubjectMutation,
} from "@/store/modules/superAdmin/global/subjectManagement/api";
import {
  closeSubjectModal,
  removeSubjectList,
  resetGroupList,
  resetSelectors,
  setfetchData,
  setGroupList,
  setSelectedSubject,
  setSelectedSubjectGroup,
  setShowSubjectTable,
  setSubjectBoardId,
  setSubjectClassId,
  setSubjectPageData,
  setSubjectSelectors,
  updateSelectedSubject,
  updateSelectedSubjectBoard,
  updateSelectedSubjectClass,
  updateSubjectList,
} from "@/store/modules/superAdmin/global/subjectManagement/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useSubjectFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.saSubjectManagement);
  const [class_code, class_id] = getClassCode(selectors?.class_id);
  const classCode = class_code ? Number(class_code) : 0;

  const groupFilterByClass = (item) => {
    if (classCode < 8) {
      return false;
    }
    return item?.global_class_id?._id === class_id;
  };

  const handleSelector = (values) => {
    dispatch(setSubjectSelectors(values));
  };

  const handleReset = () => {
    dispatch(resetSelectors());
  };

  const handleShowTable = () => {
    if (selectors?.board_id || selectors?.class_id) {
      dispatch(setShowSubjectTable(true));
      dispatch(setfetchData(true));
    } else {
      errorNotify("Please select at least one filter");
    }
  };
  return {
    selectors,
    classCode,
    groupFilterByClass,
    handleSelector,
    handleReset,
    handleShowTable,
  };
};

export const useSubjectManagement = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal, selectors, fetchData } =
    useSelector((state) => state.saSubjectManagement);
  const { currentPage, pageSize, totalPages } = pageData || {};
  const classCode = selectedData?.global_class_id?.global_class_code
    ? Number(selectedData?.global_class_id?.global_class_code)
    : 0;

  const query = Object.keys(selectors).reduce((acc, key) => {
    if (selectors[key]) {
      if (key === "class_id") {
        const [class_code, class_id] = getClassCode(selectors[key]);
        return `${acc}class_code=${class_code}&class_id=${class_id}&`;
      } else {
        return `${acc}${key}=${selectors[key]}&`;
      }
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetFilteredSubjectListsQuery(
    query,
    {
      skip: !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const [updateSubject, { isLoading: isUpdating }] = useUpdateSubjectMutation();
  const [deleteSubject, { isLoading: isDeleting }] = useDeleteSubjectMutation();

  const handleInput = (event) => {
    dispatch(updateSelectedSubject(event.target));
  };

  const handleClassSelect = (value) => {
    dispatch(updateSelectedSubjectClass(value));
  };

  const handleBoardSelect = (value) => {
    dispatch(updateSelectedSubjectBoard(value));
  };

  const handleGroupSelect = (value) => {
    const id = value?._id;
    dispatch(setSelectedSubjectGroup(id));
  };

  const handleSelect = (item) => {
    let data = {
      ...item,
      class_id: item?.global_class_id?._id,
      board_id: item?.global_board_id?._id,
      global_subject_id: item?._id,
      groups: [],
    };
    if (item?.type === "update") {
      const groups = item?.global_group_ids?.map((item) => item?._id);
      data.groups = groups;
    }
    dispatch(setSelectedSubject(data));
  };

  const updatePage = (value) => {
    dispatch(setSubjectPageData(value));
  };

  const closeModal = () => {
    dispatch(closeSubjectModal());
    dispatch(setSelectedSubject({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const goupFilterByClass = (item) => {
    if (classCode > 8) {
      return item.global_class_id?._id === selectedData?.class_id;
    } else {
      return false;
    }
  };

  const updateSelectedData = () => {
    const error = validateSubjectManagement(selectedData);
    if (error) {
      return errorNotify(error);
    } else {
      const submitData = new FormData();
      const data = {
        global_board_id: selectedData?.board_id,
        global_class_id: selectedData?.class_id,
        global_subject_name: selectedData?.global_subject_name,
        global_subject_code: selectedData?.global_subject_code,
        global_subject_order:
          Number(selectedData?.global_subject_order) || null,
        global_group_ids: selectedData?.groups,
      };
      const filteredData = filterUndefined(data);
      submitData.append("data", JSON.stringify(filteredData));

      if (classCode > 8 && selectedData?.groups == 0) {
        return errorNotify("Please select groups");
      }

      updateSubject({ data: submitData, id: selectedData?._id })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateSubjectList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeSubject = () => {
    dispatch(closeSubjectModal());
    deleteSubject(selectedData?._id)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeSubjectList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeSubject,
    currentPage,
    pageSize,
    totalPages,
    handleClassSelect,
    handleBoardSelect,
    handleGroupSelect,
    goupFilterByClass,
  };
};

export const useAddSubject = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [addSubject, { isLoading }] = useAddSubjectMutation();
  const { groups, global_board_id, global_class_id } = useSelector(
    (state) => state.saSubjectManagement
  );
  const [errors, setErrors] = useState({});
  const [class_code, class_id] = getClassCode(global_class_id);
  const classCode = class_code ? Number(class_code) : 0;

  const handleNavigate = () => {
    navigate(superAdminRoutes.subjectManagement.path);
  };

  const handleGroupSelect = (item) => {
    dispatch(setGroupList(item));
  };
  const handleBoardSelect = (item) => {
    dispatch(setSubjectBoardId(item));
  };
  const handleClassSelect = (item) => {
    dispatch(setSubjectClassId(item));
  };

  const goupFilterByClass = (item) => {
    if (classCode > 8) {
      return item.global_class_id?._id === class_id;
    } else {
      return false;
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());
    const result = subjectSchema.safeParse({
      ...entries,
      global_subject_order: Number(entries?.global_subject_order) || null,
      global_board_id,
      global_class_id: class_id,
    });
    const { isError, error, data } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    } else {
      setErrors({});
    }
    const submitData = new FormData();

    if (classCode > 8 && groups?.length == 0) {
      return errorNotify("Please select groups");
    }

    submitData.append(
      "data",
      JSON.stringify({ ...data, global_group_ids: groups })
    );

    addSubject(submitData)
      .unwrap()
      .then((res) => {
        handleNavigate();
        form.reset();
        handleClassSelect("");
        handleBoardSelect("");
        dispatch(resetGroupList());
        dispatch(resetSelectors());
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error.data.message);
      });
  };

  return {
    groups,
    onSubmit,
    isLoading,
    handleNavigate,
    handleGroupSelect,
    errors,
    handleBoardSelect,
    handleClassSelect,
    global_board_id,
    global_class_id,
    goupFilterByClass,
    classCode: classCode,
  };
};
