import { errorNotify, infoNotify } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import {
  useGetRequestedInstitutesQuery,
  useRemoveRequestedInstituteMutation,
  useUpdateRequestedInstituteMutation,
} from "@/store/modules/superAdmin/administrator/requestedInstitute/api";
import {
  closeRequestedInstituteModal,
  removeRequestedInstituteList,
  setRequestedInstitutePageData,
  setSelectedRequestedInstitute,
} from "@/store/modules/superAdmin/administrator/requestedInstitute/slice";

import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useRequestedInstitute = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { dataLists, pageData, selectedData, showModal } = useSelector(
    (state) => state.saRequestedInstitute
  );

  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetRequestedInstitutesQuery({
    page: currentPage,
    limit: pageSize,
  });

  const [updateRequestedInstitute, { isLoading: isUpdating }] =
    useUpdateRequestedInstituteMutation();
  const [removeRequestedInstitute, { isLoading: isDeleting }] =
    useRemoveRequestedInstituteMutation();

  const handleSelectInstitute = (data) => {
    dispatch(setSelectedRequestedInstitute(data));
  };

  const updatePage = (value) => {
    dispatch(setRequestedInstitutePageData(value));
  };

  const handleCloseModal = () => {
    dispatch(closeRequestedInstituteModal());
  };

  const navigateToDetails = (item) => {
    navigate(
      `${superAdminRoutes.requestedInstituteDetails.routePath}/${item?._id}`,
      {
        state: item,
      }
    );
  };

  const updateInstituteStatus = (item) => {
    handleSelectInstitute(item);
    const data = {
      status: "published",
    };
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    updateRequestedInstitute({
      data: formData,
      id: item?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  const handleRemove = () => {
    removeRequestedInstitute(selectedData?._id)
      .unwrap()
      .then((res) => {
        dispatch(removeRequestedInstituteList());
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    dataLists,
    isFetching,
    isError,
    status: error?.status,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    handleRemove,
    handleSelectInstitute,
    updateInstituteStatus,
    showModal,
    selectedData,
    closeModal: handleCloseModal,
    isLoading: isUpdating || isDeleting,
    navigateToDetails
  };
};
