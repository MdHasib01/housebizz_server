import {
  checkValidation,
  errorNotify,
  infoNotify,
  userRoutes,
} from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import instituteSchema from "@/services/validation/zodSchema/superAdmin/administrator/instituteOnboard";
import {
  useAddInstituteManagementMutation,
  useGetInstituteManagementsQuery,
  useGetInstituteQuery,
  useUpdateInstituteManagementMutation,
} from "@/store/modules/superAdmin/administrator/instituteManagement/api";
import {
  addInstituteManagementList,
  resetInstituteSelectors,
  setInstituteManagementPageData,
  setInstiuteSelectors,
  setSelectedInstituteManagement,
  updateInstituteManagementList,
} from "@/store/modules/superAdmin/administrator/instituteManagement/slice";

import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

export const useInstituteManagement = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { dataLists, pageData,selectedInstituteManagement } = useSelector(
    (state) => state.saInstituteManagement
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetInstituteManagementsQuery({
    page: currentPage,
    limit: pageSize,
  });
  const handleSelect = (item) => {
    dispatch(setSelectedInstituteManagement(item));
  };
  const updatePage = (value) => {
    dispatch(setInstituteManagementPageData(value));
  };

  return {
    dataLists,
    isFetching,
    isError,
    status: error?.status,
    handleSelect,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    selectedData:selectedInstituteManagement
  };
};

export const useAddInstitute = (type = "admin") => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [errors, setErrors] = useState({});
  const { selectors } = useSelector((state) => state.saInstituteManagement);
  const [addInstituteManagement, { isLoading }] =
    useAddInstituteManagementMutation();

  const setSelectors = (value) => {
    dispatch(setInstiuteSelectors(value));
  };

  const handleNavigate = () => {
    if (type === "admin") {
      navigate(superAdminRoutes.instituteManagement.path);
    } else {
      navigate(userRoutes.home.path);
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());
    const data = {
      ...entries,
      ...selectors,
      board_institute_code:
        selectors?.institute_type === "School"
          ? entries?.board_school_code
          : entries?.board_collage_code || "",
      eiin_number: Number(entries.eiin_number) || 0,
      total_students: Number(entries.total_students) || 0,
      status: type === "admin" ? "published" : "pending",
    };
    const results = instituteSchema.safeParse(data);
    const { isError, error } = checkValidation(results);
    const submitForm = new FormData();

    submitForm.append("data", JSON.stringify(data));
    if (isError) {
      setErrors(error);
      return;
    } else {
      setErrors({});
      addInstituteManagement(submitForm)
        .unwrap()
        .then((res) => {
          form.reset();
          dispatch(addInstituteManagementList(res?.data));
          handleNavigate();
          dispatch(resetInstituteSelectors());
          infoNotify("Institute added successfully");
        })
        .catch((error) => {
          errorNotify(error?.data?.message);
        });
    }
  };

  return {
    selectors,
    errors,
    onSubmit,
    isLoading,
    setSelectors,
  };
};

export const useUpdatedInstitute = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [errors, setErrors] = useState({});
  const { selectedInstituteManagement, selectors } = useSelector(
    (state) => state.saInstituteManagement
  );

  const { isFetching, isError } = useGetInstituteQuery(id, {
    skip: !id,
    refetchOnMountOrArgChange: true,
  });

  const [updateInstituteManagement, { isLoading }] =
    useUpdateInstituteManagementMutation();

  const setSelectors = (value) => {
    dispatch(setInstiuteSelectors(value));
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());
    const data = {
      ...entries,
      ...selectors,
      board_institute_code:
        selectors?.institute_type === "School"
          ? entries?.board_school_code
          : entries?.board_collage_code || "",
      eiin_number: Number(entries.eiin_number) || 0,
      total_students: Number(entries.total_students) || 0,
    };
    const results = instituteSchema.safeParse(data);
    const { isError, error } = checkValidation(results);
    const submitForm = new FormData();

    submitForm.append("data", JSON.stringify(data));
    if (isError) {
      setErrors(error);
      return;
    } else {
      setErrors({});
      updateInstituteManagement({ data: data, id: id })
        .unwrap()
        .then((res) => {
          navigate(superAdminRoutes.instituteManagement.path);
          form.reset();
          dispatch(resetInstituteSelectors());
          infoNotify("Institute updated successfully");
          dispatch(updateInstituteManagementList(res?.data));
        })
        .catch((error) => {
          errorNotify(error?.data?.message);
        });
    }
  };

  return {
    errors,
    onSubmit,
    isLoading,
    isFetching,
    isError,
    data: selectedInstituteManagement,
    selectors,
    setSelectors,
  };
};
