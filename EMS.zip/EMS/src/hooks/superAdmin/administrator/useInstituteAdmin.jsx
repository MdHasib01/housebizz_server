import { useGetInstituteAdminsQuery } from "@/store/modules/superAdmin/administrator/instituteManagement/adminApi";
import {
  setInstituteAdminPageData,
  setInstituteAdminSelectedData,
} from "@/store/modules/superAdmin/administrator/instituteManagement/adminSlice";

import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

export const useInstituteAdmins = () => {
  const dispatch = useDispatch();
  const { id } = useParams();
  const { dataLists, pageData, selectedData } = useSelector(
    (state) => state.saInstituteAdmin
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetInstituteAdminsQuery(
    {
      page: currentPage,
      limit: pageSize,
      institute_id: id,
    },
    {
      skip: !id,
      refetchOnMountOrArgChange: true,
    }
  );

  const updatePage = (value) => {
    dispatch(setInstituteAdminPageData(value));
  };

  const handleSelect = (value) => {
    dispatch(setInstituteAdminSelectedData(value));
  };

  return {
    dataLists,
    isFetching,
    isError,
    status: error?.status,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    handleSelect,
    selectedData,
  };
};
