import { getSession } from "@/services";
import { authApi } from "@/store/modules/auth/authApi";
import { initiateAuthData, saveAuthData } from "@/store/modules/auth/authSlice";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";

export default function useAuthCheck() {
  const dispatch = useDispatch();
  const [authChecked, setAuthChecked] = useState(false);

  const getAuthUserData = async () => {
    const auth = await getSession();
    try {
      if (auth) {
        dispatch(initiateAuthData(auth));
        if (
          auth?.instituteAdmin &&
          auth?.instituteAdmin?.role === "institute_admin"
        ) {
          const institute = await dispatch(
            authApi.endpoints.getInstituteProfile.initiate(
              auth?.instituteAdmin?.institute_id,
              {
                forceRefetch: true,
              }
            )
          ).unwrap();
          const { data } = institute;
          dispatch(saveAuthData({ institute: data }));
        }
      }
    } catch (error) {
    } finally {
      setAuthChecked(true);
    }
  };

  useEffect(() => {
    getAuthUserData();
  }, [dispatch, setAuthChecked]);
  return authChecked;
}
