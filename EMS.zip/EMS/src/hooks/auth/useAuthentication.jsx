import { adminRoutes, errorNotify, infoNotify } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { useSigninMutation } from "@/store/modules/auth/authApi";
import { updateSigninInfo } from "@/store/modules/auth/authSlice";
import Autoplay from "embla-carousel-autoplay";
import useEmblaCarousel from "embla-carousel-react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useDotButton } from "../shared/useCarouselDotButton";

export const useSignin = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true }, [Autoplay({})]);
  const { selectedIndex, scrollSnaps } = useDotButton(emblaApi);
  const { signinInfo } = useSelector((state) => state.auth);
  const [siginin, { isLoading }] = useSigninMutation();

  const handleInput = (e) => {
    const { name, value } = e.target;
    dispatch(updateSigninInfo({ [name]: value }));
  };

  const handleSelectChange = (value) => {
    dispatch(updateSigninInfo({ entity_type: value }));
  };

  const withoutInstitute = ["super_admin", "staff_admin"];
  const isCompleteField = withoutInstitute?.includes(signinInfo?.entity_type)
    ? signinInfo?.username && signinInfo?.password
    : signinInfo?.institute_id && signinInfo?.username && signinInfo?.password;

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isCompleteField) return errorNotify("Please fill all fields");
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({
        ...signinInfo,
        institute_id: signinInfo?.institute_id || "super_admin",
      })
    );
    siginin(formData)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        if (signinInfo?.entity_type === "super_admin") {
          navigate(superAdminRoutes.dashboard.path);
        } else {
          navigate(adminRoutes.dashboard.path);
        }
      })
      .catch((error) => {
        errorNotify(error?.data?.message || "Something went wrong");
      });
  };

  return {
    handleInput,
    handleSelectChange,
    handleSubmit,
    signinInfo,
    isCompleteField,
    isLoading,
    emblaRef,
    selectedIndex,
    scrollSnaps,
  };
};
