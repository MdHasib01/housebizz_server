import { errorNotify, infoNotify } from "@/services";
import { useRemoveSmsMutation } from "@/store/modules/admin/settings/sms/api";
import {
  addSms,
  closeSmsModal,
  handleRemoveSms,
  setSelectSms,
  updateSms,
  updateSmsState,
} from "@/store/modules/admin/settings/sms/slice";
import { useDispatch, useSelector } from "react-redux";

export const useSmsForm = () => {
  const dispatch = useDispatch();
  const { smsTags, sms_type, message, selectedData, dataLists } = useSelector(
    (state) => state.smsSetting
  );

  const handleChange = (value) => {
    dispatch(updateSmsState({ name: "sms_type", value }));
  };

  const TagClick = (tag) => {
    const newMessage = message + tag;
    dispatch(updateSmsState({ name: "message", value: newMessage }));
  };

  const handleMessageChange = (e) => {
    const value = e.target.value;
    dispatch(updateSmsState({ name: "message", value }));
  };

  const handleReset = () => {
    handleChange("");
    dispatch(updateSmsState({ name: "message", value: "" }));
  };

  const handleSubmit = () => {
    const _id = new Date().getTime().toString();
    let data = {
      sms_type: sms_type,
      message: message,
    };
    if (selectedData?._id) {
      data = {
        ...data,
        _id: selectedData?._id,
      };
      dispatch(updateSms(data));
    } else {
      data = {
        ...data,
        _id: _id,
      };
      const existingData = dataLists.find((item) => item.sms_type === sms_type);
      if (existingData) {
        return errorNotify("Sms already exists!");
      }
      dispatch(addSms(data));
    }
  };

  return {
    smsTags,
    sms_type,
    message,
    selectedData,
    handleChange,
    TagClick,
    handleMessageChange,
    handleReset,
    handleSubmit,
  };
};

export const useSms = () => {
  const dispatch = useDispatch();
  const { dataLists, showModal, selectedData } = useSelector(
    (state) => state.smsSetting
  );

  const [removeSms, { isLoading }] = useRemoveSmsMutation();

  const handleSelect = (data) => {
    dispatch(setSelectSms(data));
  };

  const closeModal = () => {
    dispatch(closeSmsModal());
  };

  const handleRemove = () => {
    closeModal();
    dispatch(handleRemoveSms());
    infoNotify("Sms removed successfully!");
    // removeSms(selectedData?._id)
    //   .unwrap()
    //   .then((res) => {
    //     dispatch(handleRemoveSms());
    //     infoNotify(res?.message);
    //   })
    //   .catch((error) => {
    //     errorNotify(error?.data?.message);
    //   });
  };

  return {
    dataLists,
    showModal,
    selectedData,
    isLoading,
    handleSelect,
    closeModal,
    handleRemove,
    isFetching: false,
    isError: false,
    status: 400,
  };
};
