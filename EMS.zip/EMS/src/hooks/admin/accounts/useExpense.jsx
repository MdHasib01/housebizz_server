import { infoNotify } from "@/services";
import {
  closeAddExpense,
  closeModalHandler,
  deleteExpenseHandler,
  setSelectedData,
  showAddExpense,
  updateExpenseValue,
} from "@/store/modules/admin/accounts/expences/expensesSlice";
import { useDispatch, useSelector } from "react-redux";

export const useExpense = () => {
  const dispatch = useDispatch();

  const { showModal, addExpenseModal, expenseData, selectedData } = useSelector(
    (state) => state.adminAccountExpense
  );
  const closeAddExpenseModal = () => {
    dispatch(closeAddExpense());
  };
  const showAddExpenseModal = () => {
    dispatch(showAddExpense());
    dispatch(setSelectedData({ item: {}, type: "add" }));
  };
  const closeModal = () => {
    dispatch(closeModalHandler());
  };
  const handleAction = ({ item, type }) => {
    dispatch(setSelectedData({ item, type }));
  };
  const getType = () => {
    return selectedData.type;
  };
  const handleDelete = () => {
    console.log("selectedData", selectedData);
    dispatch(deleteExpenseHandler(selectedData.item));
    closeModal();
    infoNotify("Expense deleted successfully!");
  };
  const updateValue = (value) => {
    dispatch(updateExpenseValue(value));
  };
  return {
    getType,
    updateValue,
    dataLists: expenseData,
    handleDelete,
    closeModal,
    selectedData,
    showModal,
    handleAction,
    addExpenseModal,
    closeAddExpenseModal,
    showAddExpenseModal,
  };
};
