import { closeMoneyDepositInvoiceModal } from "@/store/modules/admin/accounts/overview/moneyDepositSlice";
import { useDispatch, useSelector } from "react-redux";

export const useMoneyDeposit = () => {
  const dispatch = useDispatch();
  const {
    showModal,
    depositData,
    isFetching,
    isError,
    status,
    isLoading,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
  } = useSelector((state) => state.adminAccountDeposit);
  const closeModal = () => {
    dispatch(closeMoneyDepositInvoiceModal());
  };
  return {
    isFetching,
    isError,
    status,
    isLoading,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    showModal: showModal,
    closeModal,
    dataLists: depositData,
  };
};
