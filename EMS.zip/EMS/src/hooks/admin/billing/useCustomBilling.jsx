import { errorNotify, infoNotify } from "@/services";
import { useAddStudentCustomBillingMutation, useGetStudentCustomBillingQuery } from "@/store/modules/admin/billing/invoices/api";
import {
  changeCustomBillingSummeryAmount,
  resetCustomBillingState,
  setCustomBillingFetchStudent,
  setCustomBillingShowStudent,
  setCustomBillingStudentId,
} from "@/store/modules/admin/billing/invoices/customBillingSlice";
import { useDispatch, useSelector } from "react-redux";

export const useCustomerBillingFilter = () => {
  const dispatch = useDispatch();
  const { student_id } = useSelector((state) => state.adminCustomBilling);

  const handleReset = () => {
    dispatch(setCustomBillingStudentId(""));
    dispatch(setCustomBillingShowStudent(false));
    dispatch(setCustomBillingFetchStudent(false));
  };

  const handleInput = (event) => {
    const value = event.target.value;
    dispatch(setCustomBillingStudentId(value));
  };

  const handleSearch = () => {
    if (!student_id) return errorNotify("Please enter student id to search");
    dispatch(setCustomBillingShowStudent(true));
    dispatch(setCustomBillingFetchStudent(true));
  };

  return {
    handleReset,
    handleInput,
    handleSearch,
    student_id,
  };
};

export const useCustomBilling = () => {
  const dispatch = useDispatch();
  const { student_id, showStudent, fetchStudent, student, charges_summary } =
    useSelector((state) => state.adminCustomBilling);

  const [addStudentCustomBilling, { isLoading }] =
    useAddStudentCustomBillingMutation();
  const { isFetching, isError, error } = useGetStudentCustomBillingQuery(
    student_id,
    {
      skip: !showStudent || !fetchStudent,
      refetchOnMountOrArgChange: true,
    }
  );

  const handleSummeryAmountChange = (event, index) => {
    const { value } = event.target;
    dispatch(
      changeCustomBillingSummeryAmount({
        index: index,
        value,
      })
    );
  };

  const handleSubmit = () => {
    const filteredSummeries = charges_summary.filter(
      (item) => item?.amount !== "" && item?.amount !== 0
    );
    if (filteredSummeries?.length === 0)
      return errorNotify("Please add at least one head amount");
    const data = {
      ...student,
      charges_summary: filteredSummeries,
    };
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));
    addStudentCustomBilling(submitData)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(resetCustomBillingState());
      })
      .catch((err) => {
        errorNotify(err?.data?.message);
      });
  };
  
  return {
    isFetching,
    isError,
    error,
    student,
    charges_summary,
    handleSummeryAmountChange,
    handleSubmit,
    isLoading,
    showStudent
  };
};
