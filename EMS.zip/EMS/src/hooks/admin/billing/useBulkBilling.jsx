import {
  errorNotify,
  getClassCode,
  getMonthYearCode,
  infoNotify,
} from "@/services";
import {
  useAddBulkBillingMutation,
  useGetBulkBillingStudentsQuery,
} from "@/store/modules/admin/billing/invoices/api";
import {
  changeBulkBillingDueDate,
  resetBillingStudentSelectors,
  resetBulkBillingSelectors,
  selectAllBulkBilling,
  setBulkBillingFetchData,
  setBulkBillingSelectors,
  setBulkBillingShowTable,
  toggleSelectedBulkBilling,
} from "@/store/modules/admin/billing/invoices/bulkBillingSlice";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";

export const useBulkBillingFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminBulkBilling);
  const [class_code, _] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code);

  const handleUpdateSelectors = (values) => {
    dispatch(setBulkBillingSelectors(values));
  };

  const handleReset = () => {
    dispatch(resetBulkBillingSelectors());
  };

  const handleFilter = () => {
    if (
      !selectors?.academic_year ||
      !selectors?.current_category ||
      !selectors?.current_class ||
      !selectors?.month ||
      !selectors?.billing_type?._id
    ) {
      return errorNotify("Please fill all the fields");
    }
    dispatch(setBulkBillingShowTable(true));
    dispatch(setBulkBillingFetchData(true));
  };
  return {
    selectors,
    classCode,
    handleUpdateSelectors,
    handleReset,
    handleFilter,
  };
};

export const useBulkBilling = () => {
  const dispatch = useDispatch();
  const { allData, student_ids, fetchData, selectors } = useSelector(
    (state) => state.adminBulkBilling
  );
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const querySelectors = {
    category_id: selectors?.current_category,
    class_id: getClassCode(selectors?.current_class)[1],
    academic_year: selectors?.academic_year,
    group_id: selectors?.current_group,
    institute_id,
    billing_type: selectors?.billing_type,
    month: selectors?.month,
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetBulkBillingStudentsQuery(
    { query },
    {
      skip: !institute_id || !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const handleSelectAllBulkBilling = () => {
    dispatch(selectAllBulkBilling());
  };

  const handleToggleSelectStudent = (id) => {
    dispatch(toggleSelectedBulkBilling(id));
  };

  return {
    dataLists: allData,
    isFetching,
    isError,
    status: error?.status,
    student_ids,
    handleSelectAllBulkBilling,
    handleToggleSelectStudent,
    isAllSelected: student_ids?.length === allData?.length,
    dataLength: allData?.length || 0,
  };
};

export const useAddBulkBilling = () => {
  const dispatch = useDispatch();
  const { selectors, students } = useSelector(
    (state) => state.adminBulkBilling
  );
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const handleDate = (value) => {
    dispatch(changeBulkBillingDueDate(value));
  };
  const [addBulkBilling, { isLoading }] = useAddBulkBillingMutation();

  const shortMonth = selectors?.month.slice(0, 3);
  let totalAmount = 0;
  const heads = selectors?.billing_type
    ? selectors?.billing_type?.assigned_heads
        ?.filter((item) => (item?.monthly_fees[shortMonth] || 0) > 0)
        .map((item) => {
          const amount = item?.monthly_fees[shortMonth];
          totalAmount += amount;
          return {
            billing_head_id: item?.billing_head_id?._id,
            title: item?.billing_head_id?.head_title,
            amount,
          };
        })
    : [];

  const onSubmit = () => {
    if (!selectors?.due_date?.startDate || students?.length === 0)
      return errorNotify("students or due date is missing");

    const dueData = moment(new Date(selectors?.due_date?.startDate)).unix();
    const data = students?.map((item) => {
      return {
        institute_id: institute_id,
        student_id: item?._id,
        student_username: item?.username,
        academic_year: selectors?.academic_year,
        charges_summary: heads,
        total_amount: totalAmount,
        status: "Pending",
        due_date: dueData,
        billing_month: getMonthYearCode(selectors?.month),
      };
    });
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    addBulkBilling(formData)
      .unwrap()
      .then((res) => {
        dispatch(resetBulkBillingSelectors());
        dispatch(resetBillingStudentSelectors());
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    selectors,
    students,
    heads,
    onSubmit,
    isLoading,
    totalAmount,
    shortMonth,
    handleDate,
    isSubmitable:
      selectors?.due_date?.startDate && students?.length > 0 ? true : false,
  };
};
