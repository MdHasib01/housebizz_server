import { errorNotify, infoNotify } from "@/services";
import {
  useAddStudentCashPayMutation,
  useGetStudentInvoicesQuery,
} from "@/store/modules/admin/billing/cashPay/api";
import {
  closeCashPayInvoiceModal,
  closeCashPayModal,
  closeCashPayViewInvoiceModal,
  movePendingToPaidInvoices,
  removeCashPayList,
  removeSelectedCashPaySummery,
  selectAllCashPay,
  setCashPayFetchStudent,
  setCashPayShowStudent,
  setCashPayStudentId,
  setPendingCashPayPageData,
  setSelectedCashPay,
  toggleSelectedCashPay,
  updateCashPayInvoice,
  updateSelectedCashPaySummery,
} from "@/store/modules/admin/billing/cashPay/slice";
import {
  useDeleteBillingSearchInvoiceMutation,
  useUpdateBillingSearchSummeryMutation,
} from "@/store/modules/admin/billing/invoices/api";
import { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useReactToPrint } from "react-to-print";

export const useCashPayFilter = () => {
  const dispatch = useDispatch();
  const { student_id } = useSelector((state) => state.adminCashPay);

  const handleReset = () => {
    dispatch(setCashPayStudentId(""));
    dispatch(setCashPayShowStudent(false));
    dispatch(setCashPayFetchStudent(false));
  };

  const handleInput = (event) => {
    const value = event.target.value;
    dispatch(setCashPayStudentId(value));
  };

  const handleSearch = () => {
    if (!student_id) return errorNotify("Please enter student id to search");
    dispatch(setCashPayShowStudent(true));
    dispatch(setCashPayFetchStudent(true));
  };

  return {
    handleReset,
    handleInput,
    handleSearch,
    student_id,
  };
};

export const useCashPay = () => {
  const [activeTab, setActiveTab] = useState(0);
  const {
    student_id,
    showStudent,
    fetchStudent,
    student,
    pendingPageData,
    paidPageData,
  } = useSelector((state) => state.adminCashPay);

  const { isFetching, isError, error } = useGetStudentInvoicesQuery(
    student_id,
    {
      skip: !showStudent || !fetchStudent,
      refetchOnMountOrArgChange: true,
    }
  );

  return {
    isFetching,
    isError,
    error,
    student,
    showStudent,
    activeTab,
    setActiveTab,
    pendingPageData,
    paidPageData,
  };
};

export const usePendingCashPay = () => {
  const dispatch = useDispatch();
  const ref = useRef(null);
  const [isPdfLoading, setPdfLoading] = useState(false);
  const {
    student_id,
    invoice_ids,
    pendingLists: dataLists,
    pendingPageData,
    selectedData,
    showModal,
  } = useSelector((state) => state.adminCashPay);
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const { currentPage, pageSize, totalPages } = pendingPageData || {};

  const [deleteBillingSearchInvoice, { isLoading: isDeleting }] =
    useDeleteBillingSearchInvoiceMutation();
  const [updateBillingSearchSummery, { isLoading }] =
    useUpdateBillingSearchSummeryMutation();
  const [addStudentCashPay, { isLoading: isPaying }] =
    useAddStudentCashPayMutation();

  const onPrint = useReactToPrint({
    contentRef: ref,
    documentTitle: "student-invoice",
    onBeforePrint: () => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setPdfLoading(false);
        }, 900);
      });
    },
  });

  const handleSelectData = (value) => {
    dispatch(setSelectedCashPay(value));
    if (value?.type == "print") {
      setTimeout(() => {
        setPdfLoading(true);
        onPrint();
      }, 100);
    }
  };

  const updateHandler = (data) => {
    dispatch(closeCashPayInvoiceModal());
    updateBillingSearchSummery({
      data,
      institute_id,
      invoice_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(updateCashPayInvoice(res?.data));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  const updatePage = (value) => {
    dispatch(setPendingCashPayPageData(value));
  };

  const closeModal = () => {
    dispatch(closeCashPayModal());
    dispatch(setSelectedCashPay({}));
  };

  const removeCashPay = () => {
    dispatch(closeCashPayModal());
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ institute_id: selectedData?.institute_id })
    );
    const query = `?institute_id=${institute_id}&invoice_id=${selectedData?._id}`;
    deleteBillingSearchInvoice(query)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeCashPayList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  const handleSelectAllCashPay = () => {
    dispatch(selectAllCashPay());
  };

  const handleToggleSelectInvoice = (id) => {
    dispatch(toggleSelectedCashPay(id));
  };
  const isAllSelected = invoice_ids?.length === dataLists?.length;

  const handleSubmit = () => {
    const data = {
      student_id: student_id,
      institute_id: institute_id,
      invoice_ids: [...(invoice_ids || [])],
    };
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    addStudentCashPay(formData)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(movePendingToPaidInvoices());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    isLoading: isDeleting || isLoading || isPaying,
    isPdfLoading,
    handleSelectData,
    updatePage,
    closeModal,
    removeCashPay,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    invoice_ids,
    handleSelectAllCashPay,
    handleToggleSelectInvoice,
    handleSubmit,
    isAllSelected,
    ref,
    updateHandler,
  };
};

export const useCashPayModal = (updateHandler) => {
  const dispatch = useDispatch();
  const { showInvoiceModal, selectedData } = useSelector(
    (state) => state.adminCashPay
  );

  const closeModal = () => {
    dispatch(closeCashPayInvoiceModal());
  };

  const handleAmountChange = (e, index) => {
    const value = Number(e.target.value) || 0;
    dispatch(updateSelectedCashPaySummery({ index: index, value }));
  };

  const handleRemoveSummery = (index) => {
    dispatch(removeSelectedCashPaySummery(index));
  };

  const handleUpdateSummery = () => {
    if (selectedData?.charges_summary.length === 0) {
      return errorNotify("Please add atleast one billing head");
    }
    const data = {
      charges_summary: selectedData?.charges_summary?.map((item) => ({
        amount: item?.amount,
        billing_head_id: item?.billing_head_id?._id,
      })),
      total_amount: selectedData?.total_amount,
    };
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    updateHandler(formData);
  };

  return {
    showModal: showInvoiceModal,
    closeModal,
    selectedData,
    handleAmountChange,
    handleRemoveSummery,
    handleUpdateSummery,
  };
};

export const useCashPayViewModal = () => {
  const dispatch = useDispatch();
  const { showViewInvoiceModal, selectedData } = useSelector(
    (state) => state.adminCashPay
  );

  const closeModal = () => {
    dispatch(closeCashPayViewInvoiceModal());
  };

  return {
    showModal: showViewInvoiceModal,
    closeModal,
    selectedData,
  };
};
