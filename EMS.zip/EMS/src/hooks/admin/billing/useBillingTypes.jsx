import {
  adminRoutes,
  billingTypeSchema,
  checkValidation,
  errorNotify,
  getClassCode,
  infoNotify,
} from "@/services";
import { useGetAllBillingHeadsQuery } from "@/store/modules/admin/billing/billingHead/api";
import {
  useAddBillingTypeMutation,
  useDeleteBillingTypeMutation,
  useFindBillingTypeQuery,
  useGetFilteredBillingTypesQuery,
  useUpdateBillingTypeMutation,
} from "@/store/modules/admin/billing/billingTypes/api";
import {
  closeBillingTypeModal,
  moveLeftRightHead,
  moveRightLeftHead,
  removeBillingTypeList,
  resetBillingTypeSearhQuerySelectors,
  resetBillingTypeSelectors,
  setAllLeftHeads,
  setAllRightHeads,
  setBillingTypeFetchData,
  setBillingTypeLeftSearch,
  setBillingTypeRightSearch,
  setBillingTypeSearhQuerySelectors,
  setBillingTypeSelectors,
  setBillingTypeShowTable,
  setBillingTypesPageData,
  setSelectedBillingType,
  toggleLeftHead,
  toggleRightHead,
} from "@/store/modules/admin/billing/billingTypes/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

export const useBillingTypesFiter = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { search_query } = useSelector((state) => state.adminBillingTypes);
  const [class_code, class_id] = getClassCode(search_query?.class_id);

  const handleSetSearchQuery = (value) =>
    dispatch(setBillingTypeSearhQuerySelectors(value));
  const handleResetSearchQuery = () =>
    dispatch(resetBillingTypeSearhQuerySelectors());

  const handleFilter = () => {
    if (
      !search_query?.category_id &&
      !search_query?.academic_year &&
      !search_query?.class_id &&
      ((class_code > 8 && !search_query?.group_id) || true)
    ) {
      return errorNotify("Please select at least one filter");
    }
    dispatch(setBillingTypeShowTable(true));
    dispatch(setBillingTypeFetchData(true));
  };

  return {
    dispatch,
    navigate,
    class_code,
    search_query,
    handleSetSearchQuery,
    handleResetSearchQuery,
    handleFilter,
  };
};

export const useBillingTypes = () => {
  const dispatch = useDispatch();
  const {
    dataLists,
    selectedData,
    pageData,
    showModal,
    search_query,
    fetchData,
  } = useSelector((state) => state.adminBillingTypes);

  const { currentPage, pageSize, totalPages } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const querySelectors = {
    category_id: search_query?.category_id,
    academic_year: search_query?.academic_year,
    local_class_id: getClassCode(search_query?.class_id)[1],
    group_id: search_query?.group_id ? search_query?.group_id : undefined,
    institute_id,
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetFilteredBillingTypesQuery(
    { query },
    // {
    //     page: currentPage,
    //     limit: pageSize,
    //     institute_id,
    // },
    {
      skip: !institute_id || !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const [deleteBillingType, { isLoading: isDeleting }] =
    useDeleteBillingTypeMutation();

  const handleSelect = (value) => dispatch(setSelectedBillingType(value));
  const updatePage = (value) => dispatch(setBillingTypesPageData(value));
  // const handleReset = () => dispatch(resetBillingTypeSelectors());

  const closeModal = () => {
    dispatch(closeBillingTypeModal());
    dispatch(setSelectedBillingType({}));
  };

  const removeBillingType = () => {
    dispatch(closeBillingTypeModal());
    deleteBillingType({ institute_id, billing_type_id: selectedData?._id })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeBillingTypeList({ _id: selectedData?._id }));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    status: error?.status,
    isLoading: isDeleting,
    dataLists,
    isFetching,
    isError,
    handleSelect,
    updatePage,
    closeModal,
    removeBillingType,
    // handleReset,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    selectedData,
  };
};

export const useAddNewBillingType = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    selectors,
    left_heads,
    right_heads,
    selected_left_heads,
    selected_right_heads,
    left_search,
    right_search,
  } = useSelector((state) => state.adminBillingTypes);
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const [addBillingType, { isLoading: isAdding }] = useAddBillingTypeMutation();
  const { isFetching, isError, error } = useGetAllBillingHeadsQuery(
    { institute_id },
    {
      skip: !institute_id,
      refetchOnMountOrArgChange: true,
    }
  );
  const [class_code, class_id] = getClassCode(selectors?.local_class_id);

  const [errors, setErrors] = useState({});

  const handleReset = () => dispatch(resetBillingTypeSelectors());
  const handleSelector = (value) => dispatch(setBillingTypeSelectors(value));

  const selectAllLeftHeads = () => dispatch(setAllLeftHeads());
  const handleToggleLeftHead = (head) => dispatch(toggleLeftHead(head));
  const selectAllRightHeads = () => dispatch(setAllRightHeads());
  const handleToggleRightHead = (head) => dispatch(toggleRightHead(head));
  const handleMoveRightToLeft = () => dispatch(moveRightLeftHead());
  const handleMoveLeftToRight = () => dispatch(moveLeftRightHead());

  const setLeftSearch = (event) => {
    const value = event.target.value;
    dispatch(setBillingTypeLeftSearch(value?.trim()));
  };

  const setRightSearch = (event) => {
    const value = event.target.value;
    dispatch(setBillingTypeRightSearch(value?.trim()));
  };

  // Add new billing type handler
  const addBillingTypeHandler = (e) => {
    e.preventDefault();
    const finalData = {
      ...selectors,
      institute_id,
      local_class_id: class_id,
      assigned_heads: right_heads.map((item) => ({
        billing_head_id: item._id, // Convert to expected object format
      })),
      group_id: selectors?.group_id ? selectors?.group_id : undefined,
    };

    const result = billingTypeSchema.safeParse(finalData);
    const { isError, error } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    }

    setErrors({});
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(finalData));

    addBillingType(submitData)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        handleReset();
        dispatch(resetBillingTypeSearhQuerySelectors());
        navigate(adminRoutes.billing.billingTypes.path);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    addBillingTypeHandler,
    handleReset,
    handleSelector,
    isFetching,
    isError,
    selectors,
    errors,
    class_code,
    isAdding,

    left_heads,
    right_heads,
    selected_left_heads,
    selected_right_heads,
    left_search,
    right_search,
    setLeftSearch,
    setRightSearch,
    selectAllLeftHeads,
    handleToggleLeftHead,
    selectAllRightHeads,
    handleToggleRightHead,
    handleMoveRightToLeft,
    handleMoveLeftToRight,
  };
};

export const useUpdateBillingType = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { billingTypeId } = useParams();
  const {
    selectors,
    left_heads,
    right_heads,
    selected_left_heads,
    selected_right_heads,
    left_search,
    right_search,
  } = useSelector((state) => state.adminBillingTypes);
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const [updateBillingType, { isLoading: isUpdating }] =
    useUpdateBillingTypeMutation();
  const {
    isFetching: isFetchingHeads,
    isError: isErrorHeads,
    error: errorHeads,
  } = useGetAllBillingHeadsQuery(
    { institute_id },
    {
      skip: !institute_id,
      refetchOnMountOrArgChange: true,
    }
  );
  const { isFetching, isError, error } = useFindBillingTypeQuery(
    { institute_id, billing_type_id: billingTypeId },
    {
      skip: !institute_id || !billingTypeId || isFetchingHeads,
      refetchOnMountOrArgChange: true,
    }
  );
  const [class_code, class_id] = getClassCode(selectors?.local_class_id || "");

  const [errors, setErrors] = useState({});

  const handleReset = () => dispatch(resetBillingTypeSelectors());
  const handleSelector = (value) => dispatch(setBillingTypeSelectors(value));

  const selectAllLeftHeads = () => dispatch(setAllLeftHeads());
  const handleToggleLeftHead = (head) => dispatch(toggleLeftHead(head));
  const selectAllRightHeads = () => dispatch(setAllRightHeads());
  const handleToggleRightHead = (head) => dispatch(toggleRightHead(head));
  const handleMoveRightToLeft = () => dispatch(moveRightLeftHead());
  const handleMoveLeftToRight = () => dispatch(moveLeftRightHead());

  const setLeftSearch = (event) => {
    const value = event.target.value;
    dispatch(setBillingTypeLeftSearch(value?.trim()));
  };

  const setRightSearch = (event) => {
    const value = event.target.value;
    dispatch(setBillingTypeRightSearch(value?.trim()));
  };

  const updateBillingTypeHandler = (e) => {
    e.preventDefault();
    const finalData = {
      ...selectors,
      institute_id,
      local_class_id: class_id,
      assigned_heads: right_heads.map((item) => ({
        billing_head_id: item._id, // Convert to expected object format
      })),
      group_id: selectors?.group_id ? selectors?.group_id : undefined,
    };

    const result = billingTypeSchema.safeParse(finalData);
    const { isError, error } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    }

    setErrors({});
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(finalData));

    updateBillingType({
      data: submitData,
      institute_id,
      billing_type_id: billingTypeId,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        handleReset();
        dispatch(resetBillingTypeSearhQuerySelectors());
        navigate(adminRoutes.billing.billingTypes.path);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    selectors,
    left_heads,
    right_heads,
    selected_left_heads,
    selected_right_heads,
    left_search,
    right_search,
    selectAllLeftHeads,
    handleToggleLeftHead,
    selectAllRightHeads,
    handleToggleRightHead,
    handleMoveRightToLeft,
    handleMoveLeftToRight,
    setLeftSearch,
    setRightSearch,

    isUpdating,
    isFetching: isFetchingHeads || isFetching,
    isError: isErrorHeads || isError,
    errors,
    class_code,

    handleSelector,
    // handleReset,
    updateBillingTypeHandler,
  };
};
