import {
  errorNotify,
  getClassCode,
  getMonthYearCode,
  infoNotify,
} from "@/services";
import { closeMoneyDepositInvoiceModal } from "@/store/modules/admin/accounts/overview/moneyDepositSlice";
import {
  useDeleteBillingSearchInvoiceMutation,
  useGetBillingSearchStudentsQuery,
  useUpdateBillingSearchSummeryMutation,
} from "@/store/modules/admin/billing/invoices/api";
import {
  closeBillingInvoiceModal,
  closeBillingSearchModal,
  closeBillingViewInvoiceModal,
  removeBillingSearchList,
  removeSelectedBillingSummery,
  resetBillingSearchSelectors,
  selectAllBillingSearch,
  setBillingSearchFetchData,
  setBillingSearchPageData,
  setBillingSearchSearchValue,
  setBillingSearchSelectors,
  setBillingSearchShowTable,
  setSelectedBillingSearch,
  toggleSelectedBillingSearch,
  updateBillingSearchInvoice,
  updateSelectedBillingSearchSummery,
} from "@/store/modules/admin/billing/invoices/searchBillingSlice";
import { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useReactToPrint } from "react-to-print";

export const useBillingSearchFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminSearchBilling);
  const [class_code, _] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code);

  const handleUpdateSelectors = (values) => {
    dispatch(setBillingSearchSelectors(values));
  };

  const handleReset = () => {
    dispatch(resetBillingSearchSelectors());
  };

  const handleFilter = () => {
    if (
      !selectors?.academic_year &&
      !selectors?.current_group &&
      !selectors?.current_section &&
      !selectors?.current_category &&
      !selectors?.current_class &&
      !selectors?.month &&
      !selectors?.status
    ) {
      return errorNotify("Please select at least one filter");
    }
    dispatch(setBillingSearchShowTable(true));
    dispatch(setBillingSearchFetchData(true));
  };
  return {
    selectors,
    classCode,
    handleUpdateSelectors,
    handleReset,
    handleFilter,
  };
};

export const useBillingSearch = () => {
  const ref = useRef(null);
  const dispatch = useDispatch();
  const {
    dataLists,
    selectedData,
    pageData,
    showModal,
    student_ids,
    searchValue,
    fetchData,
    selectors,
  } = useSelector((state) => state.adminSearchBilling);

  const { currentPage, pageSize, totalPages, totalItems } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [isPdfLoading, setPdfLoading] = useState(false);
  const [updateBillingSearchSummery, { isLoading }] =
    useUpdateBillingSearchSummeryMutation();

  const querySelectors = {
    category_id: selectors?.current_category,
    local_class_id: getClassCode(selectors?.current_class)[1],
    section_id: selectors?.current_section,
    academic_year: selectors?.academic_year,
    group_id: selectors?.current_group,
    institute_id,
    status: selectors?.status,
    billing_month: getMonthYearCode(selectors?.month),
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetBillingSearchStudentsQuery(
    { query },
    {
      skip: !institute_id || !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const [deleteBillingSearchInvoice, { isLoading: isDeleting }] =
    useDeleteBillingSearchInvoiceMutation();

  const handleSelectData = (value) => {
    dispatch(setSelectedBillingSearch(value));
    if (value?.type == "print") {
      setTimeout(() => {
        setPdfLoading(true);
        onPrint();
      }, 100);
    }
  };

  const onPrint = useReactToPrint({
    contentRef: ref,
    documentTitle: "student-invoice",
    onBeforePrint: () => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setPdfLoading(false);
        }, 900);
      });
    },
  });

  const handleSelectAllBillingSearch = () => {
    dispatch(selectAllBillingSearch());
  };

  const handleToggleSelectStudent = (id) => {
    dispatch(toggleSelectedBillingSearch(id));
  };

  const updatePage = (value) => {
    dispatch(setBillingSearchPageData(value));
  };

  const handleSearchValue = (event) => {
    dispatch(setBillingSearchSearchValue(event.target.value));
  };

  const closeModal = () => {
    dispatch(closeBillingSearchModal());
    dispatch(setSelectedBillingSearch({}));
  };

  const removeBillingSearchAdmission = () => {
    dispatch(closeBillingSearchModal());
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ institute_id: selectedData?.institute_id })
    );
    const query = `?institute_id=${institute_id}&invoice_id=${selectedData?._id}`;
    deleteBillingSearchInvoice(query)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeBillingSearchList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  const updateHandler = (data) => {
    dispatch(closeBillingInvoiceModal());
    updateBillingSearchSummery({
      data,
      institute_id,
      invoice_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(updateBillingSearchInvoice(res?.data));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isDeleting || isLoading,
    handleSelectData,
    updatePage,
    closeModal,
    removeBillingSearchAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    student_ids,
    handleSelectAllBillingSearch,
    handleToggleSelectStudent,
    handleSearchValue,
    searchValue,
    isAllSelected: student_ids?.length === dataLists?.length,
    dataLength: totalItems,
    ref,
    onPrint,
    isPdfLoading,
    updateHandler,
  };
};

export const useBillingSearchModal = (updateHandler) => {
  const dispatch = useDispatch();
  const { showInvoiceModal, selectedData } = useSelector(
    (state) => state.adminSearchBilling
  );

  const closeModal = () => {
    dispatch(closeBillingInvoiceModal());
  };

  const handleAmountChange = (e, index) => {
    const value = Number(e.target.value) || 0;
    dispatch(updateSelectedBillingSearchSummery({ index: index, value }));
  };

  const handleRemoveSummery = (index) => {
    dispatch(removeSelectedBillingSummery(index));
  };

  const handleUpdateSummery = () => {
    if (selectedData?.charges_summary.length === 0) {
      return errorNotify("Please add atleast one billing head");
    }
    const data = {
      charges_summary: selectedData?.charges_summary?.map((item) => ({
        amount: item?.amount,
        billing_head_id: item?.billing_head_id?._id,
      })),
      total_amount: selectedData?.total_amount,
    };
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    updateHandler(formData);
  };

  return {
    showModal: showInvoiceModal,
    closeModal,
    selectedData,
    handleAmountChange,
    handleRemoveSummery,
    handleUpdateSummery,
  };
};

export const useBillingSearchViewModal = () => {
  const dispatch = useDispatch();
  const { showViewInvoiceModal, selectedData } = useSelector(
    (state) => state.adminSearchBilling
  );

  const closeModal = () => {
    dispatch(closeBillingViewInvoiceModal());
  };

  return {
    showModal: showViewInvoiceModal,
    closeModal,
    selectedData,
  };
};
