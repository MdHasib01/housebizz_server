import { errorNotify, infoNotify } from "@/services";
import {
  useDeleteBillingConfigMutation,
  useFindBillingConfigQuery,
  useGetBillingConfigQuery,
  useUpdateBillingConfigMutation,
} from "@/store/modules/admin/billing/billingConfig/api";
import {
  removeBillingConfig,
  searchBillingConfigData,
  setPageBillingTypesAndConfigs,
  setSelectedBillingConfig,
  setSelectedBillingYear,
  toggleBillingConfigDeleteModal,
  updateBillingField,
} from "@/store/modules/admin/billing/billingConfig/slice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

export const useBillingTypesAndConfigs = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const {
    selectedBillingYear,
    showModal,
    pageData,
    selectedData,
    dataLists,
    fetchData,
  } = useSelector((state) => state.adminBillingConfig);
  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;

  const { isFetching, error, isError } = useGetBillingConfigQuery(
    {
      institute_id: institute_id,
      academic_year: selectedBillingYear,
    },
    {
      skip: !auth?.instituteAdmin?.institute_id || !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const [deleteBillingConfig, { isLoading: isDeletingBillingConfig }] =
    useDeleteBillingConfigMutation();

  const handleSelect = (value) => {
    dispatch(setSelectedBillingConfig(value));
  };

  const updatePage = (value) => {
    dispatch(setPageBillingTypesAndConfigs(value));
  };

  const handleYearSelection = (year) => {
    dispatch(setSelectedBillingYear(year));
  };

  const handleSearch = () => {
    if (!selectedBillingYear)
      return errorNotify("Please select a year to search");
    dispatch(searchBillingConfigData(true));
  };

  const handleModalToggle = () => {
    dispatch(toggleBillingConfigDeleteModal());
  };

  const handleDeleteBillingConfig = () => {
    handleModalToggle();
    deleteBillingConfig({
      institute_id: auth?.instituteAdmin?.institute_id,
      billing_type_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        if (res?.success) {
          dispatch(removeBillingConfig());
          infoNotify(res?.message || "Deleted Successfully");
        }
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    isFetching,
    isLoading: isDeletingBillingConfig,
    status: error?.status,
    isError,
    currentPage,
    pageSize,
    totalPages,
    dispatch,
    navigate,
    updatePage,
    handleModalToggle,
    handleYearSelection,
    handleDeleteBillingConfig,
    showModal,
    selectedBillingYear,
    handleSearch,
    selectedData,
    handleSelect,
    currentBillingTypes: dataLists,
  };
};

export const useBillingConfigUpdate = () => {
  const { auth } = useSelector((state) => state.auth);
  const { renderableBillingList, allBillingTypes } = useSelector(
    (state) => state.adminBillingConfig
  );

  const dispatch = useDispatch();
  const { id } = useParams();
  const navigate = useNavigate();
  const navigateBack = () => navigate(-1);

  const { isFetching, status, isError } = useFindBillingConfigQuery(
    {
      billing_type_id: id,
      institute_id: auth?.instituteAdmin?.institute_id,
    },
    {
      skip: !auth?.instituteAdmin?.institute_id || !id,
      refetchOnMountOrArgChange: true,
    }
  );
  const [updateBillingConfig, { isLoading: isUpdatingBillingConfig }] =
    useUpdateBillingConfigMutation();

  const activeConfigDetails = allBillingTypes?.find((item) => item._id === id);

  const calculateTotals = (data) => {
    if (!data || !data.length) return {};
    const totals = {};
    const monthList = Object.keys(data[0]?.monthly_fees || {});
    monthList.forEach((month) => {
      totals[month] = data.reduce((sum, row) => {
        const value = row.monthly_fees[month]
          ? Number(row.monthly_fees[month])
          : 0;
        return sum + value;
      }, 0);
    });
    return totals;
  };

  const getCompleteData = () => {
    const totals = calculateTotals(renderableBillingList);
    return [
      ...renderableBillingList,
      { headName: "Total Amount", monthly_fees: totals },
    ];
  };

  const inputChangeHandler = (e, month, index) => {
    const value = e.target.value;
    dispatch(
      updateBillingField({
        index,
        month: month.charAt(0).toUpperCase() + month.slice(1),
        value: Number(value) || 0,
      })
    );
  };

  const completeData = getCompleteData();

  const updateBillingTypeHandler = () => {
    const updateData = {
      billing_type: completeData[0]?.billing_type,
      academic_year: completeData[0]?.academic_year,
      local_class_id: completeData[0]?.local_class_id,
      category_id: completeData[0]?.category_id,
      assigned_heads: completeData
        ?.filter((item) => item?.headName !== "Total Amount")
        .map((item) => ({
          billing_head_id: item?.id,
          monthly_fees: item?.monthly_fees,
        })),
    };
    updateBillingConfig({
      institute_id: auth?.instituteAdmin?.institute_id,
      billing_type_id: id,
      data: updateData,
    })
      .unwrap()
      .then((res) => {
        if (res?.success) {
          infoNotify(res?.message);
          navigateBack();
        }
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    isFetching,
    status,
    isError,
    activeConfigDetails,
    completeData,
    inputChangeHandler,
    updateBillingTypeHandler,
    isUpdatingBillingConfig,
    navigateBack,
  };
};
