import {
  adminRoutes,
  biliingHeadSchema,
  checkValidation,
  errorNotify,
  infoNotify,
  validateBillingHeadManagement,
} from "@/services";
import {
  useAddBillingHeadMutation,
  useDeleteBillingHeadMutation,
  useGetBillingHeadsQuery,
  useUpdateBillingHeadMutation,
} from "@/store/modules/admin/billing/billingHead/api";
import {
  addBillingHeadList,
  closeBillingHeadModal,
  removeBillingHeadList,
  setBillingHeadPageData,
  setSelectedBillingHead,
  updateBillingHeadList,
  updateSelectedBillingHead,
} from "@/store/modules/admin/billing/billingHead/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useBillingHead = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.adminBillingHead
  );
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const { currentPage, pageSize, totalPages } = pageData || {};
  const { isFetching, isError, error } = useGetBillingHeadsQuery(
    {
      page: currentPage,
      limit: pageSize,
      institute_id,
    },
    {
      skip: !institute_id,
    }
  );

  const [updateBillingHead, { isLoading: isUpdating }] =
    useUpdateBillingHeadMutation();
  const [deleteBillingHead, { isLoading: isDeleting }] =
    useDeleteBillingHeadMutation();

  const handleInput = (event) => {
    dispatch(updateSelectedBillingHead(event.target));
  };

  const onStatusChange = (value) => {
    dispatch(updateSelectedBillingHead({ name: "status", value }));
  };

  const handleSelect = (value) => {
    dispatch(setSelectedBillingHead(value));
  };

  const updatePage = (value) => {
    dispatch(setBillingHeadPageData(value));
  };

  const closeModal = () => {
    dispatch(closeBillingHeadModal());
    dispatch(setSelectedBillingHead({}));
  };

  const isUpdatable = (item) => {
    return (
      selectedData?._id &&
      selectedData?._id === item?._id &&
      selectedData?.type === "update"
    );
  };

  const updateSelectedData = () => {
    const error = validateBillingHeadManagement(selectedData);
    if (error) {
      return errorNotify(error);
    } else {
      const data = {
        ...selectedData,
        head_id: Number(selectedData?.head_id),
      };
      const submitData = new FormData();
      submitData.append("data", JSON.stringify(data));
      updateBillingHead({
        data: submitData,
        institute_id: institute_id,
        billing_head_id: data?._id,
      })
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(updateBillingHeadList(res?.data));
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  const removeBillingHead = () => {
    dispatch(closeBillingHeadModal());
    deleteBillingHead({
      institute_id: institute_id,
      billing_head_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeBillingHeadList("delete"));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    pageData,
    showModal,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isUpdating || isDeleting,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeBillingHead,
    currentPage,
    pageSize,
    totalPages,
    onStatusChange,
  };
};

export const useAddBillingHead = () => {
  const navigate = useNavigate();
  const [addBillingHead, { isLoading }] = useAddBillingHeadMutation();
  const dispatch = useDispatch();
  const [errors, setErrors] = useState({});
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const navigateToBillingHeadManagement = () => {
    navigate(adminRoutes.billing.billingHead.path);
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());

    const data = {
      ...entries,
      head_id: Number(entries?.head_id),
    };

    const result = biliingHeadSchema.safeParse(data);
    const { isError, error } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    }
    setErrors({});
    const submitData = new FormData();
    submitData.append(
      "data",
      JSON.stringify({
        ...data,
        institute_id,
      })
    );
    addBillingHead(submitData)
      .unwrap()
      .then((res) => {
        form.reset();
        dispatch(addBillingHeadList(res?.data));
        navigateToBillingHeadManagement();
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error.data.message);
      });
  };
  return {
    onSubmit,
    isLoading,
    navigateToBillingHeadManagement,
    errors,
  };
};
