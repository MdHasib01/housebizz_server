import {
  errorNotify,
  getClassCode,
  getMonthDays,
  isUnixDateMatch,
} from "@/services";
import {
  useGetClassAttendanceQuery,
  useGetClassAttendanceStudentsQuery,
} from "@/store/modules/admin/attendance/classAttendance/api";
import {
  resetClassAttendanceSelectors,
  setClassAttendanceFetchData,
  setClassAttendancePageData,
  setClassAttendanceSelectors,
  setClassAttendanceShowTable,
  setStudentDayAttendance,
} from "@/store/modules/admin/attendance/classAttendance/slice";
import { useDispatch, useSelector } from "react-redux";

export const useClassAttendanceFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminClassAttendance);
  const [class_code, _] = getClassCode(selectors?.local_class_id);
  const classCode = Number(class_code);
  const handleSelector = (values) => {
    dispatch(setClassAttendanceSelectors(values));
  };
  const handleReset = () => {
    dispatch(resetClassAttendanceSelectors());
  };

  const handleShowTable = () => {
    if (
      !selectors?.academic_year ||
      !selectors?.local_class_id ||
      !selectors?.section_id ||
      !selectors?.month
    ) {
      return errorNotify("Please select all filters");
    }

    dispatch(setClassAttendanceShowTable(true));
    dispatch(setClassAttendanceFetchData(true));
  };

  return {
    classCode,
    selectors,
    handleSelector,
    handleReset,
    handleShowTable,
  };
};

export const useClassAttendanceLists = () => {
  const dispatch = useDispatch();
  const {
    dataLists,
    pageData,
    fetchData,
    selectors,
    attendance,
    studentDayAttendance,
  } = useSelector((state) => state.adminClassAttendance);
  const [_, local_class_id] = getClassCode(selectors?.local_class_id);
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const querySelectors = {
    ...selectors,
    local_class_id,
    institute_id,
    status: "active",
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const attendanceResponse = useGetClassAttendanceQuery(query, {
    skip: !institute_id || !fetchData,
    refetchOnMountOrArgChange: true,
  });

  const studentResponse = useGetClassAttendanceStudentsQuery(query, {
    skip: !institute_id || !fetchData,
    refetchOnMountOrArgChange: true,
  });

  const updatePage = (value) => {
    dispatch(setClassAttendancePageData(value));
  };

  const days = getMonthDays({
    monthName: selectors?.month,
    sessionYear: selectors?.academic_year,
  });

  const getSingleDayAttendance = (student, day) => {
    const dayStudents = attendance.filter(
      (item) =>
        item?.student_id?._id === student?._id &&
        isUnixDateMatch({ unix: item?.attendance_date, date: day?.date })
    );
    const totalPresent = dayStudents.filter(
      (item) => item?.attendance_status === "present"
    )?.length;
    const totalAbsent = dayStudents.filter(
      (item) => item?.attendance_status === "absent"
    )?.length;
    const totalLeave = dayStudents.filter(
      (item) => item?.attendance_status === "leave"
    )?.length;

    dispatch(
      setStudentDayAttendance({
        totalPresent,
        totalAbsent,
        totalLeave,
        attendance: dayStudents,
      })
    );
  };

  return {
    attendance,
    dataLists,
    isFetching: attendanceResponse.isFetching || studentResponse.isLoading,
    isError: attendanceResponse.isError || studentResponse.isError,
    status:
      attendanceResponse.status === 404 || studentResponse.status === 404
        ? 404
        : 400,
    currentPage,
    pageSize,
    totalPages,
    updatePage,
    days,
    getSingleDayAttendance,
    studentDayAttendance,
  };
};
