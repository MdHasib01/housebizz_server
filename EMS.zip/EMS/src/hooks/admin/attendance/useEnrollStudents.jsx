import { errorNotify, getClassCode, infoNotify } from "@/services";
import {
  useDeleteEnrollStudentMutation,
  useGetEnrollFilteredStudentsQuery,
} from "@/store/modules/admin/attendance/subjectEnroll/enrollStudentApi";
import {
  closeEnrollStudentsModal,
  removeEnrollStudentList,
  resetEnrollStudentsSelectors,
  setEnrollStudentsFetchData,
  setEnrollStudentsPageData,
  setEnrollStudentsSelectors,
  setEnrollStudentsShowTable,
  setSelectedEnrollStudents,
} from "@/store/modules/admin/attendance/subjectEnroll/studentsSlice";
import { useDispatch, useSelector } from "react-redux";

export const useEnrollStudentsFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminEnrollStudents);
  const [class_code, _] = getClassCode(selectors?.local_class_id);
  const classCode = Number(class_code);
  const handleSelector = (values) => {
    dispatch(setEnrollStudentsSelectors(values));
  };
  const handleReset = () => {
    dispatch(resetEnrollStudentsSelectors());
  };

  const handleShowTable = () => {
    if (
      !selectors?.academic_year &&
      !selectors?.local_class_id &&
      !selectors?.section_id
    ) {
      return errorNotify("Please select at least one filter");
    }

    dispatch(setEnrollStudentsShowTable(true));
    dispatch(setEnrollStudentsFetchData(true));
  };

  return {
    classCode,
    selectors,
    handleSelector,
    handleReset,
    handleShowTable,
  };
};

export const useEnrollStudentLists = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal, fetchData, selectors } =
    useSelector((state) => state.adminEnrollStudents);
  const [_, local_class_id] = getClassCode(selectors?.local_class_id);
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const querySelectors = {
    ...selectors,
    class_id: local_class_id,
    institute_id,
    status: "active",
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetEnrollFilteredStudentsQuery(
    { query },
    {
      skip: !institute_id || !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const [deleteEnrollStudent, { isLoading }] = useDeleteEnrollStudentMutation();

  const handleSelect = (value) => {
    dispatch(setSelectedEnrollStudents(value));
  };

  const updatePage = (value) => {
    dispatch(setEnrollStudentsPageData(value));
  };

  const closeModal = () => {
    dispatch(closeEnrollStudentsModal());
    dispatch(setSelectedEnrollStudents({}));
  };

  const removeStudentAdmission = () => {
    dispatch(closeEnrollStudentsModal());
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ institute_id: selectedData?.institute_id })
    );
    const query = `?institute_id=${institute_id}&student_id=${selectedData?._id}`;
    deleteEnrollStudent({ query })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeEnrollStudentList(selectedData?._id));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status: error?.status,
    isLoading,
    handleSelect,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
  };
};
