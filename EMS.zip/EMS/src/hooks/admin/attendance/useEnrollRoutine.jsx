import { adminRoutes, errorNotify, getClassCode, infoNotify } from "@/services";
import {
  useAddSubjectEnrollMutation,
  useGetEnrolledStudentsQuery,
  useGetEnrollFilteredRoutineQuery,
  useGetEnrollRoutineStudentsQuery,
} from "@/store/modules/admin/attendance/subjectEnroll/enrollRoutineApi";
import {
  moveLeftRightStudent,
  moveRightLeftStudent,
  resetAllRoutineState,
  resetEnrollRoutineSelectors,
  setAllLeftStudents,
  setAllRightStudents,
  setEnrollRoutineFetchData,
  setEnrollRoutineLeftSearch,
  setEnrollRoutinePageData,
  setEnrollRoutineRightSearch,
  setEnrollRoutineSelectors,
  setEnrollRoutineShowTable,
  setSelectedEnrollRoutine,
  toggleLeftStudent,
  toggleRightStudent,
} from "@/store/modules/admin/attendance/subjectEnroll/routineSlice";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";

export const useEnrollRoutineFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminEnrollRoutine);
  const [class_code, _] = getClassCode(selectors?.local_class_id);
  const classCode = Number(class_code);
  const handleSelector = (values) => {
    dispatch(setEnrollRoutineSelectors(values));
  };
  const handleReset = () => {
    dispatch(resetEnrollRoutineSelectors());
  };

  const handleShowTable = () => {
    if (
      !selectors?.academic_year &&
      !selectors?.local_class_id &&
      !selectors?.section_id
    ) {
      return errorNotify("Please select at least one filter");
    }

    dispatch(setEnrollRoutineShowTable(true));
    dispatch(setEnrollRoutineFetchData(true));
  };

  return {
    classCode,
    selectors,
    handleSelector,
    handleReset,
    handleShowTable,
  };
};

export const useEnrollRoutineLists = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { dataLists, pageData, fetchData, selectors,selectedData } = useSelector(
    (state) => state.adminEnrollRoutine
  );

  const { currentPage, pageSize, totalPages } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [_, local_class_id] = getClassCode(selectors?.local_class_id);

  const querySelectors = {
    ...selectors,
    local_class_id,
    institute_id,
    status: "active",
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetEnrollFilteredRoutineQuery(
    { query },
    {
      skip: !institute_id || !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const handleSelectData = (item) => {
    navigate(adminRoutes.attendance.enrollDetails.path, {
      state: { ...item, subjects: [], selectors: selectors },
    });
  };

  const handleSelect = (item) => {
    dispatch(setSelectedEnrollRoutine(item));
  };

  const updatePage = (value) => {
    dispatch(setEnrollRoutinePageData(value));
  };

  return {
    dataLists,
    isFetching,
    isError,
    status: error?.status,
    handleSelectData,
    handleSelect,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    selectedData
  };
};

export const useAddEnrollSubject = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const {
    left_students,
    right_students,
    selected_left_students,
    selected_right_students,
    left_search,
    right_search,
  } = useSelector((state) => state.adminEnrollRoutine);
  const { state } = useLocation();
  const [addSubjectEnroll, { isLoading }] = useAddSubjectEnrollMutation();

  const selectors = {
    ...state?.selectors,
    section_id: state?.section_id?._id,
    class_id: state?.local_class_id?._id,
    academic_year: state?.selectors?.academic_year,
    status: "active",
    institute_id: state?.institute_id,
    group_id: state?.selectors?.group_id,
    local_class_id: state?.local_class_id?._id,
    teacher_id: state.teacher_id?._id,
    subject_id: state.subject_id?._id,
  };

  let query = Object.keys(selectors).reduce((acc, key) => {
    if (selectors[key]) {
      return `${acc}${key}=${selectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching: isEnrollLoading } = useGetEnrolledStudentsQuery(
    { query },
    {
      refetchOnMountOrArgChange: true,
    }
  );

  const { isFetching, isError } = useGetEnrollRoutineStudentsQuery(
    { query },
    {
      skip: isEnrollLoading,
      refetchOnMountOrArgChange: true,
    }
  );

  const selectAllLeftStudents = () => {
    dispatch(setAllLeftStudents());
  };

  const handleToggleLeftStudent = (student) => {
    dispatch(toggleLeftStudent(student));
  };

  const selectAllRightStudents = () => {
    dispatch(setAllRightStudents());
  };

  const handleToggleRightStudent = (student) => {
    dispatch(toggleRightStudent(student));
  };

  const handleMoveRightToLeft = () => {
    dispatch(moveRightLeftStudent());
  };
  const handleMoveLeftToRight = () => {
    dispatch(moveLeftRightStudent());
  };

  const setLeftSearch = (event) => {
    const value = event.target.value;
    dispatch(setEnrollRoutineLeftSearch(value?.trim()));
  };

  const setRightSearch = (event) => {
    const value = event.target.value;
    dispatch(setEnrollRoutineRightSearch(value?.trim()));
  };

  const handleSubmit = () => {
    const students = right_students?.map((student) => student?._id);

    if (right_students.length === 0 && left_students?.length === 0)
      return errorNotify("Please select students to enroll");

    let data = {
      institute_id: state.institute_id,
      academic_year: state?.selectors?.academic_year,
      local_class_id: state?.local_class_id?._id,
      section_id: state.section_id?._id,
      subject_id: state?.subject_id?._id,
      teacher_id: state?.teacher_id?._id,
      students: [...students],
    };

    if (state?.selectors?.group_id) {
      data.group_id = state?.selectors?.group_id;
    }

    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    addSubjectEnroll(formData)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(resetAllRoutineState());
        navigate(adminRoutes.attendance.subjectEnroll.path);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    state,
    left_students,
    right_students,
    selected_left_students,
    selected_right_students,
    left_search,
    right_search,
    isFetching: isFetching || isEnrollLoading,
    isError,
    isLoading,
    selectAllLeftStudents,
    handleToggleLeftStudent,
    selectAllRightStudents,
    handleToggleRightStudent,
    handleMoveRightToLeft,
    handleMoveLeftToRight,
    setLeftSearch,
    setRightSearch,
    handleSubmit,
  };
};
