import {
  adminRoutes,
  checkClassScheduleFilter,
  checkValidation,
  errorNotify,
  getClassCode,
  infoNotify,
  scheduleSchema,
} from "@/services";
import {
  useAddClassRoutineMutation,
  useDeleteClassRoutineMutation,
  useGetClassRoutineQuery,
  useGetClassSchedulesQuery,
  useUpdateClassRoutineMutation,
} from "@/store/modules/admin/attendance/classSchedule/api";
import {
  addClassRoutineList,
  addClassScheduleSubjects,
  removeClassRoutineList,
  removeClassScheduleSubject,
  resetAddClassScheduleSelectors,
  resetClassScheduleSelectors,
  setClassScheduleFetchData,
  setClassScheduleSelectors,
  setClassScheduleSelectorsSubjects,
  setClassScheduleShowTable,
  updateClassRoutineList,
} from "@/store/modules/admin/attendance/classSchedule/slice";
import { useGetAllDaysQuery } from "@/store/modules/admin/institute/day/api";
import { useGetAllPeriodsQuery } from "@/store/modules/admin/institute/period/api";
import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useReactToPrint } from "react-to-print";

export const useClassScheduleFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminClassSchedule);
  const [class_code, _] = getClassCode(selectors?.local_class_id);
  const classCode = Number(class_code);
  const handleSelector = (values) => {
    dispatch(setClassScheduleSelectors(values));
  };
  const handleReset = () => {
    dispatch(resetClassScheduleSelectors());
  };

  const handleShowTable = () => {
    const error = checkClassScheduleFilter(selectors);
    if (error) {
      return errorNotify(error);
    }
    dispatch(setClassScheduleShowTable(true));
    dispatch(setClassScheduleFetchData(true));
  };

  return {
    classCode,
    selectors,
    handleSelector,
    handleReset,
    handleShowTable,
  };
};

export const useClassSchedule = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { selectors, dataLists, fetchData } = useSelector(
    (state) => state.adminClassSchedule
  );
  const { auth } = useSelector((state) => state.auth);
  const { allData: days } = useSelector((state) => state.adminDays);
  const { allData: periods } = useSelector((state) => state.adminPeriod);
  const [_, class_id] = getClassCode(selectors?.local_class_id);
  const pdfRef = useRef();
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [isPdfLoading, setPdfLoading] = useState(false);

  const querySelectors = {
    academic_year: selectors?.academic_year,
    institute_id,
    subject_id: selectors?.subject_id || "",
    section_id: selectors?.section_id || "",
    local_class_id: class_id,
    group_id: selectors?.group_id || "",
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "?");

  const { isFetching, isError, error } = useGetClassSchedulesQuery(
    { query },
    {
      skip: !fetchData || !institute_id,
      refetchOnMountOrArgChange: true,
    }
  );
  const periodResponse = useGetAllPeriodsQuery(
    { institute_id: institute_id },
    { skip: !institute_id }
  );
  const dayResponse = useGetAllDaysQuery(
    { institute_id: institute_id },
    { skip: !institute_id }
  );

  const onPrint = useReactToPrint({
    contentRef: pdfRef,
    documentTitle: "class-schedule",
    onBeforePrint: () => {
      setPdfLoading(true);
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setPdfLoading(false);
        }, 1000);
      });
    },
  });

  const [deleteClassRoutine, { isLoading }] = useDeleteClassRoutineMutation();

  const handleNavigate = () => {
    navigate(adminRoutes.attendance.addRoutine.path, {
      state: {
        academic_year: selectors?.academic_year,
        section_id: selectors?.section_id,
        local_class_id: selectors?.local_class_id,
        group_id: selectors?.group_id,
      },
    });
  };

  const handleRemoveRoutine = (id) => {
    const query = `institute_id=${institute_id}&routine_id=${id}`;
    deleteClassRoutine(query)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeClassRoutineList(id));
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    isFetching,
    isError,
    isLoading,
    dataLists,
    status: error?.status,
    handleNavigate,
    handleRemoveRoutine,
    days,
    periods,
    isTableLoading: periodResponse.isFetching || dayResponse.isFetching,
    isTableError: periodResponse.isError || dayResponse.isError,
    tableLength: days?.length === 0 || periods?.length === 0 ? 0 : 1,
    tableStatus:
      periodResponse.error?.status == 404 || dayResponse.error?.status == 404
        ? 404
        : 400,
    onPrint,
    pdfRef,
  };
};

export const useAddClassSchedule = () => {
  const navigate = useNavigate();
  const { state } = useLocation();
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminClassSchedule);
  const [errors, setErrors] = useState({});
  const [addClassRoutine, { isLoading }] = useAddClassRoutineMutation();
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [class_code, local_class_id] = getClassCode(selectors?.local_class_id);
  const classCode = Number(class_code) || 0;

  const handleUpdateSelector = (values) => {
    dispatch(setClassScheduleSelectors(values));
  };

  const handleUpdateSubjectSelector = (obj) => {
    dispatch(setClassScheduleSelectorsSubjects(obj));
  };

  const handleAddMore = () => {
    dispatch(addClassScheduleSubjects());
  };

  const handleCancel = () => {
    dispatch(resetAddClassScheduleSelectors());
    navigate(adminRoutes.attendance.classSchedule.path);
  };

  const removeSubject = (index) => {
    dispatch(removeClassScheduleSubject(index));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = {
      institute_id: institute_id,
      ...selectors,
      local_class_id,
    };
    const results = scheduleSchema.safeParse(data);
    const { error, isError } = checkValidation(results);
    if (isError) {
      setErrors(error);
      return;
    }
    setErrors({});
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    addClassRoutine(formData)
      .unwrap()
      .then((res) => {
        dispatch(resetAddClassScheduleSelectors());
        dispatch(addClassRoutineList(res?.data));
        infoNotify(res?.message);
        navigate(adminRoutes.attendance.classSchedule.path);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  useEffect(() => {
    if (!state.local_class_id) {
      navigate(adminRoutes.attendance.classSchedule.path);
    }
    dispatch(setClassScheduleSelectors(state));
  }, []);

  return {
    classCode,
    selectors,
    subjectData: {
      ...state,
      class_id: local_class_id,
    },
    errors,
    isLoading,
    handleUpdateSelector,
    handleUpdateSubjectSelector,
    handleAddMore,
    handleSubmit,
    handleCancel,
    removeSubject,
  };
};

export const useUpdateClassSchedule = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminClassSchedule);
  const [errors, setErrors] = useState({});
  const [updateClassRoutine, { isLoading }] = useUpdateClassRoutineMutation();
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [class_code, local_class_id] = getClassCode(selectors?.local_class_id);
  const classCode = Number(class_code) || 0;

  const query = `?institute_id=${institute_id}&routine_id=${id}`;
  const { isFetching, isError } = useGetClassRoutineQuery(
    { query },
    {
      skip: !institute_id || !id,
      refetchOnMountOrArgChange: true,
    }
  );

  const handleUpdateSelector = (values) => {
    dispatch(setClassScheduleSelectors(values));
  };

  const handleUpdateSubjectSelector = (obj) => {
    dispatch(setClassScheduleSelectorsSubjects(obj));
  };

  const handleAddMore = () => {
    dispatch(addClassScheduleSubjects());
  };

  const removeSubject = (index) => {
    dispatch(removeClassScheduleSubject(index));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const data = {
      institute_id: institute_id,
      ...selectors,
      local_class_id,
    };
    const results = scheduleSchema.safeParse(data);
    const { error, isError } = checkValidation(results);
    if (isError) {
      setErrors(error);
      return;
    }
    setErrors({});
    const formData = new FormData();
    formData.append("data", JSON.stringify(data));
    updateClassRoutine({ data: formData, query })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(resetAddClassScheduleSelectors());
        navigate(adminRoutes.attendance.classSchedule.path);
        dispatch(updateClassRoutineList(res?.data));
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  const handleCancel = () => {
    dispatch(resetAddClassScheduleSelectors());
    navigate(adminRoutes.attendance.classSchedule.path);
  };

  return {
    selectors,
    errors,
    isLoading,
    handleUpdateSelector,
    handleUpdateSubjectSelector,
    handleAddMore,
    handleSubmit,
    isFetching,
    isError,
    handleCancel,
    removeSubject,
    classCode,
  };
};
