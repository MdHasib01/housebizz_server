import {
  checkValidation,
  errorNotify,
  filterUndefined,
  getClassCode,
  infoNotify,
  studentAdmissionSchema,
} from "@/services";
import { useAddStudentAdmissionMutation } from "@/store/modules/admin/institute/admission/api";
import {
  resetAdmissionSelectors,
  setStudentAdmissionSelectors,
} from "@/store/modules/admin/institute/admission/slice";
import { useGetInstituteQuery } from "@/store/modules/superAdmin/administrator/instituteManagement/api";
import moment from "moment";
import { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";

export const useAddStudentAdmison = () => {
  const ref = useRef(null);
  const { id } = useParams();
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminAdmission);
  const { selectedInstituteManagement } = useSelector(
    (state) => state.saInstituteManagement
  );
  const [class_code, class_id] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code || 0);
  const [errors, setErrors] = useState({});
  const [image, setImage] = useState({});
  const [addStudentAdmission, { isLoading }] = useAddStudentAdmissionMutation();
  const setSelector = (values) => {
    dispatch(setStudentAdmissionSelectors(values));
  };
  const { isFetching, isError } = useGetInstituteQuery(id, {
    skip: !id,
    refetchOnMountOrArgChange: true,
  });

  const onAddressCheck = (val) => {
    if (ref.current) {
      const presentFields = ref.current.querySelectorAll(
        "[data-type='present']"
      );
      const permanentFields = ref.current.querySelectorAll(
        "[data-type='permanent']"
      );

      presentFields.forEach((presentField, index) => {
        if (permanentFields[index]) {
          permanentFields[index].value = val ? presentField?.value : "";
        }
      });
    }
  };

  const onGurdianCheck = (event) => {
    const value = event.target.value;
    const fatherFields = ref.current.querySelectorAll("[data-type='father']");
    const motherFields = ref.current.querySelectorAll("[data-type='mother']");
    const gardianFields = ref.current.querySelectorAll(
      "[data-type='guardian']"
    );

    if (value === "father") {
      gardianFields.forEach((gardianField, index) => {
        if (fatherFields[index]) {
          gardianField.value = fatherFields[index]?.value;
        }
      });
    } else {
      gardianFields.forEach((gardianField, index) => {
        if (motherFields[index]) {
          gardianField.value = motherFields[index]?.value;
        }
      });
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const formEvent = event.target;
    const form = new FormData(formEvent);
    const entries = Object.fromEntries(form.entries());
    const dateOfBirtth = selectors?.date_of_birth?.startDate
      ? moment(selectors?.date_of_birth?.startDate).format("YYYY-MM-DD")
      : "";
    let data = {
      ...entries,
      ...selectors,
      current_class: class_id,
      institute_id: selectedInstituteManagement?.institute_id,
      date_of_birth: dateOfBirtth,
    };

    if (image?.key) {
      data = { ...data, image: image?.key };
    }

    const results = studentAdmissionSchema.safeParse(data);
    const { isError, error } = checkValidation(results);
    if (isError) {
      setErrors(error);
      return;
    } else {
      setErrors({});
      const filteredData = filterUndefined(data);
      const submitForm = new FormData();
      submitForm.append("data", JSON.stringify(filteredData));
      addStudentAdmission(submitForm)
        .unwrap()
        .then((res) => {
          infoNotify(res?.message);
          dispatch(resetAdmissionSelectors());
          setImage("");
          formEvent.reset();
        })
        .catch((err) => {
          errorNotify(err?.data?.message);
        });
      setErrors({});
    }
  };

  return {
    isFetching,
    isError,
    isLoading,
    onSubmit,
    setSelector,
    errors,
    image,
    setImage,
    selectors,
    selectedInstituteManagement,
    institute_id: selectedInstituteManagement?.institute_id,
    institute_type: selectedInstituteManagement?.institute_type,
    classCode,
    onAddressCheck,
    onGurdianCheck,
    ref,
  };
};
