import { errorNotify, getClassCode, infoNotify } from "@/services";
import {
  useAddLocalClassMutation,
  useDeleteLocalClassMutation,
  useGetClassesQuery,
} from "@/store/modules/admin/institute/class/api";
import {
  addClassList,
  closeClassModal,
  removeClassList,
  setClassPageData,
  setSelectedClass,
} from "@/store/modules/admin/institute/class/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export const useClasses = () => {
  // global
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const { selectedData, dataLists, pageData, showModal } = useSelector(
    (state) => state.adminClasses
  );

  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;

  const [addLocalClass, { isLoading: isAdding }] = useAddLocalClassMutation();
  const [deleteLocalClass, { isLoading: isDeleting }] =
    useDeleteLocalClassMutation();
  const { isFetching, isError, error } = useGetClassesQuery(
    { page: currentPage, limit: pageSize, institute_id: institute_id },
    { skip: !institute_id }
  );

  // states
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  // handler
  const updatePage = (value) => dispatch(setClassPageData(value));

  const handleSelect = (data) =>
    dispatch(setSelectedClass(data));



  const closeModal = () => {
    if (selectedData?.type === "delete") dispatch(closeClassModal());
    else setSuccessDialogOpen(false);
  };

  //  handle add class
  const addClassHandler = (data) => {
    if (!selectedData && selectedData.type !== "select") return;

    const splitedSelectedData = getClassCode(data?.value);
    const submitData = new FormData();
    submitData.append(
      "data",
      JSON.stringify({
        local_class_code: Number(splitedSelectedData[0]),
        local_class_name: splitedSelectedData[1],
        institute_id: institute_id,
      })
    );

    addLocalClass(submitData)
      .unwrap()
      .then((res) => {
        dispatch(setSelectedClass({}));
        dispatch(addClassList(res?.data));
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  // delete shift handler
  const removeClassHanlder = () => {
    if (selectedData?.type !== "delete") return;
    const deleteItemnId = selectedData?._id;
    dispatch(closeClassModal());

    deleteLocalClass({
      institute_id: institute_id,
      local_class_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeClassList({ _id: deleteItemnId }));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status: error?.status,
    selectedData,
    isLoading: isAdding || isDeleting,
    showModal: showModal || successDialogOpen,

    // functions
    updatePage,
    closeModal,
    addClassHandler,
    removeClassHanlder,
    handleSelect,
  };
};
