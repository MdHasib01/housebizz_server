import { errorNotify, infoNotify } from "@/services";
import {
  useAddPeriodMutation,
  useDeletePeriodMutation,
  useGetPeriodsQuery,
} from "@/store/modules/admin/institute/period/api";
import {
  addPeriodList,
  closePeriodModal,
  removePeriodList,
  setPeriodPageData,
  setSelectedPeriod,
} from "@/store/modules/admin/institute/period/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export const usePeriods = () => {
  // global
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const { showModal, selectedData, pageData, dataLists } = useSelector(
    (state) => state.adminPeriod
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;

  const [addPeriod, { isLoading: isAdding }] = useAddPeriodMutation();
  const [deletePeriod, { isLoading: isDeleting }] = useDeletePeriodMutation();
  const { isFetching, isError, error } = useGetPeriodsQuery(
    { page: currentPage, limit: pageSize, institute_id: institute_id },
    { skip: !institute_id }
  );

  // states
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  //handlers
  const updatePage = (value) => dispatch(setPeriodPageData(value));
  const handlerSelectPeriod = (value) =>
    dispatch(setSelectedPeriod({ period_name: value, type: "select" }));
  const handleSelect = (value) => dispatch(setSelectedPeriod(value));
  const closeModal = () => {
    if (selectedData?.type === "delete") dispatch(closePeriodModal());
    else setSuccessDialogOpen(false);
  };

  //  handle add class
  const addPeriodHandler = () => {
    if (!selectedData && selectedData.type !== "select") return;

    const submitData = new FormData();
    submitData.append(
      "data",
      JSON.stringify({
        period_name: selectedData?.period_name,
        institute_id: institute_id,
      })
    );

    addPeriod(submitData)
      .unwrap()
      .then((res) => {
        dispatch(setSelectedPeriod({}));
        dispatch(addPeriodList(res?.data));
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  // delete handler
  const removePeriodHanlder = () => {
    if (selectedData?.type !== "delete") return;

    const deleteItemnId = selectedData?._id;
    dispatch(closePeriodModal());

    deletePeriod({
      institute_id: institute_id,
      period_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removePeriodList({ _id: deleteItemnId }));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status: error?.status,
    selectedData,
    isLoading: isAdding || isDeleting,
    showModal: showModal || successDialogOpen,

    // functions
    updatePage,
    closeModal,
    addPeriodHandler,
    removePeriodHanlder,
    handlerSelectPeriod,
    handleSelect,
  };
};
