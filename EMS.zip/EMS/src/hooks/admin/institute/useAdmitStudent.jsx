import { adminRoutes, errorNotify, getClassCode, infoNotify } from "@/services";
import {
  adminAdmitStudentApi,
  useDeleteStudentAdmissionMutation,
  useGetAdmitStudentAdmissionsQuery,
  useGetStudentAdmissionsQuery,
  useStudentBulkAdmissionMutation,
} from "@/store/modules/admin/institute/admission/admitApi";
import {
  closeAdmitStudentModal,
  removeAdmitStudentList,
  removeUpdatedAdmitStudentList,
  resetAdmitStudentSelectors,
  selectAllAdmitStudents,
  setAdmitStudentFetchData,
  setAdmitStudentPageData,
  setAdmitStudentSelectors,
  setAdmitStudentShowTable,
  setSelectedAdmitStudent,
  toggleAdmitStudent,
} from "@/store/modules/admin/institute/admission/admitSlice";
import {
  closeStudentAdmissionModal,
  removeStudentAdmissionList,
  resetAllAdmissionData,
  setSelectedStudentAdmission,
  setStudentAdmissionPageData,
} from "@/store/modules/admin/institute/admission/slice";
import { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useReactToPrint } from "react-to-print";

export const useStudentAdmission = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal } = useSelector(
    (state) => state.adminAdmission
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [pdfLoading, setPdfLoading] = useState(false);
  const ref = useRef(null);

  const { isFetching, isError, error } = useGetStudentAdmissionsQuery(
    {
      page: currentPage,
      limit: pageSize,
      institute_id,
    },
    {
      skip: !institute_id,
    }
  );

  const onPrint = useReactToPrint({
    contentRef: ref,
    documentTitle: "student",
    onBeforePrint: () => {
      setPdfLoading(true);
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setPdfLoading(false);
        }, 900);
      });
    },
  });

  const [deleteStudentAdmission, { isLoading: isDeleting }] =
    useDeleteStudentAdmissionMutation();

  const handleSelect = (value) => {
    dispatch(setSelectedStudentAdmission(value));
    if (value?.type === "pdf") {
      setTimeout(() => {
        onPrint();
      }, 100);
    }
  };

  const updatePage = (value) => {
    dispatch(setStudentAdmissionPageData(value));
  };

  const closeModal = () => {
    dispatch(closeStudentAdmissionModal());
    dispatch(setSelectedStudentAdmission({}));
  };

  const removeStudentAdmission = () => {
    dispatch(closeStudentAdmissionModal());
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ institute_id: selectedData?.institute_id })
    );
    const query = `?institute_id=${institute_id}&student_id=${selectedData?._id}`;
    deleteStudentAdmission({
      query: query,
      data: formData,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeStudentAdmissionList("delete"));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    status: error?.status,
    isLoading: isDeleting,
    dataLists,
    selectedData,
    isFetching,
    isError,
    // handleSelectDelete,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    handleSelect,
    pdfLoading,
    onPrint,
    ref,
  };
};

export const useAdmitStudentFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminAdmitAdmission);
  const [class_code, class_id] = getClassCode(selectors?.class_id);
  const classCode = Number(class_code);
  const handleSelector = (values) => {
    dispatch(setAdmitStudentSelectors(values));
  };
  const handleReset = () => {
    dispatch(resetAdmitStudentSelectors());
  };

  const handleShowTable = () => {
    if (
      !selectors?.academic_year &&
      !selectors?.class_id &&
      !selectors?.section_id &&
      !selectors?.current_category
    ) {
      return errorNotify("Please select at least one filter");
    }

    dispatch(setAdmitStudentShowTable(true));
    dispatch(setAdmitStudentFetchData(true));
  };

  return {
    classCode,
    selectors,
    handleSelector,
    handleReset,
    handleShowTable,
  };
};

export const useAdmitStudents = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const {
    dataLists,
    selectedData,
    pageData,
    showModal,
    selectors,
    fetchData,
    student_ids,
  } = useSelector((state) => state.adminAdmitAdmission);

  const { currentPage, pageSize, totalPages } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [_, class_id] = getClassCode(selectors?.class_id);
  const [class_code, current_class_id] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code || 0);
  const [pdfLoading, setPdfLoading] = useState(false);
  const ref = useRef(null);

  const onPrint = useReactToPrint({
    contentRef: ref,
    documentTitle: "student",
    onBeforePrint: () => {
      setPdfLoading(true);
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setPdfLoading(false);
        }, 900);
      });
    },
  });

  const [studentBulkAdmission, { isLoading }] =
    useStudentBulkAdmissionMutation();

  const handleNavigate = () => {
    navigate(adminRoutes.institute.admission.path);
  };

  const querySelectors = {
    academic_year: selectors?.academic_year,
    class_id: class_id,
    group_id: selectors?.group_id,
    institute_id: institute_id,
    current_category: selectors?.current_category,
    status: "pending",
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetAdmitStudentAdmissionsQuery(
    {
      page: currentPage,
      limit: pageSize,
      query,
    },
    {
      skip: !institute_id || !fetchData,
      refetchOnMountOrArgChange: fetchData,
    }
  );

  const [deleteStudentAdmission, { isLoading: isDeleting }] =
    useDeleteStudentAdmissionMutation();

  const handleSelect = (value) => {
    dispatch(setSelectedAdmitStudent(value));
    if (value?.type === "pdf") {
      setTimeout(() => {
        onPrint();
      }, 100);
    }
  };

  const updatePage = (value) => {
    dispatch(setAdmitStudentPageData(value));
  };

  const closeModal = () => {
    dispatch(closeAdmitStudentModal());
    dispatch(setSelectedAdmitStudent({}));
  };

  const handleSelectAllStudent = () => {
    dispatch(selectAllAdmitStudents());
  };

  const handleToggleSelectStudent = (id) => {
    dispatch(toggleAdmitStudent(id));
  };

  const handleSelector = (values) => {
    dispatch(setAdmitStudentSelectors(values));
  };

  const resetAdmitSelectors = () => {
    dispatch(
      setAdmitStudentSelectors({
        current_academic_year: "",
        current_class: "",
        current_section: "",
        current_group: "",
      })
    );
  };

  const resetAdmissionData = () => {
    dispatch(resetAllAdmissionData());
    dispatch(
      adminAdmitStudentApi.endpoints.getStudentAdmissions.initiate(
        {
          page: 1,
          limit: 50,
          institute_id: institute_id,
        },
        {
          forceRefetch: true,
        }
      )
    );
  };

  const handleSubmit = () => {
    let data = {
      student_ids: [...student_ids],
      current_section: selectors?.current_section,
      academic_year: selectors?.current_academic_year,
      current_class: current_class_id,
      status: "active",
    };

    if (selectors?.current_group) {
      data = { ...data, current_group: selectors?.current_group };
    }

    const submitFormData = new FormData();
    submitFormData.append("data", JSON.stringify(data));
    const query = `?institute_id=${institute_id}`;
    studentBulkAdmission({
      query,
      data: submitFormData,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        resetAdmissionData();
        dispatch(setAdmitStudentFetchData(true));
        dispatch(removeUpdatedAdmitStudentList());
        handleNavigate();
        resetAdmitSelectors();
        resetAdmissionData();
        dispatch(setAdmitStudentShowTable(false));
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  const removeStudentAdmission = () => {
    dispatch(closeStudentAdmissionModal());
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ institute_id: selectedData?.institute_id })
    );
    const query = `?institute_id=${institute_id}&student_id=${selectedData?._id}`;
    deleteStudentAdmission({
      query: query,
      data: formData,
    })
      .unwrap()
      .then(() => {
        resetAdmissionData();
        dispatch(removeAdmitStudentList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  const isSubmitable = () => {
    let isOk =
      student_ids?.length > 0 &&
      current_class_id &&
      selectors?.current_section &&
      selectors?.current_academic_year
        ? true
        : false;

    isOk = classCode > 8 ? isOk && selectors?.current_group : isOk;
    return isOk;
  };

  return {
    status: error?.status,
    isLoading: isDeleting || isLoading,
    dataLists,
    selectedData,
    isFetching,
    isError,
    handleSelect,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    isAllSelected: student_ids?.length === dataLists?.length,
    student_ids,
    handleSelectAllStudent,
    selectors,
    isSubmitable: isSubmitable(),
    handleSubmit,
    handleToggleSelectStudent,
    classCode,
    handleSelector,
    handleReset: resetAdmitSelectors,
    pdfLoading,
    ref,
  };
};
