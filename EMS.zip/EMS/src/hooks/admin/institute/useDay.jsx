import { errorNotify, infoNotify } from "@/services";
import {
  useAddDayMutation,
  useDeleteDayMutation,
  useGetDaysQuery,
} from "@/store/modules/admin/institute/day/api";
import {
  addDayList,
  closeDayModal,
  removeDayList,
  setDayPageData,
  setSelectedDay,
} from "@/store/modules/admin/institute/day/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export const useDays = () => {
  // global
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const { showModal, selectedData, pageData, dataLists } = useSelector(
    (state) => state.adminDays
  );

  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [addDay, { isLoading: isAdding }] = useAddDayMutation();
  const [deleteDay, { isLoading: isDeleting }] = useDeleteDayMutation();
  const { isFetching, isError, error } = useGetDaysQuery(
    { page: currentPage, limit: pageSize, institute_id: institute_id },
    { skip: !institute_id }
  );

  // states
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  //handlers
  const updatePage = (value) => dispatch(setDayPageData(value));
  const handlerSelectDay = (day) =>
    dispatch(setSelectedDay({ day_name: day, type: "select" }));
  const handleSelect = (value) => dispatch(setSelectedDay(value));
  const closeModal = () => {
    if (selectedData?.type === "delete") dispatch(closeDayModal());
    else setSuccessDialogOpen(false);
  };

  //  handle add class
  const addDayHandler = () => {
    if (!selectedData && selectedData.type !== "select") return;

    const submitData = new FormData();
    submitData.append(
      "data",
      JSON.stringify({
        day_name: selectedData?.day_name,
        institute_id: institute_id,
      })
    );

    addDay(submitData)
      .unwrap()
      .then((res) => {
        dispatch(setSelectedDay({}));
        dispatch(addDayList(res?.data));
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  // delete handler
  const removeDayHanlder = () => {
    if (selectedData?.type !== "delete") return;

    const deleteItemnId = selectedData?._id;
    dispatch(closeDayModal());

    deleteDay({
      institute_id: institute_id,
      day_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeDayList({ _id: deleteItemnId }));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status: error?.status,

    selectedData,
    isLoading: isAdding || isDeleting,
    showModal: showModal || successDialogOpen,

    //handlers
    updatePage,
    closeModal,
    addDayHandler,
    removeDayHanlder,
    handlerSelectDay,
    handleSelect,
  };
};
