import {
  adminRoutes,
  checkValidation,
  errorNotify,
  infoNotify,
  validateShift,
} from "@/services";
import { shiftSchema } from "@/services/validation/zodSchema/admin/institute/shift";
import {
  useAddShiftMutation,
  useDeleteShiftMutation,
  useGetShiftsQuery,
  useUpdateShiftMutation,
} from "@/store/modules/admin/institute/scheduleShift/api";
import {
  addShiftList,
  closeShiftModal,
  removeShiftList,
  setSelectedShift,
  setShiftPageData,
  updateSelectedShiftValue,
  updateShiftListItem,
} from "@/store/modules/admin/institute/scheduleShift/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useAddShift = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [addShift, { isLoading }] = useAddShiftMutation();
  const [errors, setErrors] = useState({});
  const [formInput, setFormInput] = useState({ start_time: "", end_time: "" });
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const onChangeTime = (name, value) =>
    setFormInput((prev) => ({ ...prev, [name]: value }));

  const resetFields = () => {
    setFormInput({ start_time: "", end_time: "" });
    document.getElementById("add-shift-form").reset();
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const entries = Object.fromEntries(formData.entries());

    const data = { ...entries, ...formInput, institute_id: institute_id };
    const result = shiftSchema.safeParse(data);

    const { isError, error } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    }

    setErrors({});
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));

    addShift(submitData)
      .unwrap()
      .then((res) => {
        event.target.reset();
        setFormInput({ start_time: "", end_time: "" });
        dispatch(addShiftList(res?.data));
        navigate(adminRoutes.institute.shift.path);
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    errors,
    formInput,
    isLoading,
    onSubmit,
    resetFields,
    onChangeTime,
  };
};

export const useShifts = () => {
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const { dataLists, pageData, showModal, selectedData } = useSelector(
    (state) => state.adminScheduleShifts
  );

  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;

  const [updateShift, { isLoading: isUpdating }] = useUpdateShiftMutation();
  const [deleteShift, { isLoading: isDeleting }] = useDeleteShiftMutation();
  const { isFetching, isError, error } = useGetShiftsQuery(
    { page: currentPage, limit: pageSize, institute_id: institute_id },
    { skip: !institute_id }
  );

  // handle select
  const closeModal = () => dispatch(closeShiftModal());
  const updatePage = (value) => dispatch(setShiftPageData(value));
  const handleSelect = (value) => dispatch(setSelectedShift(value));
  const updateSelectedRowValue = (name, value) =>
    dispatch(updateSelectedShiftValue({ name, value }));

  // update shift handler
  const updateShiftHandler = (data) => {
    const error = validateShift(data);
    if (error) return errorNotify(error);
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));
    updateShift({
      institute_id: selectedData?.institute_id,
      shift_id: selectedData?._id,
      data: submitData,
    })
      .unwrap()
      .then((res) => {
        dispatch(updateShiftListItem(res?.data));
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  // delete shift handler
  const removeShiftHanlder = () => {
    if (selectedData?.type !== "delete") return;

    const deleteItemnId = selectedData?._id;
    dispatch(closeShiftModal());

    deleteShift({
      institute_id: institute_id,
      shift_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeShiftList({ _id: deleteItemnId }));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status: error?.status,
    selectedData,
    isLoading: isDeleting || isUpdating,
    showModal,

    // functions
    closeModal,
    updatePage,
    handleSelect,
    updateShiftHandler,
    removeShiftHanlder,
    updateSelectedRowValue,
  };
};
