import {
  adminRoutes,
  checkValidation,
  errorNotify,
  infoNotify,
  userManageSchema,
} from "@/services";

import {
  useAddUserManagementMutation,
  useDeleteUserManagementMutation,
  useGetUserManagementsQuery,
} from "@/store/modules/admin/institute/userManagement/api";
import {
  addUserManageList,
  closeUserManageModal,
  removeUserManageList,
  setSelectedUserManage,
} from "@/store/modules/admin/institute/userManagement/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useUserManagement = () => {
  // global
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const { selectedData, dataLists, pageData, showModal } = useSelector(
    (state) => state.adminUserManagement
  );
  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [deleteUserManagement, { isLoading: isDeleting }] =
    useDeleteUserManagementMutation();
  const { isFetching, isError, error } = useGetUserManagementsQuery(
    { page: currentPage, limit: pageSize, institute_id: institute_id },
    { skip: !institute_id }
  );

  // handler
  const updatePage = (value) => dispatch(setUserManagePageData(value));
  const setSelectedData = (data) => dispatch(setSelectedUserManage(data));
  const closeModal = () => dispatch(closeUserManageModal());

  const handleResetPassword = () => {
    setSelectedData({});
  };

  // delete handler
  const removeUserManageHanlder = () => {
    if (selectedData?.type !== "delete") return;
    dispatch(closeUserManageModal());
    deleteUserManagement({
      institute_id: institute_id,
      institute_admin_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeUserManageList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status: error?.status,
    selectedData,
    isLoading: isDeleting,
    showModal: showModal,
    updatePage,
    setSelectedData,
    closeModal,
    removeUserManageHanlder,
    handleResetPassword,
  };
};

export const useAddUserManagement = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [errors, setErrors] = useState({});
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [addUserManagement, { isLoading }] = useAddUserManagementMutation();

  const handleSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());
    const data = {
      ...entries,
      institute_id: institute_id,
      name: "Admin",
    };
    const result = userManageSchema.safeParse(data);
    const { isError, error } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    }
    setErrors({});
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(data));
    addUserManagement(submitData)
      .unwrap()
      .then((res) => {
        form.reset();
        infoNotify(res?.message);
        dispatch(addUserManageList(res?.data));
        navigate(adminRoutes.institute.userManage.path);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    errors,
    onSubmit: handleSubmit,
    isLoading,
  };
};
