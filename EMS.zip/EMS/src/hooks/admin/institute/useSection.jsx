import {
  adminRoutes,
  checkValidation,
  errorNotify,
  filterUndefined,
  getClassCode,
  infoNotify,
  sectionSchema,
} from "@/services";
import { validateSection } from "@/services/validation/admin/institute/section";
import {
  useAddSectionMutation,
  useDeleteSectionMutation,
  useGetSectionsQuery,
  useUpdateSectionMutation,
} from "@/store/modules/admin/institute/sectionList/api";
import {
  addSectionList,
  closeSectionModal,
  removeSectionList,
  setSectionPageData,
  setSelectedSection,
  updateSectionListItem,
  updateSelectedSectionValue,
} from "@/store/modules/admin/institute/sectionList/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useAddSection = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [addSection, { isLoading }] = useAddSectionMutation();
  const { auth } = useSelector((state) => state.auth);
  const [errors, setErrors] = useState({});
  const [formSelect, setFormSelect] = useState({
    local_class_id: "",
    group_id: "",
    shift_id: "",
  });
  const [class_code, class_id] = getClassCode(formSelect?.local_class_id);
  const classCode = Number(class_code);
  const institute_id = auth?.instituteAdmin?.institute_id;

  const onChangeSelect = (name, value) =>
    setFormSelect((prev) => ({ ...prev, [name]: value }));
  const resetFields = () => {
    setFormSelect({ local_class_id: "", group_id: "", shift_id: "" });
    document.getElementById("add-section-form").reset();
  };

  //  handle form submit
  const addSectionHandler = (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const entries = Object.fromEntries(formData.entries());

    const data = {
      ...entries,
      ...formSelect,
      local_class_id: class_id,
      section_capacity: Number(entries?.section_capacity),
      institute_id: institute_id,
    };

    const filteredData = filterUndefined(data);
    const result = sectionSchema.safeParse(filteredData);
    const { isError, error } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    }
    setErrors({});
    const submitData = new FormData();
    submitData.append("data", JSON.stringify(filteredData));
    addSection(submitData)
      .unwrap()
      .then((res) => {
        event.target.reset();
        setFormSelect({ local_class_id: "", group_id: "", shift_id: "" });
        dispatch(addSectionList(res?.data));
        navigate(adminRoutes.institute.section.path);
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  return {
    errors,
    isLoading,
    formSelect,
    classCode,
    // methods
    resetFields,
    onChangeSelect,
    addSectionHandler,
  };
};

export const useSections = () => {
  // global
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const { dataLists, pageData, showModal, selectedData } = useSelector(
    (state) => state.adminSections
  );
  const [class_code, class_id] = getClassCode(selectedData?.local_class_id);
  const classCode = Number(class_code || 0);
  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;

  const [updateSection, { isLoading: isUpdating }] = useUpdateSectionMutation();
  const [deleteSection, { isLoading: isDeleting }] = useDeleteSectionMutation();
  const { isFetching, isError, error } = useGetSectionsQuery({
    page: currentPage,
    limit: pageSize,
    institute_id: institute_id,
  });

  // states
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  //handlers
  const updatePage = (value) => dispatch(setSectionPageData(value));
  const handleSelectUpdate = (value) => {
    if (value) {
      dispatch(
        setSelectedSection({
          ...value,
          group_id: value?.group_id?._id,
          local_class_id: `${value?.local_class_id?.local_class_code}-${value?.local_class_id?._id}`,
          shift_id: value?.shift_id?._id,
          type: "update",
        })
      );
    } else {
      dispatch(
        setSelectedSection({
          group_id: "",
          local_class_id: "",
          shift_id: "",
        })
      );
    }
  };

  const handleSelectDelete = (value) =>
    dispatch(setSelectedSection({ ...value, type: "delete" }));

  const handleSelectRow = (value) => {
    dispatch(setSelectedSection({ ...value, type: "row" }));
  };

  const updateSelectedRowValue = (name, value) =>
    dispatch(updateSelectedSectionValue({ name, value }));

  const closeModal = () => {
    if (selectedData?.type === "delete") dispatch(closeSectionModal());
    else setSuccessDialogOpen(false);
  };

  // update handler
  const updateSectionHandler = (data) => {
    const filteredData = filterUndefined({ ...data, local_class_id: class_id });
    const error = validateSection(filteredData);
    if (error) return errorNotify(error);

    const submitData = new FormData();
    submitData.append("data", JSON.stringify(filteredData));

    updateSection({
      institute_id: selectedData?.institute_id,
      section_id: selectedData?._id,
      data: submitData,
    })
      .unwrap()
      .then((res) => {
        dispatch(updateSectionListItem(res?.data));
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  // remove handler
  const removeSectionHanlder = () => {
    if (selectedData?.type !== "delete") return;

    const deleteItemnId = selectedData?._id;
    dispatch(closeSectionModal());

    deleteSection({
      institute_id: institute_id,
      section_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeSectionList({ _id: deleteItemnId }));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status: error?.status,
    selectedData,
    isLoading: isDeleting || isUpdating,
    showModal: showModal || successDialogOpen,
    classCode,

    // methods
    handleSelectRow,
    updatePage,
    closeModal,
    handleSelectUpdate,
    handleSelectDelete,
    setSuccessDialogOpen,
    removeSectionHanlder,
    updateSectionHandler,
    updateSelectedRowValue,
  };
};
