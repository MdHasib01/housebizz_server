import { errorNotify, infoNotify } from "@/services";
import {
  useAddCategoryMutation,
  useDeleteCategoryMutation,
  useGetCategoriesQuery,
} from "@/store/modules/admin/institute/category/api";
import {
  addCategoryList,
  closeCategoryModal,
  removeCategoryList,
  setCategoryPageData,
  setSelectedCategory,
} from "@/store/modules/admin/institute/category/slice";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";

export const useCategories = () => {
  // global
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const { showModal, selectedData, pageData, dataLists } = useSelector(
    (state) => state.adminCategory
  );

  const { currentPage, pageSize, totalPages } = pageData || {};
  const institute_id = auth?.instituteAdmin?.institute_id;

  const [addCategory, { isLoading: isAdding }] = useAddCategoryMutation();
  const [deleteCategory, { isLoading: isDeleting }] =
    useDeleteCategoryMutation();
  const { isFetching, isError, error } = useGetCategoriesQuery(
    { page: currentPage, limit: pageSize, institute_id: institute_id },
    { skip: !institute_id }
  );

  // states
  const [successDialogOpen, setSuccessDialogOpen] = useState(false);

  //handlers
  const updatePage = (value) => dispatch(setCategoryPageData(value));
  const handlerSelectCategory = (value) =>
    dispatch(
      setSelectedCategory({ local_category_name: value, type: "select" })
    );
  const handleSelect = (value) => dispatch(setSelectedCategory(value));
  const closeModal = () => {
    if (selectedData?.type === "delete") dispatch(closeCategoryModal());
    else setSuccessDialogOpen(false);
  };

  //  handle add class
  const addCategoryHandler = () => {
    if (!selectedData && selectedData.type !== "select") return;

    const submitData = new FormData();
    submitData.append(
      "data",
      JSON.stringify({
        local_category_name: selectedData?.local_category_name,
        institute_id: institute_id,
      })
    );

    addCategory(submitData)
      .unwrap()
      .then((res) => {
        dispatch(setSelectedCategory({}));
        dispatch(addCategoryList(res?.data));
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.data?.message);
      });
  };

  // delete handler
  const removeCategoryHanlder = () => {
    if (selectedData?.type !== "delete") return;

    const deleteItemnId = selectedData?._id;
    dispatch(closeCategoryModal());

    deleteCategory({
      institute_id: institute_id,
      local_category_id: selectedData?._id,
    })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeCategoryList({ _id: deleteItemnId }));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  return {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status: error?.status,
    selectedData,
    isLoading: isAdding || isDeleting,
    showModal: showModal || successDialogOpen,

    // functions
    updatePage,
    closeModal,
    addCategoryHandler,
    removeCategoryHanlder,
    handlerSelectCategory,
    handleSelect,
  };
};
