import {
  adminRoutes,
  checkValidation,
  errorNotify,
  filterUndefined,
  infoNotify,
  teacherSchema,
} from "@/services";
import {
  useAddTeacherMutation,
  useDeleteTeacherMutation,
  useGetTeacherQuery,
  useGetTeachersQuery,
  useUpdateTeacherMutation,
} from "@/store/modules/admin/institute/teacherManagement/api";
import {
  addTeacherList,
  closeTeacherModal,
  removeTeacherList,
  resetTeacherSelectors,
  selectAllTeacher,
  setSelectedTeacher,
  setSelectors,
  setTeacherImage,
  setTeacherPageData,
  toggleSelectedTeacher,
  updateTeacherList,
} from "@/store/modules/admin/institute/teacherManagement/slice";
import { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";

export const useTeachers = () => {
  const dispatch = useDispatch();
  const { dataLists, selectedData, pageData, showModal, selectedTeachers } =
    useSelector((state) => state.adminTeacherManagement);

  const { currentPage, pageSize, totalPages, totalItems } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [action, setAction] = useState("");

  const { isFetching, isError, error } = useGetTeachersQuery(
    {
      page: currentPage,
      limit: pageSize,
      institute_id,
    },
    {
      skip: !institute_id,
    }
  );

  const [deleteTeacher, { isLoading: isDeleting }] = useDeleteTeacherMutation();

  const handleSelectDelete = (value) => {
    dispatch(setSelectedTeacher({ ...value, type: "delete" }));
  };

  const updatePage = (value) => {
    dispatch(setTeacherPageData(value));
  };

  const closeModal = () => {
    dispatch(closeTeacherModal());
    dispatch(setSelectedTeacher({}));
  };

  const handleSelectAllTeacher = () => {
    dispatch(selectAllTeacher());
  };

  const handleToggleSelectTeacher = (id) => {
    dispatch(toggleSelectedTeacher(id));
  };

  const removeTeacher = () => {
    dispatch(closeTeacherModal());
    const query = `?institute_id=${institute_id}&teacher_id=${selectedData?._id}`;
    deleteTeacher({ query })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeTeacherList("delete"));
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  const handleAction = () => {
    // if (student_ids?.length === 0) return errorNotify("Please select student");
    // studentBulkAction(action)
    //   .unwrap()
    //   .then((res) => {
    //     if (action === "export") {
    //       setAction("");
    //       dispatch(resetStudentSelection());
    //       return;
    //     }
    //     if (action === "remove") {
    //       dispatch(removeBulkStudentList());
    //     }
    //     setAction("");
    //     dispatch(resetStudentSelection());
    //     infoNotify(res?.message);
    //   })
    //   .catch((error) => {
    //     errorNotify(error?.message);
    //   });
  };

  return {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isDeleting,
    handleSelectDelete,
    updatePage,
    closeModal,
    removeTeacher,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    selectedTeachers,
    handleSelectAllTeacher,
    handleToggleSelectTeacher,
    isAllSelected: selectedTeachers.length === dataLists.length,
    totalItems,
    action,
    setAction,
    handleAction,
  };
};

export const useAddTeacher = () => {
  const ref = useRef(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const [errors, setErrors] = useState({});
  const { selectors, image } = useSelector(
    (state) => state.adminTeacherManagement
  );
  const [addTeacher, { isLoading }] = useAddTeacherMutation();
  const institute_id = auth?.instituteAdmin?.institute_id;

  const handleSelectors = (values) => {
    dispatch(setSelectors(values));
  };

  const handleImage = (value) => {
    dispatch(setTeacherImage(value));
  };

  const onAddressCheck = (val) => {
    if (ref.current) {
      const presentFields = ref.current.querySelectorAll(
        "[data-type='present']"
      );
      const permanentFields = ref.current.querySelectorAll(
        "[data-type='permanent']"
      );

      presentFields.forEach((presentField, index) => {
        if (permanentFields[index]) {
          permanentFields[index].value = val ? presentField?.value : "";
        }
      });
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const entries = Object.fromEntries(formData.entries());
    const data = {
      ...entries,
      ...selectors,
      teacher_index: Number(entries.teacher_index),
      role: "teacher",
    };
    if (image?.key) {
      data.image = image?.key;
    }
    const result = teacherSchema.safeParse(data);
    const { isError, error } = checkValidation(result);
    if (isError) {
      setErrors(error);
      return;
    } else {
      const filteredData = filterUndefined(data);
      const submitData = new FormData();
      submitData.append("data", JSON.stringify(filteredData));
      setErrors({});
      addTeacher(submitData)
        .unwrap()
        .then((res) => {
          form.reset();
          dispatch(addTeacherList(res?.data));
          navigate(adminRoutes.institute.teacher.path);
          dispatch(resetTeacherSelectors());
          infoNotify(res?.message);
        })
        .catch((error) => {
          errorNotify(error?.data?.message);
        });
    }
  };

  return {
    auth,
    image,
    setImage: handleImage,
    errors,
    selectors,
    setSelectors: handleSelectors,
    onSubmit,
    addTeacher,
    isLoading,
    institute_id,
    ref,
    onAddressCheck,
  };
};

export const useUpdateTeacher = () => {
  const ref = useRef(null);
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const [errors, setErrors] = useState({});
  const { selectors, image, selectedData } = useSelector(
    (state) => state.adminTeacherManagement
  );

  const institute_id = auth?.instituteAdmin?.institute_id;
  const [updateTeacher, { isLoading }] = useUpdateTeacherMutation();
  const { isFetching, isError } = useGetTeacherQuery(
    {
      teacher_id: id,
      institute_id: institute_id,
    },
    {
      skip: !id || !institute_id,
      refetchOnMountOrArgChange: true,
    }
  );

  const handleSelectors = (values) => {
    dispatch(setSelectors(values));
  };

  const handleImage = (value) => {
    dispatch(setTeacherImage(value));
  };

  const onAddressCheck = (val) => {
    if (ref.current) {
      const presentFields = ref.current.querySelectorAll(
        "[data-type='present']"
      );
      const permanentFields = ref.current.querySelectorAll(
        "[data-type='permanent']"
      );

      presentFields.forEach((presentField, index) => {
        if (permanentFields[index]) {
          permanentFields[index].value = val ? presentField?.value : "";
        }
      });
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const entries = Object.fromEntries(formData.entries());
    let data = {
      ...entries,
      ...selectors,
      teacher_index: Number(entries.teacher_index),
      role: "teacher",
    };

    if (image?.key) {
      data.image = image?.key;
    }

    const result = teacherSchema.safeParse(data);
    const { isError, error } = checkValidation(result);
    const query = `?institute_id=${institute_id}&teacher_id=${id}`;
    if (isError) {
      setErrors(error);
      return;
    } else {
      const filteredData = filterUndefined(data);
      const submitData = new FormData();
      submitData.append("data", JSON.stringify(filteredData));
      setErrors({});
      updateTeacher({ query: query, data: submitData })
        .unwrap()
        .then((res) => {
          dispatch(updateTeacherList(res?.data));
          dispatch(resetTeacherSelectors());
          navigate(adminRoutes.institute.teacher.path);
          infoNotify(res?.message);
        })
        .catch((error) => {
          errorNotify(error?.data?.message);
        });
    }
  };

  return {
    auth,
    image,
    setImage: handleImage,
    errors,
    selectors,
    setSelectors: handleSelectors,
    onSubmit,
    selectedData,
    isLoading,
    isFetching,
    isError,
    ref,
    onAddressCheck,
  };
};
