import {
  adminRoutes,
  errorNotify,
  filterUndefined,
  getClassCode,
  infoNotify,
} from "@/services";
import { useAddBulkStudentsMutation } from "@/store/modules/admin/institute/studentBulkInsert/api";
import {
  removeStudentList,
  resetStudentBulkSelectors,
  setSelectedStudentBulk,
  setStudentBulkPageData,
  setStudentBulkSelectors,
  setStudentBulkShowCsv,
  updateBulkStudent,
} from "@/store/modules/admin/institute/studentBulkInsert/slice";
import moment from "moment";
import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const useBulkStudentBulkFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminStudentBulk);
  const [class_code] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code);

  const handleUpdateSelectors = (values) => {
    dispatch(setStudentBulkSelectors(values));
  };

  const handleReset = () => {
    dispatch(resetStudentBulkSelectors());
  };

  const handleFilter = () => {
    if (
      !selectors?.current_section ||
      !selectors?.academic_year ||
      !selectors?.current_class ||
      !selectors?.current_category
    ) {
      return errorNotify("Please select academic year, class and section");
    }

    dispatch(setStudentBulkShowCsv(true));
  };

  return {
    selectors,
    classCode,
    handleUpdateSelectors,
    handleReset,
    handleFilter,
  };
};

export const useBulkStudents = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { dataLists, pageData, allData, selectors,selectedData } = useSelector(
    (state) => state.adminStudentBulk
  );
  const { currentPage, pageSize, totalPages } = pageData;
  const [addBulkStudents, { isLoading }] = useAddBulkStudentsMutation();
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const updatePage = (values) => {
    dispatch(setStudentBulkPageData(values));
  };

  const handleSelectData = (item) => {
    if (item?.type === "delete") {
      dispatch(removeStudentList(item?.index));
    } else if(item?.type === "update") {
      dispatch(setSelectedStudentBulk(item));
      const dob = item?.date_of_birth
        ? moment(item?.date_of_birth).format("YYYY-MM-DD")
        : null;
      const bulkSelectors = {
        blood_group: item?.blood_group,
        date_of_birth: {
          startDate: dob,
          endDate: dob,
        },
        disability: item?.disability,
        gender: item?.gender,
        academic_year: item?.academic_year,
        religion: item?.religion,
      };
      dispatch(setStudentBulkSelectors(bulkSelectors));
      navigate(adminRoutes.institute.students.updateBulkStudent.path);
    } else {
      dispatch(setSelectedStudentBulk(item));
    }
  };

  const handleReset = () => {
    dispatch(resetStudentBulkSelectors());
    dispatch(setStudentBulkShowCsv(false));
  };
  const handleSubmit = () => {
    const [_, class_id] = getClassCode(selectors?.current_class);
    const modifiedData = allData.map((item) => {
      let data = {
        ...item,
        current_roll_number: item?.current_roll_number
          ? Number(item?.current_roll_number)
          : null,
        academic_year: selectors?.academic_year,
        current_class: class_id,
        current_section: selectors?.current_section,
        current_group: selectors?.current_group,
        current_category: selectors?.current_category,
        institute_id,
        status: "active",
      };
      return filterUndefined(data);
    });

    // remove group if it's not available

    const formData = new FormData();
    formData.append("data", JSON.stringify(modifiedData));

    addBulkStudents(formData)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(resetStudentBulkSelectors());
        dispatch(setStudentBulkShowCsv(false));
      })
      .catch((err) => {
        errorNotify(err?.data?.message);
      });
  };

  return {
    dataLists,
    handleSelectData,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    handleReset,
    handleSubmit,
    isLoading,
    length: allData?.length,
    selectedData
  };
};

export const useUpdateBulkStudent = () => {
  const ref = useRef(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { selectedData, selectors } = useSelector(
    (state) => state.adminStudentBulk
  );

  const [errors, setErrors] = useState({});

  const onSubmit = (event) => {
    event.preventDefault();
    const eventTarget = event.target;
    const form = new FormData(eventTarget);
    const entities = Object.fromEntries(form.entries());
    const date_of_birth = moment(entities?.date_of_birth).format("YYYY-MM-DD");
    const data = {
      ...selectedData,
      ...selectors,
      ...entities,
      date_of_birth,
    };
    dispatch(updateBulkStudent(data));
    navigate(adminRoutes.institute.students.bulkImport.path);
  };

  const onAddressCheck = (val) => {
    if (ref.current) {
      const presentFields = ref.current.querySelectorAll(
        "[data-type='present']"
      );
      const permanentFields = ref.current.querySelectorAll(
        "[data-type='permanent']"
      );

      presentFields.forEach((presentField, index) => {
        if (permanentFields[index]) {
          permanentFields[index].value = val ? presentField?.value : "";
        }
      });
    }
  };

  const onGurdianCheck = (event) => {
    const value = event.target.value;
    const fatherFields = ref.current.querySelectorAll("[data-type='father']");
    const motherFields = ref.current.querySelectorAll("[data-type='mother']");
    const gardianFields = ref.current.querySelectorAll(
      "[data-type='guardian']"
    );

    if (value === "father") {
      gardianFields.forEach((gardianField, index) => {
        if (fatherFields[index]) {
          gardianField.value = fatherFields[index]?.value;
        }
      });
    } else {
      gardianFields.forEach((gardianField, index) => {
        if (motherFields[index]) {
          gardianField.value = motherFields[index]?.value;
        }
      });
    }
  };

  const setSelector = (value) => {
    dispatch(setStudentBulkSelectors(value));
  };

  useEffect(() => {
    if (!selectedData?.index && selectedData?.index !== 0) {
      navigate(adminRoutes.institute.students.bulkImport.path);
    }
  }, []);

  return {
    selectors,
    selectedData,
    onSubmit,
    errors,
    setSelector,
    ref,
    onAddressCheck,
    onGurdianCheck,
  };
};
