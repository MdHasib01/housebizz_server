import {
  adminRoutes,
  checkValidation,
  errorNotify,
  filterUndefined,
  getClassCode,
  infoNotify,
  studentAddSchema,
  studentAdmissionSchema,
} from "@/services";
import {
  useAddStudentMutation,
  useDeleteStudentMutation,
  useGetFilteredStudentsQuery,
  useGetStudentQuery,
  useStudentBulkActionMutation,
  useUpdateStudentMutation,
} from "@/store/modules/admin/institute/studentManagement/api";
import {
  closeStudentManagementModal,
  removeBulkStudentList,
  removeStudentList,
  resetStudentManagementSelectors,
  resetStudentSelection,
  selectAllStudentManagement,
  setSelectedStudentManagement,
  setStudentManagementFetchData,
  setStudentManagementImage,
  setStudentManagementPageData,
  setStudentManagementSearchValue,
  setStudentManagementSelectors,
  setStudentManagementShowTable,
  toggleSelectedStudentManagement,
} from "@/store/modules/admin/institute/studentManagement/slice";
import moment from "moment";
import { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { useReactToPrint } from "react-to-print";

export const useStudentManagementFilter = () => {
  const dispatch = useDispatch();
  const { selectors } = useSelector((state) => state.adminStudentManagement);
  const [class_code, _] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code);

  const handleUpdateSelectors = (values) => {
    dispatch(setStudentManagementSelectors(values));
  };

  const handleReset = () => {
    dispatch(resetStudentManagementSelectors());
  };

  const handleFilter = () => {
    if (
      !selectors?.current_class &&
      !selectors?.current_section &&
      !selectors?.academic_year &&
      !selectors?.current_category
    ) {
      return errorNotify("Please select at least one filter");
    }
    dispatch(setStudentManagementShowTable(true));
    dispatch(setStudentManagementFetchData(true));
  };
  return {
    selectors,
    classCode,
    handleUpdateSelectors,
    handleReset,
    handleFilter,
  };
};

export const useStudentManagement = () => {
  const dispatch = useDispatch();
  const {
    dataLists,
    selectedData,
    pageData,
    showModal,
    student_ids,
    searchValue,
    fetchData,
    selectors,
    students,
  } = useSelector((state) => state.adminStudentManagement);

  const { currentPage, pageSize, totalPages, totalItems } = pageData || {};
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [action, setAction] = useState("");
  const [pdfLoading, setPdfLoading] = useState(false);
  const ref = useRef(null);

  const querySelectors = {
    category_id: selectors?.current_category,
    class_id: getClassCode(selectors?.current_class)[1],
    section_id: selectors?.current_section,
    academic_year: selectors?.academic_year,
    group_id: selectors?.current_group,
    gender: selectors?.gender,
    religion: selectors?.religion,
    institute_id,
    status: "active",
  };

  let query = Object.keys(querySelectors).reduce((acc, key) => {
    if (querySelectors[key]) {
      return `${acc}${key}=${querySelectors[key]}&`;
    }
    return acc;
  }, "");

  const { isFetching, isError, error } = useGetFilteredStudentsQuery(
    { query },
    {
      skip: !institute_id || !fetchData,
      refetchOnMountOrArgChange: true,
    }
  );

  const [deleteStudent, { isLoading: isDeleting }] = useDeleteStudentMutation();
  const [studentBulkAction, { isLoading: isBulkActionLoading }] =
    useStudentBulkActionMutation();

  const onPrint = useReactToPrint({
    contentRef: ref,
    documentTitle: "student",
    onBeforePrint: () => {
      setPdfLoading(true);
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setPdfLoading(false);
        }, 900);
      });
    },
  });
  const handleSelect = (value) => {
    dispatch(setSelectedStudentManagement(value));
    if (value?.type === "pdf") {
      setTimeout(() => {
        onPrint();
      }, 100);
    }
  };
  const handleSelectAllStudent = () => {
    dispatch(selectAllStudentManagement());
  };

  const handleToggleSelectStudent = (student) => {
    dispatch(toggleSelectedStudentManagement(student));
  };

  const updatePage = (value) => {
    dispatch(setStudentManagementPageData(value));
  };

  const handleSearchValue = (event) => {
    dispatch(setStudentManagementSearchValue(event.target.value));
  };

  const closeModal = () => {
    dispatch(closeStudentManagementModal());
    dispatch(setSelectedStudentManagement({}));
  };

  const removeStudentAdmission = () => {
    dispatch(closeStudentManagementModal());
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({ institute_id: selectedData?.institute_id })
    );
    const query = `?institute_id=${institute_id}&student_id=${selectedData?._id}`;
    deleteStudent(query)
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
        dispatch(removeStudentList());
      })
      .catch((error) => {
        errorNotify(error.data?.message);
      });
  };

  const handleAction = () => {
    if (student_ids?.length === 0) return errorNotify("Please select student");
    studentBulkAction(action)
      .unwrap()
      .then((res) => {
        if (action === "export") {
          setAction("");
          dispatch(resetStudentSelection());
          return;
        }
        if (action === "remove") {
          dispatch(removeBulkStudentList());
        }
        setAction("");
        dispatch(resetStudentSelection());
        infoNotify(res?.message);
      })
      .catch((error) => {
        errorNotify(error?.message);
      });
  };

  return {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status: error?.status,
    isLoading: isDeleting || isBulkActionLoading,
    handleSelect,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    student_ids,
    handleSelectAllStudent,
    handleToggleSelectStudent,
    handleSearchValue,
    searchValue,
    isAllSelected: student_ids?.length === dataLists?.length,
    dataLength: totalItems,
    action,
    setAction,
    handleAction,
    pdfLoading,
    ref,
  };
};

export const useAddStudent = () => {
  const ref = useRef(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { selectors, image } = useSelector(
    (state) => state.adminStudentManagement
  );
  const [errors, setErrors] = useState({});
  const [addStudent, { isLoading }] = useAddStudentMutation();
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [class_code, class_id] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code || 0);

  const setSelector = (values) => {
    dispatch(setStudentManagementSelectors(values));
  };

  const handleImage = (value) => {
    dispatch(setStudentManagementImage(value));
  };

  const onAddressCheck = (val) => {
    if (ref.current) {
      const presentFields = ref.current.querySelectorAll(
        "[data-type='present']"
      );
      const permanentFields = ref.current.querySelectorAll(
        "[data-type='permanent']"
      );

      presentFields.forEach((presentField, index) => {
        if (permanentFields[index]) {
          permanentFields[index].value = val ? presentField?.value : "";
        }
      });
    }
  };

  const onGurdianCheck = (event) => {
    const value = event.target.value;
    const fatherFields = ref.current.querySelectorAll("[data-type='father']");
    const motherFields = ref.current.querySelectorAll("[data-type='mother']");
    const gardianFields = ref.current.querySelectorAll(
      "[data-type='guardian']"
    );

    if (value === "father") {
      gardianFields.forEach((gardianField, index) => {
        if (fatherFields[index]) {
          gardianField.value = fatherFields[index]?.value;
        }
      });
    } else {
      gardianFields.forEach((gardianField, index) => {
        if (motherFields[index]) {
          gardianField.value = motherFields[index]?.value;
        }
      });
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const eventTarget = event.target;
    const form = new FormData(eventTarget);
    const entries = Object.fromEntries(form.entries());
    const dateOfBirtth = selectors?.date_of_birth?.startDate
      ? moment(selectors?.date_of_birth?.startDate).format("YYYY-MM-DD")
      : "";
    let data = {
      ...entries,
      ...selectors,
      current_roll_number: entries?.current_roll_number
        ? Number(entries?.current_roll_number)
        : null,
      current_class: class_id,
      entity_type: "student",
      institute_id: institute_id,
      date_of_birth: dateOfBirtth,
      status: "active",
      transaction_id: "123456",
    };
    if (image?.key) {
      data.image = image?.key;
    }
    const results = studentAdmissionSchema.safeParse(data);
    const { isError, error } = checkValidation(results);
    if (isError) {
      setErrors(error);
      return;
    } else {
      setErrors({});
      const filteredData = filterUndefined(data);
      const formData = new FormData();
      formData.append("data", JSON.stringify(filteredData));
      addStudent(formData)
        .unwrap()
        .then((res) => {
          eventTarget.reset();
          dispatch(resetStudentManagementSelectors());
          infoNotify(res?.message);
          handleImage({});
          navigate(adminRoutes.institute.students.management.path);
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };

  return {
    selectors,
    setSelector,
    onSubmit,
    errors,
    isLoading,
    institute_id,
    classCode,
    image,
    setImage: handleImage,
    onAddressCheck,
    ref,
    onGurdianCheck,
  };
};

export const useUpdateStudent = () => {
  const ref = useRef(null);
  const { id } = useParams();
  const dispatch = useDispatch();
  const { selectors, selectedData, image } = useSelector(
    (state) => state.adminStudentManagement
  );
  const [errors, setErrors] = useState({});
  const [updateStudent, { isLoading }] = useUpdateStudentMutation();
  const [openModal, setOpenModal] = useState(false);
  const { auth } = useSelector((state) => state.auth);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const [class_code, class_id] = getClassCode(selectors?.current_class);
  const classCode = Number(class_code || 0);
  const navigate = useNavigate();

  const query = `institute_id=${institute_id}&student_id=${id}`;

  const { isFetching, isError } = useGetStudentQuery(
    { query },
    {
      skip: !institute_id || !id,
      refetchOnMountOrArgChange: true,
    }
  );

  const handleImage = (value) => {
    dispatch(setStudentManagementImage(value));
  };

  const setSelector = (values) => {
    dispatch(setStudentManagementSelectors(values));
  };

  const onAddressCheck = (val) => {
    if (ref.current) {
      const presentFields = ref.current.querySelectorAll(
        "[data-type='present']"
      );
      const permanentFields = ref.current.querySelectorAll(
        "[data-type='permanent']"
      );

      presentFields.forEach((presentField, index) => {
        if (permanentFields[index]) {
          permanentFields[index].value = val ? presentField?.value : "";
        }
      });
    }
  };

  const onGurdianCheck = (event) => {
    const value = event.target.value;
    const fatherFields = ref.current.querySelectorAll("[data-type='father']");
    const motherFields = ref.current.querySelectorAll("[data-type='mother']");
    const gardianFields = ref.current.querySelectorAll(
      "[data-type='guardian']"
    );

    if (value === "father") {
      gardianFields.forEach((gardianField, index) => {
        if (fatherFields[index]) {
          gardianField.value = fatherFields[index]?.value;
        }
      });
    } else {
      gardianFields.forEach((gardianField, index) => {
        if (motherFields[index]) {
          gardianField.value = motherFields[index]?.value;
        }
      });
    }
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const eventTarget = event.target;
    const form = new FormData(eventTarget);
    const entries = Object.fromEntries(form.entries());
    const dateOfBirtth = selectors?.date_of_birth?.startDate
      ? moment(selectors?.date_of_birth?.startDate).format("YYYY-MM-DD")
      : "";
    let data = {
      ...entries,
      ...selectors,
      current_roll_number: entries?.current_roll_number
        ? Number(entries?.current_roll_number)
        : null,
      current_class: class_id,
      entity_type: "student",
      institute_id: institute_id,
      date_of_birth: dateOfBirtth,
    };

    if (image?.key) {
      data.image = image?.key;
    }

    const results = studentAddSchema.safeParse(data);
    const { isError, error } = checkValidation(results);
    if (isError) {
      setErrors(error);
      return;
    } else {
      setErrors({});
      const filteredData = filterUndefined(data);
      const formData = new FormData();
      formData.append("data", JSON.stringify(filteredData));
      updateStudent({ data: formData, query })
        .unwrap()
        .then((res) => {
          dispatch(resetStudentManagementSelectors());
          eventTarget.reset();
          infoNotify(res?.message);
          navigate(adminRoutes.institute.students.management.path);
        })
        .catch((error) => {
          errorNotify(error.data?.message);
        });
    }
  };
  return {
    selectors,
    setSelector,
    onSubmit,
    errors,
    isLoading,
    openModal,
    setOpenModal,
    institute_id,
    classCode,
    selectedData,
    isFetching,
    isError,
    image,
    setImage: handleImage,
    onAddressCheck,
    ref,
    onGurdianCheck,
  };
};
