import SelectCategory from "@/components/admin/admin/institute/category/SelectCategory";
import SelectLocalClass from "@/components/admin/admin/institute/class/SelectLocalClass";
import SelectSection from "@/components/admin/admin/institute/section/SelectSection";
import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import BanglaInput from "@/components/shared/BanglaInput";
import Divider from "@/components/shared/Divider";
import ErrorUi from "@/components/shared/ErrorUi";
import ImageUploadProfile from "@/components/shared/ImageUploadProfile";
import Input from "@/components/shared/Input";
import NumberInput from "@/components/shared/NumberInput";
import RequestLoading from "@/components/shared/RequestLoading";
import SelectBloodGroup from "@/components/shared/SelectBloodGroup";
import SelectDisability from "@/components/shared/SelectDisability";
import SelectGender from "@/components/shared/SelectGender";
import SelectReligion from "@/components/shared/SelectReligion";
import TWDatePicker from "@/components/shared/TWDatePicker";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useAddStudentAdmison } from "@/hooks";
import { MailIcon, PhoneIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";

function StudentAdmission() {
  const {
    isFetching,
    isError,
    isLoading,
    onSubmit,
    setSelector,
    errors,
    image,
    setImage,
    selectors,
    selectedInstituteManagement,
    institute_id,
    classCode,
    onAddressCheck,
    onGurdianCheck,
    institute_type,
    ref,
  } = useAddStudentAdmison();

  return (
    <div className="min-h-screen bg-mainGradient px-4 py-10 sm:py-16 md:py-20">
      <div className="p-6 sm:p-10 sm:pt-14 bg-white max-w-[840px] mx-auto shadow-lg shadow-text-100 rounded-2xl">
        <div className="text-center">
          {isFetching ? (
            <div>
              <div className="pulse h-8 rounded max-w-96 mx-auto"></div>
              <div className="pulse h-5 rounded max-w-96 mx-auto mt-3 mb-2"></div>
              <div className="pulse h-4 rounded max-w-96 mx-auto"></div>
            </div>
          ) : (
            !isError && (
              <div>
                <h2 className="text-xl sm:text-2xl md:text-3xl font-medium">
                  {selectedInstituteManagement?.institute_name}
                </h2>
                <p className="text-sm sm:text-base mt-2">
                  {selectedInstituteManagement?.institute_upazilla},{" "}
                  {selectedInstituteManagement?.institute_district} -{" "}
                  {selectedInstituteManagement?.institute_postal_code}
                </p>
                <div className="flex items-center gap-4 justify-center mt-2">
                  <a
                    href={`tel:${selectedInstituteManagement?.institute_mobilephone}`}
                    className="flex items-center gap-1.5"
                  >
                    <PhoneIcon color={colors.text[700]} />
                    {selectedInstituteManagement?.institute_mobilephone}
                  </a>
                  <a
                    href={`mailto:${selectedInstituteManagement?.institute_email}`}
                    className="flex items-center gap-1.5"
                  >
                    <MailIcon />
                    {selectedInstituteManagement?.institute_email}
                  </a>
                </div>
              </div>
            )
          )}

          <p className="text-lg sm:text-xl mt-4 sm:mt-6 mb-6 sm:mb-10 font-medium bg-neutral-100 p-2 rounded-md">
            Admission Form
          </p>
          <Divider title="Student Basic Information" />
        </div>
        <form
          onSubmit={onSubmit}
          action=""
          className="flex flex-col gap-6 mt-6"
          ref={ref}
        >
          <div className="grid sm:grid-cols-2 gap-4">
            <Input
              placeholder="Full Name (in English)"
              name="name_english"
              label="Full Name (in English)"
              labelClass="required"
              wrapper="sm:col-span-2"
              errorMessage={errors?.name_english}
              required
            />
            <BanglaInput
              placeholder="Full Name (in Bangla)"
              name="name_bangla"
              label="Full Name (in Bangla)"
              wrapper="sm:col-span-2"
              errorMessage={errors?.name_bangla}
            />
            <Input
              placeholder="Mobile Number"
              name="mobile_number"
              label="Mobile Number"
              errorMessage={errors?.mobile_number}
              labelClass="required"
              required
            />
            <SelectGender
              value={selectors?.gender}
              onValueChange={(value) => setSelector({ gender: value })}
              placeholder="Select Gender"
              label="Gender"
              errorMessage={errors?.gender}
              labelClass="required"
              required
            />
            <TWDatePicker
              value={selectors?.date_of_birth}
              setValue={(value) => setSelector({ date_of_birth: value })}
              placeholder="Select Date"
              label="Date of Birth"
              errorMessage={errors?.date_of_birth}
            />
            <Input
              placeholder="Birth Certificate Number"
              name="birth_certificate_number"
              label="Birth Certificate Number"
              errorMessage={errors?.birth_certificate_number}
            />
            <Input
              type="email"
              placeholder="Email"
              name="email"
              label="Email"
              wrapper="sm:col-span-2"
              errorMessage={errors?.email}
            />
            <Input
              placeholder="Nationality"
              name="nationality"
              label="Nationality"
              defaultValue="Bangladeshi"
              errorMessage={errors?.nationality}
            />
            <SelectReligion
              value={selectors?.religion}
              onValueChange={(value) => setSelector({ religion: value })}
              label="Religion"
              errorMessage={errors?.religion}
              labelClass="required"
              required
            />
            <SelectBloodGroup
              value={selectors?.blood_group}
              onValueChange={(value) => setSelector({ blood_group: value })}
              label="Blood Group"
              errorMessage={errors?.blood_group}
            />
            <SelectDisability
              value={selectors?.disability}
              onValueChange={(value) => setSelector({ disability: value })}
              label="Special Child/Disability"
              errorMessage={errors?.disability}
            />
          </div>
          <Divider title="Academic Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <SelectLocalSessionYear
              value={selectors?.academic_year}
              onValueChange={(value) => setSelector({ academic_year: value })}
              label="Year/Session"
              isLoading={isFetching}
              institute_type={institute_type}
              errorMessage={errors?.academic_year}
              labelClass="required"
              required
            />
            <SelectLocalClass
              value={selectors?.current_class}
              onValueChange={(value) =>
                setSelector({
                  current_class: value,
                  current_group: "",
                  current_section: "",
                })
              }
              label="Class"
              errorMessage={errors?.current_class}
              isLoading={isFetching}
              institute_id={institute_id}
              visibleItem={true}
              labelClass="required"
              required
            />
            {classCode > 8 && (
              <SelectLocalGroup
                value={selectors?.current_group}
                onValueChange={(value) =>
                  setSelector({ current_group: value, current_section: "" })
                }
                label="Group"
                errorMessage={errors?.current_group}
                isLoading={isFetching}
                classCode={classCode}
              />
            )}
            <SelectSection
              value={selectors?.current_section}
              onValueChange={(value) => setSelector({ current_section: value })}
              triggerClass="!bg-white"
              label="Select Section"
              isFiltered={true}
              isLoading={isFetching}
              institute_id={institute_id}
              classCode={classCode}
              labelClass="required"
              group_id={selectors?.current_group}
              required
            />
            <SelectCategory
              value={selectors?.current_category}
              onValueChange={(value) =>
                setSelector({ current_category: value })
              }
              label="Select Category"
              errorMessage={errors?.current_category}
              isLoading={isFetching}
              institute_id={institute_id}
              labelClass="required"
              required
            />
          </div>
          <Divider title="Previous Institute Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              placeholder="Name of The Institution"
              name="previous_insitute_name"
              label="Name of The Institution"
              wrapper="sm:col-span-2"
              errorMessage={errors?.previous_insitute_name}
            />
            <Input
              placeholder="Class"
              name="previous_class"
              label="Class"
              errorMessage={errors?.previous_class}
            />
            <Input
              placeholder="Result"
              name="previous_result"
              label="Result"
              errorMessage={errors?.previous_result}
            />
          </div>
          <Divider title="Father's Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              placeholder="Father Name (in English)"
              name="father_name_english"
              label="Name (in English)"
              wrapper="sm:col-span-2"
              labelClass="required"
              required
              errorMessage={errors?.father_name_english}
              data-type="father"
            />
            <BanglaInput
              placeholder="Father Name (in Bangla)"
              name="father_name_bangla"
              label="Name (in Bangla)"
              wrapper="sm:col-span-2"
              errorMessage={errors?.father_name_bangla}
              data-type="father"
            />
            <Input
              placeholder="Father Mobile Number"
              name="father_mobile_number"
              label="Mobile Number"
              errorMessage={errors?.father_mobile_number}
              data-type="father"
            />
            <NumberInput
              placeholder="Father NID Number"
              name="father_nid_number"
              label="NID Number"
              errorMessage={errors?.father_nid_number}
              data-type="father"
            />
            <Input
              placeholder="Father Profession"
              name="father_profession"
              label="Profession"
              wrapper="sm:col-span-2"
              errorMessage={errors?.father_profession}
              data-type="father"
            />
          </div>
          <Divider title="Mother's Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              placeholder="Mother Name (in English)"
              name="mother_name_english"
              label="Name (in English)"
              wrapper="sm:col-span-2"
              errorMessage={errors?.mother_name_english}
              data-type="mother"
            />
            <BanglaInput
              placeholder="Mother Name (in Bangla)"
              name="mother_name_bangla"
              label="Name (in Bangla)"
              wrapper="sm:col-span-2"
              errorMessage={errors?.mother_name_bangla}
              data-type="mother"
            />
            <Input
              placeholder="Mother Mobile Number"
              name="mother_mobile_number"
              label="Mobile Number"
              errorMessage={errors?.mother_mobile_number}
              data-type="mother"
            />
            <NumberInput
              placeholder="Mother NID Number"
              name="mother_nid_number"
              label="NID Number"
              errorMessage={errors?.mother_nid_number}
              data-type="mother"
            />
            <Input
              placeholder="Mother Profession"
              name="mother_profession"
              label="Profession"
              wrapper="sm:col-span-2"
              errorMessage={errors?.mother_profession}
              data-type="mother"
            />
          </div>
          <Divider title="Guardian's Information" />
          <div className="flex items-center space-x-2 relative">
            <label
              htmlFor="father"
              className="flex items-center space-x-2 border border-neutral-300 p-2 rounded-lg cursor-pointer"
            >
              <input
                type="radio"
                name="gurdian"
                onClick={onGurdianCheck}
                value="father"
                id="father"
              />
              <span className="text-sm text-text-900">Same as Father</span>
            </label>
            <label
              htmlFor="mother"
              className="flex items-center space-x-2 border border-neutral-300 p-2 rounded-lg cursor-pointer"
            >
              <input
                type="radio"
                name="gurdian"
                onClick={onGurdianCheck}
                value="mother"
                id="mother"
              />
              <span className="text-sm text-text-900">Same as Mother</span>
            </label>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              placeholder="Guardian Name (in English)"
              name="guardian_name_english"
              label="Name (in English)"
              wrapper="sm:col-span-2"
              errorMessage={errors?.guardian_name_english}
              data-type="guardian"
            />
            <Input
              placeholder="Guardian Name (in Bangla)"
              name="guardian_name_bangla"
              label="Name (in Bangla)"
              wrapper="sm:col-span-2"
              errorMessage={errors?.guardian_name_bangla}
              data-type="guardian"
            />
            <Input
              placeholder="Guardian Mobile Number"
              name="guardian_mobile_number"
              label="Mobile Number"
              errorMessage={errors?.guardian_mobile_number}
              data-type="guardian"
            />
            <NumberInput
              placeholder="Guardian NID Number"
              name="guardian_nid_number"
              label="NID Number"
              errorMessage={errors?.guardian_nid_number}
              data-type="guardian"
            />
            <Input
              placeholder="Guardian Profession"
              name="guardian_profession"
              label="Profession"
              wrapper="sm:col-span-2"
              errorMessage={errors?.guardian_profession}
              data-type="guardian"
            />
          </div>
          <Divider title="Present Address Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              placeholder="House no, road no..."
              name="present_address_line"
              label="Present Address"
              wrapper="sm:col-span-2"
              errorMessage={errors?.present_address_line}
              data-type="present"
            />
            <Input
              placeholder="Present District"
              name="present_address_district"
              label="District"
              errorMessage={errors?.present_address_district}
              data-type="present"
            />
            <Input
              placeholder="Present Upazilla"
              name="present_address_upozilla"
              label="Upazilla"
              errorMessage={errors?.present_address_upozilla}
              data-type="present"
            />
            <Input
              placeholder="Present Post Office"
              name="present_address_post_office"
              label="Post Office"
              errorMessage={errors?.present_address_post_office}
              data-type="present"
            />
            <NumberInput
              placeholder="Present Post Code"
              name="present_address_post_code"
              label="Post Code"
              errorMessage={errors?.present_address_post_code}
              data-type="present"
            />
          </div>
          <Divider title="Permanent Address Information" />
          <div className="flex items-center space-x-2 relative">
            <Checkbox id="address" onCheckedChange={onAddressCheck} />
            <label
              htmlFor="address"
              className="text-sm font-medium cursor-pointer"
            >
              Same as Present Address
            </label>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              placeholder="House no, road no..."
              name="permanent_address_line"
              label="Permanent Address"
              wrapper="sm:col-span-2"
              errorMessage={errors?.permanent_address_line}
              data-type="permanent"
            />
            <Input
              placeholder="Permanent District"
              name="permanent_address_district"
              label="District"
              errorMessage={errors?.permanent_address_district}
              data-type="permanent"
            />
            <Input
              placeholder="Permanent Upazilla"
              name="permanent_address_upozilla"
              label="Upazilla"
              errorMessage={errors?.permanent_address_upozilla}
              data-type="permanent"
            />
            <Input
              placeholder="Permanent Post Office"
              name="permanent_address_post_office"
              label="Post Office"
              errorMessage={errors?.permanent_address_post_office}
              data-type="permanent"
            />
            <NumberInput
              placeholder="Permanent Post Code"
              name="permanent_address_post_code"
              label="Post Code"
              errorMessage={errors?.permanent_address_post_code}
              data-type="permanent"
            />
          </div>
          <Divider title="Transaction Information" />
          <Input
            placeholder="Transaction ID"
            name="transaction_id"
            label="Transaction ID"
            wrapper="sm:col-span-2"
            errorMessage={errors?.transaction_id}
          />
          <Divider title="Passport Size Image" />
          <ImageUploadProfile
            image={image?.fileUrl}
            setImage={setImage}
            inputWrapper="w-32 h-32 rounded-full flex-col-reverse justify-center"
          />
          <div className="flex items-center justify-end border-t pt-6">
            <Button
              type="submit"
              className="h-12 min-w-[132px] ml-4"
              size="lg"
              disabled={isError}
            >
              Submit
            </Button>
          </div>
        </form>
        {!isFetching && isError && <ErrorUi wrapper="py-10" />}
      </div>
      {isLoading && <RequestLoading />}
    </div>
  );
}

export default StudentAdmission;
