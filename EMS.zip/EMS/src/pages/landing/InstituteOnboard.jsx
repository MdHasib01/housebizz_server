import SelectBoard from "@/components/admin/superAdmin/global/boardManagement/SelectBoard";
import SelectInstituteType from "@/components/admin/superAdmin/global/sessionYear/SelectInstituteType";
import DialogExtended from "@/components/shared/DialogExtended";
import Input from "@/components/shared/Input";
import NumberInput from "@/components/shared/NumberInput";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddInstitute } from "@/hooks/superAdmin/administrator/useInstituteOnboard";
import { images, userRoutes } from "@/services";
import { Link } from "react-router-dom";

function InstituteOnboard() {
  const {
    selectors,
    setSelectors,
    type,
    setType,
    errors,
    onSubmit,
    isLoading,
    openModal,
    setOpenModal,
  } = useAddInstitute("onboard");

  return (
    <section className="bg-natural-100 min-h-screen p-10">
      <div className="w-full max-w-[1160px] mx-auto bg-white px-12 py-14 rounded-2xl">
        <form onSubmit={onSubmit} action="">
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="flex items-center gap-4 sm:col-span-2">
              <h2 className="text-lg font-semibold text-text-700">
                Basic Information
              </h2>
              <div className="flex-1 h-[1px] bg-natural-400"></div>
            </div>
            <Input
              placeholder="Enter full name"
              name="institute_name"
              label="Institute Name"
              errorMessage={errors?.institute_name}
              labelClass="required"
              required
            />
            <Input
              placeholder="Enter short name"
              name="institute_short_name"
              label="Short Name"
              errorMessage={errors?.institute_short_name}
              labelClass="required"
              required
            />
            <SelectInstituteType
              value={selectors?.institute_type}
              onValueChange={(val) => setSelectors({ institute_type: val })}
              placeholder="Select type"
              label="Type"
              errorMessage={errors?.institute_type}
              labelClass="required"
              required
            />
            <SelectBoard
              value={selectors?.institute_board_id}
              onValueChange={(val) => setSelectors({ institute_board_id: val })}
              label="Board"
              errorMessage={errors?.institute_board_id}
              labelClass="required"
              required
            />
            <Input
              placeholder="ESTD"
              name="estd_code"
              label="ESTD"
              errorMessage={errors?.estd_code}
              labelClass="required"
              required
            />
            <div className="flex items-center gap-4 sm:col-span-2">
              <h2 className="text-lg font-semibold text-text-700">
                Identification Codes
              </h2>
              <div className="flex-1 h-[1px] bg-natural-400"></div>
            </div>
            <Input
              placeholder="Enter school code"
              name="board_school_code"
              label="School Code"
              errorMessage={errors?.board_institute_code}
            />
            <Input
              placeholder="Enter college code"
              name="board_collage_code"
              label="College Code"
              errorMessage={errors?.board_institute_code}
            />
            <NumberInput
              placeholder="Enter EIIN"
              name="eiin_number"
              label="EIIN Code"
              errorMessage={errors?.eiin_number}
              labelClass="required"
              required
            />
            <div className="flex items-center gap-4 sm:col-span-2">
              <h2 className="text-lg font-semibold text-text-700">
                Location Details
              </h2>
              <div className="flex-1 h-[1px] bg-natural-400"></div>
            </div>
            <Input
              placeholder="Enter address line"
              name="institute_address"
              label="Address Line"
              wrapper="col-span-2"
              errorMessage={errors?.institute_address}
              labelClass="required"
              required
            />
            <Input
              placeholder="Enter post office"
              name="institute_post_office"
              label="Post Office"
              errorMessage={errors?.institute_post_office}
              labelClass="required"
              required
            />
            <Input
              placeholder="Enter post code"
              name="institute_postal_code"
              label="Post Code"
              errorMessage={errors?.institute_postal_code}
              labelClass="required"
              required
            />
            <Input
              placeholder="Enter upazila"
              name="institute_upazilla"
              label="Upazila"
              errorMessage={errors?.institute_upazilla}
              labelClass="required"
              required
            />
            <Input
              placeholder="Enter district"
              name="institute_district"
              label="District"
              errorMessage={errors?.institute_district}
              labelClass="required"
              required
            />
            <div className="flex items-center gap-4 sm:col-span-2">
              <h2 className="text-lg font-semibold text-text-700">
                Contact Information
              </h2>
              <div className="flex-1 h-[1px] bg-natural-400"></div>
            </div>
            <Input
              type="email"
              placeholder="Enter email"
              name="institute_email"
              label="Email"
              errorMessage={errors?.institute_email}
              labelClass="required"
              required
            />
            <Input
              placeholder="Enter mobile no."
              name="institute_mobilephone"
              label="Mobile No."
              errorMessage={errors?.institute_mobilephone}
              labelClass="required"
              required
            />
            <Input
              placeholder="Enter phone no."
              name="institute_telephone"
              label="Phone No."
              errorMessage={errors?.institute_telephone}
              labelClass="required"
              required
            />

            <div className="flex items-center gap-4 sm:col-span-2">
              <h2 className="text-lg font-semibold text-text-700">
                School Capacity
              </h2>
              <div className="flex-1 h-[1px] bg-natural-400"></div>
            </div>
            <NumberInput
              placeholder="Institute Name"
              name="total_students"
              label="Enter total students"
              errorMessage={errors?.total_students}
              labelClass="required"
              required
            />
          </div>
          <div className="flex items-center justify-end mt-10">
            <Link
              className="h-12 min-w-[132px] btn_blue !bg-transparent !text-main-500 justify-center"
              to={userRoutes.home.path}
            >
              Cancel
            </Link>
            <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
              Create New Institute
            </Button>
          </div>
        </form>
      </div>
      {isLoading && <RequestLoading />}
      <DialogExtended
        isDialogOpen={openModal}
        setIsDialogOpen={setOpenModal}
        title="Successful!"
        text="The information has been updated successfully."
        imageSrc={images.checkGreen}
        customDialogButtons={
          <Button
            className="text-white h-12 w-full"
            size="lg"
            onClick={() => {
              setOpenModal(false);
            }}
          >
            Close
          </Button>
        }
      />
    </section>
  );
}

export default InstituteOnboard;
