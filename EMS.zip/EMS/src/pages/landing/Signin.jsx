import Image from "@/components/shared/Image";
import Input from "@/components/shared/Input";
import Password from "@/components/shared/password";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DotButton } from "@/hooks";
import { useSignin } from "@/hooks/auth";
import { cn } from "@/lib/utils";
import { images, userRoutes } from "@/services";
import { Link } from "react-router-dom";

function Signin() {
  const {
    handleInput,
    handleSelectChange,
    handleSubmit,
    signinInfo,
    isCompleteField,
    isLoading,
    emblaRef,
    selectedIndex,
    scrollSnaps,
  } = useSignin();

  return (
    <section className="h-screen overflow-hidden bg-white">
      <div className="h-full flex items-center">
        <div className="h-full px-4 py-6 sm:p-6 pt-20 w-full flex items-center justify-center flex-wrap overflow-auto text-center relative no-scrollbar">
          <div className="flex flex-row items-center gap-[6px] justify-start absolute top-6 left-4 sm:top-10 sm:left-10">
            <Image src={images.appLogo} alt="Logo" className="w-auto h-9" />
            <h1 className="font-black leading-none">SMART PATHSHALA</h1>
          </div>
          <div className="w-full  max-w-[420px] mx-auto flex flex-col gap-12">
            <div>
              <h2 className="text-4xl font-bold text-text-700">
                Welcome Back!
              </h2>
              <p className="text-base text-text-600 mt-2">
                Access your account by entering your credentials
              </p>
            </div>
            <form
              action="#"
              onSubmit={handleSubmit}
              className="flex flex-col gap-4"
            >
              <div className="flex flex-col gap-2 relative">
                <span className="label">Entity Type</span>
                <Select
                  value={signinInfo?.entity_type}
                  onValueChange={handleSelectChange}
                  name="entity_type"
                >
                  <SelectTrigger className="w-full h-[54px] outline-none input focus:ring-transparent !shadow-none">
                    <SelectValue placeholder="Select Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem
                      value="super_admin"
                      className="cursor-pointer py-2.5"
                    >
                      Super Admin
                    </SelectItem>
                    <SelectItem
                      value="staff_admin"
                      className="cursor-pointer py-2.5"
                    >
                      Staff Admin
                    </SelectItem>
                    <SelectItem
                      value="institute_admin"
                      className="cursor-pointer py-2.5"
                    >
                      Institute Admin
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {signinInfo?.entity_type === "institute_admin" && (
                <Input
                  placeholder="Enter your username"
                  name="institute_id"
                  label="Institute Id"
                  value={signinInfo?.institute_id}
                  onChange={handleInput}
                />
              )}

              <Input
                placeholder="Enter your username"
                name="username"
                label="Username"
                required
                value={signinInfo?.username}
                onChange={handleInput}
              />
              <Password
                name="password"
                placeholder="Password here"
                label="Password"
                required
                value={signinInfo?.password}
                onChange={handleInput}
              ></Password>

              <div className="mt-6">
                <Button
                  type="submit"
                  className="w-full py-4"
                  variant={isCompleteField ? "default" : "disabled"}
                  disabled={!isCompleteField}
                >
                  Signin
                </Button>
                <Link
                  to={userRoutes.instituteOnboard.path}
                  className="flex justify-center mt-3 rounded-lg text-white px-6 py-2 bg-blue-400"
                >
                  Onboard
                </Link>
              </div>
            </form>
          </div>
        </div>
        <div className="w-full h-full hidden md:flex flex-col gap-14 justify-end py-15 flex-wrap bg-main-500 relative">
          <div className="absolute left-0 top-0 w-full h-full">
            <Image
              src={images.loginBg}
              width="auto"
              height="auto"
              className="w-auto h-auto object-contain"
            />
          </div>
          <div
            className="relative overflow-hidden max-w-[576px] mx-auto"
            ref={emblaRef}
          >
            <div className="flex w-full">
              <div className="flex-1 min-w-full mx-auto text-white text-center p-6 relative z-10">
                <h2 className="md:text-2xl lg:text-3xl font-bold">
                  The Future of School Management
                </h2>
                <p className="leading-6 mt-2.5">
                  Effortless tracking, scheduling, and communication
                </p>
              </div>
              <div className="flex-1 min-w-full mx-auto text-white text-center p-6 relative z-10">
                <h2 className="md:text-2xl lg:text-3xl font-bold">
                  The Future of School Management
                </h2>
                <p className="leading-6 mt-2.5">
                  Effortless tracking, scheduling, and communication
                </p>
              </div>
            </div>
          </div>
          <div className="flex justify-center gap-2 z-20">
            {scrollSnaps?.map((_, index) => (
              <DotButton
                key={index}
                className={cn(
                  "bg-white w-2.5 h-2.5 aspect-square rounded-full duration-500",
                  index === selectedIndex ? "w-6" : "w-2.5 opacity-50"
                )}
              />
            ))}
          </div>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </section>
  );
}

export default Signin;
