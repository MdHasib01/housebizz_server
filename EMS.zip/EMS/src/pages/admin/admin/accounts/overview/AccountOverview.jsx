import AccountsOverviewCards from "@/components/admin/admin/accounts/overview/AccountsOverviewCards";
import MoneyDepositListTable from "@/components/admin/admin/accounts/overview/MoneyDepositTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const AccountOerview = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.accounts, adminRoutes.accounts.overview]}
    >
      <AccountsOverviewCards />
      <MoneyDepositListTable />
    </AdminPanelWrapper>
  );
};

export default AccountOerview;
