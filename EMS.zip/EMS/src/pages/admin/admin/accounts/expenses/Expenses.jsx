import ExpensesTable from "@/components/admin/admin/accounts/expenses/ExpensesTable";

import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import React from "react";

const Expenses = () => {
  return (
    <div>
      <AdminPanelWrapper
        crumbList={[adminRoutes.accounts, adminRoutes.accounts.expenses]}
      >
        <ExpensesTable />
      </AdminPanelWrapper>
    </div>
  );
};

export default Expenses;
