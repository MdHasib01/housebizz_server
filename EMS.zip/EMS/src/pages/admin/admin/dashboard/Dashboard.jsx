import BillsAndPayments from "@/components/admin/admin/dashboard/BillsAndPayments";
import BookInformation from "@/components/admin/admin/dashboard/BookInformation";
import DashboardBanner from "@/components/admin/admin/dashboard/DashboardBanner";
import DashboardCalender from "@/components/admin/admin/dashboard/DashboardCalender";
import Event from "@/components/admin/admin/dashboard/Event";
import ExamResults from "@/components/admin/admin/dashboard/ExamResults";
import NoticeBoard from "@/components/admin/admin/dashboard/NoticeBoard";
import Resident from "@/components/admin/admin/dashboard/Resident";
import StatsSummary from "@/components/admin/admin/dashboard/StatsSummary";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { useSelector } from "react-redux";

const Dashboard = () => {
  const {
    schoolInfo,
    noticeBoard,
    events,
    resident,
    bookInformation,
    examResults,
  } = useSelector((state) => state.adminDashboard);
  const { auth } = useSelector((state) => state.auth);



  return (
    <AdminPanelWrapper crumbTitle={"Welcome to Smart Pathshala"}>
      <div className="flex flex-col gap-5">
        <DashboardBanner auth={auth} />
        <StatsSummary auth={auth} />
        <div className="grid grid-cols-3 gap-5">
          <BillsAndPayments className={"col-span-2"} />
          <ExamResults item={examResults} className={"col-span-1"} />
        </div>
        <div className="grid grid-cols-3 gap-5">
          <Resident item={resident} />
          <BookInformation item={bookInformation} />
          <DashboardCalender />
        </div>
        <div className="grid grid-cols-2 gap-5">
          <NoticeBoard item={noticeBoard} />
          <Event item={events} />
        </div>
      </div>
    </AdminPanelWrapper>
  );
};

export default Dashboard;
