import TeacherListTable from "@/components/admin/admin/institute/teacher/TeacherListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const TeacherList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.teacher]}
    >
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common !px-4 py-7 gap-6">
        <TeacherListTable />
      </div>
    </AdminPanelWrapper>
  );
};

export default TeacherList;
