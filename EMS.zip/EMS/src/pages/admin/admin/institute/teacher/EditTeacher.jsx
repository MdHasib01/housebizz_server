import EditTeacherForm from "@/components/admin/admin/institute/teacher/EditTeacherForm";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const EditTeacher = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.teacher,
        adminRoutes.institute.teacher.editTeacher,
      ]}
    >
      <EditTeacherForm />
    </AdminPanelWrapper>
  );
};

export default EditTeacher;
