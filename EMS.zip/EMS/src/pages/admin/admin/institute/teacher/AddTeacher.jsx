import AddTeacherForm from "@/components/admin/admin/institute/teacher/AddTeacherForm";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const AddTeacher = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.teacher,
        adminRoutes.institute.teacher.addTeacher,
      ]}
    >
      <AddTeacherForm />
    </AdminPanelWrapper>
  );
};

export default AddTeacher;
