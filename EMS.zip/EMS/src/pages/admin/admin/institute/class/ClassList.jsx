import ClassListTable from "@/components/admin/admin/institute/class/ClassListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const ClassList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.class]}
    >
      <ClassListTable />
    </AdminPanelWrapper>
  );
};

export default ClassList;
