import StudentStatusTable from "@/components/admin/admin/institute/reports/StudentStatusTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const StudentStatus = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.reports,
        adminRoutes.institute.reports.studentStatus,
      ]}
    >
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common !px-4 py-7 gap-6">
        <StudentStatusTable />
      </div>
    </AdminPanelWrapper>
  );
};

export default StudentStatus;
