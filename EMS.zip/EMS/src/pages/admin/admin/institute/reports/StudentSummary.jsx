import StudentSummaryTable from "@/components/admin/admin/institute/reports/StudentSummaryTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const StudentSummary = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.reports,
        adminRoutes.institute.reports.studentSummary,
      ]}
    >
      <StudentSummaryTable />
    </AdminPanelWrapper>
  );
};

export default StudentSummary;
