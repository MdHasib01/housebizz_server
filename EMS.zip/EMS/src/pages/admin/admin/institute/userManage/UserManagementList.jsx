import UserManagementListTable from "@/components/admin/admin/institute/userManagement/UserManagementListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { adminRoutes } from "@/services";

const UserManagementList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.userManage]}
    >
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common py-7 gap-6">
        <PageHeader
          title="User Management"
          btnText="Add User"
          path={adminRoutes.institute.userManage.addUser.path}
        />
        <UserManagementListTable />
      </div>
    </AdminPanelWrapper>
  );
};

export default UserManagementList;
