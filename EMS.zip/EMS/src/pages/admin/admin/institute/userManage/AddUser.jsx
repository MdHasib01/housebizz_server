import AddUserForm from "@/components/admin/admin/institute/userManagement/AddUserForm";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const AddUser = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.userManage,
        adminRoutes.institute.userManage.addUser,
      ]}
    >
      <AddUserForm />
    </AdminPanelWrapper>
  );
};

export default AddUser;
