import CategoryListTable from "@/components/admin/admin/institute/category/CategoryListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const CategoryList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.category]}
    >
      <CategoryListTable />
    </AdminPanelWrapper>
  );
};

export default CategoryList;
