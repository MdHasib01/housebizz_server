import CSVUploader from "@/components/admin/admin/institute/students/bulkImport/CSVUploader";
import StudentBulkFilter from "@/components/admin/admin/institute/students/bulkImport/StudentBulkFilter";
import StudentBulkTable from "@/components/admin/admin/institute/students/bulkImport/StudentBulkTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import {
  setStudentBulkData,
  setStudentBulkShowTable,
} from "@/store/modules/admin/institute/studentBulkInsert/slice";
import { useDispatch, useSelector } from "react-redux";

const BulkImport = () => {
  const dispatch = useDispatch();
  const { showTable, showCsvUploader } = useSelector(
    (state) => state.adminStudentBulk
  );

  const handleUpload = (items) => {
    if (items.length === 0) return;
    dispatch(setStudentBulkData(items));
    dispatch(setStudentBulkShowTable(true));
  };

  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.students,
        adminRoutes.institute.students.bulkImport,
      ]}
    >
      <div className="flex flex-col gap-6">
        <StudentBulkFilter />
        {showCsvUploader && <CSVUploader onUpload={handleUpload} />}
        {showTable && <StudentBulkTable />}
      </div>
    </AdminPanelWrapper>
  );
};

export default BulkImport;
