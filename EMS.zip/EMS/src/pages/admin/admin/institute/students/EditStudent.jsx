import SelectCategory from "@/components/admin/admin/institute/category/SelectCategory";
import SelectLocalClass from "@/components/admin/admin/institute/class/SelectLocalClass";
import SelectSection from "@/components/admin/admin/institute/section/SelectSection";
import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import UpdateStudentHelper from "@/components/responseHelper/admin/admin/institute/UpdateStudentHelper";
import BanglaInput from "@/components/shared/BanglaInput";
import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import ImageUploadProfile from "@/components/shared/ImageUploadProfile";
import Input from "@/components/shared/Input";
import NumberInput from "@/components/shared/NumberInput";
import RequestLoading from "@/components/shared/RequestLoading";
import SelectBloodGroup from "@/components/shared/SelectBloodGroup";
import SelectDisability from "@/components/shared/SelectDisability";
import SelectGender from "@/components/shared/SelectGender";
import SelectReligion from "@/components/shared/SelectReligion";
import TWDatePicker from "@/components/shared/TWDatePicker";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useUpdateStudent } from "@/hooks";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const EditStudent = () => {
  const {
    selectors,
    setSelector,
    onSubmit,
    errors,
    isLoading,
    institute_id,
    classCode,
    selectedData,
    isFetching,
    isError,
    image,
    setImage,
    ref,
    onAddressCheck,
    onGurdianCheck,
  } = useUpdateStudent();

  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.students,
        adminRoutes.institute.students.management,
        adminRoutes.institute.students.editStudent,
      ]}
    >
      <div className="card_common py-7 bg-white rounded-2xl">
        <UpdateStudentHelper isLoading={isFetching} isError={isError}>
          <form
            onSubmit={onSubmit}
            action=""
            className="flex flex-col gap-6"
            ref={ref}
          >
            <GroupTitleComponent title="Basic Information" />
            <ImageUploadProfile
              image={image?.fileUrl}
              setImage={setImage}
              inputWrapper="w-32 h-32 rounded-full flex-col-reverse justify-center"
            />
            <div className="grid sm:grid-cols-2 gap-4">
              <Input
                placeholder="Full Name (in English)"
                name="name_english"
                label="Full Name (in English)"
                errorMessage={errors?.name_english}
                defaultValue={selectedData?.name_english}
              />
              <BanglaInput
                placeholder="Full Name (in Bangla)"
                name="name_bangla"
                label="Full Name (in Bangla)"
                errorMessage={errors?.name_bangla}
                defaultValue={selectedData?.name_bangla}
              />
              <NumberInput
                placeholder="Roll Number"
                name="current_roll_number"
                label="Roll"
                errorMessage={errors?.current_roll_number}
                defaultValue={selectedData?.current_roll_number}
              />
              <Input
                placeholder="Mobile Number"
                name="mobile_number"
                label="Mobile No."
                errorMessage={errors?.mobile_number}
                defaultValue={selectedData?.mobile_number}
              />
              <SelectGender
                value={selectors?.gender}
                onValueChange={(value) => setSelector({ gender: value })}
                placeholder="Select Gender"
                label="Gender"
                errorMessage={errors?.gender}
              />
              <TWDatePicker
                value={selectors?.date_of_birth}
                setValue={(value) => setSelector({ date_of_birth: value })}
                placeholder="Select Date"
                label="Date of Birth"
                errorMessage={errors?.date_of_birth}
              />
              <Input
                placeholder="Birth Certificate Number"
                name="birth_certificate_number"
                label="Birth Certificate Number"
                errorMessage={errors?.birth_certificate_number}
                defaultValue={selectedData?.birth_certificate_number}
              />
              <Input
                type="email"
                placeholder="Email"
                name="email"
                label="Email"
                errorMessage={errors?.email}
                defaultValue={selectedData?.email}
              />
              <Input
                placeholder="Nationality"
                name="nationality"
                label="Nationality"
                errorMessage={errors?.nationality}
                defaultValue={selectedData?.nationality}
              />
              <SelectReligion
                value={selectors?.religion}
                onValueChange={(value) => setSelector({ religion: value })}
                label="Religion"
                errorMessage={errors?.religion}
              />
              <SelectBloodGroup
                value={selectors?.blood_group}
                onValueChange={(value) => setSelector({ blood_group: value })}
                label="Blood Group"
                errorMessage={errors?.blood_group}
              />
              <SelectDisability
                value={selectors?.disability}
                onValueChange={(value) => setSelector({ disability: value })}
                label="Special Child/Disability"
                errorMessage={errors?.disability}
              />
            </div>
            <GroupTitleComponent title="Academic Information" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <SelectLocalSessionYear
                value={selectors?.academic_year}
                onValueChange={(value) => setSelector({ academic_year: value })}
                label="Year/Session"
                errorMessage={errors?.academic_year}
              />
              <SelectLocalClass
                value={selectors?.current_class}
                onValueChange={(value) =>
                  setSelector({
                    current_class: value,
                    current_group: "",
                    current_section: "",
                  })
                }
                label="Class"
                visibleItem={true}
                errorMessage={errors?.current_class}
                institute_id={institute_id}
              />
              {classCode > 8 && (
                <SelectLocalGroup
                  value={selectors?.current_group}
                  onValueChange={(value) =>
                    setSelector({ current_group: value, current_section: "" })
                  }
                  label="Select Group"
                  classCode={classCode}
                  errorMessage={errors?.current_group}
                />
              )}
              <SelectSection
                value={selectors?.current_section}
                onValueChange={(value) =>
                  setSelector({ current_section: value })
                }
                label="Select Section"
                triggerClass="!bg-white"
                isFiltered={true}
                classCode={classCode}
                errorMessage={errors?.current_section}
                group_id={selectors?.current_group}
              />
              <SelectCategory
                value={selectors?.current_category}
                onValueChange={(value) =>
                  setSelector({ current_category: value })
                }
                label="Select Category"
                triggerClass="!bg-white"
                errorMessage={errors?.current_category}
              />
            </div>
            <GroupTitleComponent title="Previous Institute Information" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                placeholder="Name of The Institution"
                name="previous_insitute_name"
                label="Name of The Institution"
                wrapper="sm:col-span-2"
                errorMessage={errors?.previous_insitute_name}
                defaultValue={selectedData?.previous_insitute_name}
              />
              <Input
                placeholder="Class"
                name="previous_class"
                label="Class"
                errorMessage={errors?.previous_class}
                defaultValue={selectedData?.previous_class}
              />
              <Input
                placeholder="Result"
                name="previous_result"
                label="Result"
                errorMessage={errors?.previous_result}
                defaultValue={selectedData?.previous_result}
              />
            </div>
            <GroupTitleComponent title="Father's Information" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                placeholder="Father Name (in English)"
                name="father_name_english"
                label="Name (in English)"
                errorMessage={errors?.father_name_english}
                defaultValue={selectedData?.father_name_english}
                data-type="father"
              />
              <BanglaInput
                placeholder="Father Name (in Bangla)"
                name="father_name_bangla"
                label="Name (in Bangla)"
                errorMessage={errors?.father_name_bangla}
                defaultValue={selectedData?.father_name_bangla}
                data-type="father"
              />
              <Input
                placeholder="Father Mobile Number"
                name="father_mobile_number"
                label="Mobile Number"
                errorMessage={errors?.father_mobile_number}
                defaultValue={selectedData?.father_mobile_number}
                data-type="father"
              />
              <NumberInput
                placeholder="Father NID Number"
                name="father_nid_number"
                label="NID Number"
                errorMessage={errors?.father_nid_number}
                defaultValue={selectedData?.father_nid_number}
                data-type="father"
              />
              <Input
                placeholder="Father Profession"
                name="father_profession"
                label="Profession"
                errorMessage={errors?.father_profession}
                defaultValue={selectedData?.father_profession}
                data-type="father"
              />
            </div>
            <GroupTitleComponent title="Mother's Information" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                placeholder="Mother Name (in English)"
                name="mother_name_english"
                label="Name (in English)"
                errorMessage={errors?.mother_name_english}
                defaultValue={selectedData?.mother_name_english}
                data-type="mother"
              />
              <BanglaInput
                placeholder="Mother Name (in Bangla)"
                name="mother_name_bangla"
                label="Name (in Bangla)"
                errorMessage={errors?.mother_name_bangla}
                defaultValue={selectedData?.mother_name_bangla}
                data-type="mother"
              />
              <Input
                placeholder="Mother Mobile Number"
                name="mother_mobile_number"
                label="Mobile Number"
                errorMessage={errors?.mother_mobile_number}
                defaultValue={selectedData?.mother_mobile_number}
                data-type="mother"
              />
              <NumberInput
                placeholder="Mother NID Number"
                name="mother_nid_number"
                label="NID Number"
                errorMessage={errors?.mother_nid_number}
                defaultValue={selectedData?.mother_nid_number}
                data-type="mother"
              />
              <Input
                placeholder="Mother Profession"
                name="mother_profession"
                label="Profession"
                errorMessage={errors?.mother_profession}
                defaultValue={selectedData?.mother_profession}
                data-type="mother"
              />
            </div>
            <GroupTitleComponent title="Guardian's Information" />
            <div className="flex items-center space-x-2 relative">
              <label
                htmlFor="father"
                className="flex items-center space-x-2 border border-neutral-300 p-2 rounded-lg cursor-pointer"
              >
                <input
                  type="radio"
                  name="gurdian"
                  onClick={onGurdianCheck}
                  value="father"
                  id="father"
                />
                <span className="text-sm text-text-900">Same as Father</span>
              </label>
              <label
                htmlFor="mother"
                className="flex items-center space-x-2 border border-neutral-300 p-2 rounded-lg cursor-pointer"
              >
                <input
                  type="radio"
                  name="gurdian"
                  onClick={onGurdianCheck}
                  value="mother"
                  id="mother"
                />
                <span className="text-sm text-text-900">Same as Mother</span>
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                placeholder="Guardian Name (in English)"
                name="guardian_name_english"
                label="Name (in English)"
                defaultValue={selectedData?.guardian_name_english}
                errorMessage={errors?.guardian_name_english}
                data-type="guardian"
              />
              <Input
                placeholder="Guardian Name (in Bangla)"
                name="guardian_name_bangla"
                label="Name (in Bangla)"
                defaultValue={selectedData?.guardian_name_bangla}
                errorMessage={errors?.guardian_name_bangla}
                data-type="guardian"
              />
              <Input
                placeholder="Guardian Mobile Number"
                name="guardian_mobile_number"
                label="Mobile Number"
                defaultValue={selectedData?.guardian_mobile_number}
                errorMessage={errors?.guardian_mobile_number}
                data-type="guardian"
              />
              <NumberInput
                placeholder="Guardian NID Number"
                name="guardian_nid_number"
                label="NID Number"
                defaultValue={selectedData?.guardian_nid_number}
                errorMessage={errors?.guardian_nid_number}
                data-type="guardian"
              />
              <Input
                placeholder="Guardian Profession"
                name="guardian_profession"
                label="Profession"
                defaultValue={selectedData?.guardian_profession}
                errorMessage={errors?.guardian_profession}
                data-type="guardian"
              />
            </div>
            <GroupTitleComponent title="Present Address Information" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                placeholder="House no, road no..."
                name="present_address_line"
                label="Present Address"
                errorMessage={errors?.present_address_line}
                defaultValue={selectedData?.present_address_line}
                data-type="present"
              />
              <Input
                placeholder="Present District"
                name="present_address_district"
                label="District"
                errorMessage={errors?.present_address_district}
                defaultValue={selectedData?.present_address_district}
                data-type="present"
              />
              <Input
                placeholder="Present Upazilla"
                name="present_address_upozilla"
                label="Upazilla"
                errorMessage={errors?.present_address_upozilla}
                defaultValue={selectedData?.present_address_upozilla}
                data-type="present"
              />
              <Input
                placeholder="Present Post Office"
                name="present_address_post_office"
                label="Post Office"
                errorMessage={errors?.present_address_post_office}
                defaultValue={selectedData?.present_address_post_office}
                data-type="present"
              />
              <NumberInput
                placeholder="Present Post Code"
                name="present_address_post_code"
                label="Post Code"
                errorMessage={errors?.present_address_post_code}
                defaultValue={selectedData?.present_address_post_code}
                data-type="present"
              />
            </div>
            <GroupTitleComponent title="Permanent Address Information" />
            <div className="flex items-center space-x-2 relative">
              <Checkbox id="address" onCheckedChange={onAddressCheck} />
              <label
                htmlFor="address"
                className="text-sm font-medium cursor-pointer"
              >
                Same as Present Address
              </label>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                placeholder="House no, road no..."
                name="permanent_address_line"
                label="Permanent Address"
                errorMessage={errors?.permanent_address_line}
                defaultValue={selectedData?.permanent_address_line}
                data-type="permanent"
              />
              <Input
                placeholder="Permanent District"
                name="permanent_address_district"
                label="District"
                errorMessage={errors?.permanent_address_district}
                defaultValue={selectedData?.permanent_address_district}
                data-type="permanent"
              />
              <Input
                placeholder="Permanent Upazilla"
                name="permanent_address_upozilla"
                label="Upazilla"
                errorMessage={errors?.permanent_address_upozilla}
                defaultValue={selectedData?.permanent_address_upozilla}
                data-type="permanent"
              />
              <Input
                placeholder="Permanent Post Office"
                name="permanent_address_post_office"
                label="Post Office"
                errorMessage={errors?.permanent_address_post_office}
                defaultValue={selectedData?.permanent_address_post_office}
                data-type="permanent"
              />
              <NumberInput
                placeholder="Permanent Post Code"
                name="permanent_address_post_code"
                label="Post Code"
                errorMessage={errors?.permanent_address_post_code}
                defaultValue={selectedData?.permanent_address_post_code}
                data-type="permanent"
              />
            </div>

            <div className="flex items-center justify-end">
              <Link
                to={adminRoutes.institute.students.management.path}
                className="btn_blue h-12 justify-center min-w-32 !bg-transparent !text-main-500"
              >
                Cancel
              </Link>
              <Button
                type="submit"
                className="h-12 min-w-[132px] ml-4"
                size="lg"
              >
                Update
              </Button>
            </div>
          </form>
        </UpdateStudentHelper>
        {isLoading && <RequestLoading />}
      </div>
    </AdminPanelWrapper>
  );
};

export default EditStudent;
