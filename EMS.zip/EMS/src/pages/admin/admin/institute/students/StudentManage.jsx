import StudentManagementFilter from "@/components/admin/admin/institute/students/studentManagement/StudentManagementFilter";
import StudentManagementTable from "@/components/admin/admin/institute/students/studentManagement/StudentManagementTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const StudentManage = () => {
  const { showTable } = useSelector((state) => state.adminStudentManagement);

  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.students,
        adminRoutes.institute.students.management,
      ]}
    >
      <StudentManagementFilter />
      {showTable && <StudentManagementTable />}
    </AdminPanelWrapper>
  );
};

export default StudentManage;
