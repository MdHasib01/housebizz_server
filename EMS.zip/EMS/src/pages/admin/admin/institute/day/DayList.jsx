import DayListTable from "@/components/admin/admin/institute/day/DayListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const DayList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.day]}
    >
      <DayListTable />
    </AdminPanelWrapper>
  );
};

export default DayList;
