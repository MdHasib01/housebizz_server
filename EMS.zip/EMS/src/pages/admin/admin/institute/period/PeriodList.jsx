import PeriodListTable from "@/components/admin/admin/institute/period/PeriodListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const PeriodList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.period]}
    >
      <PeriodListTable />
    </AdminPanelWrapper>
  );
};

export default PeriodList;
