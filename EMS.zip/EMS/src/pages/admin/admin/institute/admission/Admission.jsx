import AdmissionManagementTable from "@/components/admin/admin/institute/admission/AdmissionManagementTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const Admission = () => {
  const { admissionList } = useSelector((state) => state.adminAdmission);

  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.admission]}
    >
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common !px-4 py-7 gap-6">
        <PageHeader
          title="Admission Management"
          btnText="Admit Students"
          path={adminRoutes.institute.admitStudents.path}
        />
        <AdmissionManagementTable item={admissionList} />
      </div>
    </AdminPanelWrapper>
  );
};

export default Admission;
