import AdmitStudentsAdmissionTable from "@/components/admin/admin/institute/admission/AdmitStudentsAdmissionTable";
import AdmitStudentsFilter from "@/components/admin/admin/institute/admission/AdmitStudentsFilter";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const AdmitStudents = () => {
  const { showTable } = useSelector((state) => state.adminAdmitAdmission);

  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.admission,
        adminRoutes.institute.admitStudents,
      ]}
    >
      <div className="flex flex-col gap-6">
        <AdmitStudentsFilter />
        {showTable && <AdmitStudentsAdmissionTable />}
      </div>
    </AdminPanelWrapper>
  );
};

export default AdmitStudents;
