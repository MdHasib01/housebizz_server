import SectionListTable from "@/components/admin/admin/institute/section/SectionListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const SectionList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.section]}
    >
      <SectionListTable />
    </AdminPanelWrapper>
  );
};

export default SectionList;
