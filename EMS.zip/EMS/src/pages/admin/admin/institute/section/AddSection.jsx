import AddSectionForm from "@/components/admin/admin/institute/section/AddSectionForm";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const AddSection = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.section,
        adminRoutes.institute.section.addSection,
      ]}
    >
      <AddSectionForm />
    </AdminPanelWrapper>
  );
};

export default AddSection;
