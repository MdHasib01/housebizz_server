import AddShiftForm from "@/components/admin/admin/institute/shift/AddShiftForm";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const AddShift = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.institute,
        adminRoutes.institute.shift,
        adminRoutes.institute.shift.addShift,
      ]}
    >
      <AddShiftForm />
    </AdminPanelWrapper>
  );
};

export default AddShift;
