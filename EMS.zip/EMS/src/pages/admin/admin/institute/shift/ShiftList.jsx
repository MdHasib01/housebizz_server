import ShiftListTable from "@/components/admin/admin/institute/shift/ShiftListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { adminRoutes } from "@/services";

const ShiftList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.institute, adminRoutes.institute.shift]}
    >
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common !px-4 py-7 gap-6">
        <PageHeader
          title="Shift List"
          btnText="Create New Shift"
          path={adminRoutes.institute.shift.addShift.path}
        />
        <ShiftListTable />
      </div>
    </AdminPanelWrapper>
  );
};

export default ShiftList;
