import ConfigUpdateTable from "@/components/admin/admin/billing/billingConfig/ConfigUpdateTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const BillingConfigUpdate = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.billing,
        adminRoutes.billing.billingConfig,
        adminRoutes.billing.billingConfig.updateConfig,
      ]}
    >
      <ConfigUpdateTable />
    </AdminPanelWrapper>
  );
};

export default BillingConfigUpdate;
