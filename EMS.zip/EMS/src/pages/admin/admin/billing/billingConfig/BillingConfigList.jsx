import BillingConfigListTable from "@/components/admin/admin/billing/billingConfig/BillingConfigListTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const BillingConfigList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.billing, adminRoutes.billing.billingConfig]}
    >
      <BillingConfigListTable />
    </AdminPanelWrapper>
  );
};

export default BillingConfigList;
