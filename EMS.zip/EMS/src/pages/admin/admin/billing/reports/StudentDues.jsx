import PaymentListFilter from "@/components/admin/admin/billing/report/headwisePayment/PaymentListFilter";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const StudentDues = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.billing,
        adminRoutes.billing.report,
        adminRoutes.billing.report.studentDues,
      ]}
    >
      <PaymentListFilter />
    </AdminPanelWrapper>
  );
};

export default StudentDues;
