import PaymentListFilter from "@/components/admin/admin/billing/report/headwisePayment/PaymentListFilter";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const DailyCollections = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.billing,
        adminRoutes.billing.report,
        adminRoutes.billing.report.dailyCollections,
      ]}
    >
      <PaymentListFilter />
    </AdminPanelWrapper>
  );
};

export default DailyCollections;
