import HeadManagementTable from "@/components/admin/admin/billing/billingHead/HeadManagementTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { adminRoutes } from "@/services";

function HeadManage() {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.billing, adminRoutes.billing.billingHead]}
    >
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common !px-4 py-7 gap-6">
        <PageHeader
          title="Head Manage"
          btnText="New Head"
          path={adminRoutes.billing.billingHead.addNewHead.path}
        />
        <HeadManagementTable />
      </div>
    </AdminPanelWrapper>
  );
}

export default HeadManage;
