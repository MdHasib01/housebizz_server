import AddHeadForm from "@/components/admin/admin/billing/billingHead/AddHeadForm";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const AddNewHead = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.billing,
        adminRoutes.billing.billingHead,
        adminRoutes.billing.billingHead.addNewHead,
      ]}
    >
      <AddHeadForm />
    </AdminPanelWrapper>
  );
};

export default AddNewHead;
