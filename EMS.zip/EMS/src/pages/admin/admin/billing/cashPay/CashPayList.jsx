import BillingTypesTable from "@/components/admin/admin/billing/cashPay/billingTypesTable/BillingTypesTable";
import SearchStudent from "@/components/admin/admin/billing/cashPay/SearchStudent";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const CashPayList = () => {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.billing, adminRoutes.billing.cashPay]}
    >
      <div className="w-full flex flex-col gap-6">
        <SearchStudent />
        <BillingTypesTable item={[]} />
      </div>
    </AdminPanelWrapper>
  );
};

export default CashPayList;
