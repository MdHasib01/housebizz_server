import AddNewBillingType from "@/components/admin/admin/billing/billingTypes/AddNewBillingType";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const AddBillingType = () => {
  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.billing,
        adminRoutes.billing.billingTypes,
        adminRoutes.billing.billingTypes.addNewType,
      ]}
    >
      <AddNewBillingType />
    </AdminPanelWrapper>
  );
};

export default AddBillingType;
