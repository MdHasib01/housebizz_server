import UpdateBillingTypeForm from "@/components/admin/admin/billing/billingTypes/UpdateBillingTypeForm";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

const UpdateBillingType = () => {
    return (
        <AdminPanelWrapper
            crumbList={[
                adminRoutes.billing,
                adminRoutes.billing.billingTypes,
                adminRoutes.billing.billingTypes.updateType,
            ]}
        >
            <UpdateBillingTypeForm />
        </AdminPanelWrapper>
    );
};

export default UpdateBillingType;
