import BillingTypesFilter from "@/components/admin/admin/billing/billingTypes/BillingTypesFilter";
import BillingTypesTable from "@/components/admin/admin/billing/billingTypes/BillingTypesTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const BillingTypesList = () => {
  const { showTable } = useSelector((state) => state.adminBillingTypes);
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.billing, adminRoutes.billing.billingTypes]}
    >
      <BillingTypesFilter />
      {showTable && (
        <div className="flex flex-col w-full bg-white card_common !px-4 py-7 gap-6 mt-5">
          <PageHeader
            title="Billing List"
          />
          <BillingTypesTable />
        </div>)}
    </AdminPanelWrapper>
  );
};

export default BillingTypesList;
