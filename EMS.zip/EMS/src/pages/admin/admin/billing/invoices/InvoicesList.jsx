import BulkBillingFilter from "@/components/admin/admin/billing/invoices/bulkBilling/BulkBillingFilter";
import CustomBillingFilter from "@/components/admin/admin/billing/invoices/customBilling/CustomBillingFilter";
import StudentInfoTable from "@/components/admin/admin/billing/invoices/customBilling/StudentInfoTable";
import IndividualBillingFilter from "@/components/admin/admin/billing/invoices/individualBilling/IndividualBillingFilter";
import BillingAsideComponent from "@/components/admin/admin/billing/invoices/partials/BillingAsideComponent";
import FoundStudentTable from "@/components/admin/admin/billing/invoices/partials/FoundStudentTable";
import BillingHistoryTable from "@/components/admin/admin/billing/invoices/search/BillingHistoryTable";
import SearchFilter from "@/components/admin/admin/billing/invoices/search/SearchFilter";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import CustomPageTab from "@/components/shared/CustomPageTab";
import { adminRoutes } from "@/services";
import { Fragment, useState } from "react";
import { useSelector } from "react-redux";

const InvoicesList = () => {
  const [activeTab, setActiveTab] = useState(0);
  const { showTable } = useSelector((state) => state.adminSearchBilling);
  const { showTable: showBulkTable } = useSelector(
    (state) => state.adminBulkBilling
  );
  const [individualSelectedStudentData, setIndividualSelectedStudentData] =
    useState(null);

  const { students } = useSelector((state) => state.adminStudentManagement);

  const tabs = [
    "Search",
    "Bulk Billing",
    "Custom Billing",
    // "Individual Billing",
  ];

  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.billing, adminRoutes.billing.invoices]}
    >
      <div className="h-full w-full">
        <CustomPageTab
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          tabs={tabs}
          className={"max-w-[410px]"}
          widthThreshold={2}
        />

        {activeTab === 0 && (
          <Fragment>
            <SearchFilter />
            {showTable && <BillingHistoryTable />}
          </Fragment>
        )}
        {activeTab === 1 && (
          <Fragment>
            <BulkBillingFilter />
            {showBulkTable && (
              <div className="grid grid-cols-3 gap-5">
                <FoundStudentTable className="col-span-2" />
                <BillingAsideComponent className="col-span-1" />
              </div>
            )}
          </Fragment>
        )}
        {activeTab === 2 && (
          <Fragment>
            <CustomBillingFilter />
            <StudentInfoTable />
          </Fragment>
        )}
        {activeTab === 3 && (
          <Fragment>
            <IndividualBillingFilter />
            <div className="grid grid-cols-3 gap-5">
              <FoundStudentTable
                className="col-span-2"
                item={[students?.[0]]}
                data={individualSelectedStudentData}
                setData={setIndividualSelectedStudentData}
                pagination={false}
              />
              <BillingAsideComponent
                className="col-span-1"
                data={individualSelectedStudentData}
              />
            </div>
          </Fragment>
        )}
      </div>
    </AdminPanelWrapper>
  );
};

export default InvoicesList;
