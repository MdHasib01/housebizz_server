import SelectLocalDay from "@/components/admin/admin/institute/day/SelectLocalDay";
import SelectLocalPeriod from "@/components/admin/admin/institute/period/SelectLocalPeriod";
import SelectTeacher from "@/components/admin/admin/institute/teacher/SelectTeacher";
import SelectSubject from "@/components/admin/superAdmin/global/subjectManagement/SelectSubject";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import RequestLoading from "@/components/shared/RequestLoading";
import Timepicker from "@/components/shared/Timepicker";
import { Button } from "@/components/ui/button";
import { useAddClassSchedule } from "@/hooks";
import { adminRoutes } from "@/services";
import { DeleteIcon, PlusRoundedIcon } from "@/services/assets/svgs";
import { Fragment } from "react";

const AddRoutine = () => {
  const {
    classCode,
    selectors,
    errors,
    isLoading,
    handleUpdateSelector,
    handleUpdateSubjectSelector,
    handleAddMore,
    handleSubmit,
    subjectData,
    handleCancel,
    removeSubject,
  } = useAddClassSchedule();

  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.attendance,
        adminRoutes.attendance.classSchedule,
        adminRoutes.attendance.addRoutine,
      ]}
    >
      <div className="card_common py-7">
        <p className="card_title">Add Routine</p>
        <form action="#" onSubmit={handleSubmit}>
          <div className="grid grid-cols-2 gap-6 mt-6">
            <SelectLocalDay
              value={selectors?.day_id}
              onValueChange={(val) => handleUpdateSelector({ day_id: val })}
              label="Day"
              errorMessage={errors?.day_id}
            />
            <SelectLocalPeriod
              value={selectors?.period_id}
              onValueChange={(val) => handleUpdateSelector({ period_id: val })}
              label="Period"
              errorMessage={errors?.period_id}
            />
            {selectors?.subjects.map((subject, index) => (
              <Fragment key={index}>
                <div className="col-span-2 gap-6 flex items-center">
                  <GroupTitleComponent
                    title={`Subject ${index + 1}`}
                    className={"flex-1"}
                  />
                  {index === 0 && selectors?.subjects.length === 1 ? (
                    <span></span>
                  ) : (
                    <button type="button" onClick={() => removeSubject(index)}>
                      <DeleteIcon />
                    </button>
                  )}
                </div>
                <SelectSubject
                  value={subject?.subject_id}
                  onValueChange={(val) =>
                    handleUpdateSubjectSelector({
                      index,
                      name: "subject_id",
                      value: val,
                    })
                  }
                  classCode={classCode}
                  selectors={subjectData}
                  errorMessage={errors?.subjects?.[index]?.subject_id}
                  group_id={selectors?.group_id}
                  label="Subject"
                />
                <SelectTeacher
                  value={subject?.teacher_id}
                  onSelect={(val) =>
                    handleUpdateSubjectSelector({
                      index,
                      name: "teacher_id",
                      value: val,
                    })
                  }
                  errorMessage={errors?.subjects?.[index]?.teacher_id}
                  label="Teacher"
                />
                <div className="flex flex-col gap-2">
                  <span className="label">Start Time</span>
                  <Timepicker
                    time={subject?.start_time}
                    setTime={(value) =>
                      handleUpdateSubjectSelector({
                        index,
                        name: "start_time",
                        value: value,
                      })
                    }
                    classNames={{
                      input: "min-h-[54px] h-full !text-sm",
                      selectHour: "!text-sm",
                      selectMinute: "!text-sm",
                      selectFormat: "!text-sm",
                    }}
                    id={`start_time_${index}`}
                    placeholder="Select start time"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <span className="label">End Time</span>
                  <Timepicker
                    time={subject?.end_time}
                    setTime={(value) =>
                      handleUpdateSubjectSelector({
                        index,
                        name: "end_time",
                        value: value,
                      })
                    }
                    classNames={{
                      input: "min-h-[54px] h-full !text-sm",
                      selectHour: "!text-sm",
                      selectMinute: "!text-sm",
                      selectFormat: "!text-sm",
                    }}
                    id={`end_time_${index}`}
                    placeholder="Select end time"
                  />
                </div>
              </Fragment>
            ))}

            <div className="col-span-2">
              <Button
                type="button"
                variant={"ghost"}
                className="text-base font-semibold !leading-[1.2] text-main-500 hover:text-main-500 w-fit group"
                onClick={handleAddMore}
              >
                <div className="transition_common group-hover:rotate-180 duration-1000 h-fit w-fit">
                  <PlusRoundedIcon className="!h-6 !w-6 shrink-0" />
                </div>
                <span>Add another subject</span>
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-end">
            <Button
              type="button"
              onClick={handleCancel}
              className="btn_blue justify-center min-w-32 h-12 !bg-transparent !text-main-500"
            >
              Cancel
            </Button>
            <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
              Add
            </Button>
          </div>
        </form>

        {isLoading && <RequestLoading />}
      </div>
    </AdminPanelWrapper>
  );
};

export default AddRoutine;
