import ClassScheduleFilter from "@/components/admin/admin/attendance/classSchedules/ClassScheduleFilter";
import ClassScheduleTable from "@/components/admin/admin/attendance/classSchedules/ClassScheduleTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const ClassSchedule = () => {
  const { showTable } = useSelector((state) => state.adminClassSchedule);

  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.attendance, adminRoutes.attendance.classSchedule]}
    >
      <ClassScheduleFilter />
      {showTable && <ClassScheduleTable />}
    </AdminPanelWrapper>
  );
};

export default ClassSchedule;
