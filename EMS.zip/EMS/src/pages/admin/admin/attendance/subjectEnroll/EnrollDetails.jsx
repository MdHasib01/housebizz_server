import AssignableList from "@/components/admin/admin/attendance/subjectEnrollDetails/AssignableList";
import AssignedList from "@/components/admin/admin/attendance/subjectEnrollDetails/AssignedList";
import DataSwappingBar from "@/components/admin/admin/attendance/subjectEnrollDetails/DataSwappingBar";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import CustomSpinner from "@/components/shared/CustomSpinner";
import ErrorUi from "@/components/shared/ErrorUi";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddEnrollSubject } from "@/hooks";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const EnrollDetails = () => {
  const {
    state,
    left_students,
    right_students,
    selected_left_students,
    selected_right_students,
    left_search,
    right_search,
    isFetching,
    isError,
    isLoading,
    selectAllLeftStudents,
    handleToggleLeftStudent,
    selectAllRightStudents,
    handleToggleRightStudent,
    handleMoveRightToLeft,
    handleMoveLeftToRight,
    setLeftSearch,
    setRightSearch,
    handleSubmit,
  } = useAddEnrollSubject();

  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.attendance,
        adminRoutes.attendance.subjectEnroll,
        adminRoutes.attendance.enrollDetails,
      ]}
    >
      <div className="card_common py-7 max-w-full">
        <p className="card_title">Selected Enroll Details</p>

        <div className="grid grid-cols-3 gap-5 mt-4">
          <p className="text-sm font-normal !leading-[1.2] text-text-700">
            Session/Year :{" "}
            <span className="font-semibold">
              {state?.selectors?.academic_year}
            </span>
          </p>
          <p className="text-sm font-normal !leading-[1.2] text-text-700">
            Class :{" "}
            <span className="font-semibold">
              {state?.local_class_id?.local_class_name}
            </span>
          </p>
          <p className="text-sm font-normal !leading-[1.2] text-text-700">
            Section :{" "}
            <span className="font-semibold">
              {state?.section_id?.section_name}
            </span>
          </p>
          <p className="text-sm font-normal !leading-[1.2] text-text-700">
            Subject :{" "}
            <span className="font-semibold">
              {state?.subject_id?.global_subject_name}
            </span>
          </p>
          <p className="text-sm font-normal !leading-[1.2] text-text-700 col-span-2">
            Teacher :{" "}
            <span className="font-semibold">
              {state?.teacher_id?.first_name} {state?.teacher_id?.last_name}
            </span>
          </p>
        </div>

        <hr className="my-6 h-[1px] text-natural-300" />

        {isFetching ? (
          <CustomSpinner />
        ) : isError ? (
          <ErrorUi />
        ) : (
          <div className="flex flex-row items-stretch">
            <AssignableList
              className={"flex-grow"}
              students={left_students}
              selectedStudents={selected_left_students}
              handleAll={selectAllLeftStudents}
              handleSingle={handleToggleLeftStudent}
              search={left_search}
              setSearch={setLeftSearch}
            />
            <DataSwappingBar
              className={""}
              handleMoveRightToLeft={handleMoveRightToLeft}
              handleMoveLeftToRight={handleMoveLeftToRight}
            />
            <AssignedList
              className={"flex-grow"}
              students={right_students}
              selectedStudents={selected_right_students}
              handleAll={selectAllRightStudents}
              handleSingle={handleToggleRightStudent}
              search={right_search}
              setSearch={setRightSearch}
            />
          </div>
        )}

        <div className="flex flex-row items-center justify-end gap-6 mt-4">
          <Link
            to={adminRoutes.attendance.subjectEnroll.path}
            className="btn_blue justify-center min-w-32 h-12 !bg-transparent !text-main-500"
          >
            Cancel
          </Link>
          <Button size="lg" className="min-w-32" onClick={handleSubmit}>
            Update
          </Button>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </AdminPanelWrapper>
  );
};

export default EnrollDetails;
