import EnrollRoutineFilter from "@/components/admin/admin/attendance/subjectEnroll/EnrollRoutineFilter";
import EnrollRoutineTable from "@/components/admin/admin/attendance/subjectEnroll/EnrollRoutineTable";
import EnrollStudentFilter from "@/components/admin/admin/attendance/subjectEnroll/EnrollStudentFilter";
import EnrollStudentTable from "@/components/admin/admin/attendance/subjectEnroll/EnrollStudentTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import CustomPageTab from "@/components/shared/CustomPageTab";
import { adminRoutes } from "@/services";
import { setSubjectEnrollTab } from "@/store/modules/common/slice";
import { Fragment } from "react";
import { useDispatch, useSelector } from "react-redux";

const SubjectEnroll = () => {
  const dispatch = useDispatch();
  const { showTable: showStudentTable } = useSelector(
    (state) => state.adminEnrollStudents
  );
  const { showTable: showRoutineTable } = useSelector(
    (state) => state.adminEnrollRoutine
  );
  const { subjectEnrollTab } = useSelector((state) => state.common);

  const setActiveTab = (tab) => {
    dispatch(setSubjectEnrollTab(tab));
  };

  const tabs = ["List", "Enroll"];

  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.attendance, adminRoutes.attendance.subjectEnroll]}
    >
      <div className="h-full w-full">
        <CustomPageTab
          activeTab={subjectEnrollTab}
          setActiveTab={setActiveTab}
          tabs={tabs}
          className="mb-6"
        />
        {subjectEnrollTab === 0 ? (
          <Fragment>
            <EnrollStudentFilter />
            {showStudentTable && <EnrollStudentTable />}
          </Fragment>
        ) : (
          <Fragment>
            <EnrollRoutineFilter />
            {showRoutineTable && <EnrollRoutineTable />}
          </Fragment>
        )}
      </div>
    </AdminPanelWrapper>
  );
};

export default SubjectEnroll;
