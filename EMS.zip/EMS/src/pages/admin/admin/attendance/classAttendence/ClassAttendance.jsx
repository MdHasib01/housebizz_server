import AttendanceReportTable from "@/components/admin/admin/attendance/classAttendance/AttendanceReportTable";
import SearchAttendanceFilter from "@/components/admin/admin/attendance/classAttendance/SearchAttendanceFilter";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";
import { useSelector } from "react-redux";

const ClassAttendance = () => {
  const { showTable } = useSelector((state) => state.adminClassAttendance);

  return (
    <AdminPanelWrapper
      crumbList={[
        adminRoutes.attendance,
        adminRoutes.attendance.report,
        adminRoutes.attendance.report.classAttendance,
      ]}
    >
      <SearchAttendanceFilter />
      {showTable && <AttendanceReportTable />}
    </AdminPanelWrapper>
  );
};

export default ClassAttendance;
