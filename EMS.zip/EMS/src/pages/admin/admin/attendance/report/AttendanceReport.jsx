const AttendanceReport = () => {
  return (
    <div className="flex_center min-h-full">
      <h1 className="text-2xl font-bold text-main-400">Coming soon...</h1>
    </div>
  );
};

export default AttendanceReport;
