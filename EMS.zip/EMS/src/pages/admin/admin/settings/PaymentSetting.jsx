import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  adminRoutes,
  errorNotify,
  infoNotify,
  validatePaymentSetting,
} from "@/services";
import { updatePaymentState } from "@/store/modules/admin/settings/payment/slice";
import { useUpdateInstituteManagementMutation } from "@/store/modules/superAdmin/administrator/instituteManagement/api";
import { useDispatch, useSelector } from "react-redux";

function PaymentSetting() {
  const dispatch = useDispatch();
  const { settings } = useSelector((state) => state.paymentSetting);
  const { auth } = useSelector((state) => state.auth);
  const [updateInstituteManagement, { isLoading }] =
    useUpdateInstituteManagementMutation();

  const handleWalletNumberChange = (event) => {
    const { name, value } = event.target;
    dispatch(updatePaymentState({ [name]: value }));
  };

  const handleStatusChange = (name, status) => {
    dispatch(updatePaymentState({ [name]: status }));
  };

  const onSubmit = (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("data", JSON.stringify(settings));
    const error = validatePaymentSetting(settings);
    if (error) return errorNotify(error);
    updateInstituteManagement({ data: formData, id: auth?.institute?._id })
      .unwrap()
      .then((res) => {
        infoNotify(res?.message);
      })
      .catch((err) => {
        errorNotify(err?.data?.message);
      });
  };

  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.settings, adminRoutes.settings.payment]}
    >
      <div className="card_common py-7">
        <h2 className="text-lg font-medium text-text-900">Payment Setting</h2>
        <div className="mt-6">
          <form onSubmit={onSubmit} action="">
            <div className="flex items-center justify-between gap-6">
              <h4 className="text-base  text-text-700 w-full max-w-40">
                Payment Method:
              </h4>
              <div className="flex items-center gap-4 flex-1 ">
                <label
                  htmlFor="bkash"
                  className="flex items-center gap-2 border w-full max-w-32 px-3 py-2 rounded-lg cursor-pointer"
                >
                  <Checkbox
                    id="bkash"
                    checked={settings?.bkash_payment_is_active}
                    onCheckedChange={(val) =>
                      handleStatusChange("bkash_payment_is_active", val)
                    }
                  />
                  Bkash
                </label>
                <label
                  htmlFor="rocket"
                  className="flex items-center gap-2 border w-full max-w-32 px-3 py-2 rounded-lg cursor-pointer"
                >
                  <Checkbox
                    id="rocket"
                    checked={settings?.rocket_payment_is_active}
                    onCheckedChange={(val) =>
                      handleStatusChange("rocket_payment_is_active", val)
                    }
                  />
                  Rocket
                </label>
                <label
                  htmlFor="nagad"
                  className="flex items-center gap-2 border w-full max-w-32 px-3 py-2 rounded-lg cursor-pointer"
                >
                  <Checkbox
                    id="nagad"
                    checked={settings?.nagad_payment_is_active}
                    onCheckedChange={(val) =>
                      handleStatusChange("nagad_payment_is_active", val)
                    }
                  />
                  Nagad
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 mt-10">
              {settings?.bkash_payment_is_active && (
                <Input
                  label="BKash Merchant Wallet No"
                  placeholder="Enter Bkash Merchant Wallet No"
                  name="bkash_merchant_wallet_number"
                  value={settings?.bkash_merchant_wallet_number}
                  onChange={handleWalletNumberChange}
                />
              )}
              {settings?.rocket_payment_is_active && (
                <Input
                  label="Rocket Merchant Wallet No"
                  placeholder="Enter Rocket Merchant Wallet No"
                  name="rocket_merchant_wallet_number"
                  value={settings?.rocket_merchant_wallet_number}
                  onChange={handleWalletNumberChange}
                />
              )}

              {settings?.nagad_payment_is_active && (
                <Input
                  label="Nagad Merchant Wallet No"
                  placeholder="Enter Nagad Merchant Wallet No"
                  name="nagad_merchant_wallet_number"
                  value={settings?.nagad_merchant_wallet_number}
                  onChange={handleWalletNumberChange}
                />
              )}
            </div>
            <div className="flex justify-end mt-6">
              <Button
                type="submit"
                className="h-12 w-[132px] ml-auto"
                size="lg"
              >
                Update
              </Button>
            </div>
          </form>
        </div>
        {isLoading && <RequestLoading />}
      </div>
    </AdminPanelWrapper>
  );
}

export default PaymentSetting;
