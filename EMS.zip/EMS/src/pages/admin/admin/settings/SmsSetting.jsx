import SmsAddForm from "@/components/admin/admin/settings/sms/SmsAddForm";
import SmsStates from "@/components/admin/admin/settings/sms/SmsStates";
import SmsTable from "@/components/admin/admin/settings/sms/SmsTable";
import AdminPanelWrapper from "@/components/layout/AdminPanelWrapper";
import { adminRoutes } from "@/services";

function SmsSetting() {
  return (
    <AdminPanelWrapper
      crumbList={[adminRoutes.settings, adminRoutes.settings.sms]}
    >
      <div>
        <div className="card_common py-7">
          <h2 className="text-lg font-medium text-text-900">SMS Settings</h2>
          <SmsStates />
          <SmsAddForm />
        </div>
        <SmsTable />
      </div>
    </AdminPanelWrapper>
  );
}

export default SmsSetting;
