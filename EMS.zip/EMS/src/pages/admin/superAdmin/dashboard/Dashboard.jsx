import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import { superAdminBreads } from "@/services";
import { useSelector } from "react-redux";

function Dashboard() {
  const { auth } = useSelector((state) => state.auth);
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.dashboard}>
      <div className="">AssignInstitute</div>
    </SuperAdminPanelWrapper>
  );
}

export default Dashboard;
