import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddBoardManagement } from "@/hooks";
import { superAdminBreads } from "@/services";

function AddBoardManagement() {
  const { onSubmit, isLoading, navigateToBoardManagement, errors } =
    useAddBoardManagement();

  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.addBoardManagement}>
      <div className="card_common py-7">
        <p className="card_title">Add New Head</p>

        <div className="flex flex-col gap-10 mt-6">
          <form onSubmit={onSubmit} className="flex flex-col gap-10 mt-6">
            <div className="grid grid-cols-2 gap-6">
              <Input
                label="Board Code"
                placeholder="Enter board code"
                name="global_board_code"
                required
                errorMessage={errors?.global_board_code}
              />
              <Input
                label="Board Name"
                placeholder="Enter board name"
                name="global_board_name"
                required
                errorMessage={errors?.global_board_name}
              />
            </div>
            <div className="flex items-center justify-end">
              <Button
                className="h-12 min-w-[132px] text-main-500"
                size="lg"
                variant="outline"
                type="reset"
                onClick={navigateToBoardManagement}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="h-12 min-w-[132px] ml-4"
                size="lg"
              >
                Add
              </Button>
            </div>
          </form>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </SuperAdminPanelWrapper>
  );
}

export default AddBoardManagement;
