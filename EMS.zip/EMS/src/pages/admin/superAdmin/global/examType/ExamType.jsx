import ExamTypeTable from "@/components/admin/superAdmin/global/examType/ExamTypeTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import RequestLoading from "@/components/shared/RequestLoading";
import { useAddExamType } from "@/hooks/superAdmin/global/useExamType";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";

function ExamType() {
  const { onSubmit, isLoading, name, setName } = useAddExamType();
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.examType}>
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common py-7 gap-6">
        <PageHeader
          title="Exam Type"
          btnText="Add"
          type="add"
          path={superAdminRoutes.addClassManagement.path}
          onBtnClick={onSubmit}
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <ExamTypeTable />
      </div>
      {isLoading && <RequestLoading />}
    </SuperAdminPanelWrapper>
  );
}

export default ExamType;
