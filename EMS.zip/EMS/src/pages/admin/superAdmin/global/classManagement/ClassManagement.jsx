import ClassManagementTable from "@/components/admin/superAdmin/global/classManagement/ClassManagementTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";

function ClassManagement() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.classManagement}>
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common py-7 gap-6">
        <PageHeader
          title="Class Management"
          btnText="Add New Class"
          path={superAdminRoutes.addClassManagement.path}
        />
        <ClassManagementTable />
      </div>
    </SuperAdminPanelWrapper>
  );
}

export default ClassManagement;
