import SelectClass from "@/components/admin/superAdmin/global/classManagement/SelectClass";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddGroupManagement } from "@/hooks/superAdmin/global/useGroupManagement";
import { superAdminBreads } from "@/services";

function AddGroupManagement() {
  const { onSubmit, isLoading, handleNavigate, selectors, setSelctors } =
    useAddGroupManagement();

  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.addGroupManagement}>
      <div className="card_common py-7">
        <p className="card_title">Add New Group</p>

        <div className="flex flex-col gap-10 mt-6">
          <form onSubmit={onSubmit} className="flex flex-col gap-10 mt-6">
            <div className="grid grid-cols-2 gap-6">
              <Input
                label="Group Name"
                placeholder="Enter group name"
                name="global_group_name"
                required
              />
              <SelectClass
                required
                name="global_class_id"
                label="Select Class"
                value={selectors?.global_class_id}
                onValueChange={(val) => {
                  setSelctors({ global_class_id: val });
                }}
              />
            </div>
            <div className="flex items-center justify-end">
              <Button
                className="h-12 min-w-[132px] text-main-500"
                size="lg"
                variant="outline"
                type="reset"
                onClick={handleNavigate}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="h-12 min-w-[132px] ml-4"
                size="lg"
              >
                Add
              </Button>
            </div>
          </form>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </SuperAdminPanelWrapper>
  );
}

export default AddGroupManagement;
