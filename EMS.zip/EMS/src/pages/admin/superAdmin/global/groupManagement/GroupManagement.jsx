import GroupManagementTable from "@/components/admin/superAdmin/global/groupManagement/GroupManagementTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";

function GroupManagement() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.groupManagement}>
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common py-7 gap-6">
        <PageHeader
          title="Group Management"
          btnText="Add New Group"
          path={superAdminRoutes.addGroupManagement.path}
        />
        <GroupManagementTable />
      </div>
    </SuperAdminPanelWrapper>
  );
}

export default GroupManagement;
