import GradingManagementTable from "@/components/admin/superAdmin/global/gradingManagement/GradingManagementTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";

function ClassManagement() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.gradingManagement}>
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common py-7 gap-6">
        <PageHeader
          title="Grading Management"
          btnText="Add New Grade"
          path={superAdminRoutes.addGradingManagement.path}
        />
        <GradingManagementTable />
      </div>
    </SuperAdminPanelWrapper>
  );
}

export default ClassManagement;
