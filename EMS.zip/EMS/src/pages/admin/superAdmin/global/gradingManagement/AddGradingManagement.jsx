import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import Input from "@/components/shared/Input";
import NumberInput from "@/components/shared/NumberInput";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddGradingManagement } from "@/hooks/superAdmin/global/useGradingManagement";
import { superAdminBreads } from "@/services";

function AddGradingManagement() {
  const { onSubmit, isLoading, handleNavigate, errors } =
    useAddGradingManagement();

  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.addBoardManagement}>
      <div className="card_common py-7">
        <p className="card_title">Add New Grade</p>

        <div className="flex flex-col gap-10 mt-6">
          <form onSubmit={onSubmit} className="flex flex-col gap-10 mt-6">
            <div className="grid grid-cols-2 items-start gap-6">
              <Input
                label="Grade Name"
                placeholder="Enter grade name"
                name="global_grade_name"
                required
                errorMessage={errors?.global_grade_name}
              />
              <NumberInput
                label="Grade Point"
                placeholder="Enter grade point"
                name="global_grade_point"
                required
                errorMessage={errors?.global_grade_point}
              />
              <NumberInput
                label="Lowest Mark"
                placeholder="Enter lowest mark"
                name="global_grade_lowest_mark"
                required
                errorMessage={errors?.global_grade_lowest_mark}
              />
              <NumberInput
                label="Highest Mark"
                placeholder="Enter highest mark"
                name="global_grade_highest_mark"
                required
                errorMessage={errors?.global_grade_highest_mark}
              />
            </div>
            <div className="flex items-center justify-end">
              <Button
                className="h-12 min-w-[132px] text-main-500"
                size="lg"
                variant="outline"
                type="reset"
                onClick={handleNavigate}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="h-12 min-w-[132px] ml-4"
                size="lg"
              >
                Add
              </Button>
            </div>
          </form>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </SuperAdminPanelWrapper>
  );
}

export default AddGradingManagement;
