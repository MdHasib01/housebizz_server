import SubjectManagementFilter from "@/components/admin/superAdmin/global/subjectManagement/SubjectManagementFilter";
import SubjectManagementTable from "@/components/admin/superAdmin/global/subjectManagement/SubjectManagementTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { useSelector } from "react-redux";

function SubjectManagement() {
  const { showSubjectTable } = useSelector(
    (state) => state.saSubjectManagement
  );

  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.subjectManagement}>
      <div className="flex flex-col w-full bg-white card_common !px-4 py-7 gap-6 mb-6">
        <PageHeader
          title="Subject Management"
          btnText="Add New Subject"
          path={superAdminRoutes.addSubjectManagement.path}
        />
        <SubjectManagementFilter />
      </div>
      {showSubjectTable && <SubjectManagementTable />}
    </SuperAdminPanelWrapper>
  );
}

export default SubjectManagement;
