import SelectBoard from "@/components/admin/superAdmin/global/boardManagement/SelectBoard";
import SelectClass from "@/components/admin/superAdmin/global/classManagement/SelectClass";
import PopoverGroup from "@/components/admin/superAdmin/global/groupManagement/PopoverGroup";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddSubject } from "@/hooks/superAdmin/global/useSubjectManagement";
import { superAdminBreads } from "@/services";

function AddSubjectManagement() {
  const {
    groups,
    onSubmit,
    isLoading,
    handleNavigate,
    handleGroupSelect,
    errors,
    handleBoardSelect,
    handleClassSelect,
    goupFilterByClass,
    global_board_id,
    global_class_id,
    classCode,
  } = useAddSubject();

  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.addSubjectManagement}>
      <div className="card_common py-7">
        <p className="card_title">Add New Subject</p>

        <div className="flex flex-col gap-10 mt-6">
          <form onSubmit={onSubmit} className="flex flex-col gap-10 mt-6">
            <div className="grid grid-cols-2 gap-6">
              <SelectBoard
                value={global_board_id}
                onValueChange={handleBoardSelect}
                label="Select Board"
                required
                errorMessage={errors?.global_board_id}
              />
              <SelectClass
                value={global_class_id}
                onValueChange={handleClassSelect}
                label="Select Class"
                required
                errorMessage={errors?.global_class_id}
                visibleItem={true}
              />
              <Input
                label="Subject Name"
                placeholder="Enter subject code"
                name="global_subject_name"
                required
                errorMessage={errors?.global_subject_name}
              />
              <Input
                label="Subject Code"
                placeholder="Enter subject code"
                name="global_subject_code"
                required
                errorMessage={errors?.global_subject_code}
              />
              <Input
                label="Subject Order"
                placeholder="Enter subject order"
                name="global_subject_order"
                required
                errorMessage={errors?.global_subject_order}
              />
              {classCode > 8 && (
                <PopoverGroup
                  onSelect={handleGroupSelect}
                  groups={groups}
                  label="Select Group"
                  filterBy={goupFilterByClass}
                />
              )}
            </div>
            <div className="flex items-center justify-end">
              <Button
                className="h-12 min-w-[132px] text-main-500"
                size="lg"
                variant="outline"
                type="reset"
                onClick={handleNavigate}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="h-12 min-w-[132px] ml-4"
                size="lg"
              >
                Add
              </Button>
            </div>
          </form>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </SuperAdminPanelWrapper>
  );
}

export default AddSubjectManagement;
