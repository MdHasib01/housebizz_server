import SelectInstituteType from "@/components/admin/superAdmin/global/sessionYear/SelectInstituteType";
import SelectSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectSessionYear";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddSessionYear } from "@/hooks/superAdmin/global/useSessionYear";
import { superAdminBreads } from "@/services";

function AddSessionYear() {
  const { onSubmit, isLoading, handleNavigate, selectors, setSelectors } =
    useAddSessionYear();

  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.addSessionYear}>
      <div className="card_common py-7">
        <p className="card_title">Add New Session/Year</p>

        <div className="flex flex-col gap-10 mt-6">
          <form onSubmit={onSubmit} className="flex flex-col gap-10">
            <div className="grid grid-cols-2 gap-6">
              <SelectInstituteType
                value={selectors?.institute_type}
                onValueChange={(val) => setSelectors({ institute_type: val })}
                name="institute_type"
                label="Institute Type"
                required
              />
              <SelectSessionYear
                value={selectors?.global_academic_year}
                onValueChange={(val) =>
                  setSelectors({ global_academic_year: val })
                }
                name="global_academic_year"
                label="Year"
                required
              />
            </div>
            <div className="flex items-center justify-end">
              <Button
                className="h-12 min-w-[132px] text-main-500"
                size="lg"
                variant="outline"
                type="reset"
                onClick={handleNavigate}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="h-12 min-w-[132px] ml-4"
                size="lg"
              >
                Add
              </Button>
            </div>
          </form>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </SuperAdminPanelWrapper>
  );
}

export default AddSessionYear;
