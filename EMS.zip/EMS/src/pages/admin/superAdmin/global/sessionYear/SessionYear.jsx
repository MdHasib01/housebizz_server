import SessionYearTable from "@/components/admin/superAdmin/global/sessionYear/SessionYearTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";

function SessionYear() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.sessionYear}>
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common py-7 gap-6">
        <PageHeader
          title="Session/Year"
          btnText="Add New Session/Year"
          path={superAdminRoutes.addSessionYear.path}
        />
        <SessionYearTable />
      </div>
    </SuperAdminPanelWrapper>
  );
}

export default SessionYear;
