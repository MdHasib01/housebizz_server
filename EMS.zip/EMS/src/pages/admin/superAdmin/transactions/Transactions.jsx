import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import { superAdminBreads } from "@/services";

function Transactions() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.transactions}>
      <div className="">AssignInstitute</div>
    </SuperAdminPanelWrapper>
  );
}

export default Transactions;
