import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import { superAdminBreads } from "@/services";

function AssignInstitute() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.assignInstitute}>
      <div className="">AssignInstitute</div>
    </SuperAdminPanelWrapper>
  );
}

export default AssignInstitute;
