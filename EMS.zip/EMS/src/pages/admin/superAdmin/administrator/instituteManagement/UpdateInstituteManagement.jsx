import SelectBoard from "@/components/admin/superAdmin/global/boardManagement/SelectBoard";
import SelectInstituteType from "@/components/admin/superAdmin/global/sessionYear/SelectInstituteType";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import Input from "@/components/shared/Input";
import NumberInput from "@/components/shared/NumberInput";
import RequestLoading from "@/components/shared/RequestLoading";
import SelectInstituteStatus from "@/components/shared/SelectInstituteStatus";
import { Button } from "@/components/ui/button";
import { useUpdatedInstitute } from "@/hooks/superAdmin/administrator/useInstituteOnboard";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { Link } from "react-router-dom";
import UpdateInstituteManagementHelper from "../../../../../components/responseHelper/admin/superAdmin/administrator/UpdateInstituteManagementHelper";

function UpdateInstituteManagement() {
  const {
    setSelectors,
    errors,
    onSubmit,
    isLoading,
    isFetching,
    isError,
    data,
    selectors,
  } = useUpdatedInstitute();

  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.addInstituteManagement}>
      <div className="w-full mx-auto bg-white px-12 py-14 rounded-2xl">
        <UpdateInstituteManagementHelper
          isLoading={isFetching}
          isError={isError}
        >
          <form onSubmit={onSubmit} action="">
            <div className="grid sm:grid-cols-2 gap-6">
              <GroupTitleComponent
                title="Institute Status"
                className="sm:col-span-2"
              />
              <SelectInstituteStatus
                label="Institute Status"
                defaultValue={data?.status || "published"}
                name="status"
              />
              <GroupTitleComponent
                title="Basic Information"
                className="sm:col-span-2"
              />

              <Input
                placeholder="Enter full name"
                name="institute_name"
                label="Institute Name"
                errorMessage={errors?.institute_name}
                defaultValue={data?.institute_name}
                labelClass="required"
                required
              />
              <Input
                placeholder="Enter short name"
                name="institute_short_name"
                label="Short Name"
                errorMessage={errors?.institute_short_name}
                defaultValue={data?.institute_short_name}
                labelClass="required"
                required
              />
              <SelectInstituteType
              value={selectors?.institute_type}
              onValueChange={(val) => setSelectors({ institute_type: val })}
              placeholder="Select type"
              label="Type"
              errorMessage={errors?.institute_type}
              labelClass="required"
              required
            />
            <SelectBoard
              value={selectors?.institute_board_id}
              onValueChange={(val) => setSelectors({ institute_board_id: val })}
              label="Board"
              errorMessage={errors?.institute_board_id}
              labelClass="required"
              required
            />
              <Input
                placeholder="ESTD"
                name="estd_code"
                label="ESTD"
                errorMessage={errors?.estd_code}
                defaultValue={data?.estd_code}
                labelClass="required"
                required
              />

              <GroupTitleComponent
                title="Identification Codes"
                className="sm:col-span-2"
              />
              <Input
                placeholder="Enter school code"
                name="board_school_code"
                label="School Code"
                errorMessage={errors?.board_institute_code}
                defaultValue={data?.board_institute_code}
              />
              <Input
                placeholder="Enter college code"
                name="board_collage_code"
                label="College Code"
                errorMessage={errors?.board_institute_code}
                defaultValue={data?.board_institute_code}
              />
              <NumberInput
                placeholder="Enter EIIN"
                name="eiin_number"
                label="EIIN Code"
                errorMessage={errors?.eiin_number}
                defaultValue={data?.eiin_number}
                labelClass="required"
                required
              />

              <GroupTitleComponent
                title="Location Details"
                className="sm:col-span-2"
              />
              <Input
                placeholder="Enter address line"
                name="institute_address"
                label="Address Line"
                wrapper="col-span-2"
                errorMessage={errors?.institute_address}
                defaultValue={data?.institute_address}
                labelClass="required"
                required
              />
              <Input
                placeholder="Enter post office"
                name="institute_post_office"
                label="Post Office"
                errorMessage={errors?.institute_post_office}
                defaultValue={data?.institute_post_office}
                labelClass="required"
                required
              />
              <Input
                placeholder="Enter post code"
                name="institute_postal_code"
                label="Post Code"
                errorMessage={errors?.institute_postal_code}
                defaultValue={data?.institute_postal_code}
                labelClass="required"
                required
              />
              <Input
                placeholder="Enter upazila"
                name="institute_upazilla"
                label="Upazila"
                errorMessage={errors?.institute_upazilla}
                defaultValue={data?.institute_upazilla}
                labelClass="required"
                required
              />
              <Input
                placeholder="Enter district"
                name="institute_district"
                label="District"
                errorMessage={errors?.institute_district}
                defaultValue={data?.institute_district}
                labelClass="required"
                required
              />

              <GroupTitleComponent
                title="Contact Information"
                className="sm:col-span-2"
              />
              <Input
                type="email"
                placeholder="Enter email"
                name="institute_email"
                label="Email"
                errorMessage={errors?.institute_email}
                defaultValue={data?.institute_email}
                labelClass="required"
                required
              />
              <Input
                placeholder="Enter mobile no."
                name="institute_mobilephone"
                label="Mobile No."
                errorMessage={errors?.institute_mobilephone}
                defaultValue={data?.institute_mobilephone}
                labelClass="required"
                required
              />
              <Input
                placeholder="Enter phone no."
                name="institute_telephone"
                label="Phone No."
                errorMessage={errors?.institute_telephone}
                defaultValue={data?.institute_telephone}
                labelClass="required"
                required
              />

              <GroupTitleComponent
                title="School Capacity"
                className="sm:col-span-2"
              />
              <NumberInput
                placeholder="Institute Name"
                name="total_students"
                label="Enter total students"
                errorMessage={errors?.total_students}
                defaultValue={data?.total_students}
                labelClass="required"
                required
              />
            </div>
            <div className="flex items-center justify-end mt-10">
              <Link
                className="h-12 min-w-[132px] btn_blue !bg-transparent !text-main-500 justify-center"
                to={superAdminRoutes.instituteManagement.path}
              >
                Cancel
              </Link>
              <Button
                type="submit"
                className="h-12 min-w-[132px] ml-4"
                size="lg"
              >
                Update Institute
              </Button>
            </div>
          </form>
        </UpdateInstituteManagementHelper>
      </div>
      {isLoading && <RequestLoading />}
    </SuperAdminPanelWrapper>
  );
}

export default UpdateInstituteManagement;
