import InstituteAdminsTable from "@/components/admin/superAdmin/administrator/instituteManagement/InstituteAdminsTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";

function InstituteAdmins() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.instituteAdmins}>
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common !px-4 py-7 gap-6">
        <PageHeader
          title="Institute Admins"
          path={superAdminRoutes.addInstituteManagement.path}
        />
        <InstituteAdminsTable />
      </div>
    </SuperAdminPanelWrapper>
  );
}

export default InstituteAdmins;
