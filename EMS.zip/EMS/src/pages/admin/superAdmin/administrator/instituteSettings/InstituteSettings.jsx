import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import { superAdminBreads } from "@/services";

function InstituteSettings() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.instituteSettings}>
      <div className="">AssignInstitute</div>
    </SuperAdminPanelWrapper>
  );
}

export default InstituteSettings;
