import RequestedInstituteTable from "@/components/admin/superAdmin/administrator/requestedInstitute/RequestedInstituteTable";
import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import PageHeader from "@/components/shared/PageHeader";
import { superAdminBreads } from "@/services";

function RequestedInstitute() {
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.instituteManagement}>
      <div className="flex-1 flex flex-col w-full overflow-auto bg-white card_common !px-4 py-7 gap-6">
        <PageHeader title="Requested Institutes" />
        <RequestedInstituteTable />
      </div>
    </SuperAdminPanelWrapper>
  );
}

export default RequestedInstitute;
