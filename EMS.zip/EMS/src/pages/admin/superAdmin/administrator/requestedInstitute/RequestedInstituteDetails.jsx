import SuperAdminPanelWrapper from "@/components/layout/SuperAdminPanelWrapper";
import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import { superAdminBreads } from "@/services";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { Link, useLocation } from "react-router-dom";

function RequestedInstituteDetails() {
  const { state } = useLocation();
  return (
    <SuperAdminPanelWrapper crumbList={superAdminBreads.requestedInstituteDetails}>
      <div className=" flex-1 w-full ">
        <div className="bg-white card_common !px-4 py-7 gap-6 flex flex-col">
          <GroupTitleComponent title="Basic Information" />
          <div className="flex flex-col gap-4 w-full ">
            <InstituteCard
              title="Institute Name"
              value={state?.institute_name}
            />
            <InstituteCard
              title="Short Name"
              value={state?.institute_short_name}
            />
            <InstituteCard title="Type" value={state?.institute_type} />
            <InstituteCard title="ESTD" value={state?.estd_code} />
          </div>
          <GroupTitleComponent title="Identification Codes" />
          <div className="flex flex-col gap-4 w-full ">
            <InstituteCard
              title="Institute Code"
              value={state?.board_institute_code}
            />
            <InstituteCard title="EIIN Code" value={state?.eiin_number} />
          </div>
          <GroupTitleComponent title="Location Details" />
          <div className="flex flex-col gap-4 w-full ">
            <InstituteCard
              title="Address Line"
              value={state?.institute_address}
            />
            <InstituteCard
              title="Post Office"
              value={state?.institute_post_office}
            />
            <InstituteCard
              title="Post Code"
              value={state?.institute_postal_code}
            />
            <InstituteCard title="Upazila" value={state?.institute_upazilla} />
            <InstituteCard title="District" value={state?.institute_district} />
          </div>
          <GroupTitleComponent title="Contact Information" />
          <div className="flex flex-col gap-4 w-full ">
            <InstituteCard title="Email" value={state?.institute_email} />
            <InstituteCard
              title="Mobile No."
              value={state?.institute_mobilephone}
            />
            <InstituteCard
              title="Phone No."
              value={state?.institute_telephone}
            />
          </div>
          <GroupTitleComponent title="School Capacity" />
          <div className="flex flex-col gap-4 w-full ">
            <InstituteCard
              title="Total Student"
              value={state?.total_students}
            />
          </div>
          <Link
            to={superAdminRoutes.requestedInstitute.path}
            className="btn_blue max-w-max ml-auto !px-10 py-4"
          >
            Back
          </Link>
        </div>
      </div>
    </SuperAdminPanelWrapper>
  );
}

export default RequestedInstituteDetails;

export const InstituteCard = ({ title = "", value = "" }) => {
  return (
    <div className="grid grid-cols-4 w-full">
      <span className="text-sm text-text-700">{title}</span>
      <span className="col-span-3 text-sm text-text-700 font-semibold">
        {value}
      </span>
    </div>
  );
};
