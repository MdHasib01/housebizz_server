import { RouterProvider } from "react-router-dom";
import useAuthCheck from "./hooks/auth/useAuthCheck";
import { routes } from "./routes/Router";
import NotifyContainer from "./services/helpers/toastify";

function App() {
  const Router = routes;
  const authChecked = useAuthCheck();

  return !authChecked ? (
    <div>loading...</div>
  ) : (
    <div className="font-inter ">
      <RouterProvider router={Router} />
      <NotifyContainer />
    </div>
  );
}

export default App;
