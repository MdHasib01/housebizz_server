import colors from "@/services/config/colors";
import { ChevronRight } from "lucide-react";
import React, { Fragment } from "react";
import { Link } from "react-router-dom";

const HeaderBreadCrumb = ({ crumbList, crumbTitle }) => {
  return (
    <div className="">
      {crumbList && (
        <ul className="flex flex-row ">
          {crumbList.map((crumb, index) => (
            <li key={index} className="flex flex-row items-center gap-[2px]">
              {index < crumbList.length - 1 ? (
                <Fragment>
                  {crumb.path ? (
                    <Link
                      to={crumb?.path}
                      className="text-base font-normal !leading-normal text-text-600 hover:text-text-600/50 me-1"
                    >
                      {crumb?.name}
                    </Link>
                  ) : (
                    <span className="text-base font-normal !leading-normal text-text-600 me-1">
                      {crumb?.name}
                    </span>
                  )}

                  <ChevronRight
                    className="h-4 w-4 me-1"
                    color={colors.natural[500]}
                  />
                </Fragment>
              ) : (
                <span className="text-base font-semibold !leading-[1.2] text-text-900 me-1">
                  {crumb?.name}
                </span>
              )}
            </li>
          ))}{" "}
        </ul>
      )}

      {crumbTitle && (
        <p className="hidden md:block text-base font-semibold !leading-[1.2]">
          {crumbTitle}
        </p>
      )}
    </div>
  );
};

export default HeaderBreadCrumb;
