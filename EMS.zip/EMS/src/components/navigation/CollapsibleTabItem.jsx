import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "react-router-dom";

const SubItem = ({ subItem }) => {
  // checks if the submenu is available in it or not for nested submenu
  if (subItem.subMenu) {
    return (
      <AccordionItem value={subItem.title} className="!px-0 border-none">
        <AccordionTrigger
          className={cn("flex flex-row ps-[52px] pe-4 py-3 rounded-lg")}
        >
          <p
            className={cn(
              "text-xs font-normal !leading-[1.2] text-text-600",
              location.pathname.includes(subItem.activeSegment) &&
                "font-semibold !leading-[1.24] text-text-700"
            )}
          >
            {subItem.title}
          </p>
        </AccordionTrigger>

        <AccordionContent>
          {subItem.subMenu.map((subSubItem) => (
            <Link
              className={cn(
                "block rounded-lg ps-16 pe-4 py-3 text-xs font-normal !leading-[1.2] text-text-600",
                location.pathname.includes(subSubItem.link) &&
                  "font-semibold !leading-[1.24] text-text-700"
              )}
              to={subSubItem.link}
              key={subSubItem.title}
            >
              {subSubItem.title}
            </Link>
          ))}
        </AccordionContent>
      </AccordionItem>
    );
  } else {
    return (
      <Link
        className={cn(
          "block rounded-lg ps-[52px] pe-4 py-3 text-xs font-normal !leading-[1.2] text-text-600",
          location.pathname.includes(subItem.link) &&
            "font-semibold !leading-[1.2] text-text-700"
        )}
        to={subItem.link}
      >
        {subItem.title}
      </Link>
    );
  }
};

const CollapsibleTabItem = ({ item }) => {
  const location = useLocation();
  const isActive = location.pathname.includes(item.activeSegment);
  return (
    <AccordionItem
      value={item.title}
      className={cn(
        "!px-0 border-none",
        location.pathname.includes(item.activeSegment) &&
          "bg-main-50 rounded-lg"
      )}
    >
      <AccordionTrigger
        className={cn("flex flex-row min-h-12 px-4 py-3 rounded-lg relative")}
      >
        {/* Animated side content on path activation */}
        <div
          className={cn(
            "absolute left-0 top-1/2 -translate-y-1/2 h-0 w-1 bg-main-500 rounded-full transition_common",
            isActive && "h-6"
          )}
        />
        <div className="flex items-center flex-row gap-[6px]">
          {isActive ? item.activeIcon : item.icon}
          <p
            className={cn(
              "inline-block text-sm font-normal !leading-[1.4]",
              isActive && "font-medium"
            )}
          >
            {item.title}
          </p>
        </div>
      </AccordionTrigger>

      <AccordionContent>
        <Accordion type="single" collapsible className="w-full">
          {item.subMenu.map((subItem) => (
            <SubItem key={subItem.title} subItem={subItem} />
          ))}
        </Accordion>
      </AccordionContent>
    </AccordionItem>
  );
};

export default CollapsibleTabItem;
