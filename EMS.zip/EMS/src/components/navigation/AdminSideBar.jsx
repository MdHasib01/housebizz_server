import Image from "@/components/shared/Image";
import { Accordion } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { userRoutes } from "@/services";
import { images } from "@/services/assets";
import { LogoutIcon } from "@/services/assets/svgs";
import { adminNavigationData } from "@/services/data/navigation";
import { logout } from "@/store/modules/auth/authSlice";
import { Fragment, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import DialogExtended from "../shared/DialogExtended";
import CollapsibleTabItem from "./CollapsibleTabItem";
import LinkTabItem from "./LinkTabItem";

const AdminSideBar = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const {
    attendance,
    billing,
    dashboard,
    examination,
    institute,
    accounts,
    settings,
  } = adminNavigationData;
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleLogout = () => {
    dispatch(logout());
    navigate(userRoutes.home.path);
  };

  return (
    <Fragment>
      <Sidebar className="max-w-[232px] bg-white !border-natural-250">
        <SidebarContent className="py-10 px-4 flex flex-col justify-start">
          <div className="flex flex-row items-center gap-[6px] justify-start">
            <Image src={images.appLogo} alt="Logo" className="w-auto h-9" />
            {/* <a href="https://mobipath.com" target="_blank" rel="noreferrer"> */}
            {/* <a href="https://mobipath.com"> */}
            <h1 className="font-black leading-none">
              SMART <br />
              PATHSHALA
              {/* SHALI */}
            </h1>
            {/* </a> */}
          </div>

          <div className="flex flex-col mt-[52px]">
            <LinkTabItem item={dashboard} />
            <Accordion type="single" collapsible className="w-full">
              <CollapsibleTabItem item={institute} />
              <CollapsibleTabItem item={attendance} />
              {/* <CollapsibleTabItem item={examination} /> */}
              <CollapsibleTabItem item={billing} />
              <CollapsibleTabItem item={accounts} />

              {/* <CollapsibleTabItem item={accounts} /> */}
              <CollapsibleTabItem item={settings} />
            </Accordion>
          </div>
        </SidebarContent>

        <SidebarFooter className="border-t border-natural-300 mx-4 mb-4">
          <Button
            className={cn(
              "text-xs font-normal !leading-[1.4] text-black-700 gap-[6px] justify-start !ps-3"
            )}
            variant="ghost"
            onClick={() => setIsDialogOpen(true)}
          >
            <LogoutIcon className={"h-5 w-5"} />
            <p className="inline-block text-sm font-normal !leading-[1.4]">
              {`Log Out`}
            </p>
          </Button>
        </SidebarFooter>
      </Sidebar>

      <DialogExtended
        isDialogOpen={isDialogOpen}
        setIsDialogOpen={setIsDialogOpen}
        title="Are you sure?"
        text="You want to sign out?"
        confirmButtonText="Sign Out"
        onCancelPress={() => setIsDialogOpen(false)}
        onconfirmPress={handleLogout}
      />
    </Fragment>
  );
};

export default AdminSideBar;
