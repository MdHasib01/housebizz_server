import { cn } from "@/lib/utils";
import { Link, useLocation } from "react-router-dom";

const LinkTabItem = ({ item }) => {
  const location = useLocation();

  return (
    <Link
      className={cn(
        "block rounded-lg relative",
        location.pathname.includes(item.activeSegment) && "bg-main-50"
      )}
      to={item.link}
    >
      {/* Animated side content on path activation */}
      <div
        className={cn(
          "absolute left-0 top-1/2 -translate-y-1/2 h-0 w-1 bg-main-500 rounded-full transition_common",
          location.pathname.includes(item.activeSegment) && "h-6"
        )}
      />

      <div className="min-h-12 flex items-center flex-row gap-[6px] px-4 py-3">
        {location.pathname.includes(item.activeSegment)
          ? item.activeIcon
          : item.icon}
        <p
          className={cn(
            "inline-block text-sm font-normal !leading-[1.4]",
            location.pathname.includes(item.activeSegment) && "font-medium"
          )}
        >
          {item.title}
        </p>
      </div>
    </Link>
  );
};

export default LinkTabItem;
