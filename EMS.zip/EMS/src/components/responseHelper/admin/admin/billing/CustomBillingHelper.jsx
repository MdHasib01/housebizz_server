import StudentInfoError from "@/components/admin/admin/billing/invoices/customBilling/StudentInfoError";
import StudentInfoSkeleton from "@/components/admin/admin/billing/invoices/customBilling/StudentInfoSkeleton";

function CustomBillingHelper({
  showContent = false,
  isLoading = false,
  isError = false,
  errorMessage = "",
  children,
}) {
  if (!showContent) return <div></div>;
  else if (isLoading) return <StudentInfoSkeleton />;
  else if (isError) return <StudentInfoError message={errorMessage} />;
  else return children;
}

export default CustomBillingHelper;
