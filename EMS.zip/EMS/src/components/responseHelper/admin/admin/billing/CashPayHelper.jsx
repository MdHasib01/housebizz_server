import StudentStatsSkeleton from "@/components/admin/admin/billing/cashPay/StudentStatsSkeleton";
import StudentInfoError from "@/components/admin/admin/billing/invoices/customBilling/StudentInfoError";

function CashPayHelper({
  showContent = false,
  isLoading = false,
  isError = false,
  errorMessage = "",
  children,
}) {
  if (!showContent) return <div></div>;
  else if (isLoading) return <StudentStatsSkeleton />;
  else if (isError) return <StudentInfoError message={errorMessage} />;
  else return children;
}

export default CashPayHelper;
