import UpdateTeacherSkeleton from "@/components/admin/admin/institute/teacher/UpdateTeacherSkeleton";
import ErrorUi from "@/components/shared/ErrorUi";

function UpdateTeacherHelper({ isLoading = false, isError = false, children }) {
  if (isLoading) {
    return <UpdateTeacherSkeleton />;
  } else if (isError) {
    return <ErrorUi />;
  } else {
    return children;
  }
}

export default UpdateTeacherHelper;
