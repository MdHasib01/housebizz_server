import UpdateStudentSkeleton from "@/components/admin/admin/institute/students/studentManagement/UpdateStudentSkeleton";
import ErrorUi from "@/components/shared/ErrorUi";

function UpdateStudentHelper({ isLoading = false, isError = false, children }) {
  if (isLoading) {
    return <UpdateStudentSkeleton />;
  } else if (isError) {
    return <ErrorUi />;
  } else {
    return children;
  }
}

export default UpdateStudentHelper;
