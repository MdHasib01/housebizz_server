import UpdateRoutineSkeleton from "@/components/admin/admin/attendance/classSchedules/UpdateRoutineSkeleton";
import ErrorUi from "@/components/shared/ErrorUi";

function UpdateRoutineHelper({ isLoading = false, isError = false, children }) {
  if (isLoading) {
    return <UpdateRoutineSkeleton />;
  } else if (isError) {
    return <ErrorUi />;
  } else {
    return children;
  }
}

export default UpdateRoutineHelper;
