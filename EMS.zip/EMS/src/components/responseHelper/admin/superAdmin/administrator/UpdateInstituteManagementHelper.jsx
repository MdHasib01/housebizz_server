import UpdateInstituteManagementSkeleton from "@/components/admin/superAdmin/administrator/instituteManagement/UpdateInstituteManagementSkeleton";
import ErrorUi from "@/components/shared/ErrorUi";

function UpdateInstituteManagementHelper({
  isLoading = false,
  isError = false,
  children,
}) {
  if (isLoading) {
    return <UpdateInstituteManagementSkeleton />;
  } else if (isError) {
    return <ErrorUi />;
  } else {
    return children;
  }
}

export default UpdateInstituteManagementHelper;
