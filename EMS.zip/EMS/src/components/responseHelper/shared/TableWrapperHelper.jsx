import CustomSpinner from "@/components/shared/CustomSpinner";
import ErrorUi from "@/components/shared/ErrorUi";
import NoData from "@/components/shared/NoData";

function TableWrapperHelper({
  isLoading = false,
  isError = false,
  status = 404,
  dataLength = 0,
  emptyTitle = "No data Found",
  errorTitle = "Couldn't retrieve the data.",
  children,
}) {
  if (isLoading)
    return (
      <div className="p-10 bg-white">
        <CustomSpinner />
      </div>
    );
  else if (isError && status !== 404) return <ErrorUi title={errorTitle} />;
  else if (dataLength === 0) return <NoData title={emptyTitle} />;
  else return children;
}

export default TableWrapperHelper;
