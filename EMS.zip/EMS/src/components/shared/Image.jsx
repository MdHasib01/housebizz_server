import React from "react";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";

const Image = ({
  src,
  alt = "Image",
  effect = "blur",
  width = "auto",
  height = "auto",
  className = "",
  placeholderSrc,
  ...props
}) => {
  return (
    <LazyLoadImage
      alt={alt}
      src={src}
      effect={effect} // Options: blur, opacity, black-and-white
      height={height}
      width={width}
      className={className}
      placeholderSrc={placeholderSrc} // Optional placeholder image
      {...props}
    />
  );
};

export default Image;
