import ResponsivePagination from "react-responsive-pagination";
import "react-responsive-pagination/themes/classic.css";

function Pagination({ currentPage, totalPages, updatePage = () => {} }) {
  return (
    <div className="flex items-center justify-end gap-6 py-3">
      <ResponsivePagination
        current={currentPage}
        total={totalPages == 0 ? 1 : totalPages}
        onPageChange={(value) => updatePage({ currentPage: value })}
        maxWidth={250}
      />
    </div>
  );
}

export default Pagination;
