import { cn } from "@/lib/utils";

const GroupTitleComponent = ({ title, className }) => {
  return (
    <div className={cn("flex items-center gap-4", className)}>
      <p className="text-lg font-semibold !leading-[1.4] text-text-700">
        {title}
      </p>
      <div className="border-t border-natural-400 flex-grow" />
    </div>
  );
};

export default GroupTitleComponent;
