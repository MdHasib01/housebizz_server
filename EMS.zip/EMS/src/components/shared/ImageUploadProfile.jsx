import RequestLoading from "@/components/shared/RequestLoading";
import { cn } from "@/lib/utils";
import { errorNotify } from "@/services";
import { AddPhotoIcon, EditIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import { useUploadFileMutation } from "@/store/modules/common/api";

const ImageUploadProfile = ({
  id = "file",
  label = "",
  placeholder = "Upload Image",
  image,
  setImage = () => {},
  inputClassName = "",
  inputWrapper = "",
  imageClass = "",
  errorMessage = "",
  editIconClass = "",
}) => {
  const [uploadFile, { isLoading }] = useUploadFileMutation();
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith("image/")) {
      const formData = new FormData();
      formData.append("files", file);
      uploadFile(formData)
        .unwrap()
        .then((res) => {
          setImage(res?.data[0]);
        })
        .catch((err) => {
          errorNotify(err?.data?.message);
        });
    } else {
      errorNotify("Please select a valid image file.");
    }
  };

  return (
    <div className="flex flex-col gap-2 w-full">
      {label && (
        <p className="text-text-700 text-sm font-semibold !leading-[1.2]">
          {label}
        </p>
      )}
      <label
        htmlFor={id}
        className={cn(
          "w-full rounded-lg border border-dashed border-main-500 relative cursor-pointer flex items-center justify-between gap-2",
          errorMessage && "!border-red-500",
          !image && "p-4",
          inputWrapper
        )}
      >
        <input
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className={cn(
            "opacity-0 w-0.5 h-0.5 absolute_center min-h-full min-w-full cursor-pointer",
            inputClassName
          )}
          id={id}
        />
        {image ? (
          <>
            <img
              src={image}
              alt="image file"
              className={cn(
                "h-full w-full object-cover rounded-full",
                imageClass
              )}
            />
            <div
              className={cn(
                "w-7 h-7 bg-main-500 rounded-full absolute bottom-2 right-2 flex items-center justify-center",
                editIconClass
              )}
            >
              <EditIcon color="#fff" className="w-4 h-4" />
            </div>
          </>
        ) : (
          <>
            {placeholder && (
              <p className="text-sm font-normal !leading-[1.4] text-main-500 text-start">
                {placeholder}
              </p>
            )}
            <AddPhotoIcon
              className={"!h-6 !w-6 !shrink-0"}
              color={colors.main[500]}
            />
          </>
        )}
      </label>
      {errorMessage && (
        <p className="text-xs text-red-500 font-semibold !leading-[1.2]">
          {errorMessage}
        </p>
      )}
      {isLoading && <RequestLoading />}
    </div>
  );
};

export default ImageUploadProfile;
