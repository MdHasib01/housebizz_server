import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const SelectSmsType = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select Type",
  triggerClass = "",
  heightClass = "",
  onSelect = () => {},
  errorMessage = "",
  ...rest
}) => {
  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <div className="relative w-full">
        <Select {...rest}>
          <SelectTrigger
            className={cn(
              "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
              errorMessage && "!border-red-500",
              triggerClass,
              heightClass
            )}
          >
            <SelectValue placeholder={placeholder} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Absent SMS" className="cursor-pointer py-2.5">
              Absent SMS
            </SelectItem>
            <SelectItem
              value="Invoice Pending Bill"
              className="cursor-pointer py-2.5"
            >
              Invoice Pending Bill
            </SelectItem>
            <SelectItem value="Present SMS" className="cursor-pointer py-2.5">
              Present SMS
            </SelectItem>
            <SelectItem value="Bulk SMS" className="cursor-pointer py-2.5">
              Bulk SMS
            </SelectItem>
            <SelectItem
              value="Tabulation Result SMS"
              className="cursor-pointer py-2.5"
            >
              Tabulation Result SMS
            </SelectItem>
          </SelectContent>
        </Select>
      </div>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectSmsType;
