import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import "@/styles/calender.css";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { DayPicker } from "react-day-picker";
import { Fragment } from "react";
import { DateRangeIcon } from "@/services/assets/svgs";

const FormDatePicker = ({
  name,
  label,
  formControl,
  description,
  buttonClasses,
  value,
  setValue,
  containerClasses,
  ...props
}) => {
  const renderDatePicker = (selectedValue, onChangeHandler) => (
    <Popover>
      <PopoverTrigger asChild>
        {formControl ? (
          <FormControl>
            <Button
              variant="outline"
              className={cn(
                "min-h-12 w-full !outline-none !ring-0 bg-white shadow-none gap-4 rounded-lg border border-natural-300 focus:border-2 focus:border-main-500 text-sm font-normal !leading-[1.4]"
              )}
            >
              {selectedValue ? (
                format(selectedValue, "PPP")
              ) : (
                <span
                  className={cn(!selectedValue && "select_span_placeholder")}
                >
                  Pick a date
                </span>
              )}
              <DateRangeIcon className="ml-auto !h-6 !w-6 !shrink-0" />
            </Button>
          </FormControl>
        ) : (
          <Button
            variant="outline"
            className={cn(
              "min-h-12 w-full !outline-none !ring-0 bg-white shadow-none gap-4 rounded-lg border border-natural-300 focus:border-2 focus:border-main-500 text-sm font-normal !leading-[1.4]"
            )}
          >
            {selectedValue ? (
              format(selectedValue, "PPP")
            ) : (
              <span className={cn(!selectedValue && "select_span_placeholder")}>
                Pick a date
              </span>
            )}
            <DateRangeIcon className="ml-auto !h-6 !w-6 !shrink-0" />
          </Button>
        )}
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <DayPicker
          mode="single"
          defaultMonth={selectedValue || new Date()}
          selected={selectedValue}
          onSelect={onChangeHandler}
          className="px-4 py-5 w-[400px]"
          autoFocus
          showOutsideDays
          classNames={{
            day: "transition-all duration-150 hover:bg-natural-100",
            selected: "bg-main-500 !text-main-50 hover:bg-main-400",
          }}
          {...props}
        />
      </PopoverContent>
    </Popover>
  );

  return (
    <Fragment>
      {formControl ? (
        <FormField
          control={formControl}
          name={name}
          render={({ field }) => (
            <FormItem className={cn(containerClasses)}>
              {label && (
                <FormLabel className="text-text-700 text-sm font-semibold !leading-[1.2]">
                  {label}
                </FormLabel>
              )}
              {renderDatePicker(field.value, field.onChange)}
              <FormMessage className="text-text-600" />
            </FormItem>
          )}
        />
      ) : (
        <div className={cn(containerClasses)}>
          {label && (
            <p className="text-text-700 text-sm font-semibold !leading-[1.2] mb-2">
              {label}
            </p>
          )}
          {renderDatePicker(value, setValue)}
        </div>
      )}
    </Fragment>
  );
};

export default FormDatePicker;
