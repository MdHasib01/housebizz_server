import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import "@/styles/form.css";
import { Fragment } from "react";

const FormSelect = ({
  label,
  options,
  name,
  placeholder,
  className,
  formControl,
  selectContainerClassName,
  selectTriggerClassName,
  value,
  setValue,
  containerClasses,
  icon,
}) => {
  return (
    <Fragment>
      {formControl ? (
        <FormField
          control={formControl}
          name={name}
          render={({ field }) => (
            <FormItem className={containerClasses}>
              {label && (
                <FormLabel
                  className={cn(
                    "text-text-700 text-sm font-semibold !leading-[1.2]"
                  )}
                >
                  {label}
                </FormLabel>
              )}

              <Select
                onValueChange={field.onChange}
                defaultValue={field.value}
                value={field.value || ""}
              >
                <FormControl>
                  <SelectTrigger
                    className={cn(
                      "min-h-12 w-full !outline-none !ring-0 bg-white shadow-none gap-4 rounded-lg border border-natural-300 focus:border-2 focus:border-main-500",
                      !field.value && "select_span_placeholder",
                      selectTriggerClassName
                    )}
                    icon={icon}
                  >
                    <SelectValue placeholder={placeholder} />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {options?.map((option, index) => (
                    <SelectItem
                      key={`${option.value}_${index}`}
                      value={option.value}
                    >
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormControl className="w-full"> </FormControl>
              <FormMessage className="text-text-600" />
            </FormItem>
          )}
        />
      ) : (
        <div className={className}>
          {label && (
            <p className="text-sm font-semibold !leading-[1.2] text-text-700 mb-2">
              {label}
            </p>
          )}
          <Select
            className={cn("w-full", selectContainerClassName)}
            value={value}
            onValueChange={setValue}
          >
            <SelectTrigger
              className={cn(
                "min-h-12 w-full !outline-none !ring-0 bg-white shadow-none gap-4 rounded-lg border border-natural-300 focus:border-2 focus:border-main-500",
                !value && "select_span_placeholder",
                selectTriggerClassName
              )}
              icon={icon}
            >
              {value ? (
                <p className="select_span_placeholder !text-text-700 line-clamp-1">
                  {value}
                </p>
              ) : (
                <p className="select_span_placeholder line-clamp-1">
                  {placeholder}
                </p>
              )}
            </SelectTrigger>
            <SelectContent>
              {options?.map((option, index) => (
                <SelectItem
                  key={`${option.value}_${index}`}
                  value={option.value}
                >
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </Fragment>
  );
};

export default FormSelect;
