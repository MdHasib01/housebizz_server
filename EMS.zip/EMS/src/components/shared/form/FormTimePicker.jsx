import TimePicker from "rc-time-picker";
import "rc-time-picker/assets/index.css";
import "@/styles/timepicker.css";
import { TimerIcon } from "@/services/assets/svgs";
import { cn } from "@/lib/utils";
import { Fragment } from "react";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { pickerTimeFormat } from "@/services/helpers";
import moment from "moment";

const FormTimePicker = ({
  label,
  value,
  name,
  showSecond,
  className,
  inputContainerClassName,
  inputClassName,
  iconClassName,
  onChange,
  formControl,
  format = pickerTimeFormat,
  use12Hours = true,
  inputReadOnly,
  placeholder,
  ...props
}) => {
  return (
    <Fragment>
      {formControl ? (
        <FormField
          control={formControl}
          name={name}
          render={({ field }) => (
            <FormItem>
              {label && (
                <FormLabel
                  className={cn(
                    "text-text-700 text-sm font-semibold !leading-[1.2] mb-2"
                  )}
                >
                  {label}
                </FormLabel>
              )}
              <FormControl>
                <div
                  className={cn(
                    "h-fit w-full relative flex items-center rounded-lg border border-neutral-200 px-1 focus-within:border-2 focus-within:border-main-500",
                    inputContainerClassName
                  )}
                >
                  <TimePicker
                    showSecond={false}
                    className={cn(
                      inputClassName,
                      "placeholder:text-text-disabled text-sm font-normal !leading-[1.4] rounded-lg border-none focus-within:ring-0 bg-transparent"
                    )}
                    onChange={(value) => {
                      field.onChange(value);
                      onChange?.(value);
                    }}
                    format={pickerTimeFormat}
                    use12Hours={use12Hours}
                    inputReadOnly={inputReadOnly}
                    placeholder={placeholder}
                    // Ensure value is either null or a valid moment object
                    value={
                      value
                        ? moment(value)
                        : field.value
                        ? moment(field.value)
                        : null
                    }
                    {...props}
                  />
                  <TimerIcon className={cn("!h-6 !w-6 me-2", iconClassName)} />
                </div>
              </FormControl>
              <FormMessage className="text-text-600" />
            </FormItem>
          )}
        />
      ) : (
        <div className="flex flex-col">
          {label && (
            <p className="text-sm font-semibold !leading-[1.2] text-text-700 mb-2">
              {label}
            </p>
          )}
          <div
            className={cn(
              "h-fit min-w-full relative flex flex-row items-center rounded-lg !border border-neutral-200 px-1",
              inputContainerClassName
            )}
          >
            <TimePicker
              showSecond={false}
              className={inputClassName}
              onChange={onChange}
              format={format}
              use12Hours={use12Hours}
              inputReadOnly={inputReadOnly}
              placeholder={placeholder}
              value={value}
              {...props}
            />
            <div className="me-[6px]">
              <TimerIcon className={cn("!h-6 !w-6", iconClassName)} />
            </div>
          </div>
        </div>
      )}
    </Fragment>
  );
};

export default FormTimePicker;
