import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { Fragment } from "react";

const FormInput = ({
  name,
  label,
  placeholder,
  formControl,
  inputClasses,
  containerClasses,
  type = "text",
  value,
  setValue,
  ...props
}) => {
  return (
    <Fragment>
      {formControl ? (
        <FormField
          control={formControl}
          name={name}
          render={({ field }) => (
            <FormItem className={containerClasses}>
              {label && (
                <FormLabel
                  className={cn(
                    "text-text-700 text-sm font-semibold !leading-[1.2]"
                  )}
                >
                  {label}
                </FormLabel>
              )}
              <FormControl className="w-full">
                <Input
                  className={cn(
                    inputClasses,
                    "placeholder:text-text-disabled text-sm font-normal !leading-[1.4] rounded-lg border border-natural-300 focus-within:border-2 !ring-0 focus:border-main-500 !outline-none bg-transparent h-12 !p-4 shadow-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  )}
                  placeholder={placeholder}
                  type={type}
                  onKeyDown={(e) => {
                    if (type === "number") {
                      if (
                        e.key === "e" ||
                        e.key === "E" ||
                        e.key === "+" ||
                        e.key === "-"
                      ) {
                        e.preventDefault();
                      }
                    }
                  }}
                  onInput={(e) => {
                    if (type === "number") {
                      e.target.value = e.target.value.replace(/[eE]/g, "");
                    }
                  }}
                  {...field}
                  {...props}
                />
              </FormControl>
              <FormMessage className="text-red-400" />
            </FormItem>
          )}
        />
      ) : (
        <div className="w-full flex flex-col justify-start gap-2">
          {label && (
            <Label
              className={cn(
                "text-text-700 text-sm font-semibold !leading-[1.2]"
              )}
              htmlFor={name}
            >
              {label}
            </Label>
          )}
          <Input
            id={name}
            className={cn(
              inputClasses,
              "placeholder:text-text-disabled text-sm text-text-700 font-normal !leading-[1.2] rounded-lg border border-natural-300 focus-within:border-2 !ring-0 focus:border-main-500 !outline-none bg-transparent h-12 !p-4 shadow-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            )}
            value={value}
            onChangeCapture={setValue}
            placeholder={placeholder}
            type={type}
            onKeyDown={(e) => {
              if (type === "number") {
                if (
                  e.key === "e" ||
                  e.key === "E" ||
                  e.key === "+" ||
                  e.key === "-"
                ) {
                  e.preventDefault();
                }
              }
            }}
            onInput={(e) => {
              if (type === "number") {
                e.target.value = e.target.value.replace(/[eE]/g, "");
              }
            }}
            {...props}
          />
        </div>
      )}
    </Fragment>
  );
};

export default FormInput;
