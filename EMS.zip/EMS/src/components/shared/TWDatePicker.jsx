import { cn } from "@/lib/utils";
import Datepicker from "react-tailwindcss-datepicker";

function TWDatePicker({
  value = {
    startDate: null,
    endDate: null,
  },
  setValue = () => {},
  id = "",
  wrapper = "",
  label = "",
  labelClass = "",
  symble = "*",
  symbleClass = "",
  inputClass = "",
  errorMessage = "",
  ...rest
}) {
  return (
    <div className={`flex flex-col ${label != "" && "gap-2"} ${wrapper}`}>
      <label className={`label ${labelClass}`} htmlFor="">
        {label}
      </label>
      <Datepicker
        useRange={false}
        asSingle={true}
        value={value}
        popoverDirection="down"
        onChange={setValue}
        toggleClassName="absolute right-0 md:right-2 top-1/2 -translate-y-1/2"
        containerClassName="relative w-full customDatepicker border-none light"
        inputClassName={cn(
          "input",
          errorMessage && "!border-red-500",
          inputClass
        )}
        displayFormat="DD/MM/YYYY"
        showShortcuts={false}
        {...rest}
      />
      {errorMessage && (
        <p className="text-red-500 text-sm -mt-1">{errorMessage}</p>
      )}
    </div>
  );
}

export default TWDatePicker;
