import { cn } from "@/lib/utils";
import { TimerIcon } from "@/services/assets/svgs";
import { pickerTimeFormat } from "@/services/helpers";
import "@/styles/timepicker.css";
import moment from "moment";
import TimePicker from "rc-time-picker";
import "rc-time-picker/assets/index.css";
import { useRef } from "react";

const TimePickerInput = ({
  label,
  value,
  name,
  showSecond,
  className,
  inputContainerClassName,
  inputClassName,
  iconClassName,
  onChange,
  format = pickerTimeFormat,
  use12Hours = true,
  inputReadOnly,
  placeholder,
  wrapper = "",
  labelClass = "",
  errorMessage = "",
  ...props
}) => {
  const timePickerRef = useRef(null);

  const handleTimeChange = (time) => {
    if (!time) {
      onChange?.("");
      return;
    }

    const formattedTime = time.format("HH:MM:A");
    onChange?.(formattedTime);
  };

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
        </div>
      )}

      <TimePicker
        ref={timePickerRef}
        showSecond={false}
        className={cn(inputClassName, "w-full", errorMessage ? "error" : "")}
        use12Hours={use12Hours}
        inputReadOnly={inputReadOnly}
        placeholder={placeholder}
        value={value ? moment(value, "HH:mm") : ""} // Ensure correct display
        onChange={handleTimeChange}
        format="hh:mm A" // Display format (12-hour)
        {...props}
        inputIcon={
          <TimerIcon
            className={cn(
              "!h-6 !w-6 absolute top-1/2 -translate-y-1/2 right-4 z-50 cursor-pointer",

              iconClassName
            )}
          />
        }
      />

      {errorMessage && (
        <p className="text-status-error text-sm -mt-1">{errorMessage}</p>
      )}
    </div>
  );
};

export default TimePickerInput;
