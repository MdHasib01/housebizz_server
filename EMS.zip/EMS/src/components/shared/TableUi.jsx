import ErrorUi from "./ErrorUi";
import NoData from "./NoData";

function TableUi({
  isError = false,
  error = {},
  errorTitle = "",
  errorDescription = "",
  emptyTitle = "",
  emptyDescription = "",
}) {
  return isError && error?.status !== 404 ? (
    <ErrorUi title={errorTitle} description={errorDescription} />
  ) : (
    <NoData title={emptyTitle} text={emptyDescription} />
  );
}

export default TableUi;
