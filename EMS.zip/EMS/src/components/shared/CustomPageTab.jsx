import { cn } from "@/lib/utils";

const CustomPageTab = ({
  activeTab,
  setActiveTab,
  tabs,
  className,
  widthThreshold = 2,
}) => {
  return (
    <div className={cn("relative w-full max-w-96", className)}>
      {/* Tabs Container */}
      <div className="flex relative border border-natural-500 rounded-lg overflow-hidden h-11 group">
        {tabs.map((tab, index) => (
          <button
            key={index}
            onClick={() => setActiveTab(index)}
            className={`flex-1 text-center py-2 relative z-10 ${
              activeTab === index
                ? "text-white font-semibold !leading-[1.2]"
                : "text-text-600 font-normal !leading-[1.4]"
            }`}
          >
            {tab}
          </button>
        ))}

        {/* Active Background */}
        <div
          className="absolute left-1 top-1/2 bg-secondary-500 rounded-[4px] transition-all duration-300 h-[calc(100%-8px)]"
          style={{
            transform: `translateX(calc(${
              activeTab * 100
            }% + 0px)) translateY(-50%)`,
            width: `calc(${100 / tabs.length}% - 3px)`,
          }}
        />
      </div>
    </div>
  );
};

export default CustomPageTab;
