import React from "react";
import { cn } from "@/lib/utils";
import {
  KeyboardDoubleArrowLeftIcon,
  KeyboardDoubleArrowRightIcon,
} from "@/services/assets/svgs";
import colors from "@/services/config/colors";

const CustomRDTPagination = ({
  rowsPerPage,
  rowCount,
  onChangePage,
  onChangeRowsPerPage,
  currentPage,
}) => {
  // total pages
  const totalPages = Math.ceil(rowCount / rowsPerPage);

  // handle previous page
  const handlePrevious = () => {
    if (currentPage > 1) {
      onChangePage(currentPage - 1);
    }
  };

  // handle next page
  const handleNext = () => {
    if (currentPage < totalPages) {
      onChangePage(currentPage + 1);
    }
  };

  // handle page change
  const handlePageChange = (page) => {
    onChangePage(page);
  };

  // handle rows per page change
  const handleRowsPerPageChange = (e) => {
    onChangeRowsPerPage(Number(e.target.value));
  };

  // render page numbers
  const renderPageNumbers = () => {
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(
        <button
          key={i}
          onClick={() => handlePageChange(i)}
          className={cn(
            "w-8 h-8",
            currentPage === i
              ? "bg-main-500 text-sm font-bold text-white rounded-[8px]"
              : "bg-transparent"
          )}
        >
          {i}
        </button>
      );
    }
    return pageNumbers;
  };

  return (
    <div className="flex items-center gap-x-4 justify-end mt-7 -z-[999999]">
      <span className="text-sm text-text-600">
        {`Showing ${(currentPage - 1) * rowsPerPage + 1} to ${Math.min(
          currentPage * rowsPerPage,
          rowCount
        )} of ${rowCount} entries`}
      </span>

      <div className="flex justify-between items-center gap-x-[10px]">
        <button
          onClick={handlePrevious}
          disabled={currentPage === 1}
          className="disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <KeyboardDoubleArrowLeftIcon
            className={"h-5 w-5"}
            color={currentPage === 1 ? colors.text[300] : colors.main[500]}
          />
        </button>
        <div className="flex gap-x-[10px]">{renderPageNumbers()}</div>
        <button
          onClick={handleNext}
          disabled={currentPage === totalPages}
          className="disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <KeyboardDoubleArrowRightIcon
            className={"h-5 w-5"}
            color={
              currentPage === totalPages ? colors.text[300] : colors.main[500]
            }
          />
        </button>
      </div>

      <div className="hidden md:block">
        <select
          className="max-w-[72px] ps-2 h-8 text-text-700 bg-natural-50 rounded-[8px] text-sm outline-none"
          value={rowsPerPage}
          onChange={handleRowsPerPageChange}
        >
          <option value={5}>5</option>
          <option value={10}>10</option>
          <option value={20}>20</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
        </select>
      </div>
    </div>
  );
};

export default CustomRDTPagination;
