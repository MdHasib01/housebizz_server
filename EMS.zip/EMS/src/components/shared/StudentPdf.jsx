import { MailIcon, PhoneIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import { forwardRef } from "react";
import { useSelector } from "react-redux";
import Divider from "./Divider";
import Input from "./Input";

const StudentPdf = forwardRef(({ student }, ref) => {
  const { auth } = useSelector((state) => state.auth);
  const { institute } = auth || {};

  return (
    <div className="hidden">
      <div
        ref={ref}
        className="p-6 sm:p-10 pt-0 bg-white max-w-[840px] mx-auto shadow-lg shadow-text-100 rounded-2xl"
      >
        <div className="text-center">
          <div>
            <h2 className="text-xl sm:text-2xl md:text-3xl font-medium">
              {institute?.institute_name}
            </h2>
            <p className="text-sm sm:text-base mt-2">
              {institute?.institute_upazilla}, {institute?.institute_district} -{" "}
              {institute?.institute_postal_code}
            </p>
            <div className="flex items-center gap-4 justify-center mt-2">
              <a
                href={`tel:${institute?.institute_mobilephone}`}
                className="flex items-center gap-1.5"
              >
                <PhoneIcon color={colors.text[700]} />
                {institute?.institute_mobilephone}
              </a>
              <a
                href={`mailto:${institute?.institute_email}`}
                className="flex items-center gap-1.5"
              >
                <MailIcon />
                {institute?.institute_email}
              </a>
            </div>
          </div>
          <p className="text-lg sm:text-xl mt-4 sm:mt-6 mb-6 sm:mb-10 font-medium bg-neutral-100 p-2 rounded-md">
            Admission Form
          </p>
          <Divider title="Student Basic Information" />
        </div>
        <form action="" className="flex flex-col gap-6 mt-6">
          <div className="grid sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.name_english}
              label="Full Name (in English)"
              placeholder="Name (in English)"
            />
            <Input
              readOnly
              defaultValue={student?.name_bangla}
              placeholder="Full Name (in Bangla)"
              label="Full Name (in Bangla)"
            />
            <Input
              readOnly
              defaultValue={student?.mobile_number}
              label="Mobile Number"
              placeholder="Mobile Number"
            />
            <Input
              readOnly
              defaultValue={student?.gender}
              label="Gender"
              placeholder="Gender"
            />
            <Input
              readOnly
              defaultValue={student?.date_of_birth}
              label="Date of Birth"
              placeholder="Date of Birth"
            />
            <Input
              readOnly
              defaultValue={student?.birth_certificate_number}
              label="Birth Certificate Number"
              placeholder="Birth Certificate Number"
            />
            <Input
              readOnly
              defaultValue={student?.email}
              label="Email"
              placeholder="Email"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.nationality}
              label="Nationality"
              placeholder="Nationality"
            />
            <Input
              readOnly
              defaultValue={student?.religion}
              label="Religion"
              placeholder="Religion"
            />
            <Input
              readOnly
              defaultValue={student?.blood_group}
              label="Blood Group"
              placeholder="Blood Group"
            />
            <Input
              readOnly
              defaultValue={student?.disability}
              label="Special Child/Disability"
              placeholder="Special Child/Disability"
            />
          </div>
          <Divider title="Academic Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.academic_year}
              label="Year/Session"
              placeholder="Year/Session"
            />
            <Input
              readOnly
              defaultValue={student?.current_class?.local_class_name}
              label="Class"
              placeholder="Class"
            />
            {student?.current_class?.local_class_code > 8 && (
              <Input
                readOnly
                defaultValue={student?.current_group?.global_group_name}
                label="Group"
                placeholder="Group"
              />
            )}
            <Input
              readOnly
              defaultValue={student?.current_section?.section_name}
              label="Select Section"
              placeholder="Select Section"
            />
            <Input
              readOnly
              defaultValue={student?.current_category?.local_category_name}
              label="Select Category"
              placeholder="Select Category"
            />
          </div>
          <Divider title="Previous Institute Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.previous_insitute_name}
              label="Name of The Institution"
              placeholder="Name of The Institution"
            />
            <Input
              readOnly
              defaultValue={student?.previous_class}
              label="Class"
              placeholder="Class"
            />
            <Input
              readOnly
              defaultValue={student?.previous_result}
              label="Result"
              placeholder="Result"
            />
          </div>
          <Divider title="Father's Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.father_name_english}
              label="Name (in English)"
              placeholder="Name (in English)"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.father_name_bangla}
              label="Name (in Bangla)"
              placeholder="Name (in Bangla)"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.father_mobile_number}
              label="Mobile Number"
              placeholder="Mobile Number"
            />
            <Input
              readOnly
              defaultValue={student?.father_nid_number}
              label="NID Number"
              placeholder="NID Number"
            />
            <Input
              readOnly
              defaultValue={student?.father_profession}
              label="Profession"
              placeholder="Profession"
              wrapper="sm:col-span-2"
            />
          </div>
          <Divider title="Mother's Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.mother_name_english}
              label="Name (in English)"
              placeholder="Name (in English)"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.mother_name_bangla}
              label="Name (in Bangla)"
              placeholder="Name (in Bangla)"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.mother_mobile_number}
              label="Mobile Number"
              placeholder="Mobile Number"
            />
            <Input
              readOnly
              defaultValue={student?.mother_nid_number}
              label="NID Number"
              placeholder="NID Number"
            />
            <Input
              readOnly
              defaultValue={student?.mother_profession}
              label="Profession"
              placeholder="Profession"
              wrapper="sm:col-span-2"
            />
          </div>
          <Divider title="Guardian's Information" />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.guardian_name_english}
              label="Name (in English)"
              placeholder="Name (in English)"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.guardian_name_bangla}
              label="Name (in Bangla)"
              placeholder="Name (in Bangla)"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.guardian_mobile_number}
              label="Mobile Number"
              placeholder="Mobile Number"
            />
            <Input
              readOnly
              defaultValue={student?.guardian_nid_number}
              label="NID Number"
              placeholder="NID Number"
            />
            <Input
              readOnly
              defaultValue={student?.guardian_profession}
              label="Profession"
              placeholder="Profession"
              wrapper="sm:col-span-2"
            />
          </div>
          <Divider title="Present Address Information" />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.present_address_line}
              label="Present Address"
              placeholder="Present Address"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.present_address_district}
              label="District"
              placeholder="District"
            />
            <Input
              readOnly
              defaultValue={student?.present_address_upozilla}
              label="Upazilla"
              placeholder="Upazilla"
            />
            <Input
              readOnly
              defaultValue={student?.present_address_post_office}
              label="Post Office"
              placeholder="Post Office"
            />
            <Input
              readOnly
              defaultValue={student?.present_address_post_code}
              label="Post Code"
              placeholder="Post Code"
            />
          </div>
          <Divider title="Permanent Address Information" />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              readOnly
              defaultValue={student?.permanent_address_line}
              label="Permanent Address"
              placeholder="Permanent Address"
              wrapper="sm:col-span-2"
            />
            <Input
              readOnly
              defaultValue={student?.permanent_address_district}
              label="District"
              placeholder="District"
            />
            <Input
              readOnly
              defaultValue={student?.permanent_address_upozilla}
              label="Upazilla"
              placeholder="Upazilla"
            />
            <Input
              readOnly
              defaultValue={student?.permanent_address_post_office}
              label="Post Office"
              placeholder="Post Office"
            />
            <Input
              readOnly
              defaultValue={student?.permanent_address_post_code}
              label="Post Code"
              placeholder="Post Code"
            />
          </div>
          <Divider title="Transaction Information" />
          <Input
            readOnly
            defaultValue={student?.transaction_id}
            label="Transaction ID"
            placeholder="Transaction ID"
            wrapper="sm:col-span-2"
          />
          {student?.image && (
            <>
              <Divider title="Passport Size Image" />
              <img
                src={student?.image}
                className="w-32 h-32 rounded-full flex-col-reverse justify-center"
              />
            </>
          )}
        </form>
      </div>
    </div>
  );
});

export default StudentPdf;
