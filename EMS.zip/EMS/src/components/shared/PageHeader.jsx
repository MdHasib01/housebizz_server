import { cn } from "@/lib/utils";
import { PlusIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "../ui/button";

function PageHeader({
  title = "",
  btnText = "",
  path = "",
  className = "px-2",
  type = "link",
  placeholder = "Add",
  value = "",
  onChange = () => {},
  onBtnClick = () => {},
  ...rest
}) {
  return (
    <div className={cn("flex gap-4 items-center justify-between", className)}>
      {title && <p className="card_title">{title}</p>}
      {type == "link" && btnText && (
        <Link to={path} className="btn_blue" {...rest}>
          <PlusIcon className="!h-5 !w-5 shrink-0" />
          <span>{btnText}</span>
        </Link>
      )}

      {type === "add" && (
        <div className="flex gap-4 flex-1 max-w-[410px]">
          <input
            onChange={onChange}
            type="text"
            value={value}
            placeholder={placeholder}
            className="input"
          />
          <Button type="button" onClick={onBtnClick} className="w-28">
            {btnText}
          </Button>
        </div>
      )}
    </div>
  );
}

export default PageHeader;
