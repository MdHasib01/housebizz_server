import { images } from "@/services";
import {
  LocationMarkerIcon,
  MailIcon,
  PhoneIcon,
} from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import { useSelector } from "react-redux";

function InstitutePdfHeader() {
  const { auth } = useSelector((state) => state.auth);
  const { institute } = auth || {};
  return (
    <div className="flex items-start justify-between">
      <div className="flex flex-row items-center gap-[6px] justify-start">
        <img
          src={images.appLogo}
          alt="Logo"
          className="w-6 h-6 object-contain"
        />
        <span className="text-xs font-black leading-none">SMART PATHSHALA</span>
      </div>
      <div className="flex flex-col items-end gap-0.5">
        <h2 className="text-base font-semibold text-text-900 mb-1">
          {institute?.institute_name}
        </h2>
        <div className="flex items-end gap-1.5">
          <span className="text-[10px] text-text-600">
            {institute?.institute_address} - {institute?.institute_postal_code}
          </span>
          <LocationMarkerIcon color={colors.text[600]} />
        </div>
        <div className="flex items-end gap-1.5">
          <span className="text-[10px] text-text-600">
            {institute?.institute_mobilephone}
          </span>
          <PhoneIcon color={colors.text[600]} />
        </div>
        <div className="flex items-end gap-1.5">
          <span className="text-[10px] text-text-600">
            {institute?.institute_email}
          </span>
          <MailIcon color={colors.text[600]} />
        </div>
      </div>
    </div>
  );
}

export default InstitutePdfHeader;
