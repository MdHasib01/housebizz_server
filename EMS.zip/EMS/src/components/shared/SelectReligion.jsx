import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const SelectReligion = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select Religion",
  triggerClass = "",
  heightClass = "",
  onSelect = () => {},
  errorMessage = "",
  ...rest
}) => {
  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <div className="relative w-full">
        <Select {...rest}>
          <SelectTrigger
            className={cn(
              "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
              errorMessage && "!border-red-500",
              triggerClass,
              heightClass
            )}
          >
            <SelectValue placeholder={placeholder} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Islam" className="cursor-pointer py-2.5">
              Islam
            </SelectItem>
            <SelectItem value="Hindu" className="cursor-pointer py-2.5">
              Hindu
            </SelectItem>
            <SelectItem value="Christian" className="cursor-pointer py-2.5">
              Christian
            </SelectItem>
            <SelectItem value="Buddhist" className="cursor-pointer py-2.5">
              Buddhist
            </SelectItem>
            <SelectItem value="Other" className="cursor-pointer py-2.5">
              Other
            </SelectItem>
          </SelectContent>
        </Select>
      </div>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectReligion;
