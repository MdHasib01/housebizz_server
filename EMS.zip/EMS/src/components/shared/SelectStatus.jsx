import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const SelectStatus = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select Status",
  triggerClass = "",
  heightClass = "",
  onSelect = () => {},
  errorMessage = "",
  ...rest
}) => {
  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <div className="relative w-full">
        <Select {...rest}>
          <SelectTrigger
            className={cn(
              "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
              errorMessage && "!border-red-500",
              triggerClass,
              heightClass
            )}
          >
            <SelectValue placeholder={placeholder} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="available" className="cursor-pointer py-2.5">
              Available
            </SelectItem>
            <SelectItem value="left" className="cursor-pointer py-2.5">
              Left
            </SelectItem>
            <SelectItem value="rusticated" className="cursor-pointer py-2.5">
              Rusticated
            </SelectItem>
            <SelectItem value="pending" className="cursor-pointer py-2.5">
              Pending
            </SelectItem>
          </SelectContent>
        </Select>
      </div>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectStatus;
