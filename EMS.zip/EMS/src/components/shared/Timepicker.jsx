import { useEffect, useState } from "react";

// Your component code...

const hours12 = [
  "01",
  "02",
  "03",
  "04",
  "05",
  "06",
  "07",
  "08",
  "09",
  "10",
  "11",
  "12",
];
const hours24 = [
  "00",
  "01",
  "02",
  "03",
  "04",
  "05",
  "06",
  "07",
  "08",
  "09",
  "10",
  "11",
  "12",
  "13",
  "14",
  "15",
  "16",
  "17",
  "18",
  "19",
  "20",
  "21",
  "22",
  "23",
];
const minutes = [
  "00",
  "01",
  "02",
  "03",
  "04",
  "05",
  "06",
  "07",
  "08",
  "09",
  "10",
  "11",
  "12",
  "13",
  "14",
  "15",
  "16",
  "17",
  "18",
  "19",
  "20",
  "21",
  "22",
  "23",
  "24",
  "25",
  "26",
  "27",
  "28",
  "29",
  "30",
  "31",
  "32",
  "33",
  "34",
  "35",
  "36",
  "37",
  "38",
  "39",
  "40",
  "41",
  "42",
  "43",
  "44",
  "45",
  "46",
  "47",
  "48",
  "49",
  "50",
  "51",
  "52",
  "53",
  "54",
  "55",
  "56",
  "57",
  "58",
  "59",
];
const seconds = [
  "00",
  "01",
  "02",
  "03",
  "04",
  "05",
  "06",
  "07",
  "08",
  "09",
  "10",
  "11",
  "12",
  "13",
  "14",
  "15",
  "16",
  "17",
  "18",
  "19",
  "20",
  "21",
  "22",
  "23",
  "24",
  "25",
  "26",
  "27",
  "28",
  "29",
  "30",
  "31",
  "32",
  "33",
  "34",
  "35",
  "36",
  "37",
  "38",
  "39",
  "40",
  "41",
  "42",
  "43",
  "44",
  "45",
  "46",
  "47",
  "48",
  "49",
  "50",
  "51",
  "52",
  "53",
  "54",
  "55",
  "56",
  "57",
  "58",
  "59",
];

function Timepicker({
  time = "",
  setTime = (value) => value,
  use12Hours = true,
  showSeconds = false,
  showFormat = true,
  showIcon = true,
  timeIcon,
  closeIcon,
  id = "timepicker",
  classNames = {
    wrapper: "",
    inputWrapper: "",
    input: "",
    panel: "",
    innerPanel: "",
    selectList: "",
    selectHour: "",
    selectMinute: "",
    selectSecond: "",
    selectFormat: "",
    activeTab: "",
  },
  ...props
}) {
  const [showPanel, setShowPanel] = useState(false);
  const [times, setTimes] = useState({
    hour: "",
    minute: "",
    second: "",
    format: "",
  });

  const handleBlur = (e) => {
    if (!e.currentTarget.contains(e.relatedTarget)) {
      setShowPanel(false);
    }
  };

  const handleWrapperClick = (event) => {
    if (event.currentTarget.contains(event.relatedTarget) || !showPanel) {
      setShowPanel(true);
    }
  };

  const handleTime = ({ value, type = "hour" }) => {
    setTimes((prev) => {
      const updatedTimes = { ...prev, [type]: value };
      setTimeout(() => {
        if (use12Hours) {
          const isAllSelected =
            updatedTimes.hour && updatedTimes.minute && updatedTimes.format;
          if (isAllSelected) {
            setTime(
              `${updatedTimes.hour}:${updatedTimes.minute} ${updatedTimes.format}`
            );
            setShowPanel(false);
          }
        } else {
          if (updatedTimes.hour && updatedTimes.minute && updatedTimes.second) {
            setTime(
              `${updatedTimes.hour}:${updatedTimes.minute}:${updatedTimes.second}`
            );
            setShowPanel(false);
          }
        }
      }, 10);

      return updatedTimes;
    });
  };

  const onButtonClick = (event) => {
    if (time) {
      event.stopPropagation();
      setTime("");
      setTimes({ hour: "", minute: "", second: "", format: "" });
      setShowPanel(false);
    } else {
      setShowPanel((prev) => !prev);
    }
  };

  useEffect(() => {
    if (time) {
      if (use12Hours) {
        const [hour, minute, format] = time.split(/:| /);
        setTimes({ hour, minute, format });
      } else {
        const [hour, minute, second] = time.split(":");
        setTimes({ hour, minute, second });
      }
    }
  }, []);

  return (
    <div
      className={`tmc-wrapper ${classNames?.wrapper}`}
      onBlur={handleBlur}
      onClick={handleWrapperClick}
    >
      <label
        htmlFor={id}
        className={`tmc-input-wrapper ${classNames?.inputWrapper}`}
      >
        <input
          type="text"
          id={id}
          className={`tmc-input ${classNames?.input}`}
          value={time}
          onFocus={() => setShowPanel(true)}
          readOnly
          {...props}
        />
        {showIcon && (
          <button
            type="button"
            className={`tmc-icon ${classNames?.iconButton}`}
            onClick={onButtonClick}
          >
            {time
              ? timeIcon || (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                  >
                    <path
                      d="M18.2997 5.7107C17.9097 5.3207 17.2797 5.3207 16.8897 5.7107L11.9997 10.5907L7.10973 5.7007C6.71973 5.3107 6.08973 5.3107 5.69973 5.7007C5.30973 6.0907 5.30973 6.7207 5.69973 7.1107L10.5897 12.0007L5.69973 16.8907C5.30973 17.2807 5.30973 17.9107 5.69973 18.3007C6.08973 18.6907 6.71973 18.6907 7.10973 18.3007L11.9997 13.4107L16.8897 18.3007C17.2797 18.6907 17.9097 18.6907 18.2997 18.3007C18.6897 17.9107 18.6897 17.2807 18.2997 16.8907L13.4097 12.0007L18.2997 7.1107C18.6797 6.7307 18.6797 6.0907 18.2997 5.7107Z"
                      fill="#616161"
                    />
                  </svg>
                )
              : closeIcon || (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="25"
                    height="24"
                    viewBox="0 0 25 24"
                    fill="none"
                  >
                    <circle
                      cx="12.333"
                      cy="12"
                      r="9"
                      stroke="#33363F"
                      strokeWidth="2"
                    />
                    <path
                      d="M16.833 12H12.583C12.4449 12 12.333 11.8881 12.333 11.75V8.5"
                      stroke="#33363F"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                  </svg>
                )}
          </button>
        )}
      </label>
      <div
        className={`tmc-panel ${showPanel ? "show-panel" : ""} ${
          classNames?.panel
        }`}
      >
        <div
          className={`tmc-inner-panel ${classNames?.innerPanel}`}
          onMouseDown={(e) => e.preventDefault()}
        >
          <ul
            className={`tmc-select-list tmc-select-hour ${classNames?.selectList}`}
          >
            {(use12Hours ? hours12 : hours24).map((hour) => (
              <li
                key={hour}
                onClick={() => handleTime({ value: hour, type: "hour" })}
                className={`${
                  times?.hour === hour ? `active ${classNames?.activeTab}` : ""
                } ${classNames?.selectHour}`}
              >
                {hour}
              </li>
            ))}
          </ul>
          <ul className="tmc-select-list tmc-select-minute">
            {minutes.map((minute) => (
              <li
                key={minute}
                onClick={() => handleTime({ value: minute, type: "minute" })}
                className={`${
                  times?.minute === minute
                    ? `active ${classNames?.activeTab}`
                    : ""
                } ${classNames?.selectMinute}`}
              >
                {minute}
              </li>
            ))}
          </ul>
          {showSeconds && (
            <ul className="tmc-select-list tmc-select-second">
              {seconds.map((second) => (
                <li
                  key={second}
                  onClick={() => handleTime({ value: second, type: "second" })}
                  className={`${
                    times?.second === second
                      ? `active ${classNames?.activeTab}`
                      : ""
                  } ${classNames?.selectSecond}`}
                >
                  {second}
                </li>
              ))}
            </ul>
          )}
          {showFormat && use12Hours && (
            <ul className="tmc-select-list tmc-select-format">
              <li
                onClick={() => handleTime({ value: "AM", type: "format" })}
                className={`${
                  times?.format === "AM"
                    ? `active ${classNames?.activeTab}`
                    : ""
                } ${classNames?.selectFormat}`}
              >
                AM
              </li>
              <li
                onClick={() => handleTime({ value: "PM", type: "format" })}
                className={`${
                  times?.format === "PM"
                    ? `active ${classNames?.activeTab}`
                    : ""
                } ${classNames?.selectFormat}`}
              >
                PM
              </li>
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

export default Timepicker;
