import { EyeDisabledIcon, EyeIcon } from "@/services/assets/svgs";
import { useState } from "react";

function Password({
  label = "",
  labelClass = "",
  wrapper = "",
  innerWrapper = "",
  className = "",
  type = "text",
  icon = null,
  id = "password",
  labelChildren = null,
  ...rest
}) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <label
        htmlFor={id}
        className={`flex items-center justify-between gap-1 bg-white border border-grey-600 focus:border-grey-600 px-4 py-3.5 rounded-lg cursor-text ${innerWrapper}`}
      >
        <input
          type={showPassword ? "text" : "password"}
          className="input-none"
          autoComplete="false"
          {...rest}
          id={id}
        />
        <button type="button" onClick={() => setShowPassword((prev) => !prev)}>
          {showPassword ? <EyeIcon /> : <EyeDisabledIcon />}
        </button>
      </label>
    </div>
  );
}

export default Password;
