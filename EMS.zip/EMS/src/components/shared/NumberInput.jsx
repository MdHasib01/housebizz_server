import { cn } from "@/lib/utils";
import { useRef } from "react";

function NumberInput({
  classes = "",
  label = "",
  labelClass = "",
  inputWrapper = "",
  wrapperClass = "",
  errorMessage = "",
  children,
  ...rest
}) {
  const inputRef = useRef(null);
  const handleInput = () => {
    if (inputRef.current) {
      inputRef.current.value = inputRef.current.value.replace(/[^0-9.]/g, "");
      const parts = inputRef.current.value.split(".");
      if (parts.length > 2) {
        inputRef.current.value = parts[0] + "." + parts.slice(1).join("");
      }
    }
  };

  return (
    <div className={cn("flex flex-col gap-2", wrapperClass)}>
      {label && (
        <label className={cn(`label`, labelClass)} htmlFor="">
          {label}
        </label>
      )}
      <div className={cn(`h-full relative`, inputWrapper)}>
        <input
          type="text"
          className={cn(
            `input h-full`,
            classes,
            errorMessage ? "!border-status-error" : ""
          )}
          ref={inputRef}
          onInput={handleInput}
          {...rest}
        />
        {children}
      </div>
      {errorMessage && (
        <p className="text-status-error text-sm -mt-1">{errorMessage}</p>
      )}
    </div>
  );
}

export default NumberInput;
