import { cn } from "@/lib/utils";

function Divider({ title = "", dividerClass, className = "" }) {
  return (
    <div className="flex items-center w-full gap-6 sm:col-span-2">
      <div
        className={cn("flex-1 h-[1px] border border-dashed", dividerClass)}
      ></div>
      <span className={cn("text-base font-medium text-text-900", className)}>
        {title}
      </span>
      <div
        className={cn("flex-1 h-[1px] border border-dashed", dividerClass)}
      ></div>
    </div>
  );
}

export default Divider;
