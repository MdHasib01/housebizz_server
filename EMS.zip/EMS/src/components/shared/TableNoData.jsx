import NoData from "./NoData";

export default function TableNoData({ column = 3, title = "" }) {
  return (
    <tr className="table_row text-neutral-600">
      <td className="table_td" colSpan={column}>
        <NoData title={title} />
      </td>
    </tr>
  );
}
