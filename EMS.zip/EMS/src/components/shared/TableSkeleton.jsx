import CustomSpinner from "./CustomSpinner";

export default function TableSkeleton({ column = 3 }) {
  return (
    <tr className="table_row text-neutral-600">
      <td className="table_td" colSpan={column}>
        <CustomSpinner />
      </td>
    </tr>
  );
}
