import { cn } from "@/lib/utils";
import { SearchIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import { useState } from "react";

const CustomSearchBox = ({
  setSearchValue,
  isRequired = false,
  placeholderText = "Search here",
  className,
  inputClassName,
  ...props
}) => {
  const [inputValue, setInputValue] = useState("");

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      if (isRequired && inputValue.trim() === "") {
        alert("Search value is required");
        return;
      }
      setSearchValue(inputValue.trim());
    }
  };

  return (
    <div
      className={cn(
        "flex items-center border border-gray-300 rounded-lg p-4",
        className
      )}
    >
      <SearchIcon className="mr-2" color={colors.natural[600]} />

      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholderText}
        className={cn(
          "flex-grow outline-none text-sm font-normal !leading-[1.4] text-gray-700 placeholder:text-text-disabled",
          inputClassName
        )}
        {...props}
      />
    </div>
  );
};

export default CustomSearchBox;
