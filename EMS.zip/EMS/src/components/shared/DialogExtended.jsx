import Image from "@/components/shared/Image";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { questionMarkRed } from "@/services/assets/images";
import { Fragment } from "react";

const DialogExtended = ({
  isDialogOpen = false,
  setIsDialogOpen,
  onCancelPress,
  onconfirmPress,
  title = "",
  text = "",
  confirmButtonText = "Delete",
  imageSrc = questionMarkRed,
  customDialogButtons,
}) => {
  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogContent className="font-inter !rounded-xl min-w-[576px] py-11 px-10">
        <DialogTitle className="hidden" />
        <DialogDescription className="hidden" />
        <div className="flex flex-col justify-between items-center w-full gap-10">
          <Image
            src={imageSrc}
            alt="question mark red"
            className="h-[100px] w-[100px]"
          />

          <div className="flex flex-col gap-4 items-center">
            <p className="text-[28px] font-bold !leading-[1.2] text-text-700">
              {title}
            </p>
            <p className="text-base font-normal !leading-normal text-text-600">
              {text}
            </p>
          </div>

          <div className="flex gap-4 w-full">
            {customDialogButtons ? (
              customDialogButtons
            ) : (
              <Fragment>
                <Button
                  className="flex-1 border-natural-500 text-text-600"
                  variant="outline"
                  size="lg"
                  onClick={onCancelPress}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 text-white"
                  variant="destructive"
                  size="lg"
                  onClick={onconfirmPress}
                >
                  {confirmButtonText}
                </Button>
              </Fragment>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DialogExtended;
