function RequestLoading() {
  return (
    <div className="fixed top-0 left-0 h-screen bg-text-900/50 w-full flex items-center justify-center z-[999]">
      <div className="w-20 h-20 rounded-lg flex items-center justify-center bg-white">
        <span
          className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-main-500 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
          role="status"
        ></span>
      </div>
    </div>
  );
}

export default RequestLoading;
