import { cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";

function MonthPicker({
  id = "",
  wrapper = "",
  label = "",
  labelClass = "",
  symble = "*",
  symbleClass = "",
  inputClass = "",
  errorMessage = "",
  triggerClass = "",
  heightClass = "",
  placeholder = "Select Month",
  ...rest
}) {
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  return (
    <div className={`flex flex-col gap-2 relative ${wrapper}`}>
      <label className={`label ${labelClass}`} htmlFor="">
        {label}
      </label>
      <Select {...rest}>
        <SelectTrigger
          className={cn(
            "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
            errorMessage && "!border-red-500",
            triggerClass,
            heightClass
          )}
        >
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {months?.map((item, index) => (
            <SelectItem
              value={item}
              className="cursor-pointer py-2.5"
              key={index}
            >
              {item}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {errorMessage && (
        <p className="text-red-500 text-sm -mt-1">{errorMessage}</p>
      )}
    </div>
  );
}

export default MonthPicker;
