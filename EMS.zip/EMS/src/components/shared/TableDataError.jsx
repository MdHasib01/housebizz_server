import ErrorUi from "./ErrorUi";

export default function TableDataError({ column = 3, title = "" }) {
  return (
    <tr className="table_row text-neutral-600">
      <td className="table_td" colSpan={column}>
        <ErrorUi title={title} />
      </td>
    </tr>
  );
}
