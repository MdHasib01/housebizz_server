import { cn } from "@/lib/utils";

const BanglaInput = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  errorMessage = "",
  ...rest
}) => {
  const handleInput = (e) => {
    const banglaRegex = /^[\u0980-\u09FF\s]+$/;
    if (!banglaRegex.test(e.target.value)) {
      e.target.value = e.target.value.replace(/[^\u0980-\u09FF\s]/g, "");
    }
  };

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <div className="relative w-full">
        <input
          type={type}
          className={cn(
            "input relative",
            className,
            icon ? "pl-10" : "",
            errorMessage ? "!border-status-error" : ""
          )}
          onInput={handleInput}
          {...rest}
        />

        {icon && (
          <div className="w-5 h-5 flex items-center justify-center rounded-full overflow-hidden absolute top-1/2 -translate-y-1/2 left-4 z-50">
            <img src={icon} className="w-full h-full object-contain" alt="" />
          </div>
        )}
      </div>
      {errorMessage && (
        <p className="text-status-error text-sm -mt-1">{errorMessage}</p>
      )}
    </div>
  );
};

export default BanglaInput;
