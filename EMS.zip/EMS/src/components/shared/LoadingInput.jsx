import { cn } from "@/lib/utils";

function LoadingInput({
  label = "",
  labelClass = "",
  wrapper = "",
  loadingClass = "",
}) {
  return (
    <div className={cn(`flex flex-col gap-2`, wrapper)}>
      {label && (
        <label className={`label ${labelClass}`} htmlFor="">
          {label}
        </label>
      )}
      <div
        className={`relative h-[54px] w-full rounded-lg pulse ${loadingClass}`}
      ></div>
    </div>
  );
}

export default LoadingInput;
