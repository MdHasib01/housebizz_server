import { NoFileIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";

const NoData = ({ title = "No Data found", text }) => {
  return (
    <div className="py-20 flex_center flex-col w-full">
      <NoFileIcon className={"h-[100px] w-[100px]"} color={colors.text[200]} />
      <p className="text-2xl font-medium !leading-[1.4] text-text-200 mt-2">
        {title}
      </p>
      <p className="text-base font-normal !leading-normal text-text-200 mt-[2px]">
        {text}
      </p>
    </div>
  );
};

export default NoData;
