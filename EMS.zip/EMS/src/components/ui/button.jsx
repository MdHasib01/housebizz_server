import { Slot } from "@radix-ui/react-slot";
import { cva } from "class-variance-authority";
import * as React from "react";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "text-sm font-semibold !leading-[1.2] inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-neutral-950 disabled:pointer-events-none disabled:bg-text-disabled disabled:text-white [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 dark:focus-visible:ring-neutral-300",
  {
    variants: {
      variant: {
        default: "bg-main-500 text-white shadow hover:bg-main-400",
        secondary: "bg-secondary-500 text-white shadow hover:bg-secondary-400",
        black: "bg-black text-white shadow hover:bg-slate-900",
        destructive:
          "bg-status-error text-white shadow hover:bg-status-error/70",
        outline: "border border-main-500 bg-transparent hover:opacity-70",
        ghost:
          "hover:bg-neutral-100 hover:text-neutral-900 dark:hover:bg-neutral-800 dark:hover:text-neutral-50",
        disabled: "bg-text-disabled text-white",
      },
      size: {
        default: "rounded-lg py-3 px-4",
        sm: "rounded-md py-2 px-3",
        lg: "rounded-lg py-4 px-5",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

const Button = React.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
