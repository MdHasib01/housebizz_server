import { cn } from "@/lib/utils";
import SegmentHeader from "./partials/SegmentHeader";
import { BillingIcon } from "@/services/assets/svgs";
import "@/styles/table.css";

const BillsAndPayments = ({ className }) => {
  const data = [
    
  ];

  return (
    <div className={cn("card_common", className)}>
      {/* TITLE BAR */}
      <SegmentHeader
        title={"Bills & Payment"}
        icon={<BillingIcon className="h-6 w-6" />}
        iconContainerClassName="bg-purple-500"
      />

      <div className="w-full mt-4">
        <table className="w-full rounded-xl overflow-hidden">
          <thead className="bg-main-50">
            <tr className="text-gray-600">
              <th className="dashboard_table_header">Date</th>
              <th className="dashboard_table_header">Opening</th>
              <th className="dashboard_table_header">Collection</th>
              <th className="dashboard_table_header">Expenses</th>
              <th className="dashboard_table_header">Closing</th>
            </tr>
          </thead>
          <tbody>
            {data.map((row, index) => (
              <tr
                key={`bill-payment-row-${index}`}
                className={`${
                  index % 2 === 0 ? "bg-white" : "bg-neutral-100"
                } hover:bg-neutral-50 transition-colors`}
              >
                <td className="dashboard_table_data">{row.date}</td>
                <td className="dashboard_table_data">
                  {row.opening.toLocaleString()}
                </td>
                <td className="dashboard_table_data">
                  {row.collection.toLocaleString()}
                </td>
                <td className="dashboard_table_data">
                  {row.expenses.toLocaleString()}
                </td>
                <td className="dashboard_table_data">
                  {row.closing.toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default BillsAndPayments;
