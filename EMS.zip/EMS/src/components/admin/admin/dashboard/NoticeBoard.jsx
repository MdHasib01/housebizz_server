import { PinIcon } from "@/services/assets/svgs";
import InfoCard from "./partials/InfoCard";
import SegmentHeader from "./partials/SegmentHeader";

const NoticeBoard = ({ item }) => {
  return (
    <div className="card_common">
      {/* TITLE BAR */}
      <SegmentHeader
        title={"Notice Board"}
        link={"/"}
        icon={<PinIcon className="h-6 w-6" />}
        iconContainerClassName="bg-main-500"
      />

      {/* CONTENT */}
      <div className="flex flex-col gap-2 mt-4">
        {item?.map((notice, index) => (
          <InfoCard
            key={index}
            className={"bg-main-50"}
            title={notice.title}
            description={notice.description}
            date={notice.date}
          />
        ))}
      </div>
    </div>
  );
};

export default NoticeBoard;
