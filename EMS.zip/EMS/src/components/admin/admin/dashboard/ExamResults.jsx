import { cn } from "@/lib/utils";
import SegmentHeader from "./partials/SegmentHeader";
import { ExamIcon } from "@/services/assets/svgs";
import ResultPieChart from "./partials/ResultPieChart";
import { percentageCalculator } from "@/services/helpers";

const ExamResults = ({ className, item }) => {
  const passingPercentage = percentageCalculator(item?.pass, item?.total);
  const failingPercentage = percentageCalculator(item?.fail, item?.total);

  return (
    <div className={cn("card_common overflow-hidden", className)}>
      {/* TITLE BAR */}
      <SegmentHeader
        title={"Exam Results"}
        titleSubline={"(1st Terminal Examination 2024)"}
        icon={<ExamIcon className="h-6 w-6" />}
        iconContainerClassName="bg-cyan-800"
        className="pb-2 border-b border-natural-200"
      />

      <ResultPieChart pass={passingPercentage} fail={failingPercentage} />

      <div className="flex items-center justify-between gap-4">
        <div className="flex flex-row items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-status-success" />
          <p className="text-xs font-normal !leading-[1.24] text-text-700">
            {item?.pass} Passed
          </p>
        </div>
        <div className="flex flex-row items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-status-error" />
          <p className="text-xs font-normal !leading-[1.24] text-text-700">
            {item?.fail} Failed
          </p>
        </div>
      </div>
    </div>
  );
};

export default ExamResults;
