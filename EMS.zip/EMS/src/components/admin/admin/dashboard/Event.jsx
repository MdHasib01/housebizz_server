import { EventIcon } from "@/services/assets/svgs";
import InfoCard from "./partials/InfoCard";
import SegmentHeader from "./partials/SegmentHeader";

const Event = ({ item }) => {
  return (
    <div className="card_common">
      {/* TITLE BAR */}
      <SegmentHeader
        title={"Event"}
        link={"/"}
        icon={<EventIcon className="h-6 w-6" />}
        iconContainerClassName="bg-orange-300"
      />

      {/* CONTENT */}
      <div className="flex flex-col gap-2 mt-4">
        {item?.map((notice, index) => (
          <InfoCard
            key={index}
            className={"bg-orange-100"}
            title={notice.title}
            description={notice.description}
            date={notice.date}
          />
        ))}
      </div>
    </div>
  );
};

export default Event;
