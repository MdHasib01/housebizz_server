import { LibraryIcon } from "@/services/assets/svgs";
import SegmentHeader from "./partials/SegmentHeader";

const BookInformationCard = ({ title, value }) => {
  return (
    <div className="py-[14px] flex flex-row justify-between items-center gap-6 w-full">
      <p className="text-lg font-normal !leading-[1.4] text-text-600">
        {title}
      </p>
      <p className="card_title">{value}</p>
    </div>
  );
};

const BookInformation = ({ item }) => {
  return (
    <div className="card_common flex flex-col gap-4">
      <SegmentHeader
        title={"Book Information"}
        icon={<LibraryIcon className="h-6 w-6" />}
        iconContainerClassName="bg-green-300"
      />

      <div className="bg-orange-50 p-6 flex flex-row items-center justify-between gap-6 rounded-xl">
        <p className="text-lg font-normal !leading-[1.4] text-text-600">
          Total Books
        </p>
        <p className="text-4xl font-bold !leading-normal text-text-700">
          {item?.totalBooks}
        </p>
      </div>

      <div className="bg-yellow-50 p-6 flex flex-col rounded-xl">
        <BookInformationCard
          title={"Books Overdue"}
          value={item?.booksOverdue}
        />
        <BookInformationCard title={"Issued Today"} value={item?.issuedToday} />
        <BookInformationCard
          title={"Total Issued Books"}
          value={item?.totalIssuedBooks}
        />
      </div>
    </div>
  );
};

export default BookInformation;
