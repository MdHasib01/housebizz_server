import { cn } from "@/lib/utils";

const InfoCard = ({ className, title, description, date }) => {
  return (
    <div
      className={cn(
        "p-4 rounded-lg flex flex-row justify-between gap-6",
        className
      )}
    >
      <div className="flex flex-col gap-2">
        <p className="text-sm font-semibold !leading-[1.2] text-text-700">
          {title}
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-600">
          {description}
        </p>
      </div>
      <p className="text-sm font-normal !leading-[1.4] text-text-700 text-right shrink-0">
        {date}
      </p>
    </div>
  );
};

export default InfoCard;
