import colors from "@/services/config/colors";
import { useEffect, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";

const ResultPieChart = ({ pass, fail }) => {
  const data = [];

  const COLORS = [colors.main[500], colors.yellow[500]];

  const [pieChartSize, setPieChartSize] = useState(120);

  // Add event listener for window resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1300) setPieChartSize(100);
      else if (window.innerWidth >= 1024 && window.innerWidth < 1300)
        setPieChartSize(120);
      else if (window.innerWidth >= 820 && window.innerWidth < 1024)
        setPieChartSize(135);
      else if (window.innerWidth < 820) setPieChartSize(115);
    };
    handleResize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // render customized label for pie chart
  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    fill,
    name,
    value,
    index,
  }) => {
    const RADIAN = Math.PI / 180;

    const radius = 25 + innerRadius + (outerRadius - innerRadius);
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    const sin = Math.sin(-RADIAN * midAngle);
    const cos = Math.cos(-RADIAN * midAngle);
    const sx = cx + (outerRadius + 10) * cos;
    const sy = cy + (outerRadius + 10) * sin;
    const mx = cx + (outerRadius + 30) * cos;
    const my = cy + (outerRadius + 30) * sin;
    const ex = mx + (cos >= 0 ? 1 : -1) * 22;
    const ey = my;
    const textAnchor = cos >= 0 ? "start" : "end";

    // Text for percentage and name
    return (
      <g>
        {pieChartSize > 90 && (
          <>
            <path
              d={`M${x > cx ? sx - 16 : sx},${
                y > cy ? sy - 20 : sy + 20
              }L${mx},${my}L${ex},${ey}`}
              stroke={fill}
              fill="none"
            />
            <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
            <text
              x={ex + (cos >= 0 ? 1 : -1) * 12}
              y={ey}
              dy={18}
              textAnchor={textAnchor}
              fill={COLORS[index]}
              className="text-xs sm:text-sm lg:text-base"
              style={{ fontSize: "8px", fontWeight: 400, fontFamily: "Inter" }}
            >
              {name}
            </text>
            <text
              x={ex + (cos >= 0 ? 1 : -1) * 12}
              y={ey}
              dy={8}
              textAnchor={textAnchor}
              fill={COLORS[index]}
              style={{ fontSize: "14px", fontWeight: 600, fontFamily: "Inter" }}
            >
              {value}%
            </text>
          </>
        )}
      </g>
    );
  };

  return (
    <div className="w-full my-4">
      <ResponsiveContainer width="100%" height="100%">
        <div className="f-center relative h-[260px]">
          {/* Background Circle */}
          <div
            style={{
              width: pieChartSize * 2.2, // Slightly larger than the pie chart
              height: pieChartSize * 2.2,
            }}
            className="absolute_center bg-white rounded-full drop-shadow-[0px_1.834px_22.924px_rgba(0,0,0,0.08)] z-0"
          />

          <PieChart
            width={pieChartSize < 150 ? 500 : 600}
            height={pieChartSize < 117 ? 270 : 385}
            className="absolute_center"
            style={{ position: "absolute", zIndex: 10 }}
          >
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={renderCustomizedLabel}
              innerRadius={pieChartSize * 0.55}
              outerRadius={pieChartSize}
              dataKey="value"
              startAngle={90}
              endAngle={-270}
              paddingAngle={3}
              cornerRadius={12}
            >
              {data.map((_entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[index]}
                  className="outline-none"
                />
              ))}
            </Pie>

            {/* Centered Text */}
            <text
              x="50%"
              y="44%"
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-xs font-normal !leading-[1.24] fill-text-600"
            >
              Total
            </text>
            <text
              x="50%"
              y="54%"
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-2xl font-bold !leading-[1.4] fill-text-700"
            >
              0
            </text>
          </PieChart>
        </div>
      </ResponsiveContainer>
    </div>
  );
};

export default ResultPieChart;
