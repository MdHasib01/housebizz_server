import { cn } from "@/lib/utils";
import React, { useState, useEffect, useRef } from "react";

const CustomBarGraph = ({
  value,
  contextText,
  className = "",
  valueClassName = "",
  containerClassName = "",
}) => {
  const [animatedValue, setAnimatedValue] = useState(0);

  const containerRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          const interval = setInterval(() => {
            setAnimatedValue((prev) => {
              if (prev >= value) {
                clearInterval(interval);
                return value;
              }
              return prev + 1;
            });
          }, 10);
        }
      },
      { threshold: 1 }
    );

    if (containerRef.current) observer.observe(containerRef.current);

    return () => observer.disconnect();
  }, [value]);

  return (
    <div className={cn("flex flex-col gap-2 w-full", containerClassName)}>
      <div
        ref={containerRef}
        className={`relative w-full min-h-48 rounded-3xl overflow-hidden ${className}`}
      >
        <div
          className={`absolute bottom-0 left-0 rounded-3xl transition_common ${valueClassName}`}
          style={{
            height: `${animatedValue}%`,
            width: "100%",
          }}
        />
      </div>
      {contextText && (
        <p className="text-base font-normal !leading-normal text-text-600 text-center">
          {contextText}
        </p>
      )}
    </div>
  );
};

export default CustomBarGraph;
