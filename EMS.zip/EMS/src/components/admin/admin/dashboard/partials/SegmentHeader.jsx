import { cn } from "@/lib/utils";
import { ChevronRight } from "lucide-react";
import React from "react";
import { Link } from "react-router-dom";

const SegmentHeader = ({
  title,
  link,
  className = "",
  iconContainerClassName = "",
  titleSubline,
  icon,
}) => {
  return (
    <div className={cn("flex items-center justify-between", className)}>
      <div className="flex_center gap-3">
        <div
          className={cn(
            "flex_center h-10 w-10 rounded-full shrink-0",
            iconContainerClassName
          )}
        >
          {icon}
        </div>
        <div>
          <p className="card_title">{title}</p>
          {titleSubline && (
            <p className="text-xs font-normal !leading-[1.24] text-text-600">
              {titleSubline}
            </p>
          )}
        </div>
      </div>
      {link && (
        <Link
          to={link}
          className="text-sm font-normal !leading-[1.4] text-text-700 flex items-center group hover:scale-105 transition_common"
        >
          See Details{" "}
          <ChevronRight
            size={16}
            className="group-hover:translate-x-1 transition_common"
          />
        </Link>
      )}
    </div>
  );
};

export default SegmentHeader;
