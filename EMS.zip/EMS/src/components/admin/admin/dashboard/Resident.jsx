import { OldBuildingIcon } from "@/services/assets/svgs";
import SegmentHeader from "./partials/SegmentHeader";
import CustomBarGraph from "./partials/CustomBarGraph";
import { percentageCalculator } from "@/services/helpers";

const Resident = ({ item }) => {
  const boysPercentage = percentageCalculator(item?.boys, item?.total);
  const girlsPercentage = percentageCalculator(item?.girls, item?.total);

  return (
    <div className="card_common">
      {/* TITLE BAR */}
      <SegmentHeader
        title={"Resident"}
        link={"/"}
        icon={<OldBuildingIcon className="h-6 w-6" />}
        iconContainerClassName="bg-cyan-500"
      />

      <div className="flex flow-row gap-5 mt-6 w-full">
        <CustomBarGraph
          value={boysPercentage}
          className="bg-main-100 h-[234px] flex-grow"
          valueClassName="bg-main-500"
          contextText={`Boys (${item?.boys})`}
        />
        <CustomBarGraph
          value={girlsPercentage}
          className="bg-secondary-100 h-[234px] flex-grow"
          valueClassName="bg-yellow-500"
          contextText={`Girls (${item?.girls})`}
        />
      </div>

      <div className="mt-3 pt-3 border-t border-main-100 flex flex-row items-center justify-center gap-3">
        <div className="h-[10px] w-[10px] bg-secondary-400" />
        <p className="text-base font-semibold !leading-[1.2]">
          {`Total (${item?.total})`}
        </p>
      </div>
    </div>
  );
};

export default Resident;
