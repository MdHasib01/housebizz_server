import Spinner from "@/components/shared/Spinner";
import { cn } from "@/lib/utils";
import { adminRoutes } from "@/services";
import {
  BusIcon,
  GroupIcon,
  MultipleUserIcon,
  TeacherIcon,
} from "@/services/assets/svgs";
import { useGetFilteredStudentsQuery } from "@/store/modules/admin/institute/studentManagement/api";
import { useGetTeachersQuery } from "@/store/modules/admin/institute/teacherManagement/api";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

const StatsCard = ({
  className,
  iconBgClassName,
  icon,
  title,
  amount,
  link,
  isLoading = false,
}) => {
  return (
    <div
      className={cn(
        "min-h-[192px] flex flex-col justify-between rounded-2xl p-4 md:p-6",
        className
      )}
    >
      <div className="flex flex-row items-center gap-2 md:gap-3">
        <div
          className={cn("h-10 w-10 rounded-full flex_center", iconBgClassName)}
        >
          {icon}
        </div>
        <p className="text-sm md:text-lg font-normal !leading-[1.4] text-text-700">
          {title}
        </p>
      </div>

      <div className="flex flex-row justify-between transition_common group">
        {isLoading ? (
          <Spinner />
        ) : (
          <p className="text-2xl md:text-4xl !leading-normal font-bold">
            {amount}
          </p>
        )}

        {link && (
          <Link
            to={link}
            className="text-sm font-semibold !leading-[1.2] text-text-700 flex items-end group-hover:scale-105 transition_common"
          >
            See Details{" "}
            <ChevronRight
              size={20}
              className="group-hover:translate-x-1 transition_common"
            />
          </Link>
        )}
      </div>
    </div>
  );
};

const StatsSummary = ({ auth }) => {
  const { data: teacherData, isFetching: teacherFetching } =
    useGetTeachersQuery(
      {
        page: 1,
        limit: 99999,
        institute_id: auth?.institute?.institute_id,
      },
      {
        skip: !auth?.institute?.institute_id,
      }
    );
  const query = `institute_id=${auth?.institute?.institute_id}&status=active`;
  const { data: studentData, isFetching: studentFetching } =
    useGetFilteredStudentsQuery(
      {
        query,
      },
      {
        skip: !auth?.institute?.institute_id,
      }
    );
  const totalTeachers = teacherData?.data?.length;
  const totalStudents = studentData?.data?.length;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
      <StatsCard
        title="Total Teachers"
        amount={totalTeachers}
        className={"bg-orange-50"}
        iconBgClassName="bg-orange-500"
        icon={<TeacherIcon className={"w-6 h-6"} />}
        link={adminRoutes.institute.teacher.path}
        isLoading={teacherFetching}
      />
      <StatsCard
        title="Total Students"
        amount={totalStudents}
        className={"bg-green-50"}
        iconBgClassName="bg-green-500"
        icon={<GroupIcon className={"w-6 h-6"} />}
        link={adminRoutes.institute.students.management.path}
        isLoading={studentFetching}
      />
      <StatsCard
        title="Total Staffs"
        amount={0}
        className={"bg-sky-blue-50"}
        iconBgClassName="bg-sky-blue-500"
        icon={<MultipleUserIcon className={"w-6 h-6"} />}
      />
      <StatsCard
        title="Total Vehicle"
        amount={0}
        className={"bg-yellow-50"}
        iconBgClassName="bg-yellow-500"
        icon={<BusIcon className={"w-6 h-6"} />}
      />
    </div>
  );
};

export default StatsSummary;
