import { images } from "@/services";
import {
  EmailIcon,
  LocationMarkerIcon,
  PhoneIcon,
} from "@/services/assets/svgs";

const DashboardBanner = ({ auth = {} }) => {
  return (
    <div className="w-full min-h-[208px] h-fit rounded-2xl overflow-hidden bg-banner-conic px-4 md:px-10 py-6 md:py-8 flex flex-row flex-wrap gap-4 justify-between items-center">
      {/* left portion */}
      <div className="">
        <h1 className="text-white text-2xl md:text-4xl font-bold leading-normal">
          {auth?.institute?.institute_name}{" "}
          <span className="text-xs md:text-sm font-semibold !leading-[1.2]">
            {`(Estd: ${auth?.institute?.estd_code})`}
          </span>
        </h1>

        <div className="flex flex-col gap-2 mt-5">
          <p className="flex flex-row items-center gap-[6px] text-white text-xs md:text-sm font-normal !leading-[1.4]">
            <LocationMarkerIcon className="w-4 h-4" />
            <span>{auth?.institute?.institute_address}</span>
          </p>
          <p className="flex flex-row items-center gap-[6px] text-white text-xs md:text-sm font-normal !leading-[1.4]">
            <EmailIcon className="w-4 h-4" />
            <a href={`mailto:${auth?.institute?.institute_email}`}>
              {auth?.institute?.institute_email}
            </a>
          </p>
          <p className="flex flex-row items-center gap-[6px] text-white text-xs md:text-sm font-normal !leading-[1.4]">
            <PhoneIcon className="w-4 h-4" />
            <a href={`tel:${auth?.institute?.institute_mobilephone}`}>
              {auth?.institute?.institute_mobilephone}
            </a>
          </p>
        </div>
      </div>

      <div className="h-[145px] w-[145px] rounded-full overflow-hidden bg-neutral-200 flex_center">
        <img
          src={auth?.institute?.institute_image || images.appLogo}
          alt="School image"
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  );
};

export default DashboardBanner;
