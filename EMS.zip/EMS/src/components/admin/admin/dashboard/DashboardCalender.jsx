import { DayPicker } from "react-day-picker";
import "@/styles/calender.css";

const DashboardCalender = () => {
  return (
    <div className="card_common w-full non-selectable-datePicker">
      <DayPicker mode="single" showOutsideDays onDayClick={() => {}} />
    </div>
  );
};

export default DashboardCalender;
