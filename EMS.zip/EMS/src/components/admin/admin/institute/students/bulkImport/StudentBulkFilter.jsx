import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import PageHeader from "@/components/shared/PageHeader";
import { Button } from "@/components/ui/button";
import { useBulkStudentBulkFilter } from "@/hooks/admin/institute/useStudentBulkManagement";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import SelectCategory from "../../category/SelectCategory";
import SelectLocalClass from "../../class/SelectLocalClass";
import SelectSection from "../../section/SelectSection";

const StudentBulkFilter = () => {
  const {
    selectors,
    classCode,
    handleUpdateSelectors,
    handleReset,
    handleFilter,
  } = useBulkStudentBulkFilter();

  return (
    <div className="card_common py-7 mb-4">
      <PageHeader title="Import Student Information" />

      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4">
        <div className="grid grid-cols-5 gap-4">
          <SelectLocalSessionYear
            value={selectors?.academic_year}
            onValueChange={(value) =>
              handleUpdateSelectors({ academic_year: value })
            }
            label="Select Year"
            triggerClass="!bg-white"
          />
          <SelectLocalClass
            value={selectors?.current_class}
            onValueChange={(value) =>
              handleUpdateSelectors({
                current_class: value,
                current_group: "",
              })
            }
            visibleItem={true}
            label="Select Class"
            triggerClass="!bg-white"
          />
          {classCode > 8 && (
            <SelectLocalGroup
              value={selectors?.current_group}
              onValueChange={(value) =>
                handleUpdateSelectors({
                  current_group: value,
                  current_section: "",
                })
              }
              classCode={classCode}
              label="Select Group"
              triggerClass="!bg-white"
            />
          )}
          <SelectSection
            value={selectors?.current_section}
            onValueChange={(value) =>
              handleUpdateSelectors({ current_section: value })
            }
            label="Select Section"
            triggerClass="!bg-white"
            isFiltered={true}
            classCode={classCode}
            group_id={selectors?.current_group}
          />
          <SelectCategory
            value={selectors?.current_category}
            onValueChange={(value) =>
              handleUpdateSelectors({ current_category: value })
            }
            label="Select Category"
            triggerClass="!bg-white"
          />
        </div>

        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px] h-12"
            variant="outline"
            size="lg"
            onClick={handleReset}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            onClick={handleFilter}
            className="gap-2 min-w-[120px] h-12"
            size="lg"
          >
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default StudentBulkFilter;
