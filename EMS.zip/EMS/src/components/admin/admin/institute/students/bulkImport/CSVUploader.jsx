import { CSVIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import Papa from "papaparse";
import { useState } from "react";

const CSVUploader = ({ onUpload = () => {} }) => {
  const [fileName, setFileName] = useState("");

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setFileName(file.name);
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (result) => {
          onUpload(result.data);
        },
        error: (error) => {},
      });
      event.target.value = "";
    }
  };

  return (
    <div className="card_common py-7">
      <p className="card_title">Select the CSV File</p>
      <div className="flex flex-row gap-4 items-center mt-4">
        <label
          htmlFor="file"
          className="relative w-[355px] h-12 p-4 text-sm font-normal !leading-[1.4] text-text-600 bg-white border border-natural-500 rounded-lg border-dashed flex items-center hover:opacity-70"
        >
          {fileName ? (
            <span>{fileName}</span>
          ) : (
            <span>
              Click to <span className="text-main-500">Upload File</span>
            </span>
          )}
          <CSVIcon className="w-6 h-6 ml-auto" color={colors.main[500]} />
          <input
            id="file"
            type="file"
            accept=".csv"
            onChange={handleFileUpload}
            className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
          />
        </label>
      </div>
    </div>
  );
};

export default CSVUploader;
