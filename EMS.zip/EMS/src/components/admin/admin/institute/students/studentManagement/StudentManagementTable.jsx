import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Input from "@/components/shared/Input";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import Spinner from "@/components/shared/Spinner";
import StudentPdf from "@/components/shared/StudentPdf";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStudentManagement } from "@/hooks";
import { cn } from "@/lib/utils";
import { adminRoutes, images } from "@/services";
import {
  DeleteIcon,
  EditIcon,
  PrintIcon,
  SearchIcon,
} from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import { Link } from "react-router-dom";

function StudentManagementTable() {
  const {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status,
    isLoading,
    handleSelect,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    student_ids,
    handleSelectAllStudent,
    handleToggleSelectStudent,
    isAllSelected,
    handleSearchValue,
    searchValue,
    dataLength,
    action,
    setAction,
    handleAction,
    pdfLoading,
    ref,
  } = useStudentManagement();

  return (
    <div className="card_common py-7">
      <div className="mb-4 flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-text-700">
            Student Found ({dataLength})
          </h2>
          <div className="flex w-full gap-4 items-center mt-5 relative">
            <Select value={action} onValueChange={setAction}>
              <SelectTrigger className="min-w-48 h-12 outline-none input focus:ring-transparent !shadow-none ">
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="password" className="cursor-pointer py-2.5">
                  Change Password
                </SelectItem>
                <SelectItem value="export" className="cursor-pointer py-2.5">
                  Excel Export
                </SelectItem>
                <SelectItem value="remove" className="cursor-pointer py-2.5">
                  Bulk Delete
                </SelectItem>
              </SelectContent>
            </Select>

            <Button
              onClick={handleAction}
              size="lg"
              disabled={!action || student_ids?.length === 0}
            >
              Action
            </Button>
          </div>
        </div>
        <div className="w-full max-w-72 relative">
          <Input
            className="!py-2.5 !pl-8"
            placeholder="Search by student ID/ Roll No."
            value={searchValue}
            onChange={handleSearchValue}
          />
          <SearchIcon
            className="absolute top-1/2 left-2 -translate-y-1/2 pointer-events-none"
            color={colors.natural[700]}
          />
        </div>
      </div>

      <div className="max-h-[620px] overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">
                <div className="w-6 h-6 flex items-center justify-center">
                  <Checkbox
                    checked={isAllSelected}
                    onCheckedChange={handleSelectAllStudent}
                  />
                </div>
              </th>
              <th className="table_th">Student ID</th>
              <th className="table_th">Roll No.</th>
              <th className="table_th">Class</th>
              <th className="table_th">Section</th>
              <th className="table_th">Shift</th>
              <th className="table_th">Password</th>
              <th className="table_th">category</th>
              <th className="table_th">Avatar</th>
              <th className="table_th">Name</th>
              <th className="table_th">Religion</th>
              <th className="table_th">Father Name</th>
              <th className="table_th">Mobile No.</th>
              <th className="table_th min-w-[210px]">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={14}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    student_ids?.includes(item?._id) ? "bg-natural-100" : ""
                  )}
                  key={index}
                >
                  <td className="table_td">
                    <div className="w-6 h-6 flex items-center justify-center">
                      <Checkbox
                        checked={student_ids?.includes(item?._id)}
                        onCheckedChange={() => handleToggleSelectStudent(item)}
                      />
                    </div>
                  </td>
                  <td className="table_td">{item?.username || "N/A"}</td>
                  <td className="table_td">
                    {item?.current_roll_number || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.current_class?.local_class_name || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.current_section?.section_name || "N/A"}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {item?.current_group?.global_group_name || "N/A"}
                  </td>

                  <td className="table_td">{item?.password || "N/A"}</td>
                  <td className="table_td">
                    {item?.current_category?.local_category_name || "N/A"}
                  </td>
                  <td className="table_td">
                    <img
                      src={item?.image || images.placeholderProfileImage}
                      alt="avatar"
                      className="w-8 h-8 rounded-full object-cover mx-auto"
                    />
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {item?.name_english}
                  </td>
                  <td className="table_td">{item?.religion || "N/A"}</td>
                  <td className="table_td">
                    {item?.father_name_english || "N/A"}
                  </td>
                  <td className="table_td">{item?.mobile_number || "N/A"}</td>

                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <Link
                        to={`${adminRoutes.institute.students.editStudent.routePath}/${item?._id}`}
                        className="border-none outline-none"
                      >
                        <EditIcon className="!h-6 !w-6 shrink-0" />
                      </Link>
                      <button
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelect({ ...item, type: "delete" })
                        }
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                      <button
                        onClick={(event) => {
                          event.stopPropagation();
                          handleSelect({ ...item, type: "pdf" });
                        }}
                        disabled={pdfLoading}
                        className="border-none outline-none"
                      >
                        {pdfLoading && selectedData?._id === item?._id ? (
                          <Spinner className="w-6 h-6 border-2" />
                        ) : (
                          <PrintIcon className="!h-6 !w-6 shrink-0" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this student?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeStudentAdmission}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
      <StudentPdf student={selectedData} ref={ref} />
    </div>
  );
}

export default StudentManagementTable;
