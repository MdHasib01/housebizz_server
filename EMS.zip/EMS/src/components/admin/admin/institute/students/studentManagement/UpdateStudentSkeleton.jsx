import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import LoadingInput from "@/components/shared/LoadingInput";
import { Button } from "@/components/ui/button";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const UpdateStudentSkeleton = () => {
  return (
    <div action="" className="flex flex-col gap-6">
      <GroupTitleComponent title="Basic Information" />
      <div className="w-32 h-32 rounded-full flex-col-reverse justify-center pulse"></div>
      <div className="grid sm:grid-cols-2 gap-4">
        <LoadingInput label="Full Name (in English)" />
        <LoadingInput label="Full Name (in Bangla)" />
        <LoadingInput label="Mobile No." />
        <LoadingInput label="Gender" />
        <LoadingInput label="Date of Birth" />
        <LoadingInput label="Birth Certificate Number" />
        <LoadingInput label="Email" />
        <LoadingInput label="Nationality" />
        <LoadingInput label="Religion" />
        <LoadingInput label="Blood Group" />
        <LoadingInput label="Special Child/Disability" />
        <LoadingInput label="Select Category" />
      </div>
      <GroupTitleComponent title="Academic Information" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <LoadingInput label="Year/Session" />
        <LoadingInput label="Class" />
      </div>
      <GroupTitleComponent title="Previous Institute Information" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <LoadingInput label="Name of The Institution" />
        <LoadingInput label="Class" />
        <LoadingInput label="Result" />
      </div>
      <GroupTitleComponent title="Father's Information" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <LoadingInput label="Name (in English)" />
        <LoadingInput label="Name (in Bangla)" />
        <LoadingInput label="Mobile Number" />
        <LoadingInput label="NID Number" />
        <LoadingInput label="Profession" />
      </div>
      <GroupTitleComponent title="Mother's Information" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <LoadingInput label="Name (in English)" />
        <LoadingInput label="Name (in Bangla)" />
        <LoadingInput label="Mobile Number" />
        <LoadingInput label="NID Number" />
        <LoadingInput label="Profession" />
      </div>
      <GroupTitleComponent title="Present Address Information" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <LoadingInput label="Present Address" />
        <LoadingInput label="District" />
        <LoadingInput label="Upazilla" />
        <LoadingInput label="Post Office" />
        <LoadingInput label="Post Code" />
      </div>
      <GroupTitleComponent title="Permanent Address Information" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <LoadingInput label="Permanent Address" />
        <LoadingInput label="District" />
        <LoadingInput label="Upazilla" />
        <LoadingInput label="Post Office" />
        <LoadingInput label="Post Code" />
      </div>

      <div className="flex items-center justify-end">
        <Link
          to={adminRoutes.institute.students.management.path}
          className="btn_blue h-12 justify-center min-w-32 !bg-transparent !text-main-500"
        >
          Cancel
        </Link>
        <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
          Submit
        </Button>
      </div>
    </div>
  );
};

export default UpdateStudentSkeleton;
