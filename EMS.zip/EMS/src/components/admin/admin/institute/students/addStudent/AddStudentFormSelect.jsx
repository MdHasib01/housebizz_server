import FormSelect from "@/components/shared/form/FormSelect";
import React, { useState } from "react";

const AddStudentFormSelect = () => {
  const [studentStatList, setStudentStatList] = useState({
    year: null,
    class: null,
    group: "",
    section: "",
    category: "",
  });

  const handleValueChange = (field, value) => {
    setStudentStatList((prevState) => ({
      ...prevState,
      [field]: value,
    }));
  };

  return (
    <div className="card_common">
      <div className="grid grid-cols-5 gap-4 px-6 py-8 border border-natural-300 bg-natural-150 rounded-xl">
        <FormSelect
          label="Select Year"
          placeholder="Select a year"
          value={studentStatList.year}
          setValue={(value) => handleValueChange("year", value)}
          options={[
            {
              label: 2024,
              value: 2024,
            },
            {
              label: 2025,
              value: 2025,
            },
          ]}
        />
        <FormSelect
          label="Select Class"
          placeholder="Select a class"
          value={studentStatList.class}
          setValue={(value) => handleValueChange("class", value)}
          options={[
            {
              label: "Six",
              value: "Six",
            },
            {
              label: "Seven",
              value: "Seven",
            },
          ]}
        />
        <FormSelect
          label="Select Group"
          placeholder="Select a group"
          value={studentStatList.group}
          setValue={(value) => handleValueChange("group", value)}
          options={[
            {
              label: "Science",
              value: "Science",
            },
            {
              label: "Arts",
              value: "Arts",
            },
          ]}
        />
        <FormSelect
          label="Select Section"
          placeholder="Select a section"
          value={studentStatList.section}
          setValue={(value) => handleValueChange("section", value)}
          options={[
            {
              label: "Golap A",
              value: "Golap A",
            },
            {
              label: "Hasnahena B",
              value: "Hasnahena B",
            },
          ]}
        />
        <FormSelect
          label="Select Category"
          placeholder="Select a category"
          value={studentStatList.category}
          setValue={(value) => handleValueChange("category", value)}
          options={[
            {
              label: "Civil",
              value: "Civil",
            },
            {
              label: "Half Free",
              value: "Half Free",
            },
          ]}
        />
      </div>
    </div>
  );
};

export default AddStudentFormSelect;
