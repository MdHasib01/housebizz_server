import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import PageHeader from "@/components/shared/PageHeader";
import SelectGender from "@/components/shared/SelectGender";
import SelectReligion from "@/components/shared/SelectReligion";
import { Button } from "@/components/ui/button";
import { useStudentManagementFilter } from "@/hooks";
import { adminRoutes } from "@/services";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import SelectCategory from "../../category/SelectCategory";
import SelectLocalClass from "../../class/SelectLocalClass";
import SelectSection from "../../section/SelectSection";

const StudentManagementFilter = () => {
  const {
    selectors,
    classCode,
    handleUpdateSelectors,
    handleReset,
    handleFilter,
  } = useStudentManagementFilter();

  return (
    <div className="card_common py-7 mb-4">
      <PageHeader
        title="Filter"
        btnText="Add Student"
        path={adminRoutes.institute.students.addStudent.path}
      />

      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4">
        <div className="grid grid-cols-4 gap-4">
          <SelectLocalSessionYear
            value={selectors?.academic_year}
            onValueChange={(value) =>
              handleUpdateSelectors({ academic_year: value })
            }
            label="Select Year"
            triggerClass="!bg-white"
          />
          <SelectLocalClass
            value={selectors?.current_class}
            onValueChange={(value) =>
              handleUpdateSelectors({
                current_class: value,
                current_group: "",
                current_section: "",
              })
            }
            visibleItem={true}
            label="Select Class"
            triggerClass="!bg-white"
          />
          {classCode > 8 && (
            <SelectLocalGroup
              value={selectors?.current_group}
              onValueChange={(value) =>
                handleUpdateSelectors({
                  current_group: value,
                  current_section: "",
                })
              }
              classCode={classCode}
              label="Select Group"
              triggerClass="!bg-white"
            />
          )}
          <SelectSection
            value={selectors?.current_section}
            onValueChange={(value) =>
              handleUpdateSelectors({ current_section: value })
            }
            label="Select Section"
            triggerClass="!bg-white"
            isFiltered={true}
            classCode={classCode}
            group_id={selectors?.current_group}
          />
          <SelectCategory
            value={selectors?.current_category}
            onValueChange={(value) =>
              handleUpdateSelectors({ current_category: value })
            }
            label="Select Category"
            triggerClass="!bg-white"
          />
          <SelectGender
            value={selectors?.gender}
            onValueChange={(value) => handleUpdateSelectors({ gender: value })}
            label="Select Gender"
            triggerClass="!bg-white"
          />
          <SelectReligion
            value={selectors?.religion}
            onValueChange={(value) =>
              handleUpdateSelectors({ religion: value })
            }
            label="Select Religion"
            triggerClass="!bg-white"
          />
        </div>

        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px] h-12"
            variant="outline"
            size="lg"
            onClick={handleReset}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            onClick={handleFilter}
            className="gap-2 min-w-[120px] h-12"
            size="lg"
          >
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default StudentManagementFilter;
