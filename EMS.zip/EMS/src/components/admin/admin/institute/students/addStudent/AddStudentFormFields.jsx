import FormInput from "@/components/shared/form/FormInput";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form } from "@/components/ui/form";
import FormSelect from "@/components/shared/form/FormSelect";
import FormDatePicker from "@/components/shared/form/FormDatePicker";
import { addStudentFormSchema } from "@/services/validation";
import { Button } from "@/components/ui/button";
import { bloodGroups } from "@/services/helpers";

const GroupTitleComponent = ({ title }) => {
  return (
    <div className="flex items-center gap-4 pb-6">
      <p className="text-lg font-semibold !leading-[1.4] text-text-700">
        {title}
      </p>
      <div className="border-t border-natural-400 flex-grow" />
    </div>
  );
};

const AddStudentFormFields = () => {
  const form = useForm({
    resolver: zodResolver(addStudentFormSchema),
    defaultValues: {
      // Basic Information
      fullnameEng: "",
      fullnameBng: "",
      mobileNo: "",
      gender: "",
      dob: null, // null for the date picker
      birthCertificateNo: "",
      email: "",
      nationality: "",
      religion: "",
      bloodGroup: "",
      disability: "",

      // Father's Information
      fatherFullnameEng: "",
      fatherFullnameBng: "",
      fatherMobileNo: "",
      fatherNid: "",
      fatherProfession: "",

      // Mother's Information
      motherFullnameEng: "",
      motherFullnameBng: "",
      motherMobileNo: "",
      motherNid: "",
      motherProfession: "",

      // Present Address Information
      presentAddressLine: "",
      district: "",
      presentUpazilla: "",
      presentPostOffice: "",
      presentPostCode: "",

      // Permanent Address Information
      permanentAddressLine: "",
      permanentUpazilla: "",
      permanentPostOffice: "",
      permanentPostCode: "",
    },
  });

  function onSubmit(values) {
    // Do something with the form values.
    // ✅ This will be type-safe and validated.
  }

  return (
    <div className="card_common py-7 flex flex-col gap-6 w-full">
      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className="flex flex-col gap-10"
        >
          {/* BASIC INFORMATION */}
          <div>
            <GroupTitleComponent title={"Basic Information"} />
            <div className="grid grid-cols-2 gap-6">
              <FormInput
                label={"Full Name (In English)"}
                placeholder={"Enter full name in english"}
                formControl={form.control}
                name={"fullnameEng"}
                type="text"
              />
              <FormInput
                label={"Full Name (In Bangla)"}
                placeholder={"Enter full name in bangla"}
                formControl={form.control}
                name={"fullnameBng"}
                type="text"
              />
              <FormInput
                label={"Mobile No."}
                placeholder={"Enter mobile no."}
                formControl={form.control}
                name={"mobileNo"}
                type="number"
              />
              <FormSelect
                label={"Gender"}
                placeholder={"Select a gender"}
                formControl={form.control}
                name={"gender"}
                options={[
                  { label: "Male", value: "Male" },
                  { label: "Female", value: "Female" },
                  { label: "Others", value: "Others" },
                ]}
              />
              <FormDatePicker
                name="dob"
                label="Date of Birth"
                formControl={form.control}
                description="Your date of birth is used to calculate your age."
              />
              <FormInput
                label={"Birth Certificate Number"}
                placeholder={"Enter birth certificate no."}
                formControl={form.control}
                name={"birthCertificateNo"}
                type="number"
              />
              <FormInput
                label={"Email"}
                placeholder={"Enter your email ID"}
                formControl={form.control}
                name={"email"}
                type="email"
              />
              <FormSelect
                label={"Nationality"}
                placeholder={"Select your nationality"}
                formControl={form.control}
                name={"nationality"}
                options={[
                  { label: "Bangladeshi", value: "Bangladeshi" },
                  { label: "Non-Bangladeshi", value: "Non-Bangladeshi" },
                ]}
              />
              <FormSelect
                label={"Religion"}
                placeholder={"Select your religion"}
                formControl={form.control}
                name={"religion"}
                options={[
                  { label: "Muslim", value: "Muslim" },
                  { label: "Christian", value: "Christian" },
                ]}
              />
              <FormSelect
                label={"Blood Group"}
                placeholder={"Select your blood group"}
                formControl={form.control}
                name={"bloodGroup"}
                options={bloodGroups}
              />
              <FormSelect
                label={"Special Child/ Disability"}
                placeholder={"Select"}
                formControl={form.control}
                name={"disability"}
                options={[
                  { label: "Yes", value: "yes" },
                  { label: "No", value: "no" },
                ]}
              />
            </div>
          </div>

          {/* FATHER'S INFORMATION */}
          <div>
            <GroupTitleComponent title={"Father's Information"} />
            <div className="grid grid-cols-2 gap-6">
              <FormInput
                label={"Full Name (In English)"}
                placeholder={"Enter full name in english"}
                formControl={form.control}
                name={"fatherFullnameEng"}
                type="text"
              />
              <FormInput
                label={"Full Name (In Bangla)"}
                placeholder={"Enter full name in bangla"}
                formControl={form.control}
                name={"fatherFullnameBng"}
                type="text"
              />
              <FormInput
                label={"Mobile No."}
                placeholder={"Enter mobile no."}
                formControl={form.control}
                name={"fatherMobileNo"}
                type="number"
              />
              <FormInput
                label={"NID"}
                placeholder={"Enter your national ID"}
                formControl={form.control}
                name={"fatherNid"}
                type="number"
              />
              <FormInput
                label={"Profession"}
                placeholder={"Enter profession"}
                formControl={form.control}
                name={"fatherProfession"}
                type="text"
              />
            </div>
          </div>

          {/* MOTHER'S INFORMATION */}
          <div>
            <GroupTitleComponent title={"Mother's Information"} />
            <div className="grid grid-cols-2 gap-6">
              <FormInput
                label={"Full Name (In English)"}
                placeholder={"Enter full name in english"}
                formControl={form.control}
                name={"motherFullnameEng"}
                type="text"
              />
              <FormInput
                label={"Full Name (In Bangla)"}
                placeholder={"Enter full name in bangla"}
                formControl={form.control}
                name={"motherFullnameBng"}
                type="text"
              />
              <FormInput
                label={"Mobile No."}
                placeholder={"Enter mobile no."}
                formControl={form.control}
                name={"motherMobileNo"}
                type="number"
              />
              <FormInput
                label={"NID"}
                placeholder={"Enter your national ID"}
                formControl={form.control}
                name={"motherNid"}
                type="number"
              />
              <FormInput
                label={"Profession"}
                placeholder={"Enter profession"}
                formControl={form.control}
                name={"motherProfession"}
                type="text"
              />
            </div>
          </div>

          {/* PRESENT ADDRESS INFORMATION */}
          <div>
            <GroupTitleComponent title={"Present Address Information"} />
            <div className="grid grid-cols-2 gap-6">
              <FormInput
                label={"Present Address Line"}
                placeholder={"House no. road no..."}
                formControl={form.control}
                name={"presentAddressLine"}
                type="text"
              />
              <FormInput
                label={"District"}
                placeholder={"Present district"}
                formControl={form.control}
                name={"district"}
                type="text"
              />
              <FormInput
                label={"Upazilla"}
                placeholder={"Present upazilla"}
                formControl={form.control}
                name={"presentUpazilla"}
                type="number"
              />
              <FormInput
                label={"Post Office"}
                placeholder={"Present post office"}
                formControl={form.control}
                name={"presentPostOffice"}
                type="number"
              />
              <FormInput
                label={"Present post code"}
                placeholder={"Present post code"}
                formControl={form.control}
                name={"presentPostCode"}
                type="text"
              />
            </div>
          </div>

          {/* PERMANENT ADDRESS INFORMATION */}
          <div>
            <GroupTitleComponent title={"Permanent Address Information"} />
            <div className="grid grid-cols-2 gap-6">
              <FormInput
                label={"Permanent Address Line"}
                placeholder={"House no. road no..."}
                formControl={form.control}
                name={"permanentAddressLine"}
                type="text"
              />
              <FormInput
                label={"District"}
                placeholder={"Permanent district"}
                formControl={form.control}
                name={"district"}
                type="text"
              />
              <FormInput
                label={"Upazilla"}
                placeholder={"Permanent upazilla"}
                formControl={form.control}
                name={"permanentUpazilla"}
                type="number"
              />
              <FormInput
                label={"Post Office"}
                placeholder={"Permanent post office"}
                formControl={form.control}
                name={"permanentPostOffice"}
                type="number"
              />
              <FormInput
                label={"Permanent post code"}
                placeholder={"Permanent post code"}
                formControl={form.control}
                name={"permanentPostCode"}
                type="text"
              />
            </div>
          </div>

          <div className="flex items-center justify-end">
            <Button
              className="h-12 min-w-[132px] text-main-500"
              size="lg"
              variant="outline"
              type="reset"
            >
              Cancel
            </Button>
            <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
              Add
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default AddStudentFormFields;
