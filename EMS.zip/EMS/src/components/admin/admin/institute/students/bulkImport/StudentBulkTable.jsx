import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useBulkStudents } from "@/hooks/admin/institute/useStudentBulkManagement";
import { cn } from "@/lib/utils";
import { DeleteIcon, EditIcon, RestoreIcon } from "@/services/assets/svgs";

function StudentBulkTable() {
  const {
    dataLists,
    handleSelectData,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    handleReset,
    handleSubmit,
    isLoading,
    length,
    selectedData,
  } = useBulkStudents();

  return (
    <div className="card_common py-7">
      <div className="mb-4 flex items-start justify-between">
        <h2 className="text-lg font-semibold text-text-700">
          Student Found ({length})
        </h2>
      </div>

      <div className="max-h-[620px] overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th min-w-44">Student ID</th>
              <th className="table_th min-w-44">Roll</th>
              <th className="table_th min-w-44">Name</th>
              <th className="table_th min-w-44">District</th>
              <th className="table_th min-w-44">Address</th>
              <th className="table_th min-w-44">Religion</th>
              <th className="table_th min-w-44">Father’s Name</th>
              <th className="table_th min-w-44">Father’s Number</th>
              <th className="table_th min-w-44">Mother’s Number</th>
              <th className="table_th min-w-44">Mother’s Number</th>
              <th className="table_th min-w-44">Mobile No.</th>
              <th className="table_th min-w-[210px]">Action</th>
            </tr>
          </thead>
          <tbody>
            {dataLists?.map((item, index) => (
              <tr
                className={cn(
                  "table_row",
                  (currentPage - 1) * pageSize + index === selectedData?.index
                    ? "bg-natural-100"
                    : ""
                )}
                key={index}
                onClick={() =>
                  handleSelectData({
                    index: (currentPage - 1) * pageSize + index,
                  })
                }
              >
                <td className="table_td">{item?.username}</td>
                <td className="table_td">{item?.current_roll_number}</td>
                <td className="table_td">{item?.name_english}</td>
                <td className="table_td whitespace-nowrap">
                  {item?.present_address_district}
                </td>

                <td className="table_td">{item?.present_address_line}</td>
                <td className="table_td">{item?.religion}</td>
                <td className="table_td">{item?.father_name_english}</td>
                <td className="table_td whitespace-nowrap">
                  {item?.father_mobile_number}
                </td>
                <td className="table_td">{item?.mother_name_english}</td>
                <td className="table_td">{item?.mother_mobile_number}</td>
                <td className="table_td">{item?.mobile_number}</td>

                <td className="table_td w-[260px]">
                  <div className="flex items-center justify-center gap-2">
                    <button
                      className="border-none outline-none"
                      onClick={(event) => {
                        event.stopPropagation();
                        handleSelectData({
                          ...item,
                          type: "update",
                          index: (currentPage - 1) * pageSize + index,
                          dataIndex: index,
                        });
                      }}
                    >
                      <EditIcon className="!h-6 !w-6 shrink-0" />
                    </button>
                    <button
                      className="border-none outline-none"
                      onClick={(event) => {
                        event.stopPropagation();
                        handleSelectData({
                          ...item,
                          type: "delete",
                          index: (currentPage - 1) * pageSize + index,
                          dataIndex: index,
                        });
                      }}
                    >
                      <DeleteIcon className="!h-6 !w-6 shrink-0" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />

      <div className="flex items-center gap-4 justify-end mt-6">
        <Button
          className="gap-1 border-natural-500 min-w-[108px] h-12"
          variant="outline"
          size="lg"
          onClick={handleReset}
        >
          <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
          <span className="text-text-600">Reset</span>
        </Button>
        <Button
          onClick={handleSubmit}
          className="gap-2 min-w-[120px] h-12"
          size="lg"
        >
          <span className="text-white">Import</span>
        </Button>
      </div>
      {isLoading && <RequestLoading />}
    </div>
  );
}

export default StudentBulkTable;
