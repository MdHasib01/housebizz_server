import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import TableHelper from "@/components/responseHelper/shared/TableHelper";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { PictureAsPdfIcon, SpinnerAnimatedIcon } from "@/services/assets/svgs";
import { useGetStudentStatusQuery } from "@/store/modules/admin/institute/studentStatus/api";
import { Fragment, useRef, useState } from "react";
import { useReactToPrint } from "react-to-print";

const StudentStatusTable = () => {
  let previousClass = null;
  let isEvenRow = true;
  const targetRef = useRef(null);
  const [isPdfLoading, setIsPdfLoading] = useState(false);
  const [year, setYear] = useState("");

  const generatePDF = useReactToPrint({
    contentRef: targetRef,
    documentTitle: "studentsummary",
    onBeforePrint: () => {
      setIsPdfLoading(true);
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setIsPdfLoading(false);
        }, 1000);
      });
    },
  });

  const { data, isFetching, isError, error } = useGetStudentStatusQuery(year, {
    skip: !year,
    refetchOnMountOrArgChange: true,
  });
  const { data: processedData = [] } = data || {};

  return (
    <>
      <div className="flex flex-row justify-between items-center">
        <p className="card_title">Student Status</p>
        <div className="flex flex-row items-center gap-2">
          <SelectLocalSessionYear
            heightClass="h-12"
            value={year}
            onValueChange={setYear}
          />
          <Button
            className="gap-2 h-12 w-[165px]"
            size="lg"
            onClick={() => generatePDF()}
          >
            {isPdfLoading ? (
              <SpinnerAnimatedIcon
                strokeWidth={6}
                className={"!h-5 !w-5 shrink-0"}
              />
            ) : (
              <Fragment>
                <PictureAsPdfIcon className={"!h-5 !w-5 shrink-0"} />
                <span className="">Export to PDF</span>
              </Fragment>
            )}
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-auto px-2">
        <table className="table" ref={targetRef}>
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="w-[114px] table_th">Class</th>
              <th className="table_th w-[312px]">Section</th>
              <th className="table_th w-[170px]">Category</th>
              <th className="table_th w-[170px]">Boys</th>
              <th className="table_th w-[170px]">Girls</th>
              <th className="table_th w-[170px]">Total</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={!isError}
              status={error?.status}
              dataLength={processedData.length}
              column={6}
            >
              {processedData.map((row, index) => {
                if (row.class && row.class !== previousClass) {
                  isEvenRow = !isEvenRow;
                  previousClass = row.class;
                }
                const rowBgColor = isEvenRow ? "bg-natural-50" : "bg-white";
                return (
                  <tr key={index} className={cn("table_row group", rowBgColor)}>
                    {row.class && (
                      <td
                        rowSpan={row.classRowSpan}
                        className="table_outline_td  group-last:!border-b-0"
                      >
                        <span className="block text-text-700">{row.class}</span>
                        <span className="block text-text-600">{`(Total ${row.totalStudents})`}</span>
                      </td>
                    )}
                    {row.section && (
                      <td
                        rowSpan={row.sectionRowSpan}
                        className="table_outline_td group-last:!border-b-0"
                      >
                        <span className="block text-text-700">
                          {row.section}
                        </span>
                        <span className="block text-text-600">{`(Total ${row.sectionTotal})`}</span>
                      </td>
                    )}
                    <td className="table_outline_td group-last:!border-b-0">
                      {row.category}
                    </td>
                    <td className="table_outline_td group-last:!border-b-0">
                      {row.boys}
                    </td>
                    <td className="table_outline_td group-last:!border-b-0">
                      {row.girls}
                    </td>
                    <td className="table_outline_td last:!border-b group-last:!border-b-0">
                      {row.total}
                    </td>
                  </tr>
                );
              })}
            </TableHelper>
          </tbody>
        </table>
      </div>
    </>
  );
};

export default StudentStatusTable;
