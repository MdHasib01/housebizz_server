import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import TableHelper from "@/components/responseHelper/shared/TableHelper";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { errorNotify } from "@/services";
import { PictureAsPdfIcon, SpinnerAnimatedIcon } from "@/services/assets/svgs";
import { useGetStudentSummeryQuery } from "@/store/modules/admin/institute/studentSummery/api";
import { setSelectedStudentSummary } from "@/store/modules/admin/institute/studentSummery/slice";
import { Fragment, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useReactToPrint } from "react-to-print";

const StudentSummaryTable = () => {
  const [year, setYear] = useState("");
  const dispatch = useDispatch();
  const [isPdfLoading, setIsPdfLoading] = useState(false);
  const tableWrapperRef = useRef(null);
  const { data, isFetching, isError, error } = useGetStudentSummeryQuery(year, {
    skip: !year,
    refetchOnMountOrArgChange: true,
  });
  const { selectedData } = useSelector((state) => state.adminStudentSummary);

  const handleSelect = (item) => {
    dispatch(setSelectedStudentSummary(item));
  };

  const generatePDF = useReactToPrint({
    contentRef: tableWrapperRef,
    documentTitle: "studentsummary",
    onBeforePrint: () => {
      setIsPdfLoading(true);
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve();
          setIsPdfLoading(false);
        }, 1000);
      });
    },
  });

  const handlePrint = () => {
    if (!data || !data.length) return errorNotify("No data found to print");
    generatePDF();
  };


  return (
    <div className="card_common py-7 mt-4">
      {/* filter bar */}
      <div className="flex flex-row justify-between items-center">
        <p className="card_title">Student Summary</p>
        <div className="flex flex-row items-center gap-2">
          <SelectLocalSessionYear
            heightClass="h-12"
            value={year}
            onValueChange={setYear}
          />
          <Button
            className="gap-2 h-12 w-[165px]"
            size="lg"
            onClick={handlePrint}
          >
            {isPdfLoading ? (
              <SpinnerAnimatedIcon
                strokeWidth={6}
                className={"!h-5 !w-5 shrink-0"}
              />
            ) : (
              <Fragment>
                <PictureAsPdfIcon className={"!h-5 !w-5 shrink-0"} />
                <span className="">Export to PDF</span>
              </Fragment>
            )}
          </Button>
        </div>
      </div>

      <div
        className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5"
        ref={tableWrapperRef}
      >
        <div className="flex-1 overflow-auto px-2">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                {["Class", "Section", "Session", "Boys", "Girls", "Total"].map(
                  (item, index) => (
                    <th className="table_th" key={index}>
                      {item}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              <TableHelper
                isLoading={isFetching}
                isError={isError}
                status={error?.status}
                dataLength={data?.length}
                column={6}
              >
                {data?.map((item, index) => {
                  return (
                    <tr
                      className={cn(
                        "table_row table_picker",
                        item?._id === selectedData?._id ? "bg-natural-100" : ""
                      )}
                      key={index}
                      onClick={() => handleSelect(item)}
                    >
                      <td className="table_td w-max capitalize">
                        {item?.class}
                      </td>

                      <td className="table_td">{item?.section}</td>
                      <td className="table_td">{item?.session}</td>
                      <td className="table_td">{item?.boys}</td>
                      <td className="table_td">{item?.girls}</td>
                      <td className="table_td">{item?.total}</td>
                    </tr>
                  );
                })}
              </TableHelper>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StudentSummaryTable;
