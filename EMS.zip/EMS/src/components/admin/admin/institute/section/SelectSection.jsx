import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useGetAllSectionsQuery } from "@/store/modules/admin/institute/sectionList/api";
import { useSelector } from "react-redux";

const SelectSection = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select a section",
  triggerClass = "",
  heightClass = "",
  errorMessage = "",
  institute_id = null,
  selector = "_id",
  isFiltered = false,
  classCode = null,
  group_id = null,
  isLoading = false,
  ...rest
}) => {
  const { auth } = useSelector((state) => state.auth);
  const { allData } = useSelector((state) => state.adminSections);
  const id = institute_id ? institute_id : auth?.instituteAdmin?.institute_id;
  const { isFetching, isError, error } = useGetAllSectionsQuery(
    {
      institute_id: id,
      page: 1,
      limit: 999999,
    },
    {
      skip: !id || isLoading,
    }
  );

  const filterByClassCode = (item) => {
    if (!isFiltered) return true;
    if (!classCode && !group_id) return false;
    const isMatched = item?.local_class_id?.local_class_code === classCode;
    return group_id ? item?.group_id?._id === group_id && isMatched : isMatched;
  };

  const sortSections = (a, b) => {
    if (a.section_name < b.section_name) return -1;
    if (a.section_name > b.section_name) return 1;
    return 0;
  };

  const selectDisabled = isFiltered && (classCode === null || classCode === "");

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching || isLoading}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <div className="relative w-full">
          <Select {...rest} disabled={selectDisabled}>
            <SelectTrigger
              className={cn(
                "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
                errorMessage && "!border-red-500",
                triggerClass,
                heightClass
              )}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {[...(allData || [])]
                ?.sort(sortSections)
                ?.filter(filterByClassCode)
                ?.map((item, index) => (
                  <SelectItem
                    value={item[selector]}
                    className="cursor-pointer py-2.5"
                    key={index}
                  >
                    {item?.section_name}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectSection;
