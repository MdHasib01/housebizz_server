import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSections } from "@/hooks/admin/institute/useSection";
import { cn } from "@/lib/utils";
import { adminRoutes } from "@/services";
import { images } from "@/services/assets";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";
import { PlusIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import SelectLocalClass from "../class/SelectLocalClass";
import SelectLocalShift from "../shift/SelectLocalShift";

const SectionListTable = () => {
  const navigate = useNavigate();
  const {
    dataLists,
    isFetching,
    isError,
    status,
    currentPage,
    pageSize,
    totalPages,
    updatePage,
    selectedData,
    showModal,
    isLoading,
    setSuccessDialogOpen,
    handleSelectUpdate,
    handleSelectDelete,
    closeModal,
    removeSectionHanlder,
    updateSelectedRowValue,
    updateSectionHandler,
    classCode,
    handleSelectRow,
  } = useSections();

  const handleRowClick = (item, isActive = false) => {
    if (isActive) return;
    handleSelectRow(item);
  };

  return (
    <div className="card_common py-7">
      <div className="flex gap-4 items-center justify-between">
        <p className="card_title">Section List</p>
        <Button
          size="lg"
          onClick={() =>
            navigate(adminRoutes.institute.section.addSection.path)
          }
          className="gap-2"
        >
          <PlusIcon className="!h-5 !w-5 shrink-0" />
          <span>Add Section</span>
        </Button>
      </div>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <div className="flex-1 overflow-auto px-2">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                {[
                  "Section Name",
                  "Section Capacity",
                  "Class",
                  "Group",
                  "Shift Name",
                  "Action",
                ].map((item, index) => (
                  <th className="table_th min-w-40" key={index}>
                    {item}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <TableHelper
                isLoading={isFetching}
                isError={isError}
                status={status}
                dataLength={dataLists?.length}
                column={6}
              >
                {dataLists?.map((item, index) => {
                  const isActiveEditRow =
                    selectedData?._id === item?._id &&
                    selectedData?.type === "update";
                  const isActiveRow =
                    selectedData?._id === item?._id &&
                    selectedData?.type !== "delete";

                  return (
                    <tr
                      className={cn(
                        "table_row table_picker",
                        isActiveRow && "bg-natural-150"
                      )}
                      key={index}
                      onClick={() => handleRowClick(item, isActiveEditRow)}
                    >
                      <td className="table_td w-max capitalize">
                        {isActiveEditRow ? (
                          <>
                            <Input
                              name="section_name"
                              type="text"
                              placeholder="Enter section Name"
                              value={selectedData?.section_name}
                              onChange={(e) =>
                                updateSelectedRowValue(
                                  "section_name",
                                  e.target.value
                                )
                              }
                              className="border-main-500 text-center placeholder:text-text-200"
                            />
                          </>
                        ) : (
                          <>{item?.section_name}</>
                        )}
                      </td>

                      <td
                        className="table_td"
                        onClick={(event) => event?.stopPropagation()}
                      >
                        {isActiveEditRow ? (
                          <>
                            <Input
                              name="section_capacity"
                              type="number"
                              placeholder="Enter section capacity"
                              value={selectedData?.section_capacity}
                              onWheel={(e) => e.target.blur()}
                              onChange={(e) =>
                                updateSelectedRowValue(
                                  "section_capacity",
                                  e.target.value
                                )
                              }
                              className="border-main-500 text-center placeholder:text-text-200"
                            />
                          </>
                        ) : (
                          <>{item?.section_capacity}</>
                        )}
                      </td>
                      <td className="table_td">
                        {isActiveEditRow ? (
                          <>
                            <SelectLocalClass
                              triggerClass="!cursor-pointer"
                              name="local_class_id"
                              heightClass="h-[41px]"
                              onValueChange={(value) =>
                                updateSelectedRowValue("local_class_id", value)
                              }
                              value={selectedData?.local_class_id}
                              visibleItem={true}
                            />
                          </>
                        ) : (
                          <>{item?.local_class_id?.local_class_name}</>
                        )}
                      </td>
                      <td className="table_td w-40">
                        {isActiveEditRow ? (
                          <>
                            {classCode > 8 && (
                              <SelectLocalGroup
                                heightClass="h-[41px]"
                                triggerClass="!cursor-pointer"
                                onValueChange={(value) =>
                                  updateSelectedRowValue("group_id", value)
                                }
                                value={selectedData?.group_id}
                                classCode={classCode}
                              />
                            )}
                          </>
                        ) : (
                          <>{item?.group_id?.global_group_name}</>
                        )}
                      </td>

                      <td className="table_td capitalize">
                        {isActiveEditRow ? (
                          <>
                            <SelectLocalShift
                              triggerClass="!cursor-pointer"
                              name="shift_id"
                              heightClass="h-[41px]"
                              onValueChange={(value) =>
                                updateSelectedRowValue("shift_id", value)
                              }
                              value={selectedData?.shift_id}
                            />
                          </>
                        ) : (
                          <>{item?.shift_id?.name}</>
                        )}
                      </td>

                      <td className="table_td w-[260px]">
                        <div className="flex items-center justify-center gap-2">
                          {isActiveEditRow ? (
                            <>
                              <Button
                                size="sm"
                                className="bg-status-success hover:bg-status-success/70"
                                onClick={() =>
                                  updateSectionHandler({ ...selectedData })
                                }
                              >
                                Update
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleSelectUpdate(null)}
                              >
                                Cancel
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={(event) => {
                                  event?.stopPropagation();
                                  handleSelectUpdate({
                                    ...item,
                                    type: "update",
                                  });
                                }}
                              >
                                <EditIcon className="!h-6 !w-6 shrink-0" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={(event) => {
                                  event?.stopPropagation();
                                  handleSelectDelete(item);
                                }}
                              >
                                <DeleteIcon className="!h-6 !w-6 shrink-0" />
                              </Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </TableHelper>
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage || 1}
          rowsPerPage={pageSize || 1}
          totalPages={totalPages || 1}
          updatePage={updatePage}
        />
      </div>

      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={closeModal}
        title={
          selectedData?.type === "delete" ? "Are you sure?" : "Successful!"
        }
        text={
          selectedData?.type === "delete"
            ? "You want to delete this section?"
            : "The information has been updated successfully."
        }
        imageSrc={
          selectedData?.type === "delete"
            ? images.questionMarkRed
            : images.checkGreen
        }
        customDialogButtons={
          selectedData?.type === "delete" ? null : (
            <Button
              className="text-white h-12 w-full"
              size="lg"
              onClick={() => {
                setSuccessDialogOpen(false);
              }}
            >
              Close
            </Button>
          )
        }
        onCancelPress={closeModal}
        onconfirmPress={removeSectionHanlder}
      />

      {isLoading && <RequestLoading />}
    </div>
  );
};

export default SectionListTable;
