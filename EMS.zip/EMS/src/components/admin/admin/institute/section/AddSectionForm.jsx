import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import Input from "@/components/shared/Input";
import NumberInput from "@/components/shared/NumberInput";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddSection } from "@/hooks/admin/institute/useSection";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";
import SelectLocalClass from "../class/SelectLocalClass";
import SelectLocalShift from "../shift/SelectLocalShift";

const AddSectionForm = () => {
  const {
    formSelect,
    errors,
    isLoading,
    onChangeSelect,
    resetFields,
    addSectionHandler,
    classCode,
  } = useAddSection();
  return (
    <div className="card_common py-7">
      <p className="card_title">Add Section</p>

      <form
        onSubmit={addSectionHandler}
        id="add-section-form"
        className="flex flex-col gap-10 mt-6"
      >
        <div className="grid grid-cols-2 gap-6">
          <SelectLocalClass
            triggerClass="!cursor-pointer"
            name="local_class_id"
            label="Select Class"
            heightClass="h-12"
            onValueChange={(value) => onChangeSelect("local_class_id", value)}
            value={formSelect?.local_class_id}
            visibleItem={true}
            errorMessage={errors?.local_class_id}
          />

          {classCode > 8 && (
            <SelectLocalGroup
              label="Select Group"
              heightClass="h-12"
              name="group_id"
              triggerClass="!cursor-pointer"
              value={formSelect?.group_id || ""}
              onValueChange={(value) => onChangeSelect("group_id", value)}
              errorMessage={errors?.group_id}
              classCode={classCode}
            />
          )}
          <SelectLocalShift
            triggerClass="!cursor-pointer"
            heightClass="h-12"
            name="shift_id"
            label="Select Shift"
            onValueChange={(value) => onChangeSelect("shift_id", value)}
            value={formSelect?.shift_id}
            errorMessage={errors?.shift_id}
          />

          <Input
            label="Section Name"
            placeholder="Enter section name"
            name="section_name"
            className="h-12"
            type="text"
            errorMessage={errors?.section_name}
          />

          <NumberInput
            label="Section Capacity"
            placeholder="Enter section capacity"
            name="section_capacity"
            errorMessage={errors?.section_capacity}
          />
        </div>

        <div className="flex items-center justify-end">
          <Link
            to={adminRoutes.institute.section.path}
            className="btn_blue justify-center h-12 min-w-32 !bg-transparent !text-main-500"
            onClick={() => resetFields()}
          >
            Cancel
          </Link>
          <Button
            type="submit"
            className="h-12 min-w-[132px] ml-4"
            size="lg"
            disabled={isLoading}
          >
            Add
          </Button>
        </div>
      </form>

      {isLoading && <RequestLoading />}
    </div>
  );
};

export default AddSectionForm;
