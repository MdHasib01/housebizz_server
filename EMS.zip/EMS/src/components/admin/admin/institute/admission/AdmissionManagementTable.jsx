import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import Spinner from "@/components/shared/Spinner";
import StudentPdf from "@/components/shared/StudentPdf";
import { Button } from "@/components/ui/button";
import { useStudentAdmission } from "@/hooks";
import { cn } from "@/lib/utils";
import { getSerialNumber, images } from "@/services";
import { DeleteIcon, PrintIcon } from "@/services/assets/svgs";

function AdmissionManagementTable() {
  const {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status,
    isLoading,
    handleSelect,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    ref,
    pdfLoading,
  } = useStudentAdmission();
  return (
    <>
      <div className="flex-1 overflow-auto px-2">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">SL</th>
              <th className="table_th">Avatar</th>
              <th className="table_th">Name (English)</th>
              <th className="table_th">Name (Bangla)</th>
              <th className="table_th">Father Name</th>
              <th className="table_th">Year</th>
              <th className="table_th">Class</th>
              <th className="table_th">Group</th>
              <th className="table_th">Transaction ID</th>
              <th className="table_th border-b min-w-[210px]">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={10}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    item?._id === selectedData?._id &&
                      selectedData?.type === "row"
                      ? "bg-natural-100"
                      : ""
                  )}
                  key={index}
                  onClick={() => handleSelect({ ...item, type: "row" })}
                >
                  <td className="table_td">
                    {getSerialNumber({
                      currentPage: currentPage,
                      index,
                      rowsPerPage: pageSize,
                    })}
                  </td>
                  <td className="table_td">
                    <img
                      src={item?.image || images.placeholderProfileImage}
                      alt="avatar"
                      className="w-8 h-8 rounded-full object-cover mx-auto"
                    />
                  </td>
                  <td className="table_td">{item?.name_english || "N/A"}</td>
                  <td className="table_td">{item?.name_bangla || "N/A"}</td>
                  <td className="table_td whitespace-nowrap">
                    {item?.father_name_english || "N/A"}
                  </td>
                  <td className="table_td">{item?.academic_year || "N/A"}</td>
                  <td className="table_td">
                    {item?.current_class?.local_class_name || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.current_group?.global_group_name || "N/A"}
                  </td>
                  <td className="table_td">{item?.transaction_id || "N/A"}</td>

                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        className="border-none outline-none"
                        onClick={(event) => {
                          event.stopPropagation();
                          handleSelect({ ...item, type: "delete" });
                        }}
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                      <button
                        onClick={(event) => {
                          event.stopPropagation();
                          handleSelect({ ...item, type: "pdf" });
                        }}
                        disabled={pdfLoading}
                        className="border-none outline-none"
                      >
                        {pdfLoading && selectedData?._id === item?._id ? (
                          <Spinner className="w-6 h-6 border-2" />
                        ) : (
                          <PrintIcon className="!h-6 !w-6 shrink-0" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this student?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeStudentAdmission}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
      <StudentPdf student={selectedData} ref={ref} />
    </>
  );
}

export default AdmissionManagementTable;
