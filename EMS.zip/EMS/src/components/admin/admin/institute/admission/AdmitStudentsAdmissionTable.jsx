import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import Spinner from "@/components/shared/Spinner";
import StudentPdf from "@/components/shared/StudentPdf";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useAdmitStudents } from "@/hooks";
import { cn } from "@/lib/utils";
import { getSerialNumber } from "@/services";
import { images } from "@/services/assets";
import { DeleteIcon, PrintIcon, RestoreIcon } from "@/services/assets/svgs";
import SelectLocalClass from "../class/SelectLocalClass";
import SelectSection from "../section/SelectSection";

const AdmitStudentsAdmissionTable = () => {
  const {
    status,
    isLoading,
    dataLists,
    selectedData,
    isFetching,
    isError,
    handleSelect,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    isAllSelected,
    student_ids,
    selectors,
    handleSelectAllStudent,
    isSubmitable,
    handleSubmit,
    handleToggleSelectStudent,
    handleSelector,
    classCode,
    handleReset,
    ref,
    pdfLoading,
  } = useAdmitStudents();

  return (
    <div className="card_common py-7">
      <div className="flex gap-4 items-center justify-between">
        <p className="card_title">Admission Management</p>
      </div>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <div className="flex-1 overflow-auto px-2">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                <th className="table_th">
                  <div className="w-6 h-6 flex items-center justify-center">
                    <Checkbox
                      checked={isAllSelected}
                      onCheckedChange={handleSelectAllStudent}
                    />
                  </div>
                </th>
                <th className="table_th">SL</th>
                <th className="table_th">Avatar</th>
                <th className="table_th">Name (English)</th>
                <th className="table_th">Name (Bangla)</th>
                <th className="table_th">Father Name</th>
                <th className="table_th">Year</th>
                <th className="table_th">Class</th>
                <th className="table_th">Group</th>
                <th className="table_th">Transaction ID</th>
                <th className="table_th min-w-[210px]">Action</th>
              </tr>
            </thead>
            <tbody>
              <TableHelper
                isLoading={isFetching}
                isError={isError}
                status={status}
                dataLength={dataLists?.length}
                column={11}
              >
                {dataLists?.map((item, index) => (
                  <tr
                    className={cn(
                      "table_row",
                      student_ids?.includes(item?._id) ? "bg-natural-100" : ""
                    )}
                    key={index}
                  >
                    <td className="table_td">
                      <div className="w-6 h-6 flex items-center justify-center">
                        <Checkbox
                          checked={student_ids?.includes(item?._id)}
                          onCheckedChange={() =>
                            handleToggleSelectStudent(item?._id)
                          }
                        />
                      </div>
                    </td>
                    <td className="table_td">
                      {getSerialNumber({
                        currentPage: currentPage,
                        index,
                        rowsPerPage: pageSize,
                      })}
                    </td>
                    <td className="table_td">
                      <img
                        src={item?.image || images.placeholderProfileImage}
                        alt="avatar"
                        className="w-8 h-8 rounded-full object-cover mx-auto"
                      />
                    </td>
                    <td className="table_td">{item?.name_english || "N/A"}</td>
                    <td className="table_td">{item?.name_bangla || "N/A"}</td>
                    <td className="table_td whitespace-nowrap">
                      {item?.father_name_english || "N/A"}
                    </td>
                    <td className="table_td">{item?.academic_year || "N/A"}</td>
                    <td className="table_td">
                      {item?.current_class?.local_class_name || "N/A"}
                    </td>
                    <td className="table_td">
                      {item?.current_group?.global_group_name || "N/A"}
                    </td>

                    <td className="table_td">
                      {item?.transaction_id || "N/A"}
                    </td>

                    <td className="table_td w-[260px]">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          className="border-none outline-none"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({ ...item, type: "delete" });
                          }}
                        >
                          <DeleteIcon className="!h-6 !w-6 shrink-0" />
                        </button>
                        <button
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({ ...item, type: "pdf" });
                          }}
                          disabled={pdfLoading}
                          className="border-none outline-none"
                        >
                          {pdfLoading && selectedData?._id === item?._id ? (
                            <Spinner className="w-6 h-6 border-2" />
                          ) : (
                            <PrintIcon className="!h-6 !w-6 shrink-0" />
                          )}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </TableHelper>
            </tbody>
          </table>
        </div>
        <Pagination
          currentPage={currentPage || 1}
          rowsPerPage={pageSize || 1}
          totalPages={totalPages || 1}
          updatePage={updatePage}
        />
      </div>

      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4">
        <div className="grid grid-cols-4 gap-4">
          <SelectLocalSessionYear
            value={selectors?.current_academic_year}
            onValueChange={(val) =>
              handleSelector({ current_academic_year: val })
            }
            label="Select Year"
            triggerClass="!bg-white"
          />

          <SelectLocalClass
            value={selectors?.current_class}
            onValueChange={(val) =>
              handleSelector({
                current_class: val,
                current_group: "",
                current_section: "",
              })
            }
            visibleItem={true}
            label="Select Class"
            triggerClass="!bg-white"
          />
          {classCode > 8 && (
            <SelectLocalGroup
              value={selectors?.current_group}
              onValueChange={(value) =>
                handleSelector({ current_group: value, current_section: "" })
              }
              triggerClass="!bg-white"
              classCode={classCode}
              label="Select Group"
            />
          )}
          <SelectSection
            value={selectors?.current_section}
            onValueChange={(val) => handleSelector({ current_section: val })}
            label="Select Section"
            triggerClass="!bg-white"
            isFiltered={true}
            classCode={classCode}
            group_id={selectors?.current_group}
          />
        </div>

        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px] h-12"
            variant="outline"
            size="lg"
            onClick={handleReset}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            className="gap-2 min-w-[120px] text-white h-12"
            size="lg"
            type="button"
            disabled={!isSubmitable}
            onClick={handleSubmit}
          >
            Confirm Admission
          </Button>
        </div>
      </div>

      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={closeModal}
        imageSrc={
          selectedData?.type == "delete"
            ? images.questionMarkRed
            : images.checkGreen
        }
        title={selectedData?.type ? "Are you sure?" : "Successful!"}
        text={
          selectedData?.type == "delete"
            ? "You want to delete this billing config?"
            : "The information has been updated successfully."
        }
        customDialogButtons={
          selectedData?.type == "delete" ? null : (
            <Button
              className="text-white h-12 w-full"
              size="lg"
              onClick={() => {
                setOpenModal(false);
              }}
            >
              Close
            </Button>
          )
        }
        onCancelPress={closeModal}
        onconfirmPress={removeStudentAdmission}
      />
      {isLoading && <RequestLoading />}
      <StudentPdf student={selectedData} ref={ref} />
    </div>
  );
};

export default AdmitStudentsAdmissionTable;
