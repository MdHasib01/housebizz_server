import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useGetAllLocalShiftsQuery } from "@/store/modules/admin/institute/scheduleShift/api";
import { useSelector } from "react-redux";

const SelectLocalShift = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select a class",
  triggerClass = "",
  heightClass = "",
  onSelect = () => {},
  errorMessage = "",
  visibleItem = false,
  selector = "_id",
  ...rest
}) => {
  const { auth } = useSelector((state) => state.auth);
  const { allData } = useSelector((state) => state.adminScheduleShifts);
  const institute_id = auth?.instituteAdmin?.institute_id;
  const { isFetching, isError, error } = useGetAllLocalShiftsQuery({
    institute_id: institute_id,
    page: 1,
    limit: 999999,
  });

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <div className="relative w-full">
          <Select {...rest}>
            <SelectTrigger
              className={cn(
                "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none capitalize",
                errorMessage && "!border-red-500",
                triggerClass,
                heightClass
              )}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {allData?.map((item, index) => (
                <SelectItem
                  value={
                    visibleItem
                      ? `${item?._id}-${item[selector]}`
                      : item[selector]
                  }
                  className="cursor-pointer py-2.5 capitalize"
                  key={index}
                >
                  {item?.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectLocalShift;
