import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import Timepicker from "@/components/shared/Timepicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useShifts } from "@/hooks";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";

const ShiftListTable = () => {
  const {
    isLoading,
    showModal,
    selectedData,
    dataLists,
    isFetching,
    isError,
    status,
    currentPage,
    totalPages,
    pageSize,
    updatePage,
    closeModal,
    removeShiftHanlder,
    handleSelect,
    updateSelectedRowValue,
    updateShiftHandler,
  } = useShifts();

  return (
    <>
      <div className="flex-1 overflow-auto px-2">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              {["Name", "Start Time", "End Time", "Action"].map(
                (item, index) => (
                  <th className="table_th  min-w-48" key={index}>
                    {item}
                  </th>
                )
              )}
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={4}
            >
              {dataLists?.map((item, index) => {
                const isActiveEditRow =
                  selectedData?._id === item?._id &&
                  selectedData?.type === "update";
                const isActiveRow =
                  selectedData?._id === item?._id &&
                  selectedData?.type !== "delete";

                return (
                  <tr
                    className={cn(
                      "table_row table_sm_picker",
                      isActiveRow ? "bg-natural-100" : ""
                    )}
                    key={index}
                    onClick={() => {
                      if (isActiveEditRow) return;
                      handleSelect({ ...item, type: "row" });
                    }}
                  >
                    <td className="table_td w-max capitalize">
                      {isActiveEditRow ? (
                        <>
                          <Input
                            name="name"
                            type="text"
                            placeholder="Enter shift Name"
                            value={selectedData?.name}
                            onChange={(e) =>
                              updateSelectedRowValue("name", e.target.value)
                            }
                            className="border-main-500 text-center placeholder:text-text-200"
                          />
                        </>
                      ) : (
                        <>{item?.name}</>
                      )}
                    </td>

                    <td
                      className="table_td"
                      onClick={(event) => event.stopPropagation()}
                    >
                      {isActiveEditRow ? (
                        <>
                          <Timepicker
                            time={selectedData?.start_time}
                            setTime={(value) =>
                              updateSelectedRowValue("start_time", value)
                            }
                            classNames={{
                              input: "!h-9 !text-sm",
                              selectHour: "!text-sm",
                              selectMinute: "!text-sm",
                              selectFormat: "!text-sm",
                              inputWrapper: "!border-main-500",
                            }}
                            id={`start_time_${index}`}
                            placeholder="Select start time"
                          />
                        </>
                      ) : (
                        <> {item?.start_time}</>
                      )}
                    </td>

                    <td className="table_td">
                      {isActiveEditRow ? (
                        <>
                          <Timepicker
                            time={selectedData?.end_time}
                            setTime={(value) =>
                              updateSelectedRowValue("end_time", value)
                            }
                            classNames={{
                              input: "!h-9 !text-sm",
                              selectHour: "!text-sm",
                              selectMinute: "!text-sm",
                              selectFormat: "!text-sm",
                              inputWrapper: "!border-main-500",
                            }}
                            id={`end_time_${index}`}
                            placeholder="Select start time"
                          />
                        </>
                      ) : (
                        <> {item?.end_time}</>
                      )}
                    </td>

                    <td className="table_td w-[260px]">
                      <div className="flex items-center justify-center gap-2">
                        {isActiveEditRow ? (
                          <>
                            <Button
                              size="sm"
                              className="bg-status-success hover:bg-status-success/70"
                              onClick={() =>
                                updateShiftHandler({ ...selectedData })
                              }
                            >
                              Update
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleSelect({})}
                            >
                              Cancel
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={(event) => {
                                event.stopPropagation();
                                handleSelect({ ...item, type: "update" });
                              }}
                            >
                              <EditIcon className="!h-6 !w-6 shrink-0" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={(event) => {
                                event.stopPropagation();
                                handleSelect({ ...item, type: "delete" });
                              }}
                            >
                              <DeleteIcon className="!h-6 !w-6 shrink-0" />
                            </Button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={images.questionMarkRed}
          title="Are you sure?"
          text="You want to delete this shift?"
          customDialogButtons={null}
          onCancelPress={closeModal}
          onconfirmPress={removeShiftHanlder}
        />
        {isLoading && <RequestLoading />}
      </div>

      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </>
  );
};

export default ShiftListTable;
