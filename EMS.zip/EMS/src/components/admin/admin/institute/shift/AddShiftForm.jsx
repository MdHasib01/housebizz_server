import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import Timepicker from "@/components/shared/Timepicker";
import { Button } from "@/components/ui/button";
import { useAddShift } from "@/hooks";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const AddShiftForm = () => {
  const { errors, formInput, isLoading, resetFields, onChangeTime, onSubmit } =
    useAddShift();

  return (
    <div className="card_common py-7">
      <p className="card_title">Add New Shift</p>

      <form
        onSubmit={onSubmit}
        id="add-shift-form"
        className="flex flex-col gap-10 mt-6"
      >
        <div className="grid grid-cols-3 gap-6">
          <Input
            label="Shift Name"
            placeholder="Enter shift name"
            name="name"
            type="text"
            errorMessage={errors?.name}
          />

          <div className="flex flex-col gap-2">
            <span className="label">Start Time</span>
            <Timepicker
              time={formInput?.start_time}
              setTime={(value) => onChangeTime("start_time", value)}
              classNames={{
                input: "min-h-[54px] h-full !text-sm",
                selectHour: "!text-sm",
                selectMinute: "!text-sm",
                selectFormat: "!text-sm",
              }}
              placeholder="Select start time"
              id="start_time"
            />
            {errors?.start_time && (
              <p className="text-status-error text-sm -mt-1">
                {errors?.start_time}
              </p>
            )}
          </div>

          <div className="flex flex-col gap-2">
            <span className="label">End Time</span>
            <Timepicker
              time={formInput?.end_time}
              setTime={(value) => onChangeTime("end_time", value)}
              classNames={{
                input: "min-h-[54px] h-full !text-sm",
                selectHour: "!text-sm",
                selectMinute: "!text-sm",
                selectFormat: "!text-sm",
              }}
              id="end_time"
              placeholder="Select end time"
            />
            {errors?.end_time && (
              <p className="text-status-error text-sm -mt-1">
                {errors?.end_time}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center justify-end">
          <Link
            to={adminRoutes.institute.shift.path}
            className="btn_blue justify-center h-12 min-w-32 !bg-transparent !text-main-500"
            onClick={() => resetFields()}
          >
            Cancel
          </Link>
          <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
            Add
          </Button>
        </div>
      </form>

      {isLoading && <RequestLoading />}
    </div>
  );
};

export default AddShiftForm;
