import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useDays } from "@/hooks/admin/institute/useDay";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon } from "@/services/assets/svgs";
import SelectDay from "./SelectDay";

const DayListTable = () => {
  const {
    selectedData,
    isLoading,
    showModal,
    isFetching,
    isError,
    status,
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    updatePage,
    handlerSelectDay,
    addDayHandler,
    removeDayHanlder,
    closeModal,
    handleSelect,
  } = useDays();

  const day =
    selectedData?.type === "select" && selectedData?.day_name
      ? selectedData?.day_name
      : "";

  return (
    <div className="card_common py-7">
      <div className="flex gap-4 items-center justify-between">
        <p className="card_title">Day</p>

        <div className="flex flex-row gap-2">
          <SelectDay
            wrapper="w-[376px]"
            heightClass="h-[48px]"
            value={day}
            onValueChange={(value) => handlerSelectDay(value)}
          />

          <Button
            size="sm"
            className="h-12 w-[110px]"
            disabled={!day || isLoading}
            onClick={addDayHandler}
          >
            Add
          </Button>
        </div>
      </div>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <div className="flex-1 overflow-auto px-2">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                <th className="table_th text-start">Day</th>
                <th className="table_th">Action</th>
              </tr>
            </thead>
            <tbody>
              <TableHelper
                isLoading={isFetching}
                isError={isError}
                status={status}
                dataLength={dataLists?.length}
                column={2}
              >
                {dataLists?.map((item, index) => {
                  return (
                    <tr
                      className={cn(
                        "table_row table_picker",
                        selectedData?._id === item?._id ? "bg-natural-100" : ""
                      )}
                      key={index}
                      onClick={() => handleSelect({ ...item, type: "row" })}
                    >
                      <td className="table_td w-max capitalize !text-start">
                        {item?.day_name}
                      </td>

                      <td className="table_td w-[290px]">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({ ...item, type: "delete" });
                          }}
                        >
                          <DeleteIcon className="!h-6 !w-6 shrink-0" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </TableHelper>
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage || 1}
          rowsPerPage={pageSize || 1}
          totalPages={totalPages || 1}
          updatePage={updatePage}
        />
      </div>

      {/* modal */}
      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={closeModal}
        title={
          selectedData?.type === "delete" ? "Are you sure?" : "Successful!"
        }
        text={
          selectedData?.type === "delete"
            ? "You want to delete this day?"
            : "Day has been added to the list successfully."
        }
        imageSrc={
          selectedData?.type === "delete"
            ? images.questionMarkRed
            : images.checkGreen
        }
        customDialogButtons={
          selectedData?.type === "delete" ? null : (
            <Button
              className="text-white h-12 w-full"
              size="lg"
              onClick={closeModal}
            >
              Close
            </Button>
          )
        }
        onCancelPress={closeModal}
        onconfirmPress={selectedData?.type === "delete" && removeDayHanlder}
      />

      {isLoading && <RequestLoading />}
    </div>
  );
};

export default DayListTable;
