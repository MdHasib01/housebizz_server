import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useGetAllLocalClassesQuery } from "@/store/modules/admin/institute/class/api";
import { useSelector } from "react-redux";

const SelectLocalClass = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select a class",
  triggerClass = "",
  heightClass = "",
  onSelect = () => {},
  errorMessage = "",
  visibleItem = false,
  isLoading = false,
  selector = "_id",
  institute_id = null,
  ...rest
}) => {
  const { allData } = useSelector((state) => state.adminClasses);
  const { auth } = useSelector((state) => state.auth);
  const id = institute_id ? institute_id : auth?.instituteAdmin?.institute_id;
  const { isFetching, isError, error } = useGetAllLocalClassesQuery(
    {
      institute_id: id,
      page: 1,
      limit: 999999,
    },
    {
      skip: !id || isLoading,
    }
  );

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching || isLoading}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <div className="relative w-full">
          <Select {...rest}>
            <SelectTrigger
              className={cn(
                "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
                errorMessage && "!border-red-500",
                triggerClass,
                heightClass
              )}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {allData?.map((item, index) => (
                <SelectItem
                  value={
                    visibleItem
                      ? `${item?.local_class_code}-${item[selector]}`
                      : item[selector]
                  }
                  className="cursor-pointer py-2.5"
                  key={index}
                >
                  {item?.local_class_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectLocalClass;
