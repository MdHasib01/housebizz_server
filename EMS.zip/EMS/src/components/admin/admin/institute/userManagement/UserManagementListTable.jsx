import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useUserManagement } from "@/hooks";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";

function UserManagementListTable() {
  const {
    dataLists,
    currentPage,
    pageSize,
    totalPages,
    isFetching,
    isError,
    status,
    selectedData,
    isLoading,
    showModal: showModal,
    updatePage,
    setSelectedData,
    closeModal,
    removeUserManageHanlder,
    handleResetPassword,
  } = useUserManagement();

  return (
    <>
      <div className="flex-1 overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">ID</th>
              <th className="table_th">Password</th>
              <th className="table_th">Type</th>
              <th className="table_th">Mobile No</th>
              <th className="table_th">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={5}
            >
              {dataLists?.map((item, index) => {
                const isSelected =
                  selectedData?._id === item?._id &&
                  selectedData?.type === "update";
                const isRowSelected =
                  selectedData?._id === item?._id &&
                  selectedData?.type === "row";
                return (
                  <tr
                    className={cn(
                      "table_row",
                      isRowSelected && "bg-natural-100"
                    )}
                    key={index}
                    onClick={() => {
                      if (isSelected) return;
                      setSelectedData({ ...item, type: "row" });
                    }}
                  >
                    <td className="table_td">{item?.username}</td>
                    <td className="table_td">{item?.password}</td>
                    <td className="table_td">Admin</td>
                    <td className="table_td">{item?.mobile_number}</td>
                    <td className="table_td">
                      <div className="flex items-center justify-center gap-2">
                        {isSelected ? (
                          <>
                            <button
                              type="button"
                              className="px-3 py-2 bg-main-500 text-white rounded"
                              onClick={handleResetPassword}
                            >
                              Reset Password
                            </button>
                            <button
                              type="button"
                              className="px-3 py-2 bg-status-error text-white rounded"
                              onClick={() => setSelectedData({})}
                            >
                              Cancel
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              className="border-none outline-none"
                              onClick={(event) => {
                                event.stopPropagation();
                                setSelectedData({ ...item, type: "update" });
                              }}
                            >
                              <EditIcon className="!h-6 !w-6 shrink-0" />
                            </button>
                            <button
                              className="border-none outline-none"
                              onClick={(event) => {
                                event.stopPropagation();
                                setSelectedData({
                                  ...item,
                                  type: "delete",
                                });
                              }}
                            >
                              <DeleteIcon className="!h-6 !w-6 shrink-0" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this user?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeUserManageHanlder}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </>
  );
}

export default UserManagementListTable;
