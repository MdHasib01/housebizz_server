import NumberInput from "@/components/shared/NumberInput";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAddUserManagement } from "@/hooks";
import { cn } from "@/lib/utils";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const AddUserForm = () => {
  const { errors, onSubmit, isLoading } = useAddUserManagement();
  return (
    <div className="card_common py-7">
      <p className="card_title">Add User</p>
      <form onSubmit={onSubmit} className="flex flex-col gap-10 mt-6">
        <div className="grid grid-cols-2 gap-6">
          <div className="flex flex-col gap-2">
            <span className="label">Select User Type</span>
            <Select defaultValue="institute_admin" name="role" required>
              <SelectTrigger
                className={cn(
                  "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none "
                )}
              >
                <SelectValue placeholder="Select User Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem
                  value="institute_admin"
                  className="cursor-pointer py-2.5"
                >
                  Admin
                </SelectItem>
              </SelectContent>
            </Select>
            {errors?.role && (
              <p className="text-status-error text-sm -mt-1">{errors?.role}</p>
            )}
          </div>
          <NumberInput
            label="Enter Mobile Number"
            placeholder="Enter user’s mobile no."
            name="mobile_number"
            errorMessage={errors?.mobile_number}
            required
          />
        </div>

        <div className="flex items-center justify-end">
          <Link
            to={adminRoutes.institute.userManage.path}
            className="btn_blue justify-center min-w-32 h-12 !bg-transparent !text-main-500"
          >
            Cancel
          </Link>
          <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
            Add
          </Button>
        </div>
      </form>
      {isLoading && <RequestLoading />}
    </div>
  );
};

export default AddUserForm;
