import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import LoadingInput from "@/components/shared/LoadingInput";
import { Button } from "@/components/ui/button";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const UpdateTeacherSkeleton = () => {
  return (
    <div className="flex flex-col gap-10">
      {/* Teacher Basic Info */}
      <div className="flex flex-col gap-6">
        <GroupTitleComponent title="Basic Information" />

        {/* Teacher Image */}
        <div className="grid grid-cols-2 gap-6 w-full mb-6">
          <div className="w-32 h-32 rounded-full flex-col-reverse justify-center pulse"></div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <LoadingInput label="Teacher Index" />
          <LoadingInput label="Institute ID" />
          <LoadingInput label="First Name*" />
          <LoadingInput label="Last Name*" />
          <LoadingInput label="Gender*" />
          <LoadingInput label="NID*" />
          <LoadingInput label="Mobile No*" />
          <LoadingInput label="Status" />
          <LoadingInput label="Teacher Contact Type" />
        </div>
      </div>

      {/* Education Qualification */}
      <div className="flex flex-col gap-6">
        <GroupTitleComponent title="Education Qualification" />
        <div className="grid grid-cols-2 gap-6">
          <LoadingInput label="Highest Qualification" />
          <LoadingInput label="Other Qualification" />
          <LoadingInput label="Subject Speciality" />
        </div>
      </div>

      {/* Present Address Information */}
      <div className="flex flex-col gap-6">
        <GroupTitleComponent title="Present Address Information" />
        <div className="grid grid-cols-2 gap-6">
          <LoadingInput label="Present Address Line" />
          <LoadingInput label="Present District" />
          <LoadingInput label="Present Upazilla" />
          <LoadingInput label="Present Post Office" />
          <LoadingInput label="Present Post Code" />
        </div>
      </div>

      {/* Permanent Address Information */}
      <div className="flex flex-col gap-6">
        <GroupTitleComponent title="Permanent Address Information" />
        <div className="grid grid-cols-2 gap-6">
          <LoadingInput label="Permanent Address Line" />
          <LoadingInput label="Permanent District" />
          <LoadingInput label="Permanent Upazilla" />
          <LoadingInput label="Permanent Post Office" />
          <LoadingInput label="Permanent Post Code" />
        </div>
      </div>

      {/* Other's Information */}
      <div className="flex flex-col gap-6">
        <GroupTitleComponent title="Other's Information" />
        <div className="grid grid-cols-2 gap-6">
          <LoadingInput label="Email" />
          <LoadingInput label="Phone No." />
          <LoadingInput label="TIN" />
        </div>
      </div>

      <div className="flex items-center justify-end">
        <Link
          to={adminRoutes.institute.teacher.path}
          className="h-12 min-w-[132px] btn_blue justify-center !bg-transparent !text-main-500"
        >
          Cancel
        </Link>
        <Button
          disabled
          type="submit"
          className="h-12 min-w-[132px] ml-4"
          size="lg"
        >
          Update
        </Button>
      </div>
    </div>
  );
};

export default UpdateTeacherSkeleton;
