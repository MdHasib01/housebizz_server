import UpdateTeacherHelper from "@/components/responseHelper/admin/admin/institute/UpdateTeacherHelper";
import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import ImageUploadProfile from "@/components/shared/ImageUploadProfile";
import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import SelectContactType from "@/components/shared/SelectContactType";
import SelectGender from "@/components/shared/SelectGender";
import SelectStatus from "@/components/shared/SelectStatus";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useUpdateTeacher } from "@/hooks/admin/institute/useTeachers";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const EditTeacherForm = () => {
  const {
    image,
    setImage,
    errors,
    selectors,
    setSelectors,
    onSubmit,
    isLoading,
    isFetching,
    isError,
    selectedData,
    ref,
    onAddressCheck,
  } = useUpdateTeacher();


  return (
    <div className="card_common py-7 flex flex-col gap-6 w-full">
      <UpdateTeacherHelper isLoading={isFetching} isError={isError}>
        <form onSubmit={onSubmit} className="flex flex-col gap-10" ref={ref}>
          {/* Teacher Basic Info */}
          <div className="flex flex-col gap-6">
            <GroupTitleComponent title="Basic Information" />

            {/* Teacher Image */}
            <div className="grid grid-cols-2 gap-6 w-full mb-6">
              <ImageUploadProfile
                image={image?.fileUrl}
                setImage={setImage}
                inputWrapper="w-32 h-32 rounded-full flex-col-reverse justify-center"
                imageClass="!rounded-full"
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <Input
                label="Teacher Index"
                placeholder="Enter teacher index"
                name="teacher_index"
                defaultValue={selectedData?.teacher_index}
                errorMessage={errors?.teacher_index}
                labelClass="required"
                required
              />
              <Input
                label="Institute ID"
                placeholder="Institute ID"
                name="institute_id"
                className="!bg-natural-200 h-12 border"
                defaultValue={selectedData?.institute_id}
                disabled
              />
              <Input
                label="First Name"
                placeholder="Enter first name"
                name="first_name"
                defaultValue={selectedData?.first_name}
                errorMessage={errors?.first_name}
                labelClass="required"
                required
              />
              <Input
                label="Last Name"
                placeholder="Enter last name"
                name="last_name"
                defaultValue={selectedData?.last_name}
                errorMessage={errors?.last_name}
              />
              <SelectGender
                value={selectors?.gender}
                onValueChange={(value) => setSelectors({ gender: value })}
                label="Gender"
                placeholder="Select your gender"
                errorMessage={errors?.gender}
                labelClass="required"
                required
              />
              <Input
                label="NID"
                placeholder="Enter NID"
                name="nid_number"
                defaultValue={selectedData?.nid_number}
                errorMessage={errors?.nid_number}
                labelClass="required"
                required
              />
              <Input
                label="Mobile No"
                placeholder="Enter your mobile no"
                name="mobile_number"
                defaultValue={selectedData?.mobile_number}
                errorMessage={errors?.mobile_number}
                labelClass="required"
                required
              />
              <SelectStatus
                value={selectors?.status}
                onValueChange={(value) => setSelectors({ status: value })}
                label="Status"
                placeholder="Select status"
                errorMessage={errors?.status}
                labelClass="required"
                required
              />
              <SelectContactType
                value={selectors?.contract_type}
                onValueChange={(value) =>
                  setSelectors({ contract_type: value })
                }
                label="Teacher Contact Type"
                placeholder="Select contact type"
                errorMessage={errors?.contract_type}
              />
            </div>
          </div>

          {/* Education Qualification */}
          <div className="flex flex-col gap-6">
            <GroupTitleComponent title="Education Qualification" />
            <div className="grid grid-cols-2 gap-6">
              <Input
                label="Highest Qualification"
                placeholder="Enter highest qualification"
                name="highest_qualification"
                defaultValue={selectedData?.highest_qualification}
                errorMessage={errors?.highest_qualification}
              />
              <Input
                label="Other Qualification"
                placeholder="Enter other qualification"
                name="other_qualification"
                defaultValue={selectedData?.other_qualification}
                errorMessage={errors?.other_qualification}
              />
              <Input
                label="Subject Speciality"
                placeholder="Enter subject speciality"
                name="subject_specialization"
                defaultValue={selectedData?.subject_specialization}
                errorMessage={errors?.subject_specialization}
              />
            </div>
          </div>

          {/* Present Address Information */}
          <div className="flex flex-col gap-6">
            <GroupTitleComponent title="Present Address Information" />
            <div className="grid grid-cols-2 gap-6">
              <Input
                label="Present Address Line"
                placeholder="Enter your present address"
                name="present_address_line"
                defaultValue={selectedData?.present_address_line}
                errorMessage={errors?.present_address_line}
                data-type="present"
              />
              <Input
                label="Present District"
                placeholder="Enter present district"
                name="present_district"
                defaultValue={selectedData?.present_district}
                errorMessage={errors?.present_district}
                data-type="present"
              />
              <Input
                label="Present Upazilla"
                placeholder="Enter present upazilla"
                name="present_upozilla"
                defaultValue={selectedData?.present_upozilla}
                errorMessage={errors?.present_upozilla}
                data-type="present"
              />
              <Input
                label="Present Post Office"
                placeholder="Enter present post office"
                name="present_post_office"
                defaultValue={selectedData?.present_post_office}
                errorMessage={errors?.present_post_office}
                data-type="present"
              />
              <Input
                label="Present Post Code"
                placeholder="Enter present post code"
                name="present_post_code"
                defaultValue={selectedData?.present_post_code}
                errorMessage={errors?.present_post_code}
                data-type="present"
              />
            </div>
          </div>

          {/* Permanent Address Information */}
          <div className="flex flex-col gap-6">
            <GroupTitleComponent title="Permanent Address Information" />
            <div className="flex items-center space-x-2 relative">
              <Checkbox id="address" onCheckedChange={onAddressCheck} />
              <label
                htmlFor="address"
                className="text-sm font-medium cursor-pointer"
              >
                Same as Present Address
              </label>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <Input
                label="Permanent Address Line"
                placeholder="Enter your permanent address"
                name="permanent_address_line"
                defaultValue={selectedData?.permanent_address_line}
                errorMessage={errors?.permanent_address_line}
                data-type="permanent"
              />
              <Input
                label="Permanent District"
                placeholder="Enter permanent district"
                name="permanent_district"
                defaultValue={selectedData?.permanent_district}
                errorMessage={errors?.permanent_district}
                data-type="permanent"
              />
              <Input
                label="Permanent Upazilla"
                placeholder="Enter permanent upazilla"
                name="permanent_upozilla"
                defaultValue={selectedData?.permanent_district}
                errorMessage={errors?.permanent_district}
                data-type="permanent"
              />
              <Input
                label="Permanent Post Office"
                placeholder="Enter permanent post office"
                name="permanent_post_office"
                defaultValue={selectedData?.permanent_post_office}
                errorMessage={errors?.permanent_post_office}
                data-type="permanent"
              />
              <Input
                label="Permanent Post Code"
                placeholder="Enter permanent post code"
                name="permanent_post_code"
                defaultValue={selectedData?.permanent_post_code}
                errorMessage={errors?.permanent_post_code}
                data-type="permanent"
              />
            </div>
          </div>

          {/* Other's Information */}
          <div className="flex flex-col gap-6">
            <GroupTitleComponent title="Other's Information" />
            <div className="grid grid-cols-2 gap-6">
              <Input
                label="Email"
                placeholder="Enter your email"
                name="email"
                type="email"
                defaultValue={selectedData?.email}
                errorMessage={errors?.email}
              />
              <Input
                label="Phone No."
                placeholder="Enter your phone no."
                name="phone_number"
                defaultValue={selectedData?.mobile_number}
                errorMessage={errors?.mobile_number}
              />
              <Input
                label="TIN"
                placeholder="Enter your TIN no."
                name="tax_identification_number"
                defaultValue={selectedData?.tax_identification_number}
                errorMessage={errors?.tax_identification_number}
              />
            </div>
          </div>

          <div className="flex items-center justify-end">
            <Link
              to={adminRoutes.institute.teacher.path}
              className="h-12 min-w-[132px] btn_blue justify-center !bg-transparent !text-main-500"
            >
              Cancel
            </Link>
            <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
              Update
            </Button>
          </div>
        </form>
      </UpdateTeacherHelper>
      {isLoading && <RequestLoading />}
    </div>
  );
};

export default EditTeacherForm;
