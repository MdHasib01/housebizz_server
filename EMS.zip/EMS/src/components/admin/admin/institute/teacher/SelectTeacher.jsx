import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import colors from "@/services/config/colors";
import { useGetAllTeachersQuery } from "@/store/modules/admin/institute/teacherManagement/api";
import { Check, ChevronDown } from "lucide-react";
import { useState } from "react";
import { useSelector } from "react-redux";

function SelectTeacher({
  label = "",
  labelClass = "",
  wrapper = "",
  labelChildren = null,
  placeholder = "Select Teacher",
  triggerClass = "",
  heightClass = "",
  value = "",
  onSelect = () => {},
  errorMessage = "",
  institute_id = null,
  selector = "_id",
}) {
  const { auth } = useSelector((state) => state.auth);
  const id = institute_id ? institute_id : auth?.instituteAdmin?.institute_id;
  const { allData } = useSelector((state) => state.adminTeacherManagement);
  const { isFetching, isError, error } = useGetAllTeachersQuery(
    {
      institute_id: id,
      page: 1,
      limit: 999999,
    },
    {
      skip: !id,
    }
  );
  const [open, setOpen] = useState(false);
  const teacher = [...(allData || [])]?.find(
    (item) => item[selector] === value
  );
  const teacherName = teacher?._id
    ? teacher?.first_name + " " + teacher?.last_name
    : placeholder;

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger
            className={cn(
              "w-full flex items-center justify-between h-[54px] outline-none input focus:ring-transparent !shadow-none !cursor-pointer",
              errorMessage && "!border-red-500",
              triggerClass,
              heightClass
            )}
          >
            {teacherName}
            <ChevronDown className="h-4 w-4" color={colors.natural[600]} />
          </PopoverTrigger>
          <PopoverContent align="end" className="w-96 max-w-96 p-0">
            <Command>
              <CommandInput placeholder="Search Teacher..." />
              <CommandList>
                <CommandEmpty>No Teacher Found.</CommandEmpty>
                <CommandGroup>
                  {allData?.map((item) => (
                    <CommandItem
                      key={item[selector]}
                      onSelect={() => {
                        onSelect(item?._id === value ? undefined : item?._id);
                        setOpen(false);
                      }}
                      className="cursor-pointer"
                    >
                      {item?.first_name} {item?.last_name}
                      <Check
                        className={cn(
                          "ml-auto",
                          value === item[selector] ? "opacity-100" : "opacity-0"
                        )}
                      />
                    </CommandItem>
                  ))}
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
}

export default SelectTeacher;
