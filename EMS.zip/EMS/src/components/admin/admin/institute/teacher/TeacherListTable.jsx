import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useTeachers } from "@/hooks/admin/institute/useTeachers";
import { cn } from "@/lib/utils";
import { adminRoutes, images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";
import { PlusIcon } from "lucide-react";
import { Link } from "react-router-dom";

function TeacherListTable() {
  const {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status,
    isLoading,
    handleSelectDelete,
    updatePage,
    closeModal,
    removeTeacher,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    isAllSelected,
    selectedTeachers,
    handleSelectAllTeacher,
    handleToggleSelectTeacher,
    totalItems,
    action,
    setAction,
    handleAction,
  } = useTeachers();
  return (
    <div>
      <div className="mb-4 flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-text-700">
            Total Teacher ({totalItems})
          </h2>
          {/* <div className="flex w-full gap-4 items-center mt-5 relative">
            <Select value={action} onValueChange={setAction}>
              <SelectTrigger className="min-w-48 h-12 outline-none input focus:ring-transparent !shadow-none ">
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="password" className="cursor-pointer py-2.5">
                  Change Password
                </SelectItem>
                <SelectItem value="export" className="cursor-pointer py-2.5">
                  Send SMS
                </SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={handleAction}
              size="lg"
              disabled={!action || selectedTeachers?.length === 0}
            >
              Action
            </Button>
          </div> */}
        </div>
        <Link
          className="btn_blue max-w-max"
          to={adminRoutes.institute.teacher.addTeacher.path}
        >
          <PlusIcon className="!h-5 !w-5 shrink-0" />
          <span>Add Teacher</span>
        </Link>
      </div>
      <div className="flex-1 overflow-auto px-2">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">
                <div className="w-6 h-6 flex items-center justify-center">
                  <Checkbox
                    checked={isAllSelected}
                    onCheckedChange={handleSelectAllTeacher}
                  />
                </div>
              </th>
              <th className="table_th">ID</th>
              <th className="table_th">Avatar</th>
              <th className="table_th">Name</th>
              <th className="table_th">Teacher Index</th>
              <th className="table_th">Password</th>
              <th className="table_th">Status</th>
              <th className="table_th">Qualification</th>
              <th className="table_th">Mobile No.</th>
              <th className="table_th">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={9}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedTeachers?.includes(item?._id)
                      ? "bg-natural-100"
                      : ""
                  )}
                  key={index}
                >
                  <td className="table_td">
                    <div className="w-6 h-6 flex items-center justify-center">
                      <Checkbox
                        checked={selectedTeachers?.includes(item?._id)}
                        onCheckedChange={() =>
                          handleToggleSelectTeacher(item?._id)
                        }
                      />
                    </div>
                  </td>
                  <td className="table_td">{item?.username}</td>
                  <td className="table_td">
                    <img
                      src={item?.image || images.placeholderProfileImage}
                      alt="avatar"
                      className="w-8 h-8 rounded-full object-cover mx-auto"
                    />
                  </td>
                  <td className="table_td">
                    {item?.first_name} {item?.last_name}
                  </td>
                  <td className="table_td">{item?.teacher_index}</td>
                  <td className="table_td">{item?.password}</td>
                  <td className="table_td">{item?.status}</td>
                  <td className="table_td whitespace-nowrap">
                    {item?.highest_qualification && item?.other_qualification
                      ? item?.highest_qualification +
                        " , " +
                        item?.other_qualification
                      : item?.highest_qualification ||
                        item?.other_qualification}
                  </td>
                  <td className="table_td">{item?.mobile_number}</td>

                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <Link
                        to={`${adminRoutes.institute.teacher.editTeacher.routePath}/${item?._id}`}
                        className="border-none outline-none"
                      >
                        <EditIcon className="!h-6 !w-6 shrink-0" />
                      </Link>
                      <button
                        className="border-none outline-none"
                        onClick={() => handleSelectDelete(item)}
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this billing config?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeTeacher}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
}

export default TeacherListTable;
