import { cn } from "@/lib/utils";

function SmsCard({
  className = "",
  title = "",
  value = 0,
  prefix = "",
  suffix = "",
}) {
  return (
    <div className={cn("py-4 px-5 rounded-lg", className)}>
      <span className="text-xs font-medium text-text-700 mb-1.5">{title}</span>
      <h4 className="text-base font-semibold text-text-900">
        {prefix} {value?.toLocaleString()} {suffix}
      </h4>
    </div>
  );
}

export default SmsCard;
