import SmsCard from "./SmsCard";

function SmsStates() {
  return (
    <div className="grid grid-cols-4 gap-4 mt-4">
      <SmsCard className="bg-green-50" title="Total SMS Sent" value={5042} />
      <SmsCard className="bg-secondary-50" title="SMS this month" value={890} />
      <SmsCard
        className="bg-cyan-50"
        title="Current Bill"
        prefix="৳"
        value={5042}
      />
      <SmsCard
        className="bg-cyan-300"
        title="Due Bill"
        prefix="৳"
        value={5042}
      />
    </div>
  );
}

export default SmsStates;
