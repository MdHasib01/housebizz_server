import SelectSmsType from "@/components/shared/SelectSmsType";
import { Button } from "@/components/ui/button";
import { useSmsForm } from "@/hooks";
import { RestoreIcon } from "@/services/assets/svgs";

function SmsAddForm() {
  const {
    smsTags,
    sms_type,
    message,
    selectedData,
    handleChange,
    TagClick,
    handleMessageChange,
    handleReset,
    handleSubmit,
  } = useSmsForm();

  return (
    <div className="p-4 rounded-2xl bg-natural-150 border border-neutral-300 mt-4">
      <div className="grid grid-cols-2">
        <SelectSmsType
          value={sms_type}
          onValueChange={handleChange}
          triggerClass="!bg-white"
          label="Type"
        />
      </div>
      <div className="flex items-center gap-2 mt-4 text-sm text-text-700">
        <span className="font-semibold">Message</span>
        <span>|</span>
        <span>Available Tags:</span>
        <ul className="flex items-center flex-wrap gap-1.5">
          {smsTags?.map((tag, index) => (
            <li
              key={index}
              className="text-xs font-medium px-3 py-2 border rounded cursor-pointer"
              style={{
                color: tag?.color,
                backgroundColor: tag?.bgColor,
                borderColor: tag?.color,
              }}
              onClick={() => TagClick(tag?.tag)}
            >
              {tag?.tag}
            </li>
          ))}
        </ul>
      </div>
      <textarea
        className="border border-neutral-300 outline-none w-full rounded-lg bg-white min-h-24 mt-4 p-4 text-sm font-normal placeholder:text-text-disabled"
        placeholder="Type message here"
        value={message}
        onChange={handleMessageChange}
      />

      <div className="flex items-center justify-end mt-6 gap-4">
        <Button
          className="gap-1 border-natural-500 min-w-[108px] h-12"
          variant="outline"
          size="lg"
          onClick={handleReset}
        >
          <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
          <span className="text-text-600">Reset</span>
        </Button>
        <Button
          type="button"
          className="gap-2 min-w-[120px] h-12"
          size="lg"
          onClick={handleSubmit}
        >
          <span className="text-white">
            {selectedData?._id ? "Update" : "Add"}
          </span>
        </Button>
      </div>
    </div>
  );
}

export default SmsAddForm;
