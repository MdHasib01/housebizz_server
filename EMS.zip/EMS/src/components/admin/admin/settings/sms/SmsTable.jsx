import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useSms } from "@/hooks";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";

function SmsTable() {
  const {
    dataLists,
    showModal,
    selectedData,
    isLoading,
    handleSelect,
    closeModal,
    handleRemove,
    isFetching,
    isError,
    status,
  } = useSms();
  return (
    <div className="card_common py-7 mt-6">
      <h2 className="text-lg font-medium text-text-900">Message List</h2>
      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <div className="flex-1 overflow-auto">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                {["Type", "Message", "Action"].map((item, index) => (
                  <th
                    className="table_th text-start last:text-center first:w-56"
                    key={index}
                  >
                    {item}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <TableHelper
                isLoading={isFetching}
                isError={isError}
                status={status}
                dataLength={dataLists?.length}
                column={3}
              >
                {dataLists?.map((item, index) => {
                  return (
                    <tr
                      className={cn(
                        "table_row table_picker",
                        selectedData?._id === item?._id ? "bg-natural-100" : ""
                      )}
                      key={index}
                      onClick={() => handleSelect({ ...item, type: "row" })}
                    >
                      <td className="table_td w-max capitalize !text-start">
                        {item?.sms_type}
                      </td>

                      <td className="table_td !text-start max-w-96 truncate">
                        {item?.message}
                      </td>

                      <td className="table_td w-[260px]">
                        <div className="flex items-center justify-center">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={(event) => {
                              event.stopPropagation();
                              handleSelect({ ...item, type: "update" });
                            }}
                          >
                            <EditIcon className="!h-6 !w-6 shrink-0" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={(event) => {
                              event.stopPropagation();
                              handleSelect({ ...item, type: "delete" });
                            }}
                          >
                            <DeleteIcon className="!h-6 !w-6 shrink-0" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </TableHelper>
            </tbody>
          </table>
        </div>
      </div>

      {/* modal */}
      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={closeModal}
        title={
          selectedData?.type === "delete" ? "Are you sure?" : "Successful!"
        }
        text={
          selectedData?.type === "delete"
            ? "You want to delete this SMS?"
            : "SMS has been added to the list successfully."
        }
        imageSrc={
          selectedData?.type === "delete"
            ? images.questionMarkRed
            : images.checkGreen
        }
        customDialogButtons={
          selectedData?.type === "delete" ? null : (
            <Button
              className="text-white h-12 w-full"
              size="lg"
              onClick={closeModal}
            >
              Close
            </Button>
          )
        }
        onCancelPress={closeModal}
        onconfirmPress={selectedData?.type === "delete" && handleRemove}
      />

      {isLoading && <RequestLoading />}
    </div>
  );
}

export default SmsTable;
