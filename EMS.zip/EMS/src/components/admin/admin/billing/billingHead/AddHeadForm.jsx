import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useAddBillingHead } from "@/hooks";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";
import SelectHeadStatus from "./SelectHeadStatus";
import NumberInput from "@/components/shared/NumberInput";

const AddHeadForm = () => {
  const { onSubmit, errors, isLoading } = useAddBillingHead();

  return (
    <div className="card_common py-7">
      <p className="card_title">Add New Head</p>

      <form onSubmit={onSubmit} className="flex flex-col gap-10 mt-6">
        <div className="grid grid-cols-3 gap-6">
          <NumberInput
            label="Head ID"
            placeholder="Enter head id"
            name="head_id"
            errorMessage={errors?.head_id}
            required
          />
          <Input
            label="Head Name"
            placeholder={"Enter head name"}
            name="head_title"
            type="text"
            errorMessage={errors?.head_title}
            required
          />
          <SelectHeadStatus
            defaultValue="published"
            label="Head Status"
            placeholder="Select head status"
            name="status"
            required
            errorMessage={errors?.status}
          />
        </div>

        <div className="flex items-center justify-end">
          <Link
            to={adminRoutes.billing.billingHead.path}
            className="btn_blue h-12 justify-center min-w-32 !bg-transparent !text-main-500"
          >
            Cancel
          </Link>
          <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
            Add
          </Button>
        </div>
      </form>
      {isLoading && <RequestLoading />}
    </div>
  );
};

export default AddHeadForm;
