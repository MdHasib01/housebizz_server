import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { useBillingTypes } from "@/hooks/admin/billing/useBillingTypes";
import { cn } from "@/lib/utils";
import { adminRoutes, images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";
import { Link } from "react-router-dom";

function BillingTypesTable() {
  const {
    dataLists,
    isFetching,
    isError,
    status,
    isLoading,
    handleSelect,
    updatePage,
    closeModal,
    removeBillingType,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    selectedData,
  } = useBillingTypes();

  return (
    <div>
      <div className="max-h-[600px] overflow-auto px-2">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">Billing Type</th>
              <th className="table_th">Category</th>
              <th className="table_th">Session/Year</th>
              <th className="table_th">Class</th>
              <th className="table_th">Group</th>
              <th className="table_th">Assigned Heads</th>
              <th className="table_th min-w-[210px]">Actions</th>
            </tr>
          </thead>

          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={7}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    item?._id === selectedData?._id ? "bg-natural-100" : ""
                  )}
                  key={index}
                  onClick={() =>
                    handleSelect({
                      ...item,
                      type: "row",
                    })
                  }
                >
                  <td className="table_td">{item?.billing_type || "N/A"}</td>
                  <td className="table_td">
                    {item?.category_id?.local_category_name || "N/A"}
                  </td>
                  <td className="table_td">{item?.academic_year || "N/A"}</td>
                  <td className="table_td whitespace-nowrap">
                    {item?.local_class_id?.local_class_name || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.group_id?.global_group_name || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.total_assigned_heads || 0}
                  </td>
                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <Link
                        onClick={(event) => event.stopPropagation()}
                        to={`${adminRoutes.billing.billingTypes.updateType.routePath}/${item?._id}`}
                        className="border-none outline-none"
                      >
                        <EditIcon className="!h-6 !w-6 shrink-0" />
                      </Link>
                      <button
                        className="border-none outline-none"
                        onClick={(event) => {
                          event.stopPropagation();
                          handleSelect({
                            ...item,
                            type: "delete",
                          });
                        }}
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={images.questionMarkRed}
          title="Successful!"
          text="You want to delete this billing type?"
          onCancelPress={closeModal}
          onconfirmPress={removeBillingType}
        />
        {isLoading && <RequestLoading />}
      </div>

      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
}

export default BillingTypesTable;
