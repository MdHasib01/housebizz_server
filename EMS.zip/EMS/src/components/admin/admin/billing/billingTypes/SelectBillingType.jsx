import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useGetAllBillingTypesQuery } from "@/store/modules/admin/billing/billingTypes/api";
import { useSelector } from "react-redux";

const SelectBillingType = ({
  onValueChange = () => {},
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select a category",
  triggerClass = "",
  heightClass = "",
  errorMessage = "",
  isLoading = false,
  selector = "_id",
  institute_id = null,
  isSelectAll = false,
  academic_year = null,
  classCode = null,
  category_id = null,
  group_id = null,
  ...rest
}) => {
  const { auth } = useSelector((state) => state.auth);
  const id = institute_id ? institute_id : auth?.instituteAdmin?.institute_id;

  const { allData } = useSelector((state) => state.adminBillingTypes);
  const { isFetching, isError, error } = useGetAllBillingTypesQuery(
    {
      institute_id: id,
      page: 1,
      limit: 999999,
    },
    {
      skip: !id || isLoading,
    }
  );

  const handleSelectValue = (value) => {
    if (!isSelectAll) return onValueChange(value);
    const type = allData.find((item) => item[selector] === value);
    return onValueChange(type);
  };

  const filterByTypes = (item) => {
    if (!academic_year && !classCode && !category_id) return false;
    const isMatch =
      item?.local_class_id?.local_class_code == classCode &&
      item?.academic_year == academic_year &&
      item?.category_id?._id == category_id
        ? true
        : false;
    return group_id ? isMatch && item?.group_id?._id === group_id : isMatch;
  };

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching || isLoading}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <div className="relative w-full">
          <Select {...rest} onValueChange={handleSelectValue}>
            <SelectTrigger
              className={cn(
                "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
                errorMessage && "!border-red-500",
                triggerClass,
                heightClass
              )}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {allData.filter(filterByTypes)?.map((item, index) => (
                <SelectItem
                  value={item[selector]}
                  className="cursor-pointer py-2.5"
                  key={index}
                >
                  {item?.billing_type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectBillingType;
