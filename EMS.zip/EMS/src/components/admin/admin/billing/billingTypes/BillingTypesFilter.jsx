import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import { Button } from "@/components/ui/button";
import { useBillingTypesFiter } from "@/hooks";
import { adminRoutes } from "@/services";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import { resetBillingTypeSelectors } from "@/store/modules/admin/billing/billingTypes/slice";
import { PlusIcon } from "lucide-react";
import SelectCategory from "../../institute/category/SelectCategory";
import SelectLocalClass from "../../institute/class/SelectLocalClass";

const BillingTypesFilter = () => {
  const {
    dispatch,
    navigate,
    class_code,
    search_query,
    handleSetSearchQuery,
    handleResetSearchQuery,
    handleFilter,
  } = useBillingTypesFiter();

  return (
    <div className="card_common py-7">
      <div className="flex gap-4 items-center justify-between">
        <p className="card_title">Billing Types</p>
        <Button
          size="lg"
          onClick={() => {
            dispatch(resetBillingTypeSelectors());
            navigate(adminRoutes.billing.billingTypes.addNewType.path);
          }}
          className="gap-2"
        >
          <PlusIcon className="!h-5 !w-5 shrink-0" />
          <span>Add New Type</span>
        </Button>
      </div>

      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4">
        <div className="grid grid-cols-3 gap-4">
          <SelectLocalSessionYear
            value={search_query?.academic_year}
            onValueChange={(value) =>
              handleSetSearchQuery({ academic_year: value })
            }
            triggerClass="!bg-white"
            label="Select Year"
            heightClass="h-12"
          />

          <SelectLocalClass
            value={search_query?.class_id}
            onValueChange={(value) => handleSetSearchQuery({ class_id: value })}
            triggerClass="!bg-white"
            label="Select Class"
            visibleItem={true}
            heightClass="h-12"
          />

          {class_code > 8 && (
            <SelectLocalGroup
              value={search_query?.group_id}
              onValueChange={(value) =>
                handleSetSearchQuery({ group_id: value })
              }
              triggerClass="!bg-white"
              classCode={class_code}
              label="Select Group"
              componenetId="unique4"
              heightClass="h-12"
            />
          )}
          <SelectCategory
            value={search_query?.category_id}
            onValueChange={(value) =>
              handleSetSearchQuery({ category_id: value })
            }
            label="Select Category"
            triggerClass="!bg-white"
            name="category_id"
            heightClass="h-12"
          />
        </div>

        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px]"
            variant="outline"
            size="lg"
            onClick={() => handleResetSearchQuery()}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            className="gap-2 min-w-[120px]"
            size="lg"
            onClick={() => handleFilter()}
          >
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BillingTypesFilter;
