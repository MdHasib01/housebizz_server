import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import CustomSpinner from "@/components/shared/CustomSpinner";
import ErrorUi from "@/components/shared/ErrorUi";
import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useUpdateBillingType } from "@/hooks";
import SelectCategory from "../../institute/category/SelectCategory";
import SelectLocalClass from "../../institute/class/SelectLocalClass";
import BTAssignableList from "./swapList/BTAssignableList";
import BTAssignedList from "./swapList/BTAssignedList";
import BTDataSwapBar from "./swapList/BTDataSwapBar";

const UpdateBillingTypeForm = () => {
  const {
    selectors,
    left_heads,
    right_heads,
    selected_left_heads,
    selected_right_heads,
    left_search,
    right_search,
    selectAllLeftHeads,
    handleToggleLeftHead,
    selectAllRightHeads,
    handleToggleRightHead,
    handleMoveRightToLeft,
    handleMoveLeftToRight,
    setLeftSearch,
    setRightSearch,

    isFetching,
    isError,
    isUpdating,

    errors,
    class_code,
    handleSelector,
    updateBillingTypeHandler,
  } = useUpdateBillingType();

  return (
    <div className="card_common py-7">
      <p className="card_title">Update Billing Type</p>

      <form
        className="flex flex-col gap-10 mt-6"
        onSubmit={updateBillingTypeHandler}
        id="update-billing-type-form"
      >
        <div className="grid grid-cols-2 gap-6">
          <SelectLocalSessionYear
            value={selectors?.academic_year}
            onValueChange={(value) => handleSelector({ academic_year: value })}
            triggerClass="!bg-white"
            label={"Session / Year"}
            errorMessage={errors?.academic_year}
          />
          <SelectLocalClass
            value={selectors?.local_class_id}
            onValueChange={(value) =>
              handleSelector({ local_class_id: value, group_id: "" })
            }
            triggerClass="!bg-white"
            label="Select Class"
            errorMessage={errors?.local_class_id}
            visibleItem={true}
          />

          {class_code > 8 && (
            <SelectLocalGroup
              value={selectors?.group_id}
              onValueChange={(value) => handleSelector({ group_id: value })}
              triggerClass="!bg-white"
              classCode={class_code}
              label="Select Group"
              componenetId="unique2"
            />
          )}
          <SelectCategory
            value={selectors?.category_id}
            onValueChange={(value) => handleSelector({ category_id: value })}
            label="Select Category"
            triggerClass="!bg-white"
            name="category_id"
            errorMessage={errors?.category_id}
          />

          <Input
            label="Billing Type"
            placeholder="Type here"
            name="billing_type"
            type="text"
            errorMessage={errors?.billing_type}
            value={selectors?.billing_type}
            onChange={(e) => handleSelector({ billing_type: e.target.value })}
          />
        </div>

        <div>
          <p className="card_title mb-4">Billing Head Assigning</p>

          {isFetching ? (
            <CustomSpinner />
          ) : isError ? (
            <ErrorUi />
          ) : (
            <div className="flex flex-row items-stretch">
              <BTAssignableList
                className="flex-grow"
                data={left_heads}
                selectedData={selected_left_heads}
                handleAll={selectAllLeftHeads}
                handleSingle={handleToggleLeftHead}
                search={left_search}
                setSearch={setLeftSearch}
                selector="head_title"
              />
              <BTDataSwapBar
                className={""}
                handleMoveRightToLeft={handleMoveRightToLeft}
                handleMoveLeftToRight={handleMoveLeftToRight}
              />
              <BTAssignedList
                className="flex-grow"
                data={right_heads}
                selectedData={selected_right_heads}
                handleAll={selectAllRightHeads}
                handleSingle={handleToggleRightHead}
                search={right_search}
                setSearch={setRightSearch}
                selector="head_title"
              />
            </div>
          )}
          {errors.assigned_heads && (
            <p className="text-status-error text-sm mt-1">
              {errors?.assigned_heads}
            </p>
          )}
        </div>

        <div className="flex items-center justify-end">
          {/* <Button
                        className="h-12 min-w-[132px] text-main-500"
                        size="lg"
                        variant="outline"
                        type="reset"
                        onClick={() => handleReset()}
                    >
                        Cancel
                    </Button> */}
          <Button type="submit" className="h-12 min-w-[132px] ml-4" size="lg">
            Update
          </Button>
        </div>
      </form>

      {isUpdating && <RequestLoading />}
    </div>
  );
};

export default UpdateBillingTypeForm;
