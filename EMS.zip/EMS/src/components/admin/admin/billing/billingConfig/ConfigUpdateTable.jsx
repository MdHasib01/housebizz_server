import TableHelper from "@/components/responseHelper/shared/TableHelper";
import FormInput from "@/components/shared/form/FormInput";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useBillingConfigUpdate } from "@/hooks";
import { months } from "@/services/helpers";

const ConfigUpdateTable = () => {
  const {
    isFetching,
    status,
    isError,
    activeConfigDetails,
    completeData,
    inputChangeHandler,
    updateBillingTypeHandler,
    isUpdatingBillingConfig,
    navigateBack,
  } = useBillingConfigUpdate();

  return (
    <div className="card_common py-7">
      <div className="flex gap-4 items-center justify-between">
        <p className="card_title">Billing Configs</p>
      </div>

      <div className="bg-main-50 border border-main-500 rounded-2xl py-7 px-6 grid grid-cols-2 gap-x-12 gap-y-3 mt-4">
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Category :{" "}
          <span className="font-semibold !leading-[1.2]">
            {completeData[0]?.category_name}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Session/Year :{" "}
          <span className="font-semibold !leading-[1.2]">
            {completeData[0]?.academic_year}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Class :{" "}
          <span className="font-semibold !leading-[1.2]">
            {completeData[0]?.local_class_name}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Billing Type :{" "}
          <span className="font-semibold !leading-[1.2]">
            {completeData[0]?.billing_type}
          </span>
        </p>
      </div>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">Head Name</th>
              {months.map((month) => (
                <th key={month} className="table_th capitalize">
                  {month}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={completeData?.length}
              column={months.length + 1}
            >
              {completeData?.map(({ id, headName, monthly_fees }, rowIndex) => (
                <tr className="table_row table_picker" key={rowIndex}>
                  <td className="table_td w-max capitalize">
                    <p
                      className={
                        headName === "Total Amount"
                          ? "font-semibold whitespace-nowrap min-w-[200px]"
                          : ""
                      }
                    >
                      {headName}
                    </p>
                  </td>

                  {months.map((month) => {
                    const fee =
                      monthly_fees[
                        month.charAt(0).toUpperCase() + month.slice(1)
                      ];
                    const tableFee = fee ? fee : "";
                    return (
                      <td
                        key={month}
                        className="table_td min-w-[100px] max-w-[100px]"
                      >
                        {headName === "Total Amount" ? (
                          <div className="w-full text-center font-semibold max-w-[100px] overflow-hidden">
                            {fee}
                          </div>
                        ) : (
                          <FormInput
                            name={month}
                            type="number"
                            value={tableFee}
                            setValue={(e) =>
                              inputChangeHandler(e, month, rowIndex)
                            }
                              className="focus-within:border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0 shadow-none number_input"
                              placeholder=""
                          />
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-end mt-8">
        <Button
          className="h-12 min-w-[132px] text-main-500"
          size="lg"
          variant="outline"
          onClick={navigateBack}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          className="h-12 min-w-[132px] ml-4"
          size="lg"
          onClick={updateBillingTypeHandler}
        >
          Update
        </Button>
      </div>

      {isUpdatingBillingConfig && <RequestLoading />}
    </div>
  );
};

export default ConfigUpdateTable;
