import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useBillingTypesAndConfigs } from "@/hooks";
import { cn } from "@/lib/utils";
import { adminRoutes } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";

const BillingConfigListTable = () => {
  const {
    isFetching,
    isLoading,
    status,
    isError,
    currentPage,
    pageSize,
    totalPages,
    dispatch,
    navigate,
    updatePage,
    handleModalToggle,
    handleYearSelection,
    handleDeleteBillingConfig,
    showModal,
    selectedYear,
    currentBillingTypes,
    handleSearch,
    handleSelect,
    selectedData,
  } = useBillingTypesAndConfigs();

  return (
    <div className="card_common py-7">
      <div className="flex gap-4 items-center justify-between">
        <p className="card_title">Billing Types & Config</p>

        <div className="flex flex-row gap-2">
          <SelectLocalSessionYear
            value={selectedYear}
            onValueChange={handleYearSelection}
            triggerClass="!bg-white !w-[376px] h-12"
            placeholder="Select Year"
          />
          <Button onClick={handleSearch} size="sm" className="h-12 w-[110px]">
            Search
          </Button>
        </div>
      </div>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <div className="flex-1 overflow-auto px-2">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                <th className="table_th">Category</th>
                <th className="table_th">Session Year</th>
                <th className="table_th">Class</th>
                <th className="table_th">Group</th>
                <th className="table_th">Billing Type</th>
                <th className="table_th">Action</th>
              </tr>
            </thead>
            <tbody>
              <TableHelper
                isLoading={isFetching}
                isError={isError}
                status={status}
                dataLength={currentBillingTypes?.length}
                column={6}
              >
                {currentBillingTypes?.map((item, index) => {
                  return (
                    <tr
                      className={cn(
                        "table_row table_picker",
                        item?._id === selectedData?._id ? "bg-natural-100" : ""
                      )}
                      key={index}
                      onClick={() =>
                        handleSelect({
                          ...item,
                          type: "row",
                        })
                      }
                    >
                      <td className="table_td w-max capitalize">
                        {item?.category_id?.local_category_name}
                      </td>
                      <td className="table_td w-max capitalize">
                        {item?.academic_year}
                      </td>
                      <td className="table_td w-max capitalize">
                        {item?.local_class_id?.local_class_name}
                      </td>
                      <td className="table_td w-max capitalize">
                        {item?.group_id?.global_group_name || "N/A"}
                      </td>
                      <td className="table_td w-max capitalize">
                        {item?.billing_type}
                      </td>

                      <td className="table_td w-full flex_center">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={(event) => {
                            event.stopPropagation();
                            navigate(
                              `${adminRoutes.billing.billingConfig.updateConfig.routePath}/${item?._id}`
                            );
                          }}
                        >
                          <EditIcon className="!h-6 !w-6 shrink-0" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({
                              ...item,
                              type: "delete",
                            });
                          }}
                        >
                          <DeleteIcon className="!h-6 !w-6 shrink-0" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </TableHelper>
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage || 1}
          rowsPerPage={pageSize || 1}
          totalPages={totalPages || 1}
          updatePage={updatePage}
        />
      </div>

      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={handleModalToggle}
        onCancelPress={handleModalToggle}
        onconfirmPress={handleDeleteBillingConfig}
        title="Are you sure?"
        text="You want to delete this billing config? "
      />

      {isLoading && <RequestLoading />}
    </div>
  );
};

export default BillingConfigListTable;
