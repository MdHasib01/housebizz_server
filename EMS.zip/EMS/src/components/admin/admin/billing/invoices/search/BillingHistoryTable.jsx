import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Input from "@/components/shared/Input";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useBillingSearch } from "@/hooks";
import { cn } from "@/lib/utils";
import { getStringDate, images } from "@/services";
import {
  DeleteIcon,
  EditIcon,
  EyeIcon,
  PrintIcon,
  SearchIcon,
  SpinnerAnimatedIcon,
} from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import InvoicePdf from "./InvoicePdf";
import SearchInvoiceModal from "./SearchInvoiceModal";
import SearchInvoiceViewModal from "./SearchInvoiceViewModal";

function BillingHistoryTable() {
  const {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status,
    isLoading,
    handleSelectData,
    updatePage,
    closeModal,
    removeBillingSearchAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    student_ids,
    handleSelectAllBillingSearch,
    handleToggleSelectStudent,
    handleSearchValue,
    searchValue,
    isAllSelected,
    dataLength,
    ref,
    isPdfLoading,
    updateHandler,
  } = useBillingSearch();

  return (
    <div className="card_common py-7 mt-6">
      <div className="mb-4 flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-text-700">
            Student Found ({dataLength})
          </h2>
          <div className="flex gap-4 items-center mt-5 relative">
            <Select>
              <SelectTrigger className="border border-natural-300 p-4 rounded-lg flex items-center justify-between gap-2 focus:ring-transparent !shadow-none h-12 max-w-48">
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent className="w-48 divide-y divide-natural-200">
                <SelectItem
                  value="send_sms"
                  className="p-2 cursor-pointer text-sm text-text-600"
                >
                  Send Due Bill Sms
                </SelectItem>
              </SelectContent>
            </Select>

            <Button size="lg">Action</Button>
          </div>
        </div>
        <div className="w-full max-w-72 relative">
          <Input
            className="!py-2.5 !pl-8"
            placeholder="Search by student ID/ Roll No."
            value={searchValue}
            onChange={handleSearchValue}
          />
          <SearchIcon
            className="absolute top-1/2 left-2 -translate-y-1/2 pointer-events-none"
            color={colors.natural[700]}
          />
        </div>
      </div>

      <div className="max-h-[620px] overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">
                <div className="w-6 h-6 flex items-center justify-center">
                  <Checkbox
                    checked={isAllSelected}
                    onCheckedChange={handleSelectAllBillingSearch}
                  />
                </div>
              </th>
              <th className="table_th">Invoice ID</th>
              <th className="table_th">ID</th>
              <th className="table_th min-w-32">Roll No.</th>
              <th className="table_th min-w-32">Student Name</th>
              <th className="table_th min-w-32">C.Date</th>
              <th className="table_th min-w-32">Class</th>
              <th className="table_th min-w-32">Section</th>
              <th className="table_th min-w-32">Session</th>
              <th className="table_th min-w-32">Category</th>
              <th className="table_th min-w-32">Status</th>
              <th className="table_th min-w-32">D.Date</th>
              <th className="table_th min-w-32">B.Month</th>
              <th className="table_th min-w-32">Amount</th>
              <th className="table_th min-w-[210px]">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={15}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    student_ids?.includes(item?._id) ? "bg-natural-100" : ""
                  )}
                  key={index}
                >
                  <td className="table_td">
                    <div className="w-6 h-6 flex items-center justify-center">
                      <Checkbox
                        checked={student_ids?.includes(item?._id)}
                        onCheckedChange={() =>
                          handleToggleSelectStudent(item?._id)
                        }
                      />
                    </div>
                  </td>
                  <td className="table_td">{item?.invoice_number || "N/A"}</td>
                  <td className="table_td">
                    {item?.student_id?.username || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.student_id?.current_roll_number || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.student_id?.name_english || "N/A"}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {item?.pay_date ? getStringDate(item?.pay_date) : "N/A"}
                  </td>

                  <td className="table_td">
                    {item?.student_id?.current_class?.local_class_name || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.student_id?.current_section?.section_name || "N/A"}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {item?.student_id?.academic_year || "N/A"}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {item?.student_id?.current_category?.local_category_name}
                  </td>
                  <td className="table_td">{item?.status || "N/A"}</td>
                  <td className="table_td whitespace-nowrap">
                    {getStringDate(item?.due_date) || "N/A"}
                  </td>
                  <td className="table_td">{item?.billing_month || "N/A"}</td>
                  <td className="table_td">
                    {item?.total_amount?.toLocaleString() || "N/A"}
                  </td>
                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "view" })
                        }
                      >
                        <EyeIcon
                          className="!h-6 !w-6 shrink-0"
                          color={colors.green[500]}
                        />
                      </button>
                      <button
                        type="button"
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "update" })
                        }
                      >
                        <EditIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                      <button
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "print" })
                        }
                        disabled={isPdfLoading}
                      >
                        {isPdfLoading && selectedData?._id === item?._id ? (
                          <SpinnerAnimatedIcon
                            strokeWidth={6}
                            className={"!h-5 !w-5 shrink-0"}
                            color={colors.green[500]}
                          />
                        ) : (
                          <PrintIcon className="!h-6 !w-6 shrink-0" />
                        )}
                      </button>
                      <button
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "delete" })
                        }
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this student?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeBillingSearchAdmission}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
      <SearchInvoiceModal
        updateHandler={updateHandler}
        selectedData={selectedData}
      />
      <SearchInvoiceViewModal selectedData={selectedData} />
      <InvoicePdf ref={ref} selectedData={selectedData} />
    </div>
  );
}

export default BillingHistoryTable;
