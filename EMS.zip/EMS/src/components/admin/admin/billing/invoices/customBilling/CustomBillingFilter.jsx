import Input from "@/components/shared/Input";
import { Button } from "@/components/ui/button";
import { useCustomerBillingFilter } from "@/hooks";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";

const CustomBillingFilter = () => {
  const { handleReset, handleInput, handleSearch, student_id } =
    useCustomerBillingFilter();

  return (
    <div className="card_common py-7 mt-4">
      <p className="card_title">Filter</p>

      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4 flex flex-row items-end gap-4">
        <Input
          label={"Student ID"}
          name={"studentId"}
          className={"w-full shadow-none !bg-white max-w-[488px]"}
          placeholder="Student Id"
          value={student_id}
          onChange={handleInput}
        />

        <div className="flex items-center justify-end gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px]"
            variant="outline"
            size="lg"
            onClick={handleReset}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            onClick={handleSearch}
            className="gap-2 min-w-[120px]"
            size="lg"
          >
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CustomBillingFilter;
