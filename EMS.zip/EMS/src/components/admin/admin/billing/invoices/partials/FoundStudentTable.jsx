import TableHelper from "@/components/responseHelper/shared/TableHelper";
import { Checkbox } from "@/components/ui/checkbox";
import { useBulkBilling } from "@/hooks";
import { cn } from "@/lib/utils";

const FoundStudentTable = ({ className }) => {
  const {
    dataLists,
    isFetching,
    isError,
    status,
    student_ids,
    handleSelectAllBulkBilling,
    handleToggleSelectStudent,
    isAllSelected,
    dataLength,
  } = useBulkBilling();
  return (
    <div className={cn("card_common py-7 mt-5 max-w-full", className)}>
      <p className="card_title">Student Found ({dataLength})</p>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <div className="max-h-[620px] overflow-auto">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                <th className="table_th">
                  <div className="w-6 h-6 flex items-center justify-center">
                    <Checkbox
                      checked={isAllSelected}
                      onCheckedChange={handleSelectAllBulkBilling}
                    />
                  </div>
                </th>
                <th className="table_th">ID</th>
                <th className="table_th">Student Name</th>
                <th className="table_th">Mobile No.</th>
              </tr>
            </thead>
            <tbody>
              <TableHelper
                isLoading={isFetching}
                isError={isError}
                status={status}
                dataLength={dataLists?.length}
                column={4}
              >
                {dataLists?.map((item, index) => (
                  <tr
                    className={cn(
                      "table_row",
                      student_ids?.includes(item?._id) ? "bg-natural-100" : ""
                    )}
                    key={index}
                  >
                    <td className="table_td">
                      <div className="w-6 h-6 flex items-center justify-center">
                        <Checkbox
                          checked={student_ids?.includes(item?._id)}
                          onCheckedChange={() =>
                            handleToggleSelectStudent(item)
                          }
                        />
                      </div>
                    </td>
                    <td className="table_td">{item?.username || "N/A"}</td>
                    <td className="table_td">{item?.name_english || "N/A"}</td>
                    <td className="table_td">{item?.mobile_number || "N/A"}</td>
                  </tr>
                ))}
              </TableHelper>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FoundStudentTable;
