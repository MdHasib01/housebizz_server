import FormSelect from "@/components/shared/form/FormSelect";
import { Button } from "@/components/ui/button";
import { DateRangeIcon, RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import { monthOptions } from "@/services/helpers";
import { useState } from "react";

const IndividualBillingFilter = () => {
  const [listFilter, setListFilter] = useState({
    id: null,
    year: null,
    type: "",
    month: "",
  });

  const handleReset = () => {
    setListFilter({
      id: null,
      year: null,
      type: "",
      month: "",
    });
  };

  const handleValueChange = (field, value) => {
    setListFilter((prevState) => ({
      ...prevState,
      [field]: value,
    }));
  };

  return (
    <div className="card_common py-7 mt-4">
      <p className="card_title">Filter</p>
      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4">
        <div className="grid grid-cols-4 gap-x-4 gap-y-6">
          <FormSelect
            label="Select Id"
            placeholder="Select"
            value={listFilter.id}
            setValue={(value) => handleValueChange("id", value)}
            options={[
              {
                label: 1,
                value: 1,
              },
            ]}
          />
          <FormSelect
            label="Select Year"
            placeholder="Select"
            value={listFilter.year}
            setValue={(value) => handleValueChange("year", value)}
            options={[
              {
                label: 2022,
                value: 2022,
              },
            ]}
          />
          <FormSelect
            label="Select Type"
            placeholder="Select"
            value={listFilter.type}
            setValue={(value) => handleValueChange("type", value)}
            options={[
              {
                label: "2024 Six Civil",
                value: "2024 Six Civil",
              },
            ]}
          />

          <FormSelect
            label="Billing Month"
            placeholder="Select"
            value={listFilter.month}
            setValue={(value) => handleValueChange("month", value)}
            options={monthOptions}
            icon={<DateRangeIcon className={"!h-5 !w-5 shrink-0"} />}
          />
        </div>

        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px]"
            variant="outline"
            size="lg"
            onClick={handleReset}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button className="gap-2 min-w-[120px]" size="lg">
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default IndividualBillingFilter;
