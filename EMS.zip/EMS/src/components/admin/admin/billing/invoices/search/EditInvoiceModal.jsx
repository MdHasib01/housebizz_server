import CustomSpinner from "@/components/shared/CustomSpinner";
import FormInput from "@/components/shared/form/FormInput";
import NoData from "@/components/shared/NoData";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import { useState } from "react";
import DataTable from "react-data-table-component";

const EditInvoiceModal = ({ isDialogOpen, setIsDialogOpen }) => {
  const [headData, setHeadData] = useState([
    {
      title: "Tuition Fee",
      amount: 0,
    },
    {
      title: "Examination Fee",
      amount: 0,
    },
  ]);

  const inputChangeHandler = (e, index) => {
    const newData = [...headData];
    newData[index].amount = e.target.value;
    setHeadData(newData);
  };

  const columns = [
    {
      name: "Billing Title",
      selector: (row) => row.title,
      sortable: false,
    },
    {
      name: "Billing Amount",
      cell: (row, amountRowIndex) => (
        <div className="w-full">
          <FormInput
            type="number"
            placeholder={"Type here"}
            value={headData[amountRowIndex].amount}
            onChange={(e) => inputChangeHandler(e, amountRowIndex)}
          />
        </div>
      ),
      sortable: false,
      width: "280px",
    },
    {
      name: "Action",
      cell: (row) => (
        <Button
          size="sm"
          className="bg-status-error hover:bg-status-error/70 min-w-20 h-[34px]"
          onClick={() => updateDataHandler(actionIndex)}
        >
          Remove
        </Button>
      ),
      sortable: false,
      width: "260px",
    },
  ];

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogContent
        closeButton={true}
        closeIconClassName="!h-6 !w-6"
        className="font-inter !rounded-2xl min-w-[1080px] py-11 px-10"
      >
        <DialogTitle className="hidden" />
        <DialogDescription className="hidden" />
        <div className="flex flex-col justify-between w-full">
          <p className="card_title mb-4">Edit Invoice (INV.235.2410.935.6)</p>

          <div className="grid grid-cols-3 gap-4">
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Invoice ID :{" "}
              <span className="font-semibold !leading-[1.2]">
                INV.235.2410.935.6
              </span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Institute ID :{" "}
              <span className="font-semibold !leading-[1.2]">235</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Class : <span className="font-semibold !leading-[1.2]">Six</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Student ID :{" "}
              <span className="font-semibold !leading-[1.2]">24323</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Session/Year :{" "}
              <span className="font-semibold !leading-[1.2]">2024</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Due date :{" "}
              <span className="font-semibold !leading-[1.2]">2024-11-30</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Total Amount :{" "}
              <span className="font-semibold !leading-[1.2]">250</span>{" "}
            </p>
          </div>

          <div className="flex flex-col w-full gap-4 mt-6">
            <p className="card_title">Total Head 2</p>

            <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
              <DataTable
                columns={columns}
                data={headData}
                persistTableHead={true}
                progressComponent={CustomSpinner}
                noDataComponent={
                  <NoData
                    title="No billing data available!"
                    text={"Select a billing to add to list!"}
                  />
                }
              />
            </div>
          </div>

          <div className="flex items-center justify-end mt-6 gap-4">
            <Button
              className="gap-1 border-main-500 text-main-500 min-w-[108px] h-12"
              variant="outline"
              size="lg"
              onClick={() => setIsDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button className="gap-2 min-w-[120px] h-12" size="lg">
              Update
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditInvoiceModal;
