import CustomBillingHelper from "@/components/responseHelper/admin/admin/billing/CustomBillingHelper";
import Input from "@/components/shared/Input";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useCustomBilling } from "@/hooks";
import { cn } from "@/lib/utils";

const StudentInfoTable = () => {
  const {
    isFetching,
    isError,
    error,
    student,
    charges_summary,
    handleSummeryAmountChange,
    handleSubmit,
    isLoading,
    showStudent,
  } = useCustomBilling();

  return (
    <CustomBillingHelper
      showContent={showStudent}
      isLoading={isFetching}
      isError={isError}
      errorMessage={error?.message}
    >
      <div className={cn("card_common py-7 mt-5 max-w-full")}>
        <p className="card_title">Student Information</p>

        <div className="border border-main-500 bg-main-50 mt-4 py-[28px] px-6 grid grid-cols-2 gap-x-12 gap-y-3 rounded-2xl">
          <p className="text-sm font-normal !leading-[1.4] text-text-700">
            Student Name :{" "}
            <span className="font-semibold !leading-[1.2]">
              {student?.name_english}
            </span>
          </p>
          <p className="text-sm font-normal !leading-[1.4] text-text-700">
            Roll :{" "}
            <span className="font-semibold !leading-[1.2]">
              {" "}
              {student?.current_roll_number}
            </span>
          </p>
          <p className="text-sm font-normal !leading-[1.4] text-text-700">
            Class :{" "}
            <span className="font-semibold !leading-[1.2]">
              {student?.class_name}
            </span>
          </p>
          <p className="text-sm font-normal !leading-[1.4] text-text-700">
            Section :{" "}
            <span className="font-semibold !leading-[1.2]">
              {student?.section_name}
            </span>
          </p>
        </div>

        <div className="mt-8 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
          <div className="flex justify-end mt-4">
            <table className="table">
              <thead className="table_head sticky top-0">
                <tr className="table_row bg-natural-170">
                  <th className="table_th">SL No.</th>
                  <th className="table_th">Head Title</th>
                  <th className="table_th w-96">Amount</th>
                </tr>
              </thead>
              <tbody>
                {charges_summary?.map((item, index) => (
                  <tr className="table_row" key={index}>
                    <td className="table_td">{index + 1}</td>
                    <td className="table_td">{item?.billing_head_title}</td>
                    <td className="table_td">
                      <Input
                        className="h-10"
                        placeholder="Type here"
                        value={item?.amount}
                        onChange={(event) =>
                          handleSummeryAmountChange(event, index)
                        }
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="w-full border-t border-natural-300 h-0 my-4" />
          <p className="text-sm font-semibold !leading-[1.2] text-text-700 flex items-center justify-between w-full">
            <span className="block w-[208px] text-center">Total Amount</span>
            <span className="block w-[208px] text-center">
              {student?.total_amount}
            </span>
          </p>

          <div className="flex justify-end mt-8">
            <Button
              className="h-12 min-w-[200px]"
              disabled={student?.total_amount === 0}
              onClick={handleSubmit}
            >
              Create Invoice
            </Button>
          </div>
        </div>
      </div>
      {isLoading && <RequestLoading />}
    </CustomBillingHelper>
  );
};

export default StudentInfoTable;
