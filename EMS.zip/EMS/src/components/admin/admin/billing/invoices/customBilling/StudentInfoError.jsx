import NoData from "@/components/shared/NoData";
import { cn } from "@/lib/utils";

const StudentInfoError = ({ message = "Student not found!" }) => {
  return (
    <div className={cn("card_common py-7 mt-5 max-w-full")}>
      <NoData title={message} />
    </div>
  );
};

export default StudentInfoError;
