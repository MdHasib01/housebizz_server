import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import MonthPicker from "@/components/shared/MonthPicker";
import { Button } from "@/components/ui/button";
import { useBulkBillingFilter } from "@/hooks/admin/billing/useBulkBilling";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import SelectCategory from "../../../institute/category/SelectCategory";
import SelectLocalClass from "../../../institute/class/SelectLocalClass";
import SelectBillingType from "../../billingTypes/SelectBillingType";

const BulkBillingFilter = () => {
  const {
    selectors,
    classCode,
    handleUpdateSelectors,
    handleReset,
    handleFilter,
  } = useBulkBillingFilter();

  return (
    <div className="card_common py-7 mt-4">
      <p className="card_title">Filter</p>
      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4">
        <div className="grid grid-cols-3 gap-x-4 gap-y-6">
          <SelectLocalSessionYear
            value={selectors?.academic_year}
            onValueChange={(value) =>
              handleUpdateSelectors({ academic_year: value, billing_type: {} })
            }
            label="Select Year"
            triggerClass="!bg-white"
          />
          <SelectLocalClass
            value={selectors?.current_class}
            onValueChange={(value) =>
              handleUpdateSelectors({
                current_class: value,
                current_group: "",
                current_section: "",
                billing_type: {},
              })
            }
            visibleItem={true}
            label="Select Class"
            triggerClass="!bg-white"
          />
          {classCode > 8 && (
            <SelectLocalGroup
              value={selectors?.current_group}
              onValueChange={(value) =>
                handleUpdateSelectors({
                  current_group: value,
                  billing_type: {},
                })
              }
              classCode={classCode}
              label="Select Group"
              triggerClass="!bg-white"
            />
          )}

          <SelectCategory
            value={selectors?.current_category}
            onValueChange={(value) =>
              handleUpdateSelectors({
                current_category: value,
                billing_type: {},
              })
            }
            label="Select Category"
            triggerClass="!bg-white"
          />
          <SelectBillingType
            triggerClass="!bg-white"
            label="Billing Type"
            isSelectAll={true}
            value={selectors?.billing_type?._id || ""}
            onValueChange={(value) =>
              handleUpdateSelectors({ billing_type: value })
            }
            academic_year={selectors?.academic_year}
            classCode={classCode}
            category_id={selectors?.current_category}
            group_id={selectors?.current_group}
          />
          <MonthPicker
            value={selectors?.month}
            onValueChange={(value) => handleUpdateSelectors({ month: value })}
            triggerClass="!bg-white"
            label="Billing Month"
          />
        </div>

        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px]"
            variant="outline"
            size="lg"
            onClick={handleReset}
            type="button"
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            type="button"
            onClick={handleFilter}
            className="gap-2 min-w-[120px]"
            size="lg"
          >
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default BulkBillingFilter;
