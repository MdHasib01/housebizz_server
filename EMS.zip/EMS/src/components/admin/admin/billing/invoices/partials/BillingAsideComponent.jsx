import RequestLoading from "@/components/shared/RequestLoading";
import TWDatePicker from "@/components/shared/TWDatePicker";
import { Button } from "@/components/ui/button";
import { useAddBulkBilling } from "@/hooks";
import { cn } from "@/lib/utils";

const BillingAsideComponent = ({ className }) => {
  const {
    onSubmit,
    isLoading,
    totalAmount,
    handleDate,
    isSubmitable,
    selectors,
    heads,
  } = useAddBulkBilling();

  return (
    <div className={cn("card_common py-7 mt-5 max-w-full h-fit", className)}>
      <p className="card_title mb-4">Billing</p>

      <TWDatePicker
        label="Due Date"
        value={selectors?.due_date}
        setValue={handleDate}
        containerClasses={"mt-4"}
      />

      <p className="text-text-700 text-sm font-semibold !leading-[1.2] flex items-center justify-between mt-6">
        <span>Billing Title</span>
        <span>Billing Amount</span>
      </p>

      <div
        className={cn(
          "border-t border-natural-300 h-0 w-full my-4",
          heads?.length === 0 ? "hidden" : ""
        )}
      />

      {heads?.map((item, index) => (
        <div
          className="text-text-700 text-sm font-normal !leading-[1.2] flex items-center justify-between py-1"
          key={index}
        >
          <span>{item?.title}</span>
          <span>{item?.amount}</span>
        </div>
      ))}

      <div className="border-t border-natural-300 h-0 w-full my-4" />

      <p className="text-text-700 text-sm font-normal !leading-[1.2] flex items-center justify-between">
        <span>Total</span>
        <span>{totalAmount}</span>
      </p>

      <Button
        disabled={!isSubmitable || totalAmount === 0}
        className="w-full mt-8 h-12"
        onClick={onSubmit}
      >
        Send Invoice
      </Button>
      {isLoading && <RequestLoading />}
    </div>
  );
};

export default BillingAsideComponent;
