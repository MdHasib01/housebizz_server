import CashPayHelper from "@/components/responseHelper/admin/admin/billing/CashPayHelper";
import { useCashPay } from "@/hooks";
import { cn } from "@/lib/utils";
import StudentStats from "../StudentStats";
import PaidTable from "./PaidTable";
import PendingTable from "./PendingTable";

const BillingTypesTable = () => {
  const {
    isFetching,
    isError,
    error,
    student,
    showStudent,
    activeTab,
    setActiveTab,
    pendingPageData,
    paidPageData,
  } = useCashPay();

  return (
    <CashPayHelper
      showContent={showStudent}
      isLoading={isFetching}
      isError={isError}
      errorMessage={error?.message}
    >
      <StudentStats student={student} />
      <div className={cn("card_common py-7 max-w-full")}>
        <p className="card_title">Billing Types</p>
        <div className="flex flex-row items-center gap-6 mt-3">
          <p
            className={cn(
              "text-sm !leading-[1.2] cursor-pointer",
              activeTab === 0
                ? "text-main-500 font-semibold"
                : "text-text-600 font-normal"
            )}
            onClick={() => setActiveTab(0)}
          >
            {`Pending (${pendingPageData?.totalItems || 0})`}
          </p>
          <p
            className={cn(
              "text-sm !leading-[1.2] cursor-pointer",
              activeTab === 1
                ? "text-main-500 font-semibold"
                : "text-text-600 font-normal"
            )}
            onClick={() => setActiveTab(1)}
          >
            {`Paid Bills (${paidPageData?.totalItems || 0})`}
          </p>
          {/* <p
            className={cn(
              "text-sm !leading-[1.2] cursor-pointer",
              activeTab === 2
                ? "text-main-500 font-semibold"
                : "text-text-600 font-normal"
            )}
            onClick={() => setActiveTab(2)}
          >
            {`Trx Bills (21)`}
          </p> */}
        </div>
        {activeTab === 0 && <PendingTable />}
        {activeTab === 1 && <PaidTable />}
      </div>
    </CashPayHelper>
  );
};

export default BillingTypesTable;
