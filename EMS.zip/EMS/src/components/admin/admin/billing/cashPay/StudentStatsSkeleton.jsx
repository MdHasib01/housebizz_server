import TableHelper from "@/components/responseHelper/shared/TableHelper";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";

const StudentStatsSkeleton = () => {
  return (
    <>
      <div className="card_common py-7 max-w-full">
        <p className="card_title">Student Details. Student ID: 24318</p>

        <div className="mt-4 grid grid-cols-3 gap-x-12 gap-y-3">
          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Name :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>
          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Contact No :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>
          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Phone No :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>
          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Address :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>
        </div>

        <div className="w-full border-t border-natural-300 h-0 my-4" />

        <div className="mt-4 grid grid-cols-3 gap-x-12 gap-y-3">
          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Class :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>
          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Section :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>

          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Roll No :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>
          <div className="text-sm font-normal !leading-[1.4] text-text-700 flex gap-2">
            <span className="whitespace-nowrap">Year :</span>{" "}
            <div className="w-full h-5 pulse rounded"></div>
          </div>
        </div>
      </div>
      <div className={cn("card_common py-7 max-w-full")}>
        <p className="card_title">Billing Types</p>
        <div className="flex flex-row items-center gap-6 mt-3">
          <p
            className={cn(
              "text-sm !leading-[1.2] cursor-pointer text-main-500 font-semibold"
            )}
          >
            {`Pending (0)`}
          </p>
          <p
            className={cn(
              "text-sm !leading-[1.2] cursor-pointer text-text-600 font-normal"
            )}
          >
            {`Paid Bills (0)`}
          </p>
          {/* <p
            className={cn(
              "text-sm !leading-[1.2] cursor-pointer text-text-600 font-normal"
            )}
          >
            {`Trx Bills (0)`}
          </p> */}
        </div>
        <div className="mt-4 w-full overflow-x-scroll overflow-y-hidden min-h-5">
          <table className="table">
            <thead className="table_head sticky top-0">
              <tr className="table_row bg-natural-170">
                <th className="table_th min-w-28 w-96">
                  <Checkbox disabled />
                </th>
                <th className="table_th min-w-28 w-96">Invoice ID</th>
                <th className="table_th min-w-28 w-96">Billing Month</th>
                <th className="table_th min-w-28 w-96">Invoice Status</th>
                <th className="table_th min-w-28 w-96">Session</th>
                <th className="table_th min-w-28 w-96">Class</th>
                <th className="table_th min-w-28 w-96">Section</th>
                <th className="table_th min-w-28 w-96">Amount</th>
                <th className="table_th min-w-28 w-96">Action</th>
              </tr>
            </thead>
            <tbody>
              <TableHelper column={9} isLoading={true} />
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default StudentStatsSkeleton;
