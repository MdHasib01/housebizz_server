import TableHelper from "@/components/responseHelper/shared/TableHelper";
import Pagination from "@/components/shared/Pagination";
import { formatToDateString, formatYearMonth } from "@/services";
import { setPaidCashPayPageData } from "@/store/modules/admin/billing/cashPay/slice";
import { useSelector } from "react-redux";

function PaidTable({}) {
  const { paidLists: dataLists, paidPageData } = useSelector(
    (state) => state.adminCashPay
  );
  const { currentPage, pageSize, totalPages } = paidPageData || {};
  const updatePage = (value) => {
    dispatch(setPaidCashPayPageData(value));
  };

  return (
    <div>
      <div className="mt-4 w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th min-w-28 w-96">Trx ID</th>
              <th className="table_th min-w-28 w-96">Invoice ID</th>
              <th className="table_th min-w-28 w-96">Billing Month</th>
              <th className="table_th min-w-28 w-96">Invoice Status</th>
              <th className="table_th min-w-28 w-96">Session</th>
              <th className="table_th min-w-28 w-96">Class</th>
              <th className="table_th min-w-28 w-96">Section</th>
              <th className="table_th min-w-28 w-96">Amount</th>
              <th className="table_th min-w-[260px] w-96">Payment Date</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper dataLength={dataLists?.length} column={9}>
              {dataLists?.map((item, index) => (
                <tr className="table_row" key={index}>
                  <td className="table_td">{item?.trxid || "N/A"}</td>
                  <td className="table_td">{item?.invoice_number}</td>
                  <td className="table_td">
                    {formatYearMonth(item?.billing_month)}
                  </td>
                  <td className="table_td">{item?.status}</td>
                  <td className="table_td">{item?.academic_year}</td>
                  <td className="table_td">
                    {item?.student_id?.current_class?.local_class_name}
                  </td>
                  <td className="table_td">
                    {item?.student_id?.current_section?.section_name}
                  </td>
                  <td className="table_td">
                    {item?.total_amount?.toLocaleString() || 0}
                  </td>
                  <td className="table_td">
                    {formatToDateString(item?.pay_time)}
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
}

export default PaidTable;
