import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { usePendingCashPay } from "@/hooks";
import { formatYearMonth, images } from "@/services";
import {
  DeleteIcon,
  EditIcon,
  EyeIcon,
  PrintIcon,
  SpinnerAnimatedIcon,
} from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import InvoicePdf from "../../invoices/search/InvoicePdf";
import CashPayModal from "../CashPayModal";
import CashPayViewModal from "../CashPayViewModal";

function PendingTable() {
  const {
    dataLists,
    selectedData,
    updateHandler,
    isLoading,
    isPdfLoading,
    handleSelectData,
    updatePage,
    closeModal,
    removeCashPay,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    invoice_ids,
    handleSelectAllCashPay,
    handleToggleSelectInvoice,
    handleSubmit,
    isAllSelected,
    ref,
  } = usePendingCashPay();

  return (
    <div>
      <div className="mt-4 w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th min-w-28 w-96">
                <Checkbox
                  checked={isAllSelected}
                  onCheckedChange={handleSelectAllCashPay}
                />
              </th>
              <th className="table_th min-w-28 w-96">Invoice ID</th>
              <th className="table_th min-w-28 w-96">Billing Month</th>
              <th className="table_th min-w-28 w-96">Invoice Status</th>
              <th className="table_th min-w-28 w-96">Session</th>
              <th className="table_th min-w-28 w-96">Class</th>
              <th className="table_th min-w-28 w-96">Section</th>
              <th className="table_th min-w-28 w-96">Amount</th>
              <th className="table_th min-w-[260px] w-96">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper dataLength={dataLists?.length} column={9}>
              {dataLists?.map((item, index) => (
                <tr className="table_row" key={index}>
                  <td className="table_td">
                    <Checkbox
                      checked={invoice_ids?.includes(item?._id)}
                      onCheckedChange={() =>
                        handleToggleSelectInvoice(item?._id)
                      }
                    />
                  </td>
                  <td className="table_td">{item?.invoice_number}</td>
                  <td className="table_td">
                    {formatYearMonth(item?.billing_month)}
                  </td>
                  <td className="table_td">{item?.status}</td>
                  <td className="table_td">{item?.academic_year}</td>
                  <td className="table_td">
                    {item?.student_id?.current_class?.local_class_name}
                  </td>
                  <td className="table_td">
                    {item?.student_id?.current_section?.section_name}
                  </td>
                  <td className="table_td">
                    {item?.total_amount?.toLocaleString() || 0}
                  </td>
                  <td className="table_td ">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "view" })
                        }
                      >
                        <EyeIcon
                          className="!h-6 !w-6 shrink-0"
                          color={colors.green[500]}
                        />
                      </button>
                      <button
                        type="button"
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "update" })
                        }
                      >
                        <EditIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                      <button
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "print" })
                        }
                        disabled={isPdfLoading}
                      >
                        {isPdfLoading && selectedData?._id === item?._id ? (
                          <SpinnerAnimatedIcon
                            strokeWidth={6}
                            className={"!h-5 !w-5 shrink-0"}
                            color={colors.green[500]}
                          />
                        ) : (
                          <PrintIcon className="!h-6 !w-6 shrink-0" />
                        )}
                      </button>
                      <button
                        className="border-none outline-none"
                        onClick={() =>
                          handleSelectData({ ...item, type: "delete" })
                        }
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />

      <div className="flex justify-end mt-6">
        <Button
          className="h-12 min-w-[110px]"
          disabled={invoice_ids?.length === 0}
          onClick={handleSubmit}
        >
          Confirm
        </Button>
      </div>
      <InvoicePdf ref={ref} selectedData={selectedData} />
      <CashPayModal updateHandler={updateHandler} />
      <CashPayViewModal />
      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={closeModal}
        imageSrc={
          selectedData?.type == "delete"
            ? images.questionMarkRed
            : images.checkGreen
        }
        title={selectedData?.type ? "Are you sure?" : "Successful!"}
        text={
          selectedData?.type == "delete"
            ? "You want to delete this student?"
            : "The information has been updated successfully."
        }
        customDialogButtons={
          selectedData?.type == "delete" ? null : (
            <Button
              className="text-white h-12 w-full"
              size="lg"
              onClick={() => {
                setOpenModal(false);
              }}
            >
              Close
            </Button>
          )
        }
        onCancelPress={closeModal}
        onconfirmPress={removeCashPay}
      />
      {isLoading && <RequestLoading />}
    </div>
  );
}

export default PendingTable;
