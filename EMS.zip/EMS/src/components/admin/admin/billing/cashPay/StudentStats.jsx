const StudentStats = ({ student = {} }) => {
  return (
    <div className="card_common py-7 max-w-full">
      <p className="card_title">
        Student Details. Student ID: {student?.username}
      </p>

      <div className="mt-4 grid grid-cols-3 gap-x-12 gap-y-3">
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Name :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.name_english}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Contact No :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.mobile_number}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Phone No :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.username}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Address :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.present_address_line || "N/A"}
          </span>
        </p>
      </div>

      <div className="w-full border-t border-natural-300 h-0 my-4" />

      <div className="mt-4 grid grid-cols-3 gap-x-12 gap-y-3">
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Class :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.current_class?.local_class_name}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Section :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.current_section?.section_name}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Roll No :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.current_roll_number}
          </span>
        </p>
        <p className="text-sm font-normal !leading-[1.4] text-text-700">
          Year :{" "}
          <span className="font-semibold !leading-[1.2]">
            {student?.academic_year}
          </span>
        </p>
      </div>
    </div>
  );
};

export default StudentStats;
