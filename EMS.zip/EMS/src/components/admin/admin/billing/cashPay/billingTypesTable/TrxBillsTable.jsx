import CustomSpinner from "@/components/shared/CustomSpinner";
import NoData from "@/components/shared/NoData";
import CustomRDTPagination from "@/components/shared/table/CustomRDTPagination";
import { Button } from "@/components/ui/button";
import { PrintIcon } from "@/services/assets/svgs";
import DataTable from "react-data-table-component";

const TrxBillsTable = ({ data }) => {
  const columnsTrxBillsTable = [
    {
      name: "Invoice ID",
      selector: (row) => row.invoiceId,
      sortable: false,
    },
    {
      name: "Payment Gateway",
      selector: (row) => row.gateway,
      sortable: false,
    },
    {
      name: "Amount",
      selector: (row) => row.amount,
      sortable: false,
      right: true,
    },
    {
      name: "Payment Date",
      selector: (row) => row.paymentDate,
      sortable: false,
    },
    {
      name: "Action",
      cell: () => (
        <div className="flex flex-row items-center justify-center">
          <Button size="icon" variant="ghost">
            <PrintIcon className="!h-6 !w-6 shrink-0" />
          </Button>
        </div>
      ),
      width: "200px",
    },
  ];

  return (
    <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
      <DataTable
        pagination
        columns={columnsTrxBillsTable}
        data={data}
        persistTableHead={true}
        paginationPerPage={50}
        paginationComponent={CustomRDTPagination}
        progressComponent={CustomSpinner}
        noDataComponent={
          <NoData
            title="No billing data available!"
            text={"Select a billing to add to list!"}
          />
        }
      />
    </div>
  );
};

export default TrxBillsTable;
