import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useState } from "react";

const BillingDetailsModal = ({ isDialogOpen, setIsDialogOpen }) => {
  const [billingItems] = useState([
    { head: "Tuition Fee", amount: 200 },
    { head: "Examination Fee", amount: 100 },
  ]);

  const totalAmount = billingItems.reduce((sum, item) => sum + item.amount, 0);
  const tableText =
    "text-center text-sm font-semibold !leading-[1.2] p-6 text-text-700 border border-natural-200";

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogContent
        closeButton={true}
        closeIconClassName="!h-6 !w-6"
        className="font-inter !rounded-2xl min-w-[596px] py-11 px-10"
      >
        <DialogTitle className="hidden" />
        <DialogDescription className="hidden" />
        <div className="flex flex-col justify-between w-full">
          <p className="card_title">Billing Details</p>

          <div className="grid grid-cols-2 gap-4 mt-6">
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Name :{" "}
              <span className="font-semibold !leading-[1.2]">SAFYAT JAMIL</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Class : <span className="font-semibold !leading-[1.2]">Six</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Section :{" "}
              <span className="font-semibold !leading-[1.2]">Golap A</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Roll : <span className="font-semibold !leading-[1.2]">05</span>{" "}
            </p>
            <p className="text-sm font-normal !leading-[1.4] text-text-700">
              Status :{" "}
              <span
                className={cn(
                  "font-semibold !leading-[1.2]",
                  "pending" ? "text-status-warning" : "text-status-success"
                )}
              >
                Pending
              </span>{" "}
            </p>
          </div>

          <div className="mt-11 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
            <div className="rounded-lg border border-natural-200">
              <table className="w-full rounded-lg overflow-hidden">
                <thead className="bg-natural-170">
                  <tr>
                    <th className={cn(tableText, "border-t-0 border-l-0")}>
                      Billing Head
                    </th>
                    <th className={cn(tableText, "border-t-0 border-r-0")}>
                      Billing Amount
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {billingItems.map((item, index) => (
                    <tr key={index}>
                      <td className={cn(tableText, "font-normal border-l-0")}>
                        {item.head}
                      </td>
                      <td className={cn(tableText, "font-normal border-r-0")}>
                        {item.amount}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-main-50">
                    <td className={cn(tableText, "border-l-0")}>
                      Total Amount
                    </td>
                    <td className={cn(tableText, "border-r-0")}>
                      {totalAmount}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BillingDetailsModal;
