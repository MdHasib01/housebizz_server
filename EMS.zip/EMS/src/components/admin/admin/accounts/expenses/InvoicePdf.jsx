import { getStringDate, images } from "@/services";
import {
  LocationMarkerIcon,
  MailIcon,
  PhoneIcon,
} from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import moment from "moment";
import { forwardRef } from "react";
import { useSelector } from "react-redux";

const InvoicePdf = forwardRef(({ selectedData = {} }, ref) => {
  const { auth } = useSelector((state) => state.auth);
  const { institute } = auth || {};
  const { student_id: student } = selectedData || {};
  return (
    <div className="hidden">
      <div ref={ref} className="h-screen flex flex-col py-8 px-6 bg-white">
        <div className="flex items-start justify-between">
          <div className="flex flex-row items-center gap-[6px] justify-start">
            <img
              src={images.appLogo}
              alt="Logo"
              className="w-6 h-6 object-contain"
            />
            <span className="text-xs font-black leading-none">
              SMART PATHSHALA
            </span>
          </div>
          <div className="flex flex-col items-end gap-0.5">
            <h2 className="text-base font-semibold text-text-900 mb-1">
              {institute?.institute_name}
            </h2>
            <div className="flex items-end gap-1.5">
              <span className="text-[10px] text-text-600">
                {institute?.institute_address} -{" "}
                {institute?.institute_postal_code}
              </span>
              <LocationMarkerIcon color={colors.text[600]} />
            </div>
            <div className="flex items-end gap-1.5">
              <span className="text-[10px] text-text-600">
                {institute?.institute_mobilephone}
              </span>
              <PhoneIcon color={colors.text[600]} />
            </div>
            <div className="flex items-end gap-1.5">
              <span className="text-[10px] text-text-600">
                {institute?.institute_email}
              </span>
              <MailIcon color={colors.text[600]} />
            </div>
          </div>
        </div>
        <div className="py-5 px-4 border border-neutral-300 rounded-xl mt-6 flex-1 flex flex-col ">
          <div className="grid grid-cols-3 gap-10">
            <div className="flex flex-col gap-1">
              <span className="text-[8px] text-text-700">Billed to</span>
              <h4 className="text-xs font-semibold text-text-900">
                {student?.name_english}
              </h4>
              <div className="flex items-start gap-1.5 my-0.5">
                <span className="w-14 text-[10px] text-text-700">ID No</span>
                <span className="text-[10px] text-text-700 font-semibold">
                  {student?.username}
                </span>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="w-14 text-[10px] text-text-700">Roll</span>
                <span className="text-[10px] text-text-700 font-semibold">
                  {student?.current_roll_number}
                </span>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="w-14 text-[10px] text-text-700">Class</span>
                <span className="text-[10px] text-text-700 font-semibold">
                  {student?.current_class?.local_class_name}
                </span>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="w-14 text-[10px] text-text-700">Section</span>
                <span className="text-[10px] text-text-700 font-semibold">
                  {student?.current_section?.section_name}
                </span>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="w-14 text-[10px] text-text-700">Category</span>
                <span className="text-[10px] text-text-700 font-semibold">
                  {student?.current_category?.local_category_name}
                </span>
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <span className="text-[8px] text-text-700">Invoice Number</span>
                <h4 className="text-[10px] font-semibold text-text-900">
                  {selectedData?.invoice_number}
                </h4>
              </div>
              <div className="flex flex-col gap-1.5">
                <span className="text-[8px] text-text-700">Billing Month</span>
                <h4 className="text-[10px] font-semibold text-text-900">
                  {selectedData?.billing_month}
                </h4>
              </div>
              <div className="flex flex-col gap-1.5">
                <span className="text-[8px] text-text-700">Contact Info</span>
                <h4 className="text-[10px] font-semibold text-text-900">
                  {student?.mobile_number}
                </h4>
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <span className="text-[8px] text-text-700">Payment Date</span>
                <h4 className="text-[10px] font-semibold text-text-900">
                  {selectedData?.pay_date
                    ? getStringDate(selectedData?.pay_date)
                    : "N/A"}
                </h4>
              </div>
              <div className="flex flex-col gap-1.5">
                <span className="text-[8px] text-text-700">Status</span>
                <h4 className="text-[10px] font-semibold text-status-success">
                  {selectedData?.status}
                </h4>
              </div>
              <div className="flex flex-col gap-1.5">
                <span className="text-[8px] text-text-700">Received By</span>
                <h4 className="text-[10px] font-semibold text-text-900">
                  {selectedData?.received_by || "N/A"}
                </h4>
              </div>
            </div>
          </div>
          <div className="flex-1 mt-8">
            <table className="w-full">
              <thead className="sticky top-0">
                <tr className=" bg-natural-170">
                  <th className="text-[8px] font-normal text-text-700 p-2">
                    SL
                  </th>
                  <th className="text-[8px] font-normal text-text-700 p-2">
                    Name
                  </th>
                  <th className="text-[8px] font-normal text-text-700 text-end p-2 pr-6">
                    Amount (BDT)
                  </th>
                </tr>
              </thead>
              <tbody>
                {selectedData?.charges_summary?.map((item, index) => (
                  <tr className="border-b" key={index}>
                    <td className="text-[10px] text-center font-normal text-text-700 p-2">
                      {index + 1}
                    </td>
                    <td className="text-[10px] text-center font-normal text-text-700 p-2">
                      {item?.billing_head_id?.head_title}
                    </td>
                    <td className="text-[10px] text-end font-normal text-text-700 p-2 pr-6">
                      {item?.amount}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="">
                  <td className=""></td>
                  <td className="text-xs text-center text-text-900 font-semibold p-2">
                    Total
                  </td>
                  <td className="text-xs text-end text-text-900 font-semibold p-2 pr-6">
                    ৳{selectedData?.total_amount?.toLocaleString()}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
          <div className="flex justify-between">
            <span className="inline-block w-24 border-t border-neutral-300 pt-1 text-[10px] text-text-700 text-center">
              Received By
            </span>
            <span className="inline-block w-24 border-t border-neutral-300 pt-1 text-[10px] text-text-700 text-center">
              Deposit By
            </span>
          </div>
        </div>
        <div className="flex items-center justify-between mt-6">
          <span className="text-[10px] text-text-600">
            {moment().format("MMM DD, YYYY, h:mm A")}
          </span>
          <div className="flex flex-row items-center justify-end gap-3">
            <p className="text-[10px] font-light text-text-700">Developed by</p>
            <div className="h-3 bg-natural-500 w-[1px]" />
            <img src={images.netro} className="h-auto w-14 object-contain" />
          </div>
        </div>
      </div>
    </div>
  );
});

export default InvoicePdf;
