import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { useBillingSearchViewModal } from "@/hooks";
import { getStringDate } from "@/services";

const SearchInvoiceViewModal = () => {
  const { showModal, closeModal, selectedData } = useBillingSearchViewModal();
  return (
    <Dialog open={showModal} onOpenChange={closeModal}>
      <DialogContent
        closeButton={true}
        className="font-inter !rounded-xl w-full max-w-[1080px] py-11 px-10"
      >
        <DialogTitle className="hidden" />
        <DialogDescription className="hidden" />
        <div className="w-full">
          <h2 className="text-lg font-semibold text-text-700">
            Edit Invoice ({selectedData?.invoice_number})
          </h2>
          <div className="grid grid-cols-3 gap-3 mt-4">
            <div className="text-sm text-text-700">
              Invoice ID :{" "}
              <span className="font-semibold">
                {selectedData?.invoice_number}
              </span>
            </div>

            <div className="text-sm text-text-700">
              Institute ID :{" "}
              <span className="font-semibold">
                {selectedData?.institute_id}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Class :{" "}
              <span className="font-semibold">
                {selectedData?.student_id?.current_class?.local_class_name}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Student ID :{" "}
              <span className="font-semibold">
                {selectedData?.student_id?.username}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Session/Year :{" "}
              <span className="font-semibold">
                {selectedData?.student_id?.academic_year}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Due date :{" "}
              <span className="font-semibold">
                {getStringDate(selectedData?.due_date)}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Total Amount :{" "}
              <span className="font-semibold">
                {selectedData?.total_amount?.toLocaleString()}
              </span>
            </div>
          </div>
          <div className="max-h-[620px] overflow-auto mt-6">
            <h2 className="text-lg font-semibold text-text-700">
              Total Head 2
            </h2>
            <table className="table mt-4">
              <thead className="table_head sticky top-0">
                <tr className="table_row bg-natural-170">
                  <th className="table_th">Billing Title</th>
                  <th className="table_th w-80">Billing Amount</th>
                </tr>
              </thead>
              <tbody>
                {selectedData?.charges_summary?.map((item, index) => (
                  <tr className="table_row" key={index}>
                    <td className="table_td">
                      {item?.billing_head_id?.head_title}
                    </td>
                    <td className="table_td">
                      {item?.amount?.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SearchInvoiceViewModal;
