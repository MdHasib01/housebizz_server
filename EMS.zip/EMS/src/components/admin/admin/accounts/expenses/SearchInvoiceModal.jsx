import Input from "@/components/shared/Input";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { useBillingSearchModal } from "@/hooks";
import { getStringDate } from "@/services";

const SearchInvoiceModal = ({ updateHandler }) => {
  const {
    showModal,
    closeModal,
    selectedData,
    handleAmountChange,
    handleRemoveSummery,
    handleUpdateSummery,
  } = useBillingSearchModal(updateHandler);

  return (
    <Dialog open={showModal} onOpenChange={closeModal}>
      <DialogContent className="font-inter !rounded-xl w-full max-w-[1080px] py-11 px-10">
        <DialogTitle className="hidden" />
        <DialogDescription className="hidden" />
        <div className="w-full">
          <h2 className="text-lg font-semibold text-text-700">
            Edit Invoice ({selectedData?.invoice_number})
          </h2>
          <div className="grid grid-cols-3 gap-3 mt-4">
            <div className="text-sm text-text-700">
              Invoice ID :{" "}
              <span className="font-semibold">
                {selectedData?.invoice_number}
              </span>
            </div>

            <div className="text-sm text-text-700">
              Institute ID :{" "}
              <span className="font-semibold">
                {selectedData?.institute_id}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Class :{" "}
              <span className="font-semibold">
                {selectedData?.student_id?.current_class?.local_class_name}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Student ID :{" "}
              <span className="font-semibold">
                {selectedData?.student_id?.username}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Session/Year :{" "}
              <span className="font-semibold">
                {selectedData?.academic_year}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Due date :{" "}
              <span className="font-semibold">
                {getStringDate(selectedData?.due_date)}
              </span>
            </div>
            <div className="text-sm text-text-700">
              Total Amount :{" "}
              <span className="font-semibold">
                {selectedData?.total_amount?.toLocaleString()}
              </span>
            </div>
          </div>
          <div className="max-h-[620px] overflow-auto mt-6">
            <h2 className="text-lg font-semibold text-text-700">
              Total Head 2
            </h2>
            <table className="table mt-4">
              <thead className="table_head sticky top-0">
                <tr className="table_row bg-natural-170">
                  <th className="table_th">Billing Title</th>
                  <th className="table_th w-80">Billing Amount</th>
                  <th className="table_th">Action</th>
                </tr>
              </thead>
              <tbody>
                {selectedData?.charges_summary?.map((item, index) => (
                  <tr className="table_row" key={index}>
                    <td className="table_td">
                      {item?.billing_head_id?.head_title}
                    </td>
                    <td className="table_td">
                      <Input
                        name="head_id"
                        type="text"
                        placeholder="Type here"
                        className="h-10  !outline-none !ring-0"
                        onChange={(e) => handleAmountChange(e, index)}
                        value={item?.amount}
                      />
                    </td>
                    <td className="table_td  w-80">
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleRemoveSummery(index)}
                        >
                          Remove
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="w-full flex gap-4 items-center justify-end mt-8">
            <button
              type="button"
              className="btn_blue justify-center min-w-32 h-12 !bg-transparent !text-main-500"
              onClick={closeModal}
            >
              Cancel
            </button>
            <Button
              type="button"
              onClick={handleUpdateSummery}
              className="h-12 min-w-[132px]"
              size="lg"
            >
              Update
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SearchInvoiceModal;
