import Input from "@/components/shared/Input";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useBillingSearchModal } from "@/hooks";
import { useExpense } from "@/hooks/admin/accounts/useExpense";
import { getStringDate } from "@/services";

const AddExpensesModal = ({ updateHandler }) => {
  const {
    addExpenseModal,
    closeAddExpenseModal,
    getType,
    selectedData,
    updateValue,
  } = useExpense();
  const {
    closeModal,
    handleAmountChange,
    handleRemoveSummery,
    handleUpdateSummery,
  } = useBillingSearchModal(updateHandler);

  return (
    <Dialog open={addExpenseModal} onOpenChange={closeAddExpenseModal}>
      <DialogContent className="font-inter !rounded-xl w-full max-w-[600px] py-11 px-10">
        <DialogTitle className="hidden" />
        <DialogDescription className="hidden" />
        <div className="w-full">
          <h2 className="text-lg font-semibold text-text-700">New Expense</h2>
          <div className="grid grid-cols-2 gap-3 mt-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm text-text-600 ">Category</label>
              <Select>
                <SelectTrigger className="border border-natural-300 p-4 rounded-lg flex items-center justify-between gap-2 focus:ring-transparent !shadow-none h-13 ">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent className="w-32 divide-y divide-natural-200">
                  <SelectItem
                    value="send_sms"
                    className="p-2 cursor-pointer text-sm text-text-600"
                  >
                    category
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm text-text-600 ">Date</label>
              <input
                className="border border-natural-300 p-3 h-13 rounded-lg"
                type="date"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm text-text-600 ">Note</label>
              <input
                className="border border-natural-300 p-3 h-13 rounded-lg"
                type="text"
                placeholder="Note"
                value={getType() === "update" ? selectedData?.item?.note : ""}
                onChange={(e) =>
                  updateValue({ ...selectedData.item, note: e.target.value })
                }
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm text-text-600 ">Amount</label>
              <input
                className="border border-natural-300 p-3 h-13 rounded-lg"
                placeholder="Amount"
                type="number"
                value={getType() === "update" ? selectedData?.item?.amount : ""}
                onChange={(e) =>
                  updateValue({ ...selectedData.item, amount: e.target.value })
                }
              />
            </div>
          </div>
          <div className="w-full flex gap-4 items-center justify-end mt-8">
            <button
              type="button"
              className="btn_blue justify-center min-w-32 h-12 !bg-transparent !text-main-500"
              onClick={closeAddExpenseModal}
            >
              Cancel
            </button>
            <Button
              type="button"
              onClick={handleUpdateSummery}
              className="h-12 min-w-[132px]"
              size="lg"
            >
              Update
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AddExpensesModal;
