import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Input from "@/components/shared/Input";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useBillingSearch } from "@/hooks";
import { cn } from "@/lib/utils";
import { getStringDate, images } from "@/services";
import {
  AddIcon,
  DeleteIcon,
  EditIcon,
  EyeIcon,
  PictureAsPdfIcon,
  PrintIcon,
  PrintIconWhite,
  SearchIcon,
  SpinnerAnimatedIcon,
} from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import InvoicePdf from "./InvoicePdf";
import SearchInvoiceModal from "./SearchInvoiceModal";
import SearchInvoiceViewModal from "./SearchInvoiceViewModal";
import TWDatePicker from "@/components/shared/TWDatePicker";
import AddExpensesModal from "./AddExpensesModal";
import { useExpense } from "@/hooks/admin/accounts/useExpense";

function ExpensesTable() {
  const {
    selectedData,
    showModal,
    handleDelete,
    showAddExpenseModal,
    dataLists,
    closeModal,
    handleAction,
  } = useExpense();
  const {
    isFetching,
    isError,
    status,
    isLoading,
    handleSelectData,
    updatePage,
    removeBillingSearchAdmission,
    currentPage,
    pageSize,
    totalPages,

    student_ids,
    handleSelectAllBillingSearch,
    handleToggleSelectStudent,
    handleSearchValue,
    searchValue,
    isAllSelected,
    dataLength,
    ref,
    isPdfLoading,
    updateHandler,
  } = useBillingSearch();

  return (
    <div className="card_common py-7 mt-6">
      <div className="flex gap-4 mb-4 justify-between">
        <div>
          <h2 className="text-lg font-semibold text-text-700">Expenses</h2>
          <p className="text-xs text-gray-500">All activity shows here</p>
        </div>

        <div className="flex gap-2">
          <Select>
            <SelectTrigger className="border border-natural-300 p-4 rounded-lg flex items-center justify-between gap-2 focus:ring-transparent !shadow-none h-13 max-w-32">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent className="w-32 divide-y divide-natural-200">
              <SelectItem
                value="send_sms"
                className="p-2 cursor-pointer text-sm text-text-600"
              >
                category
              </SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2 ">
            <TWDatePicker
              placeholder="Start date"
              inputClass="!bg-white !w-32"
              // value={selectors?.start_date}
              // setValue={(value) =>
              //   handleUpdateSelectors({
              //     start_date: value,
              //   })
              // }
            />
            <span>To</span>
            <TWDatePicker
              placeholder="End date"
              inputClass="!bg-white !w-32"
              // value={selectors?.start_date}
              // setValue={(value) =>
              //   handleUpdateSelectors({
              //     start_date: value,
              //   })
              // }
            />
          </div>
          <Button>
            <PictureAsPdfIcon className="!w-6 !h-6" />
            Export to Excel
          </Button>
          <Button variant="secondary">
            <PrintIconWhite className="!w-6 !h-6" />
            Print
          </Button>
          <Button variant="black" onClick={showAddExpenseModal}>
            <AddIcon className="!w-6 !h-6 border rounded-full " />
            Add Expenses
          </Button>
        </div>
      </div>

      <div className="max-h-[620px] overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">
                <div className="w-6 h-6 flex items-center justify-center">
                  SL
                </div>
              </th>
              <th className="table_th min-w-32">Category</th>
              <th className="table_th min-w-32">Note</th>
              <th className="table_th min-w-32">Date</th>
              <th className="table_th min-w-32">Amount</th>
              <th className="table_th min-w-[110px]">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={15}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    student_ids?.includes(item?._id) ? "bg-natural-100" : ""
                  )}
                  key={index}
                >
                  <td className="table_td">{item ? index + 1 : "N/A"}</td>
                  <td className="table_td">{item?.category || "N/A"}</td>
                  <td className="table_td">{item?.note || "N/A"}</td>
                  <td className="table_td">{item?.date || "N/A"}</td>
                  <td className="table_td">{item?.amount || "N/A"}</td>

                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        className="border-none outline-none"
                        onClick={() => handleAction({ item, type: "update" })}
                      >
                        <EditIcon className="!h-6 !w-6 shrink-0" />
                      </button>

                      <button
                        className="border-none outline-none"
                        onClick={() => handleAction({ item, type: "delete" })}
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this student?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={handleDelete}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />

      <AddExpensesModal selectedData={selectedData} />

      <InvoicePdf ref={ref} selectedData={selectedData} />
    </div>
  );
}

export default ExpensesTable;
