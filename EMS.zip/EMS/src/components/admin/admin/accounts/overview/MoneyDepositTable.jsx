import TableHelper from "@/components/responseHelper/shared/TableHelper";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useBillingSearch } from "@/hooks";
import { useMoneyDeposit } from "@/hooks/admin/accounts/useDeposit";
import { cn } from "@/lib/utils";
import { PictureAsPdfIcon, PrintIconWhite } from "@/services/assets/svgs";

function MoneyDepositListTable() {
  const {
    isFetching,
    isError,
    status,
    isLoading,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    dataLists,
    selectData,
  } = useMoneyDeposit();
  console.log("selectedData", selectData);
  return (
    <div className="card_common py-7 mt-6">
      <div className="mb-4 flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-text-700">
            Money Deposited
          </h2>
          <p className="text-xs text-gray-500">All activity shows here</p>
        </div>
        <div className="flex gap-2">
          <Button>
            <PictureAsPdfIcon className="!w-6 !h-6" />
            Export to Excel
          </Button>
          <Button variant="secondary">
            <PrintIconWhite className="!w-6 !h-6" />
            Print
          </Button>
        </div>
      </div>

      <div className="max-h-[620px] overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">
                <div className="w-6 h-6 flex items-center justify-center">
                  SL
                </div>
              </th>
              <th className="table_th  min-w-40">Date</th>
              <th className="table_th">Student ID</th>
              <th className="table_th min-w-32">Roll No.</th>
              <th className="table_th min-w-32">Student Name</th>
              <th className="table_th min-w-32">Class</th>
              <th className="table_th min-w-32">Section</th>
              <th className="table_th min-w-32">Category</th>
              <th className="table_th min-w-32">B.Month</th>
              <th className="table_th min-w-32">Payment Method</th>
              <th className="table_th min-w-32">Payment ID</th>
              <th className="table_th min-w-[210px]">Amount</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={15}
            >
              {dataLists?.map((item, index) => (
                <tr className={cn("table_row", "")} key={index}>
                  <td className="table_td">
                    <div className="w-6 h-6 flex items-center justify-center">
                      {item ? index + 1 : "N/A"}
                    </div>
                  </td>
                  <td className="table_td">{item?.date || "N/A"}</td>
                  <td className="table_td">{item?.studentId || "N/A"}</td>
                  <td className="table_td">{item?.rollNo || "N/A"}</td>
                  <td className="table_td">{item?.studentName || "N/A"}</td>
                  <td className="table_td">{item?.class || "N/A"}</td>
                  <td className="table_td whitespace-nowrap">
                    {item?.section || "N/A"}
                  </td>

                  <td className="table_td whitespace-nowrap">
                    {item?.category || "N/A"}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {item?.billingMonth}
                  </td>

                  <td className="table_td">{item?.paymentMethod || "N/A"}</td>
                  <td className="table_td">{item?.paymentId || "N/A"}</td>
                  <td className="table_td">{item?.amount || "N/A"}</td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>

        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
}

export default MoneyDepositListTable;
