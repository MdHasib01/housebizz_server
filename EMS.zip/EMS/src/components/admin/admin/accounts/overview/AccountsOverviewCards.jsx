import TWDatePicker from "@/components/shared/TWDatePicker";
import React from "react";

const colorAccent = [
  "bg-green-100",
  "bg-red-100",
  "bg-sky-100",
  "bg-purple-100",
  "bg-yellow-100",
  "bg-orange-100",
  "bg-pink-100",
];
const cardData = [
  {
    title: "Money Received",
    amount: "2,000",
  },
  {
    title: "Online Payment",
    amount: "4,000",
  },
  {
    title: "Cash Pay",
    amount: "3,000",
  },
  {
    title: "Expenses",
    amount: "2,000",
  },
  {
    title: "Bkash",
    amount: "5,000",
  },
  {
    title: "Rocket",
    amount: "1,000",
  },
  {
    title: "Nagad",
    amount: "9,000",
  },
];

const AccountsOverviewCards = () => {
  return (
    <div>
      <div className="rounded-xl bg-white border-neutral-200 px-6 pt-8 pb-6 mt-4">
        <div className="flex justify-between">
          <p className="card_title">Accounts</p>
          <div className="flex items-center gap-2">
            <TWDatePicker
              placeholder="Select date"
              label="Start Date"
              inputClass="!bg-white"
              // value={selectors?.start_date}
              // setValue={(value) =>
              //   handleUpdateSelectors({
              //     start_date: value,
              //   })
              // }
            />
            <span className="mt-6">To</span>
            <TWDatePicker
              placeholder="End date"
              label="End Date"
              inputClass="!bg-white"
              // value={selectors?.start_date}
              // setValue={(value) =>
              //   handleUpdateSelectors({
              //     start_date: value,
              //   })
              // }
            />
          </div>
        </div>
        <div className="grid grid-cols-4 gap-4 mt-4">
          {cardData.slice(0, 4).map((item, index) => (
            <div className={`${colorAccent[index]} rounded-xl p-6`}>
              <p className="text-sm text-gray-600">{item.title}</p>
              <p className="font-bold">৳ {item.amount}</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4 mt-4">
          {cardData.slice(4).map((item, index) => (
            <div className={`${colorAccent[index + 4]} rounded-xl p-6`}>
              <p className="text-sm text-gray-600">{item.title}</p>
              <p className="font-bold">৳ {item.amount}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AccountsOverviewCards;
