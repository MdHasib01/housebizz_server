import FormSelect from "@/components/shared/form/FormSelect";
import FormTimePicker from "@/components/shared/form/FormTimePicker";
import { Button } from "@/components/ui/button";
import { PlusRoundedIcon } from "@/services/assets/svgs";
import { dayNames } from "@/services/helpers";
import { addRoutine } from "@/store/modules/admin/attendance/classSchedule/slice";
import { Fragment, useEffect, useState } from "react";
import { useDispatch } from "react-redux";

const AddRoutineCard = ({ item }) => {
  const timeFormat = "h:mm A";
  const days = dayNames.map((day) => ({ label: day, value: day }));
  const periods = Array.from({ length: 5 }).map((_, index) => ({
    label: index + 1,
    value: index + 1,
  }));
  const subjectList = [
    ...Object.values(
      item
        .flatMap((entry) =>
          Object.values(entry).map((day) => ({
            label: day.subject,
            value: day.subject,
          }))
        )
        .reduce((acc, { label, value }) => {
          if (label) {
            acc[label] = { label, value };
          }
          return acc;
        }, {})
    ),
  ];
  const teacherList = [
    ...new Set(
      item.flatMap((routineItem) =>
        Object.values(routineItem)
          .filter((entry) => entry.teachers)
          .flatMap((entry) => ({
            label: entry.teachers,
            value: entry.teachers,
          }))
      )
    ),
  ];

  const routineObjectPrototype = {
    subject: "",
    teachers: [],
    time: {
      start: "",
      end: "",
    },
  };

  const [routine, setRoutine] = useState({
    day: "",
    period: null,
    schedule: [routineObjectPrototype],
  }); // this includes the formatted time version
  const [timePartial, setTimePartial] = useState([{ start: null, end: null }]); // this only ensures the time is kept intact without formatted version
  const [disableSubmit, setDisableSubmit] = useState(false);

  const dispatch = useDispatch();

  const handleValueChange = (field, value, index) => {
    if (field === "day" || field === "period")
      setRoutine((prevRoutine) => ({ ...prevRoutine, [field]: value }));
    else if (field === "teachers") {
      setRoutine((prevRoutine) => ({
        ...prevRoutine,
        schedule: prevRoutine.schedule.map((item, i) =>
          i === index
            ? {
                ...item,
                teachers:
                  i === index
                    ? item.teachers.includes(value)
                      ? item.teachers.map((teacher) =>
                          teacher === value ? value : teacher
                        ) // Replace if exists
                      : [...item.teachers, value] // Add if not exists
                    : item.teachers,
              }
            : item
        ),
      }));
    } else {
      setRoutine((prevRoutine) => ({
        ...prevRoutine,
        schedule: prevRoutine.schedule.map((item, i) =>
          i === index ? { ...item, [field]: value } : item
        ),
      }));
    }
  };

  const handleTimeSelect = (timeObj, field, index) => {
    setTimePartial((prevTimePartial) =>
      prevTimePartial.map((item, i) => {
        if (i === index) {
          return {
            ...item,
            [field]: timeObj,
          };
        }
        return item;
      })
    );
    const formattedTime = timeObj.format(timeFormat);
    setRoutine((prevRoutine) => ({
      ...prevRoutine,
      schedule: prevRoutine.schedule.map((item, i) =>
        i === index
          ? {
              ...item,
              time: {
                ...item.time,
                [field]: formattedTime,
              },
            }
          : item
      ),
    }));
  };

  const handleAddMore = () => {
    setRoutine((prevState) => ({
      ...prevState,
      schedule: [...prevState.schedule, routineObjectPrototype],
    }));
    setTimePartial((prevTimePartial) => [
      ...prevTimePartial,
      { start: null, end: null },
    ]);
  };

  const handleCancelRoutineCreation = () => {
    setRoutine({
      day: "",
      period: "",
      schedule: [routineObjectPrototype],
    });
    setTimePartial([{ start: null, end: null }]);
  };

  const handleAddRoutine = () => {
    dispatch(addRoutine(routine));
    handleCancelRoutineCreation();
  };

  useEffect(() => {
    if (
      routine.day &&
      routine.period &&
      routine.schedule[0].subject &&
      routine.schedule[0].teachers &&
      routine.schedule[0].time.start &&
      routine.schedule[0].time.end
    ) {
      setDisableSubmit(false);
    } else {
      setDisableSubmit(true);
    }
  }, [routine]);

  return (
    <div className="card_common py-7 flex flex-col gap-6 w-full">
      <p className="card_title">Add Routine</p>

      <div className="grid grid-cols-2 gap-6">
        <FormSelect
          label="Day"
          placeholder="Select a day"
          value={routine.day}
          setValue={(value) => handleValueChange("day", value)}
          options={days}
        />
        <FormSelect
          label="Period"
          placeholder="Select a period"
          value={routine.period}
          setValue={(value) => handleValueChange("period", value)}
          options={periods}
        />
      </div>

      {routine.schedule?.length > 0 &&
        routine.schedule.map(
          ({ day, period, subject, teachers, time }, index) => (
            <Fragment key={`routine-${index}`}>
              <div className="flex items-center gap-4">
                <p className="text-base font-semibold !leading-[1.2] text-text-700">{`Subject ${
                  index < 10 ? `0${index + 1}` : `${index + 1}`
                }`}</p>
                <div className="border-t border-natural-400 flex-grow" />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <FormSelect
                  label="Subject"
                  placeholder="Select subject"
                  value={subject}
                  setValue={(value) =>
                    handleValueChange("subject", value, index)
                  }
                  options={subjectList}
                />
                <FormSelect
                  label="Teacher"
                  placeholder="Select teacher"
                  value={teachers[index]}
                  setValue={(value) =>
                    handleValueChange("teachers", value, index)
                  }
                  options={teacherList}
                />

                <FormTimePicker
                  label="Start Time"
                  placeholder={"Enter start time"}
                  value={timePartial[index].start}
                  onChange={(timeObject) => {
                    return handleTimeSelect(timeObject, "start", index);
                  }}
                />
                <FormTimePicker
                  label="End Time"
                  placeholder={"Enter end time"}
                  value={timePartial[index].end}
                  onChange={(timeObject) =>
                    handleTimeSelect(timeObject, "end", index)
                  }
                />
              </div>

              {routine.schedule?.length - 1 === index && (
                <Button
                  variant={"ghost"}
                  className="text-base font-semibold !leading-[1.2] text-main-500 hover:text-main-500 w-fit group"
                  onClick={handleAddMore}
                >
                  <div className="transition_common group-hover:rotate-180 duration-1000 h-fit w-fit">
                    <PlusRoundedIcon className="!h-6 !w-6 shrink-0" />
                  </div>
                  <span>Add another subject</span>
                </Button>
              )}
            </Fragment>
          )
        )}
      <div className="flex flex-row justify-end gap-4">
        <Button
          variant={"outline"}
          size={"lg"}
          className="text-main-500 min-w-[110px]"
          onClick={handleCancelRoutineCreation}
        >
          Cancel
        </Button>
        <Button
          disabled={disableSubmit}
          size={"lg"}
          className="min-w-[110px]"
          onClick={handleAddRoutine}
        >
          Add
        </Button>
      </div>
    </div>
  );
};

export default AddRoutineCard;
