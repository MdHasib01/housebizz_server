import { adminRoutes } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";
import { Link } from "react-router-dom";

function ClassRoutineCard({
  data = [],
  day = {},
  period = {},
  handleRemoveRoutine = () => {},
}) {
  const dayRoutine = data.find(
    (item) =>
      item?.day_id?.day_name === day?.day_name &&
      item?.period_id?.period_name === period?.period_name
  );


  if (!dayRoutine) return <span></span>;

  return (
    <div className="flex flex-col gap-3 divide-y divide-neutral-300 whitespace-pre">
      {dayRoutine?.subjects?.map((subject, index) => (
        <div key={index} className="pt-3 first:pt-0">
          <div className="flex items-center justify-between gap-6 max-w-96">
            <span className="truncate">
              {subject?.subject_id?.global_subject_name}
            </span>
            {index == 0 && (
              <div className="flex items-center justify-between gap-1">
                <Link
                  to={`${adminRoutes.attendance.updateRoutine.routePath}/${dayRoutine?._id}`}
                  className="border-none outline-none"
                >
                  <EditIcon className="!h-6 !w-6 shrink-0" />
                </Link>
                <button
                  className="border-none outline-none"
                  onClick={() => handleRemoveRoutine(dayRoutine?._id)}
                >
                  <DeleteIcon className="!h-6 !w-6 shrink-0" />
                </button>
              </div>
            )}
          </div>
          <div className="flex flex-col gap-3 text-start divide-y divide-neutral-300 mt-6">
            <div>
              <span className="text-xs text-text-600">
                {subject?.teacher_id?.first_name}
                {subject?.teacher_id?.middle_name &&
                  " " + subject?.teacher_id?.middle_name}
                {subject?.teacher_id?.last_name &&
                  " " + subject?.teacher_id?.last_name}
              </span>
              <div className="p-1 rounded bg-main-50 text-main-500 text-xs max-w-max mt-2">
                <span>{subject?.start_time}</span> -{" "}
                <span>{subject?.end_time}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default ClassRoutineCard;
