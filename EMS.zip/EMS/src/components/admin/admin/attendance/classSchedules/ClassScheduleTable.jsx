import TableHelper from "@/components/responseHelper/shared/TableHelper";
import TableWrapperHelper from "@/components/responseHelper/shared/TableWrapperHelper";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useClassSchedule } from "@/hooks";
import { PlusIcon } from "lucide-react";
import ClassRoutineCard from "./ClassRoutineCard";

function ClassScheduleTable() {
  const {
    isFetching,
    isError,
    status,
    dataLists,
    handleNavigate,
    days,
    periods,
    isTableLoading,
    isTableError,
    tableLength,
    tableStatus,
    isLoading,
    handleRemoveRoutine,
    pdfRef,
  } = useClassSchedule();

  return (
    <div className="card_common py-7 mt-6">
      <div className="flex gap-4 items-center justify-between">
        <p className="card_title">Routine List</p>
        <Button type="button" onClick={handleNavigate}>
          <PlusIcon className="!h-5 !w-5 shrink-0" />
          <span>Add Routine</span>
        </Button>
      </div>
      <TableWrapperHelper
        isLoading={isTableLoading}
        isError={isTableError}
        dataLength={tableLength}
        status={tableStatus}
      >
        <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
          <div className="flex-1 overflow-auto px-2">
            <table className="table">
              <thead className="table_head sticky top-0">
                <tr className="table_row bg-natural-170">
                  <th className="table_th min-w-20">Period</th>
                  {days?.map((day, index) => (
                    <th className="table_th min-w-32" key={index}>
                      {day?.day_name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <TableHelper
                  isLoading={isFetching}
                  isError={isError}
                  status={status}
                  dataLength={periods?.length}
                  column={7}
                >
                  {periods?.map((period, index) => (
                    <tr className="table_row" key={index}>
                      <td className="table_border_td whitespace-nowrap">
                        <span>{period?.period_name}</span>
                      </td>
                      {days?.map((day, dayIdx) => (
                        <td className="table_border_td !align-top" key={dayIdx}>
                          <ClassRoutineCard
                            data={dataLists}
                            period={period}
                            day={day}
                            handleRemoveRoutine={handleRemoveRoutine}
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </TableHelper>
              </tbody>
            </table>
          </div>
        </div>
      </TableWrapperHelper>
      {isLoading && <RequestLoading />}
      {/* <ClassSchedulePdf ref={pdfRef} /> */}
    </div>
  );
}

export default ClassScheduleTable;
