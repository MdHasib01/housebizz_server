import GroupTitleComponent from "@/components/shared/GroupTitleComponent";
import LoadingInput from "@/components/shared/LoadingInput";
import { Button } from "@/components/ui/button";
import { adminRoutes } from "@/services";
import { Link } from "react-router-dom";

const UpdateRoutineSkeleton = () => {
  return (
    <div>
      <div className="grid grid-cols-2 gap-6 mt-6">
        <LoadingInput label="Day" />
        <LoadingInput label="Period" />
        <GroupTitleComponent title={`Subject `} className="col-span-2" />
        <LoadingInput label="Subject" />
        <LoadingInput label="Teacher" />
        <LoadingInput label="Start Time" />
        <LoadingInput label="End Time" />
      </div>
      <div className="flex items-center justify-end mt-6">
        <Link
          to={adminRoutes.attendance.classSchedule.path}
          className="btn_blue justify-center min-w-32 h-12 !bg-transparent !text-main-500"
        >
          Cancel
        </Link>
        <Button type="button" className="h-12 min-w-[132px] ml-4" size="lg">
          Update
        </Button>
      </div>
    </div>
  );
};

export default UpdateRoutineSkeleton;
