import InstitutePdfHeader from "@/components/shared/InstitutePdfHeader";
import { forwardRef } from "react";

const ClassSchedulePdf = forwardRef(({}, ref) => {
  return (
    <div>
      <div ref={ref} className="flex flex-col py-8 px-6 bg-white">
        <InstitutePdfHeader />
      </div>
    </div>
  );
});

export default ClassSchedulePdf;
