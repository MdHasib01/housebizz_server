import SelectLocalGroup from "@/components/admin/superAdmin/global/groupManagement/SelectLocalGroup";
import SelectLocalSessionYear from "@/components/admin/superAdmin/global/sessionYear/SelectLocalSessionYear";
import { Button } from "@/components/ui/button";
import { useEnrollRoutineFilter } from "@/hooks";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import SelectLocalClass from "../../institute/class/SelectLocalClass";
import SelectSection from "../../institute/section/SelectSection";

function EnrollRoutineFilter() {
  const { selectors, handleSelector, classCode, handleReset, handleShowTable } =
    useEnrollRoutineFilter();

  return (
    <div className="py-8 px-6 bg-white rounded-xl">
      <h2 className="text-lg font-semibold text-text-700">Filter</h2>
      <div className="py-8 px-6 bg-natural-150 rounded-xl mt-4">
        <div className="grid grid-cols-4 gap-4">
          <SelectLocalSessionYear
            value={selectors?.academic_year}
            onValueChange={(value) => handleSelector({ academic_year: value })}
            triggerClass="!bg-white"
            label="Select Year"
          />

          <SelectLocalClass
            value={selectors?.local_class_id}
            onValueChange={(value) =>
              handleSelector({
                local_class_id: value,
                group_id: "",
                section_id: "",
              })
            }
            visibleItem={true}
            triggerClass="!bg-white"
            label="Select Class"
          />
          {classCode > 8 && (
            <SelectLocalGroup
              value={selectors?.group_id}
              onValueChange={(value) =>
                handleSelector({ group_id: value, section_id: "" })
              }
              triggerClass="!bg-white"
              classCode={classCode}
              label="Select Group"
              componenetId="unique2"
            />
          )}
          <SelectSection
            value={selectors?.section_id}
            onValueChange={(value) => handleSelector({ section_id: value })}
            triggerClass="!bg-white"
            label="Select Section"
            isFiltered={true}
            classCode={classCode}
            group_id={selectors?.group_id}
          />
        </div>
        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px] h-12"
            variant="outline"
            size="lg"
            onClick={handleReset}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            type="button"
            className="gap-2 min-w-[120px] h-12"
            size="lg"
            onClick={handleShowTable}
          >
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
}

export default EnrollRoutineFilter;
