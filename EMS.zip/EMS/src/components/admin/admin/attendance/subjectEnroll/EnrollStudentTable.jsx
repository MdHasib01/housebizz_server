import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useEnrollStudentLists } from "@/hooks";
import { cn } from "@/lib/utils";
import { images } from "@/services";

function EnrollStudentTable() {
  const {
    dataLists,
    selectedData,
    isFetching,
    isError,
    status,
    isLoading,
    handleSelectDelete,
    updatePage,
    closeModal,
    removeStudentAdmission,
    currentPage,
    pageSize,
    totalPages,
    showModal,
    handleSelect,
  } = useEnrollStudentLists();

  return (
    <div className="card_common py-7 mt-6">
      <div className="mb-4 flex items-start justify-between">
        <h2 className="text-lg font-semibold text-text-700">Student List</h2>
      </div>

      <div className="overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th min-w-44">Name</th>
              <th className="table_th min-w-44">Roll No</th>
              <th className="table_th min-w-44">Enroll Status</th>
              <th className="table_th min-w-44">Class</th>
              <th className="table_th min-w-44">Group</th>
              <th className="table_th min-w-44">Section</th>
              {/* <th className="table_th min-w-44">Action</th> */}
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={6}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedData?._id === item?._id &&
                      selectedData?.type === "row"
                      ? "bg-natural-100"
                      : ""
                  )}
                  key={index}
                  onClick={() => handleSelect({ ...item, type: "row" })}
                >
                  <td className="table_td">{item?.name_english}</td>
                  <td className="table_td">{item?.current_roll_number}</td>
                  <td className="table_td whitespace-nowrap">{item?.status}</td>
                  <td className="table_td">
                    {item?.current_class?.local_class_name}
                  </td>
                  <td className="table_td">
                    {item?.current_group?.global_group_name || "N/A"}
                  </td>
                  <td className="table_td">
                    {item?.current_section?.section_name}
                  </td>

                  {/* <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        className="border-none outline-none"
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                    </div>
                  </td> */}
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this enroll?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeStudentAdmission}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
}

export default EnrollStudentTable;
