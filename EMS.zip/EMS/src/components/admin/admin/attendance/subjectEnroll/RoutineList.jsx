import CustomSearchBox from "@/components/shared/CustomSearchBox";
import CustomSpinner from "@/components/shared/CustomSpinner";
import NoData from "@/components/shared/NoData";
import CustomRDTPagination from "@/components/shared/table/CustomRDTPagination";
import { Button } from "@/components/ui/button";
import { adminRoutes } from "@/services";
import { DeleteIcon, EyeOpenIcon } from "@/services/assets/svgs";
import { useState } from "react";
import DataTable from "react-data-table-component";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const RoutineList = () => {
  const { filteredRoutines } = useSelector((state) => state.adminRoutineList);
  const [searchValue, setSearchValue] = useState("");

  const navigate = useNavigate();
  const columns = [
    {
      name: "Teacher ID",
      selector: (row) => row.teacherId,
      sortable: false,
      center: 1,
      width: "120px",
    },
    {
      name: "Name",
      selector: (row) => row.name,
      sortable: false,
      center: 1,
    },
    {
      name: "Period",
      selector: (row) => row.period,
      sortable: false,
      center: 1,
      width: "88px",
    },
    {
      name: "Day",
      selector: (row) => row.day,
      sortable: false,
      center: 1,
    },
    {
      name: "Class",
      selector: (row) => row.class,
      sortable: false,
      center: 1,
    },
    {
      name: "Section",
      selector: (row) => row.section,
      sortable: false,
      center: 1,
    },
    {
      name: "Subject",
      selector: (row) => row.subject,
      sortable: false,
      center: 1,
    },
    {
      name: "Actions",
      cell: (row) => {
        return (
          <div className="flex flex-row items-center justify-center">
            <Button
              size="icon"
              variant="ghost"
              onClick={() =>
                navigate(adminRoutes.attendance.enrollDetails.path, {
                  state: row,
                })
              }
            >
              <EyeOpenIcon className="!h-6 !w-6 shrink-0" />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => handleDelete(row.id)}
            >
              <DeleteIcon className="!h-6 !w-6 shrink-0" />
            </Button>
          </div>
        );
      },
      ignoreRowClick: true,
      button: 1,
      center: 1,
      width: "186px",
    },
  ];

  const handleDelete = (id) => {
    dispatch(deleteStudent(id));
  };

  return (
    <div className="card_common py-7 mt-5 max-w-full">
      <div className="flex items-center justify-between gap-4">
        <p className="card_title">Student List</p>
        <CustomSearchBox
          setSearchValue={setSearchValue}
          isRequired={false}
          className={"max-h-10 max-w-[376px] w-[376px]"}
        />
      </div>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <DataTable
          columns={columns}
          data={filteredRoutines}
          pagination
          persistTableHead={true}
          paginationPerPage={50}
          paginationComponent={CustomRDTPagination}
          progressComponent={CustomSpinner}
          noDataComponent={
            <NoData
              title="Explore Data by Year!"
              text={"Select a Year for Detailed Information!"}
            />
          }
        />
      </div>
    </div>
  );
};
export default RoutineList;
