import TableHelper from "@/components/responseHelper/shared/TableHelper";
import Pagination from "@/components/shared/Pagination";
import { useEnrollRoutineLists } from "@/hooks";
import { cn } from "@/lib/utils";
import { EyeIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";

function EnrollRoutineTable() {
  const {
    dataLists,
    isFetching,
    isError,
    status,
    handleSelectData,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    selectedData,
    handleSelect,
  } = useEnrollRoutineLists();

  return (
    <div className="card_common py-7 mt-6">
      <div className="mb-4 flex items-start justify-between">
        <h2 className="text-lg font-semibold text-text-700">Routine List</h2>
      </div>

      <div className="overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">Teacher Id</th>
              <th className="table_th min-w-44">Teacher Name</th>
              <th className="table_th min-w-44">Class</th>
              <th className="table_th min-w-44">Section</th>
              <th className="table_th min-w-44">Subject</th>
              <th className="table_th min-w-44">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={6}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedData?.subject_id?._id === item?.subject_id?._id &&
                      selectedData?.teacher_id?._id === item?.teacher_id?._id
                      ? "bg-natural-200"
                      : ""
                  )}
                  key={index}
                  onClick={() => handleSelect(item)}
                >
                  <td className="table_td">{item?.teacher_id?.username}</td>
                  <td className="table_td">
                    {item?.teacher_id?.first_name} {item?.teacher_id?.last_name}
                  </td>
                  <td className="table_td">
                    {item?.local_class_id?.local_class_name}
                  </td>
                  <td className="table_td">{item?.section_id?.section_name}</td>

                  <td className="table_td whitespace-nowrap">
                    {item?.subject_id?.global_subject_name}
                  </td>

                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        className="border-none outline-none"
                        onClick={(event) => {
                          event.stopPropagation();
                          handleSelectData(item);
                        }}
                      >
                        <EyeIcon
                          color={colors.main[500]}
                          className="!h-6 !w-6 shrink-0"
                        />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
}

export default EnrollRoutineTable;
