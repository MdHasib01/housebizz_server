import FormSelect from "@/components/shared/form/FormSelect";
import { Button } from "@/components/ui/button";
import { RestoreIcon, SearchIcon } from "@/services/assets/svgs";
import { filterRoutineList } from "@/store/modules/admin/attendance/routineList/slice";
import { useState } from "react";
import { useDispatch } from "react-redux";

const EnrollFilter = () => {
  const [listFilter, setListFilter] = useState({
    year: null,
    class: null,
    section: "",
  });

  const dispatch = useDispatch();

  const handleFilter = () => {
    dispatch(filterRoutineList(listFilter));
  };

  const handleReset = () => {
    setListFilter({ year: null, class: null, section: "" });
  };

  const handleValueChange = (field, value) => {
    setListFilter((prevState) => ({
      ...prevState,
      [field]: value,
    }));
  };

  return (
    <div className="card_common py-7 mt-4">
      <p className="card_title">Filter</p>
      <div className="rounded-xl bg-natural-150 border border-neutral-300 px-6 pt-8 pb-6 mt-4">
        <div className="grid grid-cols-3 gap-4">
          <FormSelect
            label="Select Year"
            placeholder="Select a year"
            value={listFilter.year}
            setValue={(value) => handleValueChange("year", value)}
            options={[
              {
                label: 2023,
                value: 2023,
              },
              {
                label: 2024,
                value: 2024,
              },
            ]}
          />
          <FormSelect
            label="Select Class"
            placeholder="Select a class"
            value={listFilter.class}
            setValue={(value) => handleValueChange("class", value)}
            options={[
              {
                label: "Six",
                value: "Six",
              },
              {
                label: "Seven",
                value: "Seven",
              },
            ]}
          />
          <FormSelect
            label="Select Section"
            placeholder="Select a section"
            value={listFilter.section}
            setValue={(value) => handleValueChange("section", value)}
            options={[
              {
                label: "A",
                value: "A",
              },
              {
                label: "B",
                value: "B",
              },
            ]}
          />
        </div>

        <div className="flex items-center justify-end mt-6 gap-4">
          <Button
            className="gap-1 border-natural-500 min-w-[108px]"
            variant="outline"
            size="lg"
            onClick={handleReset}
          >
            <RestoreIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-text-600">Reset</span>
          </Button>
          <Button
            className="gap-2 min-w-[120px]"
            size="lg"
            onClick={handleFilter}
          >
            <SearchIcon className={"!h-5 !w-5 shrink-0"} />
            <span className="text-white">Search</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default EnrollFilter;
