function TotalClassCountTd({
  attendance = [],
  student = {},
  status = "present",
  dayLength = 0,
}) {
  if (status !== "uncounted") {
    const filteredAttendance = attendance.filter(
      (item) => item?.student_id?._id === student?._id
    );
    const present = filteredAttendance.filter(
      (item) => item?.attendance_status === status
    );
    return <div>{present?.length || 0}</div>;
  } else {
    const present = attendance.filter(
      (item) =>
        item?.student_id?._id === student?._id &&
        (item?.attendance_status == "present" ||
          item?.attendance_status == "absent" ||
          item?.attendance_status == "leave")
    );

    return <div>{dayLength - present?.length}</div>;
  }
}

export default TotalClassCountTd;
