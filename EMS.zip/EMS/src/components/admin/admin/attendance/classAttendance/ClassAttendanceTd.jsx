import { isUnixDateMatch } from "@/services";

function ClassAttendanceTd({ attendance = [], student = {}, day = {} }) {
  const dayStudent = attendance.find(
    (item) =>
      item?.student_id?._id === student?._id &&
      isUnixDateMatch({ unix: item?.attendance_date, date: day?.date })
  );


  if (dayStudent) {
    if (dayStudent?.attendance_status === "present") {
      return <div className="text-text-700 text-sm">P</div>;
    }
    if (dayStudent?.attendance_status === "absent") {
      return <div className="text-status-error text-sm">A</div>;
    }
    if (dayStudent?.attendance_status === "leave") {
      return <div className="text-status-warning text-sm">L</div>;
    }
  } else {
    return <div>-</div>;
  }
}

export default ClassAttendanceTd;
