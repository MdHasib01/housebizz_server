import TableHelper from "@/components/responseHelper/shared/TableHelper";
import Pagination from "@/components/shared/Pagination";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useClassAttendanceLists } from "@/hooks/admin/attendance/useClassAttendance";
import { cn } from "@/lib/utils";
import ClassAttendanceTd from "./ClassAttendanceTd";
import TotalClassCountTd from "./TotalClassCountTd";

const AttendanceReportTable = ({ listFilter }) => {
  const {
    attendance,
    dataLists,
    isFetching,
    isError,
    status,
    currentPage,
    pageSize,
    totalPages,
    days,
    updatePage,
    getSingleDayAttendance,
    studentDayAttendance,
  } = useClassAttendanceLists();

  return (
    <div className="card_common py-7 mt-5 max-w-full">
      <div className="flex items-center justify-between gap-4">
        <p className="card_title">Attendance Report</p>
        <Button size="lg">Export to Pdf</Button>
      </div>

      <div className="mt-4 max-w-full overflow-x-scroll overflow-y-hidden min-h-5">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th min-w-20 whitespace-nowrap sticky left-0 bg-natural-170 border-r">
                Roll
              </th>
              <th className="table_th min-w-20 whitespace-nowrap !border-l-0">
                Student Name
              </th>
              {days?.map((day, index) => (
                <th className="table_th min-w-20" key={index}>
                  {day?.date} <br />
                  {day?.day}
                </th>
              ))}
              <th className="table_th min-w-20">T.P</th>
              <th className="table_th min-w-20">T.A</th>
              <th className="table_th min-w-20">T.L</th>
              <th className="table_th min-w-20">UC</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists.length}
              column={35}
            >
              {dataLists.map((student, index) => (
                <tr className="table_row" key={index}>
                  <td className="table_td  sticky left-0 bg-white">
                    {student?.current_roll_number}
                  </td>
                  <td className="table_td">{student?.name_english}</td>
                  {days?.map((day, index) => (
                    <td className="table_td !p-0" key={index}>
                      <Popover>
                        <PopoverTrigger
                          className="w-full p-4 hover:bg-neutral-100 cursor-pointer duration-300"
                          onClick={() => getSingleDayAttendance(student, day)}
                        >
                          <ClassAttendanceTd
                            attendance={attendance}
                            student={student}
                            day={day}
                          />
                        </PopoverTrigger>
                        <PopoverContent className="w-[460px] overflow-hidden">
                          <table className="table">
                            <thead className="table_head">
                              <tr className="table_row">
                                <th className="table_th">Teacher Name</th>
                                <th className="table_th">Subject</th>
                                <th className="table_th">Status</th>
                              </tr>
                            </thead>
                            <tbody>
                              {studentDayAttendance?.attendance?.map(
                                (item, index) => (
                                  <tr className="table_row" key={index}>
                                    <td className="table_td max-w-32 truncate">
                                      {item?.teacher_id?.first_name}{" "}
                                      {item?.teacher_id?.last_name}
                                    </td>
                                    <td className="table_td max-w-32 truncate">
                                      {item?.subject_id?.global_subject_name}
                                    </td>
                                    <td
                                      className={cn(
                                        "table_td max-w-32 truncate",
                                        item?.attendance_status === "present"
                                          ? "!text-green-500"
                                          : item?.attendance_status === "absent"
                                          ? "!text-red-500"
                                          : item?.attendance_status === "leave"
                                          ? "!text-yellow-500"
                                          : "!text-gray-500"
                                      )}
                                    >
                                      {item?.attendance_status}
                                    </td>
                                  </tr>
                                )
                              )}
                            </tbody>
                          </table>
                          <div className="flex flex-col gap-2 text-sm p-4 max-w-max ml-auto">
                            <div className="flex items-center gap-3">
                              <span className="min-w-24">Total Present</span>
                              <span>:</span>
                              <span>{studentDayAttendance?.totalPresent}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="min-w-24">Total Absent</span>
                              <span>:</span>
                              <span>{studentDayAttendance?.totalAbsent}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className="min-w-24">Total Leave</span>
                              <span>:</span>
                              <span>{studentDayAttendance?.totalLeave}</span>
                            </div>
                          </div>
                        </PopoverContent>
                      </Popover>
                    </td>
                  ))}
                  <td className="table_td">
                    <TotalClassCountTd
                      attendance={attendance}
                      status="present"
                      student={student}
                    />
                  </td>
                  <td className="table_td">
                    <TotalClassCountTd
                      attendance={attendance}
                      status="absent"
                      student={student}
                    />
                  </td>
                  <td className="table_td">
                    <TotalClassCountTd
                      attendance={attendance}
                      status="leave"
                      student={student}
                    />
                  </td>
                  <td className="table_td">
                    <TotalClassCountTd
                      attendance={attendance}
                      status="uncounted"
                      student={student}
                      dayLength={days.length}
                    />
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
};

export default AttendanceReportTable;
