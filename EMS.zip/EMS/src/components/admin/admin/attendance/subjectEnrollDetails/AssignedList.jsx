import Input from "@/components/shared/Input";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { SearchIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";

const AssignedList = ({
  className,
  search = "",
  students = [],
  selectedStudents = [],
  handleAll = () => {},
  handleSingle = () => {},
  setSearch = () => {},
}) => {
  const filterByName = (student) => {
    if (!search) return true;
    return student.name_english.toLowerCase().includes(search.toLowerCase());
  };
  const isAllSelected =
    students?.length === 0
      ? false
      : students.length === selectedStudents.length;

  return (
    <div
      className={cn(
        "border border-neutral-300 rounded-xl p-4 min-h-[592px] max-h-[592px] flex flex-col",
        className
      )}
    >
      <div className="flex items-center gap-4 justify-between">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="allRightItems"
            checked={isAllSelected}
            onCheckedChange={handleAll}
          />
          <label
            htmlFor="allRightItems"
            className="text-base font-normal !leading-normal text-text-700 cursor-pointer"
          >
            All items :{" "}
            <span className="font-semibold !leading-[1.2]">
              {students?.length}
            </span>
          </label>
        </div>
        <p className="text-base font-normal !leading-normal text-text-700">
          Selected Items :{" "}
          <span className="font-semibold !leading-[1.2]">
            {selectedStudents?.length}
          </span>
        </p>
      </div>
      <hr className="my-3 h-[1px] text-natural-300" />
      <div className="w-full max-w-72 relative">
        <Input
          className="!py-2.5 !pl-8"
          placeholder="Search here"
          value={search}
          onChange={setSearch}
        />
        <SearchIcon
          className="absolute top-1/2 left-2 -translate-y-1/2 pointer-events-none"
          color={colors.natural[700]}
        />
      </div>
      <div className="mt-4 flex-grow overflow-y-scroll flex flex-col gap-3 px-1">
        {students?.filter(filterByName)?.map((student, index) => (
          <div className="flex items-center space-x-2" key={index}>
            <Checkbox
              id={`right-${index}`}
              checked={selectedStudents?.includes(student)}
              onCheckedChange={() => handleSingle(student)}
            />
            <label
              htmlFor={`right-${index}`}
              className="text-base font-normal !leading-normal text-text-700 cursor-pointer"
            >
              {student?.current_roll_number} {student?.name_english}
            </label>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AssignedList;
