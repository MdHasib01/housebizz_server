import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import colors from "@/services/config/colors";
import { ChevronLeft, ChevronRight } from "lucide-react";

const DataSwappingBar = ({
  className,
  handleMoveRightToLeft = () => {},
  handleMoveLeftToRight = () => {},
}) => {
  return (
    <div
      className={cn(
        "min-h-full flex flex-col items-center justify-center gap-6 px-6",
        className
      )}
    >
      <Button
        variant="ghost"
        className="bg-natural-200 flex_center rounded w-10 h-10"
        onClick={handleMoveRightToLeft}
      >
        <ChevronLeft
          className="!w-5 !h-5 !shrink-0"
          color={colors.natural[600]}
          strokeWidth={2.5}
        />
      </Button>
      <Button
        variant="ghost"
        className="bg-natural-200 flex_center rounded w-10 h-10"
        onClick={handleMoveLeftToRight}

      >
        <ChevronRight
          className="!w-5 !h-5 !shrink-0"
          color={colors.natural[600]}
          strokeWidth={2.5}
        />
      </Button>
    </div>
  );
};

export default DataSwappingBar;
