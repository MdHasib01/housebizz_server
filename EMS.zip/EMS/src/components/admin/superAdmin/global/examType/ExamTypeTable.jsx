import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useExamType } from "@/hooks/superAdmin/global/useExamType";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";

function ExamTypeTable() {
  const {
    dataLists,
    selectedData,
    showModal,
    isFetching,
    isError,
    status,
    isLoading,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeExamType,
    currentPage,
    pageSize,
    totalPages,
  } = useExamType();

  return (
    <>
      <div className="flex-1 overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th text-start">Exam Name</th>
              <th className="table_th">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={2}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedData?._id === item?._id && "bg-natural-100"
                  )}
                  key={index}
                  onClick={() => {
                    if (isUpdatable(item)) return;
                    handleSelect({ ...item, type: "row" });
                  }}
                >
                  <td className="table_td !text-start">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_exam_type_name"
                        type="text"
                        placeholder="Class Code"
                        value={selectedData.global_exam_type_name}
                        onChange={handleInput}
                        className="border-main-500 placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_exam_type_name
                    )}
                  </td>
                  <td className="table_td w-[260px]">
                    {isUpdatable(item) ? (
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          size="sm"
                          className="bg-status-success hover:bg-status-success/70"
                          onClick={updateSelectedData}
                        >
                          Update
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={closeModal}
                        >
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <button
                          className="border-none outline-none"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({ ...item, type: "update" });
                          }}
                        >
                          <EditIcon className="!h-6 !w-6 shrink-0" />
                        </button>
                        <button
                          className="border-none outline-none"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({ ...item, type: "delete" });
                          }}
                        >
                          <DeleteIcon className="!h-6 !w-6 shrink-0" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this exam type?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeExamType}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </>
  );
}

export default ExamTypeTable;
