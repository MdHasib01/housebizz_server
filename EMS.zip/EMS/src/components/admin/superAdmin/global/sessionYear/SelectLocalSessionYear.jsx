import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { sortYears } from "@/services";
import { useGetAllSessionYearQuery } from "@/store/modules/superAdmin/global/sessionYear/api";
import { useSelector } from "react-redux";

const SelectLocalSessionYear = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select session year",
  triggerClass = "",
  heightClass = "",
  onSelect = () => {},
  errorMessage = "",
  isLoading = false,
  selector = "global_academic_year",
  institute_type = null,
  ...rest
}) => {
  const { allData } = useSelector((state) => state.saSessionYear);
  const { auth } = useSelector((state) => state.auth);
  const in_type = institute_type
    ? institute_type
    : auth?.institute?.institute_type;

  const { isFetching, isError, error } = useGetAllSessionYearQuery(
    {
      institute_type: in_type,
      page: 1,
      limit: 999999,
    },
    {
      skip: !in_type || isLoading,
    }
  );

  const sortedYears = sortYears(allData);

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching || isLoading}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <div className="relative w-full">
          <Select {...rest}>
            <SelectTrigger
              className={cn(
                "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
                errorMessage && "!border-red-500",
                triggerClass,
                heightClass
              )}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {sortedYears?.map((item, index) => (
                <SelectItem
                  value={item[selector]}
                  className="cursor-pointer py-2.5"
                  key={index}
                >
                  {item?.global_academic_year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectLocalSessionYear;
