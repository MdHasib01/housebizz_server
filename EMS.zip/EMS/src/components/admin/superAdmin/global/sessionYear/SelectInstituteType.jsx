import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useSelector } from "react-redux";

function SelectInstituteType({
  label = "",
  labelClass = "",
  triggerClass = "",
  wrapperClass = "",
  errorMessage = "",
  ...rest
}) {
  const { institutes } = useSelector((state) => state.saSessionYear);
  return (
    <div className={cn("flex flex-col gap-1", wrapperClass)}>
      {label && <span className={cn("label", labelClass)}>{label}</span>}

      <Select {...rest}>
        <SelectTrigger
          className={cn(
            "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
            triggerClass,
            errorMessage && "!border-red-500"
          )}
        >
          <SelectValue placeholder="Select institute type" />
        </SelectTrigger>
        <SelectContent>
          {institutes?.map((item, index) => (
            <SelectItem
              value={item}
              className="cursor-pointer py-2.5"
              key={index}
            >
              {item}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
}

export default SelectInstituteType;
