import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useGetFilteredSubjectListsQuery } from "@/store/modules/superAdmin/global/subjectManagement/api";
import { useSelector } from "react-redux";

const SelectFilteredSubject = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select a class",
  triggerClass = "",
  heightClass = "",
  onSelect = () => {},
  errorMessage = "",
  selector = "_id",
  selectors = {},
  ...rest
}) => {
  const query = Object.keys(selectors)
    .map((key) => `${key}=${selectors[key]}`)
    .join("&");

  (query);

  const { filteredSubjects: allData } = useSelector(
    (state) => state.saSubjectManagement
  );
  const { isFetching, isError, error } = useGetFilteredSubjectListsQuery(
    query,
    {
      skip: !query,
    }
  );

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <div className="relative w-full">
          <Select {...rest}>
            <SelectTrigger
              className={cn(
                "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
                errorMessage && "!border-red-500",
                triggerClass,
                heightClass
              )}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {allData?.map((item, index) => (
                <SelectItem
                  value={item[selector]}
                  className="cursor-pointer py-2.5"
                  key={index}
                >
                  {item?.global_subject_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectFilteredSubject;
