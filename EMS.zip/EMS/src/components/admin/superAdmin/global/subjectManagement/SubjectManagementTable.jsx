import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSubjectManagement } from "@/hooks/superAdmin/global/useSubjectManagement";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";
import SelectBoard from "../boardManagement/SelectBoard";
import SelectClass from "../classManagement/SelectClass";
import PopoverGroup from "../groupManagement/PopoverGroup";

function SubjectManagementTable() {
  const {
    dataLists,
    selectedData,
    showModal,
    isFetching,
    isError,
    status,
    isLoading,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeSubject,
    currentPage,
    pageSize,
    totalPages,
    handleClassSelect,
    handleBoardSelect,
    handleGroupSelect,
    goupFilterByClass,
  } = useSubjectManagement();

  return (
    <div className="bg-white px-6 py-7 rounded-xl">
      <h2 className="text-lg font-semibold text-text-600">Subject List</h2>
      <div className="max-h-[720px] overflow-auto rounded-lg mt-4">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th whitespace-nowrap min-w-56">Class</th>
              <th className="table_th whitespace-nowrap w-80">Group</th>
              <th className="table_th whitespace-nowrap min-w-56">Board</th>
              <th className="table_th whitespace-nowrap min-w-40">
                Subject Code
              </th>
              <th className="table_th whitespace-nowrap min-w-40">Order</th>

              <th className="table_th whitespace-nowrap min-w-56">
                Subject Name
              </th>
              <th className="table_th whitespace-nowrap min-w-[260px]">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              column={9}
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedData?._id == item?._id && "bg-natural-100"
                  )}
                  key={index}
                  onClick={(event) => {
                    if (isUpdatable(item)) return;
                    handleSelect({
                      ...item,
                      type: "row",
                    });
                  }}
                >
                  <td className="table_td whitespace-nowrap">
                    {isUpdatable(item) ? (
                      <SelectClass
                        name="global_class_id"
                        value={selectedData?.class_id}
                        onValueChange={handleClassSelect}
                        triggerClass="!border-main-500"
                        heightClass="h-9"
                      />
                    ) : (
                      item?.global_class_id?.global_class_name
                    )}
                  </td>
                  <td className="table_td overflow-hidden max-w-[300px] truncate">
                    {isUpdatable(item) ? (
                      <PopoverGroup
                        name="global_class_groups"
                        triggerClass="!border-main-500"
                        heightClass="h-9"
                        groups={selectedData?.groups}
                        filterBy={goupFilterByClass}
                        onSelect={handleGroupSelect}
                      />
                    ) : (
                      item?.global_group_ids
                        ?.map((group) => group?.global_group_name)
                        .join(", ")
                    )}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {isUpdatable(item) ? (
                      <SelectBoard
                        name="global_class_id"
                        value={selectedData?.board_id}
                        onValueChange={handleBoardSelect}
                        triggerClass="!border-main-500"
                        heightClass="h-9"
                      />
                    ) : (
                      item?.global_board_id?.global_board_name
                    )}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_subject_code"
                        type="text"
                        placeholder="Group Name"
                        value={selectedData.global_subject_code}
                        onChange={handleInput}
                        className="border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_subject_code
                    )}
                  </td>
                  <td className="table_td whitespace-nowrap">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_subject_order"
                        type="text"
                        placeholder="Group Name"
                        value={selectedData.global_subject_order}
                        onChange={handleInput}
                        className="border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_subject_order
                    )}
                  </td>

                  <td className="table_td whitespace-nowrap">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_subject_name"
                        type="text"
                        placeholder="Group Name"
                        value={selectedData.global_subject_name}
                        onChange={handleInput}
                        className="border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_subject_name
                    )}
                  </td>
                  <td className="table_td w-[260px]">
                    {isUpdatable(item) ? (
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          size="sm"
                          className="bg-status-success hover:bg-status-success/70"
                          onClick={updateSelectedData}
                        >
                          Update
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={closeModal}
                        >
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <button
                          className="border-none outline-none"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({
                              ...item,
                              type: "update",
                            });
                          }}
                        >
                          <EditIcon className="!h-6 !w-6 shrink-0" />
                        </button>
                        <button
                          className="border-none outline-none"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({
                              ...item,
                              type: "delete",
                            });
                          }}
                        >
                          <DeleteIcon className="!h-6 !w-6 shrink-0" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>
      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={closeModal}
        imageSrc={
          selectedData?.type == "delete"
            ? images.questionMarkRed
            : images.checkGreen
        }
        title={selectedData?.type ? "Are you sure?" : "Successful!"}
        text={
          selectedData?.type == "delete"
            ? "You want to delete this subject management?"
            : "The information has been updated successfully."
        }
        customDialogButtons={
          selectedData?.type == "delete" ? null : (
            <Button
              className="text-white h-12 w-full"
              size="lg"
              onClick={() => {
                setOpenModal(false);
              }}
            >
              Close
            </Button>
          )
        }
        onCancelPress={closeModal}
        onconfirmPress={removeSubject}
      />
      {isLoading && <RequestLoading />}
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </div>
  );
}

export default SubjectManagementTable;
