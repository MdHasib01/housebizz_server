import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useGradingManagement } from "@/hooks/superAdmin/global/useGradingManagement";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon, EditIcon } from "@/services/assets/svgs";

function GradingManagementTable() {
  const {
    dataLists,
    selectedData,
    showModal,
    isFetching,
    isError,
    status,
    isLoading,
    handleInput,
    handleSelect,
    updatePage,
    closeModal,
    isUpdatable,
    updateSelectedData,
    removeGrading,
    currentPage,
    pageSize,
    totalPages,
  } = useGradingManagement();

  return (
    <>
      <div className="flex-1 overflow-auto">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">Grade</th>
              <th className="table_th">Grade Point</th>
              <th className="table_th">Lowest Mark</th>
              <th className="table_th">Highest Mark</th>
              <th className="table_th">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={5}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedData?._id === item?._id && "bg-natural-100"
                  )}
                  key={index}
                  onClick={() => {
                    if (isUpdatable(item)) return;
                    handleSelect({ ...item, type: "row" });
                  }}
                >
                  <td className="table_td w-[360px]">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_grade_name"
                        type="text"
                        placeholder="Group Name"
                        value={selectedData.global_grade_name}
                        onChange={handleInput}
                        className="border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_grade_name
                    )}
                  </td>
                  <td className="table_td w-[360px]">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_grade_point"
                        type="text"
                        placeholder="Group Name"
                        value={selectedData.global_grade_point}
                        onChange={handleInput}
                        className="border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_grade_point?.toFixed(2)
                    )}
                  </td>
                  <td className="table_td w-[360px]">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_grade_lowest_mark"
                        type="text"
                        placeholder="Group Name"
                        value={selectedData.global_grade_lowest_mark}
                        onChange={handleInput}
                        className="border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_grade_lowest_mark
                    )}
                  </td>
                  <td className="table_td w-[360px]">
                    {isUpdatable(item) ? (
                      <Input
                        name="global_grade_highest_mark"
                        type="text"
                        placeholder="Group Name"
                        value={selectedData.global_grade_highest_mark}
                        onChange={handleInput}
                        className="border-main-500 text-center placeholder:text-text-200 !outline-none !ring-0"
                      />
                    ) : (
                      item?.global_grade_highest_mark
                    )}
                  </td>
                  <td className="table_td w-[260px]">
                    {isUpdatable(item) ? (
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          size="sm"
                          className="bg-status-success hover:bg-status-success/70"
                          onClick={updateSelectedData}
                        >
                          Update
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={closeModal}
                        >
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <button
                          className="border-none outline-none"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({ ...item, type: "update" });
                          }}
                        >
                          <EditIcon className="!h-6 !w-6 shrink-0" />
                        </button>
                        <button
                          className="border-none outline-none"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleSelect({ ...item, type: "delete" });
                          }}
                        >
                          <DeleteIcon className="!h-6 !w-6 shrink-0" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
        <DialogExtended
          isDialogOpen={showModal}
          setIsDialogOpen={closeModal}
          imageSrc={
            selectedData?.type == "delete"
              ? images.questionMarkRed
              : images.checkGreen
          }
          title={selectedData?.type ? "Are you sure?" : "Successful!"}
          text={
            selectedData?.type == "delete"
              ? "You want to delete this billing config?"
              : "The information has been updated successfully."
          }
          customDialogButtons={
            selectedData?.type == "delete" ? null : (
              <Button
                className="text-white h-12 w-full"
                size="lg"
                onClick={() => {
                  setOpenModal(false);
                }}
              >
                Close
              </Button>
            )
          }
          onCancelPress={closeModal}
          onconfirmPress={removeGrading}
        />
        {isLoading && <RequestLoading />}
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </>
  );
}

export default GradingManagementTable;
