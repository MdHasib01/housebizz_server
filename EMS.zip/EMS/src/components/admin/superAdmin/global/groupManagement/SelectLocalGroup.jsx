import SelectHelper from "@/components/responseHelper/SelectHelper";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useGetAllLocalGroupQuery } from "@/store/modules/superAdmin/global/groupManagement/api";
import { useSelector } from "react-redux";

const SelectLocalGroup = ({
  label = "",
  labelClass = "",
  wrapper = "",
  className = "",
  type = "text",
  icon = null,
  labelChildren = null,
  placeholder = "Select a group",
  triggerClass = "",
  heightClass = "",
  classCode = null,
  errorMessage = "",
  componenetId = "unique1",
  isLoading = false,
  ...rest
}) => {
  const { localGroups: allData } = useSelector(
    (state) => state.saGroupManagement
  );

  const { isFetching, isError, error } = useGetAllLocalGroupQuery(
    { classCode, componenetId },
    {
      skip: !classCode || isLoading,
      refetchOnMountOrArgChange: true,
    }
  );

  return (
    <div className={`flex flex-col gap-2 ${wrapper}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label className={`label ${labelClass}`} htmlFor="">
            {label}
          </label>
          {labelChildren}
        </div>
      )}
      <SelectHelper
        isLoading={isFetching}
        isError={isError}
        status={error?.status}
        length={allData?.length}
        heightClass={heightClass}
      >
        <div className="relative w-full">
          <Select {...rest}>
            <SelectTrigger
              className={cn(
                "w-full h-[54px] outline-none input focus:ring-transparent !shadow-none ",
                errorMessage && "!border-red-500",
                triggerClass,
                heightClass
              )}
            >
              <SelectValue placeholder={placeholder} />
            </SelectTrigger>
            <SelectContent>
              {allData?.map((item, index) => (
                <SelectItem
                  value={item?._id}
                  className="cursor-pointer py-2.5"
                  key={index}
                >
                  {item?.global_group_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </SelectHelper>
      {errorMessage && (
        <span className="text-red-500 text-sm -mt-1">{errorMessage}</span>
      )}
    </div>
  );
};

export default SelectLocalGroup;
