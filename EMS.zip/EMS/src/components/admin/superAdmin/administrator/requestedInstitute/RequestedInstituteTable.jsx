import TableHelper from "@/components/responseHelper/shared/TableHelper";
import DialogExtended from "@/components/shared/DialogExtended";
import Pagination from "@/components/shared/Pagination";
import RequestLoading from "@/components/shared/RequestLoading";
import { Button } from "@/components/ui/button";
import { useRequestedInstitute } from "@/hooks";
import { cn } from "@/lib/utils";
import { images } from "@/services";
import { DeleteIcon, EyeIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import { Check } from "lucide-react";

function RequestedInstituteTable() {
  const {
    dataLists,
    isFetching,
    isError,
    status,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    isLoading,
    showModal,
    selectedData,
    closeModal,
    handleRemove,
    handleSelectInstitute,
    updateInstituteStatus,
    navigateToDetails,
  } = useRequestedInstitute();

  return (
    <>
      <div className="flex-1 overflow-auto px-2">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">Institute ID</th>
              <th className="table_th min-w-44">Institute Name</th>
              <th className="table_th min-w-44">Type</th>
              <th className="table_th">Email</th>
              <th className="table_th min-w-44 whitespace-nowrap">Phone No.</th>
              <th className="table_th">Total Students</th>
              <th className="table_th">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={8}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedData?._id == item?._id && "bg-natural-100"
                  )}
                  key={index}
                  onClick={() =>
                    handleSelectInstitute({
                      ...item,
                      type: "row",
                    })
                  }
                >
                  <td className="table_td">{item?.institute_id}</td>
                  <td className="table_td max-w-44 truncate">
                    {item?.institute_name}
                  </td>
                  <td className="table_td max-w-44 truncate">
                    {item?.institute_type}
                  </td>
                  <td className="table_td max-w-44 truncate">
                    {item?.institute_email}
                  </td>
                  <td className="table_td">{item?.institute_telephone}</td>
                  <td className="table_td">{item?.total_students}</td>

                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        className="border-none outline-none"
                        onClick={(event) => {
                          event.stopPropagation();
                          updateInstituteStatus(item);
                        }}
                      >
                        <Check className="!h-6 !w-6 shrink-0 text-status-success" />
                      </button>
                      <button
                        className="border-none outline-none"
                        onClick={(event) => {
                          event.stopPropagation();
                          navigateToDetails(item);
                        }}
                      >
                        <EyeIcon
                          className="!h-6 !w-6 shrink-0"
                          color={colors.main[600]}
                        />
                      </button>
                      <button
                        className="border-none outline-none"
                        onClick={(event) => {
                          event.stopPropagation();
                          handleSelectInstitute({
                            ...item,
                            type: "delete",
                          });
                        }}
                      >
                        <DeleteIcon className="!h-6 !w-6 shrink-0" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>
      <DialogExtended
        isDialogOpen={showModal}
        setIsDialogOpen={closeModal}
        imageSrc={
          selectedData?.type == "delete"
            ? images.questionMarkRed
            : images.checkGreen
        }
        title={selectedData?.type ? "Are you sure?" : "Successful!"}
        text={
          selectedData?.type == "delete"
            ? "You want to delete institute?"
            : "The information has been updated successfully."
        }
        customDialogButtons={
          selectedData?.type == "delete" ? null : (
            <Button
              className="text-white h-12 w-full"
              size="lg"
              onClick={closeModal}
            >
              Close
            </Button>
          )
        }
        onCancelPress={closeModal}
        onconfirmPress={handleRemove}
      />
      {isLoading && <RequestLoading />}
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </>
  );
}

export default RequestedInstituteTable;
