import TableHelper from "@/components/responseHelper/shared/TableHelper";
import Pagination from "@/components/shared/Pagination";
import { useInstituteManagement } from "@/hooks/superAdmin/administrator/useInstituteOnboard";
import { cn } from "@/lib/utils";
import { userRoutes } from "@/services";
import { EditIcon, EyeIcon } from "@/services/assets/svgs";
import colors from "@/services/config/colors";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { Link } from "react-router-dom";

function InstituteManagementTable() {
  const {
    dataLists,
    isFetching,
    isError,
    status,
    handleSelect,
    updatePage,
    currentPage,
    pageSize,
    totalPages,
    selectedData,
  } = useInstituteManagement();

  return (
    <>
      <div className="flex-1 overflow-auto px-2">
        <table className="table">
          <thead className="table_head sticky top-0">
            <tr className="table_row bg-natural-170">
              <th className="table_th">Institute ID</th>
              <th className="table_th min-w-44">Institute Name</th>
              <th className="table_th">Email</th>
              <th className="table_th min-w-44 whitespace-nowrap">Phone No.</th>
              <th className="table_th">Total Students</th>
              <th className="table_th">Status</th>
              <th className="table_th">Admission</th>
              <th className="table_th">Action</th>
            </tr>
          </thead>
          <tbody>
            <TableHelper
              isLoading={isFetching}
              isError={isError}
              status={status}
              dataLength={dataLists?.length}
              column={8}
            >
              {dataLists?.map((item, index) => (
                <tr
                  className={cn(
                    "table_row",
                    selectedData?._id === item?._id && "bg-natural-100"
                  )}
                  key={index}
                  onClick={() => handleSelect({ ...item, type: "row" })}
                >
                  <td className="table_td">{item?.institute_id}</td>
                  <td className="table_td max-w-44 truncate">
                    {item?.institute_name}
                  </td>
                  <td className="table_td max-w-44 truncate">
                    {item?.institute_email}
                  </td>
                  <td className="table_td">{item?.institute_telephone}</td>
                  <td className="table_td">{item?.total_students}</td>
                  <td
                    className={cn(
                      "table_td ",
                      item?.status === "published"
                        ? "!text-status-success"
                        : "!text-status-error"
                    )}
                  >
                    {item?.status === "published" ? "Published" : "Unpublished"}
                  </td>
                  <td className="table_td">
                    <Link
                      to={`${userRoutes.studemtAdmission.routePath}/${item?._id}`}
                      className="text-main-500 underline font-medium"
                    >
                      Get Link
                    </Link>
                  </td>
                  <td className="table_td w-[260px]">
                    <div className="flex items-center justify-center gap-2">
                      <Link
                        className="border-none outline-none"
                        to={`${superAdminRoutes.updateInstituteManagement.routePath}/${item?._id}`}
                        onClick={(event) => event.stopPropagation()}
                      >
                        <EditIcon className="!h-6 !w-6 shrink-0" />
                      </Link>
                      <Link
                        className="border-none outline-none"
                        to={`${superAdminRoutes.instituteAdmins.routePath}/${item?.institute_id}`}
                        onClick={(event) => event.stopPropagation()}
                      >
                        <EyeIcon
                          className="!h-6 !w-6 shrink-0"
                          color={colors.main[600]}
                        />
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </TableHelper>
          </tbody>
        </table>
      </div>
      <Pagination
        currentPage={currentPage || 1}
        rowsPerPage={pageSize || 1}
        totalPages={totalPages || 1}
        updatePage={updatePage}
      />
    </>
  );
}

export default InstituteManagementTable;
