import LoadingInput from "@/components/shared/LoadingInput";
import { Button } from "@/components/ui/button";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import { Link } from "react-router-dom";

function UpdateInstituteManagementSkeleton() {
  return (
    <div>
      <div className="grid sm:grid-cols-2 gap-6">
        <div className="flex items-center gap-4 sm:col-span-2">
          <h2 className="text-lg font-semibold text-text-700">
            Institute Status
          </h2>
          <div className="flex-1 h-[1px] bg-natural-400"></div>
        </div>
        <LoadingInput label="Institute Status" />
        <div className="flex items-center gap-4 sm:col-span-2">
          <h2 className="text-lg font-semibold text-text-700">
            Basic Information
          </h2>
          <div className="flex-1 h-[1px] bg-natural-400"></div>
        </div>
        <LoadingInput
          placeholder="Enter full name"
          name="institute_name"
          label="Institute Name"
        />
        <LoadingInput
          placeholder="Enter short name"
          name="institute_short_name"
          label="Short Name"
        />
        <LoadingInput placeholder="Select type" label="Type" />
        <LoadingInput placeholder="Select board" label="Board" />
        <LoadingInput placeholder="ESTD" name="estd_code" label="ESTD" />
        <div className="flex items-center gap-4 sm:col-span-2">
          <h2 className="text-lg font-semibold text-text-700">
            Identification Codes
          </h2>
          <div className="flex-1 h-[1px] bg-natural-400"></div>
        </div>
        <LoadingInput
          placeholder="Enter school code"
          name="board_school_code"
          label="School Code"
        />
        <LoadingInput
          placeholder="Enter college code"
          name="board_collage_code"
          label="College Code"
        />
        <LoadingInput
          placeholder="Enter EIIN"
          name="eiin_number"
          label="EIIN Code"
        />
        <div className="flex items-center gap-4 sm:col-span-2">
          <h2 className="text-lg font-semibold text-text-700">
            Location Details
          </h2>
          <div className="flex-1 h-[1px] bg-natural-400"></div>
        </div>
        <LoadingInput
          placeholder="Enter address line"
          name="institute_address"
          label="Address Line"
          wrapper="col-span-2"
        />
        <LoadingInput
          placeholder="Enter post office"
          name="institute_post_office"
          label="Post Office"
        />
        <LoadingInput
          placeholder="Enter post code"
          name="institute_postal_code"
          label="Post Code"
        />
        <LoadingInput
          placeholder="Enter upazila"
          name="institute_upazilla"
          label="Upazila"
        />
        <LoadingInput
          placeholder="Enter district"
          name="institute_district"
          label="District"
        />
        <div className="flex items-center gap-4 sm:col-span-2">
          <h2 className="text-lg font-semibold text-text-700">
            Contact Information
          </h2>
          <div className="flex-1 h-[1px] bg-natural-400"></div>
        </div>
        <LoadingInput
          type="email"
          placeholder="Enter email"
          name="institute_email"
          label="Email"
        />
        <LoadingInput
          placeholder="Enter mobile no."
          name="institute_mobilephone"
          label="Mobile No."
        />
        <LoadingInput
          placeholder="Enter phone no."
          name="institute_telephone"
          label="Phone No."
        />

        <div className="flex items-center gap-4 sm:col-span-2">
          <h2 className="text-lg font-semibold text-text-700">
            School Capacity
          </h2>
          <div className="flex-1 h-[1px] bg-natural-400"></div>
        </div>
        <LoadingInput
          placeholder="Institute Name"
          name="total_students"
          label="Enter total students"
        />
      </div>
      <div className="flex items-center justify-end mt-10">
        <Link
          className="h-12 min-w-[132px] btn_blue !bg-transparent !text-main-500 justify-center"
          to={superAdminRoutes.instituteManagement.path}
        >
          Cancel
        </Link>
        <Button
          type="button"
          disabled
          className="h-12 min-w-[132px] ml-4"
          size="lg"
        >
          Create New Institute
        </Button>
      </div>
    </div>
  );
}

export default UpdateInstituteManagementSkeleton;
