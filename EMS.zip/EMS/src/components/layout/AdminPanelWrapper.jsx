import { images } from "@/services";
import { NotificationOutlinedIcon } from "@/services/assets/svgs";
import { useUpdateAdminInstituteMutation } from "@/store/modules/auth/authApi";
import { saveAuthData } from "@/store/modules/auth/authSlice";
import { useDispatch, useSelector } from "react-redux";
import HeaderBreadCrumb from "../navigation/HeaderBreadCrumb";
import ImageUploadProfile from "../shared/ImageUploadProfile";
import { Button } from "../ui/button";
import { SidebarTrigger } from "../ui/sidebar";

const AdminPanelWrapper = ({ children, crumbList, crumbTitle }) => {
  const dispatch = useDispatch();
  const { auth } = useSelector((state) => state.auth);
  const [updateAdminInstitute] = useUpdateAdminInstituteMutation();

  const handleImageChange = (image) => {
    if (image && image?.key) {
      dispatch(
        saveAuthData({
          institute: { ...auth?.institute, institute_image: image?.fileUrl },
        })
      );
      const data = {
        institute_image: image?.key,
      };
      const formData = new FormData();
      formData.append("data", JSON.stringify(data));
      updateAdminInstitute({ data: formData, id: auth?.institute?._id });
    }
    return;
  };

  return (
    <>
      <div className="sticky top-0 z-50 h-[75px] bg-white w-[calc(100vw-6px)] md:w-[calc(100vw-238px)] flex flex-row items-center justify-between px-6 py-4 overflow-hidden">
        <HeaderBreadCrumb crumbList={crumbList} crumbTitle={crumbTitle} />

        <SidebarTrigger className="block md:hidden" />

        <div className="flex flex-row gap-4">
          {/* Notification icon */}
          <Button
            size="icon"
            className="flex_center h-10 w-10 rounded-full bg-main-500"
          >
            <NotificationOutlinedIcon className="!h-6 !w-6 text-white !shrink-0" />
          </Button>
          {/* School info */}
          <div className="flex flex-row gap-3">
            <div className="group relative">
              <ImageUploadProfile
                inputWrapper="w-10 h-10 p-0 flex items-center justify-center rounded-full border-none"
                placeholder=""
                image={auth?.institute?.institute_image || images?.appLogo}
                setImage={handleImageChange}
                editIconClass="absolute -bottom-2 -right-2 opacity-0 group-hover:opacity-100 duration-300"
              />
            </div>

            <div className="flex flex-col">
              <p className="text-base font-semibold !leading-[1.2] text-text-700">
                {auth?.institute?.institute_name}
              </p>
              <p className="text-sm font-normal !leading-[1.4] text-text-600">
                {auth?.instituteAdmin?.username}
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="flex-1 flex flex-col w-full overflow-auto p-4 bg-neutral-100">
        {children}
      </div>
    </>
  );
};

export default AdminPanelWrapper;
