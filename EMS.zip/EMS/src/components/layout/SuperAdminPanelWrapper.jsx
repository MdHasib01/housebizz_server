import { images } from "@/services";
import { NotificationOutlinedIcon } from "@/services/assets/svgs";
import { useSelector } from "react-redux";
import HeaderBreadCrumb from "../navigation/HeaderBreadCrumb";
import Image from "../shared/Image";
import { Button } from "../ui/button";
import { SidebarTrigger } from "../ui/sidebar";

const SuperAdminPanelWrapper = ({ children, crumbList, crumbTitle }) => {
  const { auth } = useSelector((state) => state.auth);


  return (
    <>
      <div className="sticky top-0 z-50 h-[75px] bg-white w-[calc(100vw-6px)] md:w-[calc(100vw-238px)] flex flex-row items-center justify-between px-6 py-4 overflow-hidden">
        <HeaderBreadCrumb crumbList={crumbList} crumbTitle={crumbTitle} />

        <SidebarTrigger className="block md:hidden" />

        <div className="flex flex-row gap-4">
          {/* Notification icon */}
          <Button
            size="icon"
            className="flex_center h-10 w-10 rounded-full bg-main-500"
          >
            <NotificationOutlinedIcon className="!h-6 !w-6 text-white !shrink-0" />
          </Button>
          {/* School info */}
          <div className="flex flex-row gap-3">
            <Image
              src={auth?.admin?.image || images.placeholderProfileImage}
              className="h-10 w-10"
              effect="none"
            />
            <div className="flex flex-col">
              <p className="text-base font-semibold !leading-[1.2] text-text-700">
                {/* {auth?.admin?.name} */}
                SUPER ADMIN
              </p>
              <p className="text-sm font-normal !leading-[1.4] text-text-600">
                {auth?.admin?.username}
              </p>
              {/* <p className="text-sm font-normal !leading-[1.4] text-text-600">
                {auth?.admin?.role}
              </p> */}
            </div>
          </div>
        </div>
      </div>
      <div className="flex-1 flex flex-col w-full overflow-auto p-4 bg-neutral-100">
        {children}
      </div>
    </>
  );
};

export default SuperAdminPanelWrapper;
