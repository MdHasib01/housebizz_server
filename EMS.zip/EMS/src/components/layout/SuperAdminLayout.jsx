import { images } from "@/services";
import { Outlet } from "react-router-dom";
import SuperAdminSidebar from "../navigation/SuperAdminSidebar";
import Image from "../shared/Image";
import { SidebarProvider } from "../ui/sidebar";

function SuperAdminLayout() {
  return (
    <SidebarProvider>
      <div className="flex h-screen w-full overflow-hidden">
        <SuperAdminSidebar />
        <div className="flex-1 flex flex-col overflow-auto">
          <Outlet />
          <div className="flex items-center justify-between p-6 bg-neutral-100">
            <p className="text-base font-bold !leading-[1.2] text-natural-500">
              <span className="font-light !leading-normal">© 2025</span>{" "}
              <span className="text-natural-black">
                Smart Institute Education Management Systems(SIEMS)
              </span>
            </p>

            <div className="flex flex-row items-center justify-end gap-3">
              <p className="text-base font-light !leading-[1.2] text-natural-black">
                Developed by
              </p>
              <div className="h-[18px] bg-natural-500 w-[1px]" />
              <Image src={images.netro} className="h-auto w-[114px]" />
            </div>
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
}

export default SuperAdminLayout;
