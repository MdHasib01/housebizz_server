import { envConfig } from "@/services";
import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setCashPayFetchStudent,
  setCashPayStudent,
  setPaidCashPayData,
  setPendingCashPayData,
} from "./slice";

export const adminInvoicesApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getStudentInvoices: builder.query({
      async queryFn(_arg, _queryApi, _extraOptions, fetchWithBQ) {
        const { getState, dispatch } = _queryApi;
        const { auth } = getState()?.auth || {};
        const baseUrl = envConfig.baseUrl;
        const institute_id = auth?.institute?.institute_id;
        try {
          const studentFetchUrl = `${baseUrl}/students/find-by-username?institute_id=${institute_id}&student_username=${_arg}`;

          const fetchOptions = {
            method: "GET",
            headers: {
              Authorization: `Bearer ${auth?.token}`,
            },
          };

          const studentResponse = await fetch(studentFetchUrl, fetchOptions);
          const studentData = await studentResponse.json();
          if (!studentResponse.ok) {
            return {
              error: studentData,
            };
          }
          const student = studentData?.data;

          const selectors = {
            student_username: _arg,
            institute_id: institute_id,
          };
          let query = Object.keys(selectors).reduce((acc, key) => {
            if (selectors[key]) {
              return `${acc}${key}=${selectors[key]}&`;
            }
            return acc;
          }, "");

          const invoiceUrl = `${baseUrl}/invoices/find-by-student-username?${query}`;
          const invoiceResponse = await fetch(invoiceUrl, fetchOptions);
          const invoiceData = await invoiceResponse.json();
          if (!invoiceResponse.ok) {
            return {
              error: invoiceData,
            };
          }

          const pendingInvoices =
            invoiceData?.data?.filter(
              (item) => item?.status?.toLowerCase() === "pending"
            ) || [];
          const paidInvoices =
            invoiceData?.data?.filter(
              (item) => item?.status?.toLowerCase() === "paid"
            ) || [];

          dispatch(setCashPayStudent(student));
          dispatch(setPendingCashPayData(pendingInvoices));
          dispatch(setPaidCashPayData(paidInvoices));
          dispatch(setCashPayFetchStudent(false));
          return {
            data: {},
          };
        } catch (error) {
          dispatch(setCashPayFetchStudent(false));
          return { error: error };
        }
      },
    }),

    addStudentCashPay: builder.mutation({
      query: (data) => ({
        url: `/invoices/ussd/cash/accept-bulk-payment`,
        method: "POST",
        body: data,
      }),
    }),
  }),
});

export const { useGetStudentInvoicesQuery, useAddStudentCashPayMutation } =
  adminInvoicesApi;
