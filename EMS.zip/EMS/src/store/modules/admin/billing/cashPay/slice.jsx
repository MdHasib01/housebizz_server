import { generateQueryTime, getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  student: {},
  student_id: "",
  showStudent: false,
  fetchStudent: false,
  // pending
  allPendingData: [],
  pendingLists: [],
  pendingPageData: {
    totalItems: 1,
    totalPages: 1,
    currentPage: 1,
    pageSize: 10,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectedData: {},
  showModal: false,
  showInvoiceModal: false,
  showViewInvoiceModal: false,
  invoice_ids: [],

  //paid
  allPaidData: [],
  paidLists: [],
  paidPageData: {
    totalItems: 1,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
};

const cashPaySlice = createSlice({
  name: "cashPaySlice",
  initialState,
  reducers: {
    setCashPayStudentId: (state, action) => {
      state.student_id = action.payload;
    },
    setCashPayStudent: (state, action) => {
      state.student = action.payload;
    },
    setCashPayShowStudent: (state, action) => {
      state.showStudent = action.payload;
    },
    setCashPayFetchStudent: (state, action) => {
      state.fetchStudent = action.payload;
    },
    resetCashPayState: (state) => {
      state.student = initialState.student;
      state.student_id = initialState.student_id;
      state.showStudent = initialState.showStudent;
      state.fetchStudent = initialState.fetchStudent;
      state.allPaidData = initialState.allPaidData;
      state.allPendingData = initialState.allPendingData;
      state.paidLists = initialState.paidLists;
      state.pendingLists = initialState.pendingLists;
    },
    // pending
    setPendingCashPayData: (state, action) => {
      const data = action.payload;
      state.allPendingData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pendingPageData.currentPage,
        pageSize: state.pendingPageData.pageSize,
        data,
      });
      state.pendingLists = currentRows;
      state.pendingPageData.totalItems = totalItems;
      state.pendingPageData.totalPages = totalPages;
    },
    setPendingCashPayPageData: (state, action) => {
      state.pendingPageData = { ...state.pendingPageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pendingPageData.currentPage,
          pageSize: state.pendingPageData.pageSize,
          data: state.allPendingData,
        });
        state.pendingLists = currentRows;
        state.pendingPageData.totalItems = totalItems;
        state.pendingPageData.totalPages = totalPages;
      }
    },
    openCashPayModal: (state) => {
      state.showModal = true;
    },
    closeCashPayModal: (state) => {
      state.showModal = false;
    },
    openCashPayInvoiceModal: (state) => {
      state.showInvoiceModal = true;
    },
    closeCashPayInvoiceModal: (state) => {
      state.showInvoiceModal = false;
    },
    openCashPayViewInvoiceModal: (state) => {
      state.showViewInvoiceModal = true;
    },
    closeCashPayViewInvoiceModal: (state) => {
      state.showViewInvoiceModal = false;
    },
    selectAllCashPay: (state) => {
      const dataLength = state.pendingLists.length;
      const selectedLength = state.invoice_ids.length;
      if (dataLength === selectedLength) {
        state.invoice_ids = [];
      } else {
        state.invoice_ids = state.pendingLists.map((item) => item?._id);
      }
    },
    toggleSelectedCashPay: (state, action) => {
      const index = state.invoice_ids.findIndex(
        (item) => item === action.payload
      );
      if (index === -1) {
        state.invoice_ids.push(action.payload);
      } else {
        state.invoice_ids.splice(index, 1);
      }
    },
    setSelectedCashPay: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      } else if (action.payload?.type === "update") {
        state.showInvoiceModal = true;
      } else if (action.payload?.type === "view") {
        state.showViewInvoiceModal = true;
      }
    },
    updateSelectedCashPaySummery: (state, action) => {
      const { index, value } = action.payload;
      state.selectedData.charges_summary[index].amount = value;
      state.selectedData.total_amount =
        state.selectedData.charges_summary.reduce(
          (acc, item) => acc + item.amount,
          0
        );
    },
    removeSelectedCashPaySummery: (state, action) => {
      state.selectedData.charges_summary.splice(action.payload, 1);
      state.selectedData.total_amount =
        state.selectedData.charges_summary.reduce(
          (acc, item) => acc + item.amount,
          0
        );
    },
    updateCashPayInvoice: (state, action) => {
      const charges_summary = state?.selectedData?.charges_summary?.map(
        (summery) => {
          const index = action.payload?.charges_summary?.findIndex(
            (item) => item?._id === summery?._id
          );
          if (index !== -1) {
            return {
              ...summery,
              amount: action.payload?.charges_summary[index]?.amount,
            };
          }
          return summery;
        }
      );
      state.pendingLists = state.pendingLists.map((item) => {
        if (item?._id === action.payload?._id) {
          return {
            ...item,
            total_amount: action.payload.total_amount,
            charges_summary,
          };
        }
        return item;
      });
      state.allPendingData = state.allPendingData.map((item) => {
        if (item?._id === action.payload?._id) {
          return {
            ...item,
            total_amount: action.payload.total_amount,
            charges_summary,
          };
        }
        return item;
      });
      state.selectedData = {};
    },
    removeCashPayList: (state) => {
      state.allPendingData = state.allPendingData.filter(
        (item) => item?._id !== state.selectedData?._id
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pendingPageData.currentPage,
        pageSize: state.pendingPageData.pageSize,
        data: state.allPendingData,
      });
      state.pendingLists = currentRows;
      state.pendingPageData.totalItems = totalItems;
      state.pendingPageData.totalPages = totalPages;
    },
    // paid
    setPaidCashPayData: (state, action) => {
      const data = action.payload;
      state.allPaidData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.paidPageData.currentPage,
        pageSize: state.paidPageData.pageSize,
        data,
      });
      state.paidLists = currentRows;
      state.paidPageData.totalItems = totalItems;
      state.paidPageData.totalPages = totalPages;
    },
    setPaidCashPayPageData: (state, action) => {
      state.paidPageData = { ...state.paidPageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.paidPageData.currentPage,
          pageSize: state.paidPageData.pageSize,
          data: state.allPaidData,
        });
        state.paidLists = currentRows;
        state.paidPageData.totalItems = totalItems;
        state.paidPageData.totalPages = totalPages;
      }
    },
    movePendingToPaidInvoices: (state) => {
      const newPaidData = state.allPendingData.filter((item) =>
        state.invoice_ids.includes(item._id)
      );
      const modifiedPaidData = newPaidData.map((item) => {
        return {
          ...item,
          pay_time: generateQueryTime(),
        };
      });
      state.allPendingData = state.allPendingData.filter(
        (item) => !state.invoice_ids.includes(item._id)
      );

      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pendingPageData.currentPage,
        pageSize: state.pendingPageData.pageSize,
        data: state.allPendingData,
      });
      state.pendingLists = currentRows;
      state.pendingPageData.totalItems = totalItems;
      state.pendingPageData.totalPages = totalPages;

      state.allPaidData = [...state.allPaidData, ...modifiedPaidData];

      const {
        totalItems: paidTotalItems,
        totalPages: paidTotalPages,
        currentRows: paidRows,
      } = getPageData({
        currentPage: state.paidPageData.currentPage,
        pageSize: state.paidPageData.pageSize,
        data: state.allPaidData,
      });

      state.paidLists = paidRows;
      state.paidPageData.totalItems = paidTotalItems;
      state.paidPageData.totalPages = paidTotalPages;
      state.invoice_ids = [];
    },
  },
});

export const {
  setCashPayStudentId,
  setCashPayStudent,
  setCashPayChargesSummary,
  setCashPayShowStudent,
  setCashPayFetchStudent,
  changeCashPaySummeryAmount,
  resetCashPayState,
  setPendingCashPayData,
  setPendingCashPayPageData,
  setPaidCashPayData,
  setPaidCashPayPageData,
  openCashPayModal,
  closeCashPayModal,
  openCashPayInvoiceModal,
  closeCashPayInvoiceModal,
  openCashPayViewInvoiceModal,
  closeCashPayViewInvoiceModal,
  selectAllCashPay,
  toggleSelectedCashPay,
  setSelectedCashPay,
  updateSelectedCashPaySummery,
  removeSelectedCashPaySummery,
  updateCashPayInvoice,
  removeCashPayList,
  movePendingToPaidInvoices,
} = cashPaySlice.actions;
export default cashPaySlice.reducer;
