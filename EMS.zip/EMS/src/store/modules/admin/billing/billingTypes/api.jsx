import { apiSlice } from "@/store/modules/api/apiSlice";
import { addBillingTypeList, setAllBillingTypes, setBillingTypeFetchData, setBillingTypesData, setBillingTypeSelectors, setBillingTypesPageData, setInitialRightHeadsFilterWithRightHeads, updateBillingType } from "./slice";

export const adminBillingTypesApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addBillingType: builder.mutation({
      query: (data) => ({
        url: "/billing-types/add",
        method: "POST",
        body: data,
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(addBillingTypeList(results));
        } catch (error) {}
      },
    }),

    // getBillingTypes: builder.query({
    //   query: ({ page = 1, limit = 50, institute_id = "" }) =>
    //     `/billing-types/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
    //   async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
    //     try {
    //       const { data } = await queryFulfilled;
    //       const results = data?.data;
    //       dispatch(setBillingTypesData({ data: results }));
    //       dispatch(setBillingTypesPageData(data?.meta));
    //     } catch (error) { }
    //   },
    // }),

    getAllBillingTypes: builder.query({
      query: ({ institute_id = "", page = 1, limit = 50 }) =>
        `/billing-types/all?institute_id=${institute_id}&page=${page}&limit=${limit}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllBillingTypes(results));
        } catch (error) {}
      },
    }),

    getFilteredBillingTypes: builder.query({
      query: ({ query = null }) => `/billing-types/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setBillingTypesData(results));
          dispatch(setBillingTypeFetchData(false));
        } catch (error) {
          dispatch(setBillingTypeFetchData(false));
        }
      },
    }),

    findBillingType: builder.query({
      query: ({ institute_id = "", billing_type_id = "" }) =>
        `/billing-types/find?institute_id=${institute_id}&billing_type_id=${billing_type_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(
            setBillingTypeSelectors({
              billing_type: results.billing_type,
              category_id: results.category_id?._id,
              local_class_id: `${results.local_class_id?.local_class_code}-${results.local_class_id?._id}`,
              academic_year: results.academic_year,
              group_id: results.group_id?._id || "",
              assigned_heads:
                results.assigned_heads.map(
                  (head) => head.billing_head_id._id
                ) || [],
            })
          );

          dispatch(
            setInitialRightHeadsFilterWithRightHeads(
              results.assigned_heads.map((head) => head.billing_head_id._id) ||
                []
            )
          );
        } catch (error) {}
      },
    }),

    updateBillingType: builder.mutation({
      query: ({ data, institute_id = "", billing_type_id = "" }) => ({
        url: `/billing-types/update?institute_id=${institute_id}&billing_type_id=${billing_type_id}`,
        method: "PATCH",
        body: data,
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(updateBillingType(results));
        } catch (error) {}
      },
    }),

    deleteBillingType: builder.mutation({
      query: ({ institute_id = "", billing_type_id = "" }) => ({
        url: `/billing-types/delete?institute_id=${institute_id}&billing_type_id=${billing_type_id}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useAddBillingTypeMutation,
  useGetAllBillingTypesQuery,
  // useGetBillingTypesQuery,
  useDeleteBillingTypeMutation,
  useFindBillingTypeQuery,
  useUpdateBillingTypeMutation,
  useGetFilteredBillingTypesQuery,
} = adminBillingTypesApi;
