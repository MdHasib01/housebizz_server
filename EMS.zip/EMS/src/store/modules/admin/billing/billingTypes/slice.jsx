import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 1,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  // form selectors
  selectors: {
    academic_year: "",
    category_id: "",
    billing_type: "",
    local_class_id: "",
    group_id: "",
    assigned_heads: [],
  },
  // movable table 
  left_heads: [],
  right_heads: [],
  selected_left_heads: [],
  selected_right_heads: [],
  selected_heads: [],
  right_search: "",
  left_search: "",

  // for filter
  showTable: false,
  fetchData: false,
  search_query: {
    category_id: "",
    academic_year: "",
    class_id: "",
    group_id: "",
  }
};

const billingTypesSlice = createSlice({
  name: "billingTypes",
  initialState,
  reducers: {
    setAllBillingTypes: (state, action) => {
      state.allData = action.payload;
    },

    // set all data after fetching
    // setBillingTypesData: (state, action) => {
    //   const { data, meta } = action.payload;
    //   if (meta?.totalPages === 0) return;

    //   if (meta?.currentPage <= meta?.totalPages) {
    //     state.data[`page${meta?.currentPage}`] = data;
    //     state.dataLists = data;
    //   } else {
    //     const otherData = state.data[`page${state.pageData.currentPage}`];
    //     const sliceData = otherData.slice(0, meta?.pageSize);
    //     const currentPage = meta?.currentPage - meta?.totalPages;
    //     const page = meta?.currentPage - currentPage;
    //     state.dataLists = [...sliceData];
    //     state.pageData.currentPage = page;
    //     state.pageData.totalPages = meta?.totalPages;
    //   }
    // },
    setBillingTypesData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },

    // set data when click on pagination
    setBillingTypesPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        state.dataLists = state.data[`page${action.payload.currentPage}`] || [];
      }
    },

    // on create new add to list
    addBillingTypeList: (state, action) => {
      const { totalPages, pageSize, currentPage } = state.pageData;
      const pageIndex = totalPages === 0 ? 1 : totalPages;
      const pageData = state.data[`page${pageIndex}`] || [];
      const totalPage = totalPages === 0 ? 1 : totalPages;
      if (pageData?.length >= pageSize) {
        state.data[`page${pageIndex + 1}`] = [action.payload];
        state.pageData.totalPages = totalPages + 1;
      } else state.data[`page${pageIndex}`] = [...pageData, action.payload];

      if (totalPage === currentPage)
        state.dataLists = state.data[`page${pageIndex}`];
    },

    // on delete remove from list
    removeBillingTypeList: (state, action) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== action.payload._id
      );
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.showModal = false;
      state.selectedData = {};
    },

    // set selected data
    setSelectedBillingType: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },

    updateBillingType: (state, action) => {
      state.dataLists = state.dataLists.map((item) => {
        if (item._id === action.payload._id) return action.payload;
        return item;
      });
    },

    // close modal
    closeBillingTypeModal: (state) => {
      state.showModal = false;
      state.selectedData = {};
    },

    // set selectors
    setBillingTypeSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },

    resetBillingTypeSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.left_heads = initialState.left_heads;
      state.right_heads = initialState.right_heads;
      state.selected_left_heads = initialState.selected_left_heads;
      state.selected_right_heads = initialState.selected_right_heads;
      state.selected_heads = initialState.selected_heads;
      state.right_search = initialState.right_search;
      state.left_search = initialState.left_search;
    },

    // set search selectors
    setBillingTypeSearhQuerySelectors: (state, action) => {
      state.search_query = { ...state.search_query, ...action.payload };
    },

    resetBillingTypeSearhQuerySelectors: (state) => {
      state.search_query = initialState.search_query;
      state.showTable = initialState.showTable;
      state.fetchData = initialState.fetchData;
    },

    setBillingTypeShowTable: (state, action) => {
      state.showTable = action.payload;
    },

    setBillingTypeFetchData: (state, action) => {
      state.fetchData = action.payload;
    },


    // swappable table actions
    setBillingTypeLeftSearch: (state, action) => {
      state.left_search = action.payload;
    },
    setBillingTypeRightSearch: (state, action) => {
      state.right_search = action.payload;
    },

    setInitialLeftHeads: (state, action) => {
      state.left_heads = action.payload;
    },

    setInitialRightHeadsFilterWithRightHeads: (state, action) => {
      const idsToMove = action.payload; // Array of IDs

      // Find matching items in leftHeads
      const matchedItems = state.left_heads.filter(item => idsToMove.includes(item._id));

      // Remove matched items from leftHeads
      state.left_heads = state.left_heads.filter(item => !idsToMove.includes(item._id));

      // Transfer matched items to rightHeads
      state.right_heads = [...state.right_heads, ...matchedItems];
    },

    setAllLeftHeads: (state) => {
      if (state.left_heads?.length === state.selected_left_heads?.length) {
        state.selected_left_heads = [];
        return;
      }
      state.selected_left_heads = state.left_heads;
    },

    setAllRightHeads: (state) => {
      state.selected_right_heads = state.right_heads;
    },

    toggleLeftHead: (state, action) => {
      const index = state.selected_left_heads.findIndex((item) => item._id === action.payload?._id);
      if (index > -1) {
        state.selected_left_heads.splice(index, 1);
      } else {
        state.selected_left_heads.push(action.payload);
      }
    },

    toggleRightHead: (state, action) => {
      const index = state.selected_right_heads.findIndex((item) => item._id === action.payload?._id);
      if (index > -1) {
        state.selected_right_heads.splice(index, 1);
      } else {
        state.selected_right_heads.push(action.payload);
      }
    },
    moveLeftRightHead: (state) => {
      state.right_heads = [
        ...state.right_heads,
        ...state.selected_left_heads,
      ];
      state.left_heads = state.left_heads.filter(
        (item) =>
          !state.selected_left_heads.some(
            (selected) => selected._id === item._id
          )
      );
      state.selected_left_heads = [];
    },

    moveRightLeftHead: (state) => {
      state.left_heads = [
        ...state.left_heads,
        ...state.selected_right_heads,
      ];
      state.right_heads = state.right_heads.filter(
        (item) =>
          !state.selected_right_heads.some(
            (selected) => selected._id === item._id
          )
      );
      state.selected_right_heads = [];
    },
  },
});

export const {
  setAllBillingTypes,
  setBillingTypesData,
  setBillingTypesPageData,
  addBillingTypeList,
  removeBillingTypeList,
  setSelectedBillingType,
  updateBillingType,
  closeBillingTypeModal,
  setBillingTypeSelectors,
  resetBillingTypeSelectors,

  setBillingTypeShowTable,
  setBillingTypeFetchData,
  setBillingTypeSearhQuerySelectors,
  resetBillingTypeSearhQuerySelectors,

  setBillingTypeLeftSearch,
  setBillingTypeRightSearch,
  setAllLeftHeads,
  setInitialLeftHeads,
  setInitialRightHeadsFilterWithRightHeads,
  setAllRightHeads,
  toggleLeftHead,
  toggleRightHead,
  moveLeftRightHead,
  moveRightLeftHead,
} = billingTypesSlice.actions;
export default billingTypesSlice.reducer;
