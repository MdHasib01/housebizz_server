import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  selectedBillingYear: "",
  showModal: false,
  allBillingTypes: null,
  filteredBillingTypes: [],
  renderableBillingList: [],
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  fetchData: false,
};

const billingConfigSlice = createSlice({
  name: "billingConfig",
  initialState,
  reducers: {
    setBillingConfigData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    setSelectedBillingYear: (state, action) => {
      state.selectedBillingYear = action.payload;
    },
    searchBillingConfigData: (state, action) => {
      state.fetchData = action.payload;
    },
    setPageBillingTypesAndConfigs: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },

    removeBillingConfig: (state) => {
      state.allData = state.allData.filter(
        (item) => item?._id !== state.selectedData?._id
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });

      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
      state.selectedData = {};
    },

    setBillingTypesAndConfigs: (state, action) => {
      const { data } = action.payload;
      const newLists = data?.assigned_heads?.map((item) => {
        const monthly_fees = Object.fromEntries(
          Object.entries(item?.monthly_fees).map(([month, value]) => [
            month,
            value === 0 ? "" : value,
          ])
        );


        return {
          local_class_id: data?.local_class_id?._id,
          local_class_name: data?.local_class_id?.local_class_name,
          category_id: data?.category_id?._id,
          category_name: data?.category_id?.local_category_name,
          academic_year: data?.academic_year,
          billing_type: data?.billing_type,
          id: item.billing_head_id?._id,
          headName: item.billing_head_id?.head_title,
          monthly_fees: item.monthly_fees,
        };
      });

      state.renderableBillingList = newLists;
    },

    updateBillingField: (state, action) => {
      const { index, month, value } = action.payload;
      state.renderableBillingList[index].monthly_fees[month] = value;
    },

    toggleBillingConfigDeleteModal: (state) => {
      state.showModal = !state.showModal;
    },

    setSelectedBillingConfig: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
  },
});

export const {
  setBillingTypesAndConfigs,
  searchBillingConfigData,
  setPageBillingTypesAndConfigs,
  updateBillingField,
  setRenderableBillingList,
  setSelectedBillingYear,
  toggleBillingConfigDeleteModal,
  removeBillingConfig,
  setSelectedBillingConfig,
  setBillingConfigData,
} = billingConfigSlice.actions;
export default billingConfigSlice.reducer;
