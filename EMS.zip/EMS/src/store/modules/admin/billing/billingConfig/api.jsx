import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  searchBillingConfigData,
  setBillingConfigData,
  setBillingTypesAndConfigs,
} from "./slice";

export const adminBillingConfigApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getBillingConfig: builder.query({
      query: ({ academic_year = 1, institute_id = "" }) => {
        return {
          url: `/billing-types/filtered?institute_id=${institute_id}&academic_year=${academic_year}`,
          method: "GET",
        };
      },
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setBillingConfigData(results));
          dispatch(searchBillingConfigData(false));
        } catch (error) {
          dispatch(searchBillingConfigData(false));
        }
      },
    }),
    findBillingConfig: builder.query({
      query: ({
        page = 1,
        limit = 1,
        billing_type_id = "",
        institute_id = "",
      }) => {
        return {
          url: `/billing-types/find?page=${page}&limit=${limit}&institute_id=${institute_id}&billing_type_id=${billing_type_id}`,
          method: "GET",
        };
      },
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setBillingTypesAndConfigs({ data: results }));
        } catch (error) {
        }
      },
    }),

    updateBillingConfig: builder.mutation({
      query: ({ institute_id, billing_type_id, data }) => {
        const formData = new FormData();
        formData.append("data", JSON.stringify(data));

        return {
          url: `/billing-types/update?institute_id=${institute_id}&billing_type_id=${billing_type_id}`,
          method: "PATCH",
          body: data,
        };
      },
    }),

    deleteBillingConfig: builder.mutation({
      query: ({ institute_id, billing_type_id }) => {
        return {
          url: `/billing-types/delete?institute_id=${institute_id}&billing_type_id=${billing_type_id}`,
          method: "DELETE",
        };
      },
    }),
  }),
});

export const {
  useGetBillingConfigQuery,
  useFindBillingConfigQuery,
  useUpdateBillingConfigMutation,
  useDeleteBillingConfigMutation,
} = adminBillingConfigApi;
