import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 1,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
};

const billingHeadSlice = createSlice({
  name: "billingHeadSlice",
  initialState,
  reducers: {
    setAllBillingHeadData: (state, action) => {
      state.allData = action.payload;
    },
    setBillingHeads: (state, action) => {
      state.dataLists = action.payload;
    },
    setBillingHeadData: (state, action) => {
      const { data, meta } = action.payload;
      if (meta?.totalPages === 0) {
        return;
      }
      if (meta?.currentPage <= meta?.totalPages) {
        state.data[`page${meta?.currentPage}`] = data;
        state.dataLists = data;
      } else {
        const otherData = state.data[`page${state.pageData.currentPage}`];
        const sliceData = otherData.slice(0, meta?.pageSize);
        const currentPage = meta?.currentPage - meta?.totalPages;
        const page = meta?.currentPage - currentPage;
        state.dataLists = [...sliceData];
        state.pageData.currentPage = page;
        state.pageData.totalPages = meta?.totalPages;
      }
    },
    addBillingHead: (state, action) => {
      state.dataLists.push(action.payload);
    },
    setSelectedBillingHead: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
    updateSelectedBillingHead: (state, action) => {
      const { name, value } = action.payload;
      state.selectedData[name] = value;
    },
    openBillingHeadModal: (state) => {
      state.showModal = true;
    },
    closeBillingHeadModal: (state) => {
      state.showModal = false;
    },
    addBillingHeadList: (state, action) => {
      const { totalPages, pageSize, currentPage } = state.pageData;
      const pageIndex = totalPages === 0 ? 1 : totalPages;
      const pageData = state.data[`page${pageIndex}`] || [];
      const totalPage = totalPages === 0 ? 1 : totalPages;
      if (pageData?.length >= pageSize) {
        state.data[`page${pageIndex + 1}`] = [action.payload];
        state.pageData.totalPages = totalPages + 1;
      } else {
        state.data[`page${pageIndex}`] = [...pageData, action.payload];
      }
      if (totalPage === currentPage) {
        state.dataLists = state.data[`page${pageIndex}`];
      }
    },
    updateBillingHeadList: (state, action) => {
      state.dataLists = state.dataLists.map((item) => {
        if (item._id === action.payload._id) {
          return {
            ...item,
            ...action.payload,
          };
        }
        return item;
      });
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.showModal = false;
      state.selectedData = {};
    },
    removeBillingHeadList: (state) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== state.selectedData._id
      );
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.showModal = false;
      state.selectedData = {};
    },

    setBillingHeadPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        state.dataLists = state.data[`page${action.payload.currentPage}`] || [];
      }
    },
  },
});

export const {
  setAllBillingHeadData,
  setSelectedBillingHead,
  updateSelectedBillingHead,
  setBillingHeads,
  addBillingHead,
  openBillingHeadModal,
  closeBillingHeadModal,
  setBillingHeadData,
  setBillingHeadPageData,
  updateBillingHeadList,
  removeBillingHeadList,
  addBillingHeadList,
} = billingHeadSlice.actions;
export default billingHeadSlice.reducer;
