import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setAllBillingHeadData,
  setBillingHeadData,
  setBillingHeadPageData,
} from "./slice";
import { resetBillingTypeSelectors, setInitialLeftHeads } from "../billingTypes/slice";

export const saBillingHeadManagementApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAllBillingHeads: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/billing-heads/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          dispatch(resetBillingTypeSelectors());
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllBillingHeadData(results));
          dispatch(setInitialLeftHeads(results));
        } catch (error) {}
      },
    }),
    getBillingHeads: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/billing-heads/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setBillingHeadData({ data: results, meta: data?.meta }));
          dispatch(setBillingHeadPageData(data?.meta));
        } catch (error) {}
        // Add loading state management here
      },
    }),
    addBillingHead: builder.mutation({
      query: (data) => ({
        url: "/billing-heads/add",
        method: "POST",
        body: data,
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (error) {}
        // Add loading state management here
      },
    }),

    updateBillingHead: builder.mutation({
      query: ({ data, institute_id, billing_head_id }) => ({
        url: `/billing-heads/update?institute_id=${institute_id}&billing_head_id=${billing_head_id}`,
        method: "PATCH",
        body: data,
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (error) {}
        // Add loading state management here
      },
    }),
    deleteBillingHead: builder.mutation({
      query: ({ institute_id, billing_head_id }) => ({
        url: `/billing-heads/delete?institute_id=${institute_id}&billing_head_id=${billing_head_id}`,
        method: "DELETE",
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (error) {}
        // Add loading state management here
      },
    }),
  }),
});

export const {
  useGetAllBillingHeadsQuery,
  useGetBillingHeadsQuery,
  useAddBillingHeadMutation,
  useUpdateBillingHeadMutation,
  useDeleteBillingHeadMutation,
} = saBillingHeadManagementApi;
