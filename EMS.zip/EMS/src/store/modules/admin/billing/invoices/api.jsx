import { envConfig } from "@/services";
import { apiSlice } from "@/store/modules/api/apiSlice";
import moment from "moment";
import {
  setAllBulkBillingData,
  setBulkBillingFetchData,
} from "./bulkBillingSlice";
import {
  setCustomBillingChargesSummary,
  setCustomBillingFetchStudent,
  setCustomBillingStudent,
} from "./customBillingSlice";
import {
  setBillingSearchData,
  setBillingSearchFetchData,
} from "./searchBillingSlice";

export const adminInvoicesApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getBillingSearchStudents: builder.query({
      query: ({ query = null }) => `/invoices/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setBillingSearchData(data?.data));
          dispatch(setBillingSearchFetchData(false));
        } catch (error) {
          dispatch(setBillingSearchFetchData(false));
        }
      },
    }),
    deleteBillingSearchInvoice: builder.mutation({
      query: (query) => ({
        url: `/invoices/delete${query}`,
        method: "DELETE",
      }),
    }),

    updateBillingSearchSummery: builder.mutation({
      query: ({ data, institute_id, invoice_id }) => ({
        url: `/invoices/update?institute_id=${institute_id}&invoice_id=${invoice_id}`,
        method: "PATCH",
        body: data,
      }),
      // async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
      //   try {
      //     const { data } = await queryFulfilled;
      //     dispatch(updateBillingSearchInvoice(data?.data));
      //   } catch (error) {}
      // },
    }),
    // bulk billing
    getBulkBillingStudents: builder.query({
      query: ({ query = null }) => `/students/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setAllBulkBillingData(data?.data));
          dispatch(setBulkBillingFetchData(false));
        } catch (error) {
          dispatch(setBulkBillingFetchData(false));
        }
      },
    }),
    addBulkBilling: builder.mutation({
      query: (data) => ({
        url: `/invoices/bulk-add`,
        method: "POST",
        body: data,
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (error) {}
      },
    }),

    // custom billing
    addStudentCustomBilling: builder.mutation({
      query: (data) => ({
        url: `/invoices/add`,
        method: "POST",
        body: data,
      }),
    }),
    getStudentCustomBilling: builder.query({
      async queryFn(_arg, _queryApi, _extraOptions, fetchWithBQ) {
        const { getState, dispatch } = _queryApi;
        const { auth } = getState()?.auth || {};
        const baseUrl = envConfig.baseUrl;
        const institute_id = auth?.institute?.institute_id;
        try {
          const studentFetchUrl = `${baseUrl}/students/find-by-username?institute_id=${institute_id}&student_username=${_arg}`;

          const fetchOptions = {
            method: "GET",
            headers: {
              Authorization: `Bearer ${auth?.token}`,
            },
          };

          const studentResponse = await fetch(studentFetchUrl, fetchOptions);
          const studentData = await studentResponse.json();
          if (!studentResponse.ok) {
            return {
              error: studentData,
            };
          }
          const student = studentData?.data;

          const category_id = student?.current_category?._id;
          const academic_year = student?.academic_year;
          const local_class_id = student?.current_class?._id;
          const group_id = student?.current_group?._id;
          const selectors = {
            category_id,
            academic_year,
            local_class_id,
            group_id,
            institute_id: institute_id,
          };
          let query = Object.keys(selectors).reduce((acc, key) => {
            if (selectors[key]) {
              return `${acc}${key}=${selectors[key]}&`;
            }
            return acc;
          }, "");

          const billingTypeUrl = `${baseUrl}/billing-types/filtered?${query}`;
          const billingResponse = await fetch(billingTypeUrl, fetchOptions);
          const billingData = await billingResponse.json();
          if (!billingResponse.ok) {
            return {
              error: billingData,
            };
          }
          const billingTypes = billingData?.data[0] || {};
          const due_date = moment().add(7, "day").unix();

          const summary = billingTypes?.assigned_heads?.map((item) => {
            return {
              billing_head_title: item?.billing_head_id?.head_title,
              billing_head_id: item?.billing_head_id?._id,
              amount: "",
            };
          });

          const data = {
            institute_id: "SPID_9",
            student_id: student?._id,
            current_roll_number: student?.current_roll_number,
            name_english: student?.name_english,
            section_name: student?.current_section?.section_name,
            class_name: student?.current_class?.local_class_name,
            student_username: student?.username,
            academic_year: academic_year,
            total_amount: 0,
            status: "Pending",
            due_date: due_date,
          };

          dispatch(setCustomBillingFetchStudent(false));
          dispatch(setCustomBillingStudent(data));
          dispatch(setCustomBillingChargesSummary(summary));

          return {
            data: {},
          };
        } catch (error) {
          dispatch(setCustomBillingFetchStudent(false));
          return { error: error };
        }
      },
    }),
  }),
});

export const {
  useGetBillingSearchStudentsQuery,
  useDeleteBillingSearchInvoiceMutation,
  useGetBulkBillingStudentsQuery,
  useUpdateBillingSearchSummeryMutation,
  useAddBulkBillingMutation,
  useGetStudentCustomBillingQuery,
  useAddStudentCustomBillingMutation,
} = adminInvoicesApi;
