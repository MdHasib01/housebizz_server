import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  allData: [],
  selectors: {
    academic_year: "",
    current_group: "",
    current_category: "",
    current_class: "",
    month: "",
    billing_type: {},
    due_date: {
      start: null,
      end: null,
    },
  },
  student_ids: [],
  students: [],
  showTable: false,
  fetchData: false,
};

const bulkBillingSlice = createSlice({
  name: "bulkBillingSlice",
  initialState,
  reducers: {
    setAllBulkBillingData: (state, action) => {
      state.allData = action.payload;
    },
    setBulkBillingSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    resetBulkBillingSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    setBulkBillingShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setBulkBillingFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
    selectAllBulkBilling: (state) => {
      const dataLength = state.allData.length;
      const selectedLength = state.student_ids.length;
      if (dataLength === selectedLength) {
        state.student_ids = [];
        state.students = [];
      } else {
        state.student_ids = state.allData.map((item) => item?._id);
        state.students = state.allData;
      }
    },
    toggleSelectedBulkBilling: (state, action) => {
      const index = state.student_ids.findIndex(
        (item) => item === action.payload?._id
      );
      if (index === -1) {
        state.student_ids.push(action.payload?._id);
        state.students.push(action.payload);
      } else {
        state.student_ids.splice(index, 1);
        state.students.splice(index, 1);
      }
    },
    resetBillingStudentSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.student_ids = [];
      state.students = [];
    },
    changeBulkBillingDueDate: (state, action) => {
      state.selectors.due_date = action.payload;
    },
  },
});

export const {
  resetBillingStudentSelectors,
  setAllBulkBillingData,
  setBulkBillingSelectors,
  resetBulkBillingSelectors,
  setBulkBillingShowTable,
  setBulkBillingFetchData,
  selectAllBulkBilling,
  toggleSelectedBulkBilling,
  changeBulkBillingDueDate,
} = bulkBillingSlice.actions;
export default bulkBillingSlice.reducer;
