import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  student: {},
  charges_summary: [],
  student_id: "",
  showStudent: false,
  fetchStudent: false,
};

const customBillingSlice = createSlice({
  name: "customBillingSlice",
  initialState,
  reducers: {
    setCustomBillingStudentId: (state, action) => {
      state.student_id = action.payload;
    },
    setCustomBillingStudent: (state, action) => {
      state.student = action.payload;
    },
    setCustomBillingChargesSummary: (state, action) => {
      state.charges_summary = action.payload;
    },
    changeCustomBillingSummeryAmount: (state, action) => {
      const { index, value } = action.payload;
      state.charges_summary[index].amount = Number(value);
      const totalAmount = state.charges_summary.reduce((acc, item) => {
        return acc + Number(item?.amount || 0);
      }, 0);
      state.student.total_amount = totalAmount;
    },
    setCustomBillingShowStudent: (state, action) => {
      state.showStudent = action.payload;
    },
    setCustomBillingFetchStudent: (state, action) => {
      state.fetchStudent = action.payload;
    },
    resetCustomBillingState: (state) => {
      state.student = initialState.student;
      state.charges_summary = initialState.charges_summary;
      state.student_id = initialState.student_id;
      state.showStudent = initialState.showStudent;
      state.fetchStudent = initialState.fetchStudent;
    },
  },
});

export const {
  setCustomBillingStudentId,
  setCustomBillingStudent,
  setCustomBillingChargesSummary,
  setCustomBillingShowStudent,
  setCustomBillingFetchStudent,
  changeCustomBillingSummeryAmount,
  resetCustomBillingState,
} = customBillingSlice.actions;
export default customBillingSlice.reducer;
