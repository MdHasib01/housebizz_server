import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  showInvoiceModal: false,
  showViewInvoiceModal: false,
  pageData: {
    totalItems: 1,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    current_group: "",
    current_section: "",
    current_category: "",
    current_class: "",
    month: "",
    status: "",
  },
  student_ids: [],
  searchValue: "",
  showTable: false,
  fetchData: false,
};

const searchBillingSlice = createSlice({
  name: "searchBillingSlice",
  initialState,
  reducers: {
    setAllBillingSearchData: (state, action) => {
      state.allData = action.payload;
    },
    setBillingSearchData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    setSelectedBillingSearch: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      } else if (action.payload?.type === "update") {
        state.showInvoiceModal = true;
      } else if (action.payload?.type === "view") {
        state.showViewInvoiceModal = true;
      }
    },
    updateSelectedBillingSearchSummery: (state, action) => {
      const { index, value } = action.payload;
      state.selectedData.charges_summary[index].amount = value;
      state.selectedData.total_amount =
        state.selectedData.charges_summary.reduce(
          (acc, item) => acc + item.amount,
          0
        );
    },

    removeSelectedBillingSummery: (state, action) => {
      state.selectedData.charges_summary.splice(action.payload, 1);
      state.selectedData.total_amount =
        state.selectedData.charges_summary.reduce(
          (acc, item) => acc + item.amount,
          0
        );
    },

    updateBillingSearchInvoice: (state, action) => {
      const charges_summary = state?.selectedData?.charges_summary?.map(
        (summery) => {
          const index = action.payload?.charges_summary?.findIndex(
            (item) => item?._id === summery?._id
          );
          if (index !== -1) {
            return {
              ...summery,
              amount: action.payload?.charges_summary[index]?.amount,
            };
          }
          return summery;
        }
      );
      state.dataLists = state.dataLists.map((item) => {
        if (item?._id === action.payload?._id) {
          return {
            ...item,
            total_amount: action.payload.total_amount,
            charges_summary,
          };
        }
        return item;
      });
      state.allData = state.allData.map((item) => {
        if (item?._id === action.payload?._id) {
          return {
            ...item,
            total_amount: action.payload.total_amount,
            charges_summary,
          };
        }
        return item;
      });
      state.selectedData = {};
    },

    openBillingSearchModal: (state) => {
      state.showModal = true;
    },
    closeBillingSearchModal: (state) => {
      state.showModal = false;
    },
    openBillingInvoiceModal: (state) => {
      state.showInvoiceModal = true;
    },
    closeBillingInvoiceModal: (state) => {
      state.showInvoiceModal = false;
    },
    openBillingViewInvoiceModal: (state) => {
      state.showViewInvoiceModal = true;
    },
    closeBillingViewInvoiceModal: (state) => {
      state.showViewInvoiceModal = false;
    },
    setBillingSearchPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    setBillingSearchSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    setBillingSearchSelectorsSubjects: (state, action) => {
      const { index, name, value } = action.payload;
      state.selectors.subjects[index][name] = value;
    },

    addBillingSearchSubjects: (state) => {
      state.selectors.subjects.push({
        subject_id: "",
        teacher_id: "",
        start_time: "",
        end_time: "",
      });
    },
    resetBillingSearchSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    setBillingSearchShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setBillingSearchFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
    removeBillingSearchList: (state) => {
      state.allData = state.allData.filter(
        (item) => item?._id !== state.selectedData?._id
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    selectAllBillingSearch: (state) => {
      const dataLength = state.dataLists.length;
      const selectedLength = state.student_ids.length;
      if (dataLength === selectedLength) {
        state.student_ids = [];
      } else {
        state.student_ids = state.dataLists.map((item) => item._id);
      }
    },
    toggleSelectedBillingSearch: (state, action) => {
      const index = state.student_ids.findIndex(
        (item) => item === action.payload
      );
      if (index === -1) {
        state.student_ids.push(action.payload);
      } else {
        state.student_ids.splice(index, 1);
      }
    },
    setBillingSearchSearchValue: (state, action) => {
      state.searchValue = action.payload;
      const newData = [...state.allData];
      const data = newData?.filter((item) => {
        if (action.payload?.trim() === "") return true;
        return (
          item?.student_id?.username
            ?.toLowerCase()
            .startsWith(action.payload?.toLowerCase()) ||
          item?.student_id?.current_roll_number?.toString()?.startsWith(action.payload)
        );
      });
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
      state.dataLists = currentRows;
    },
  },
});

export const {
  setBillingSearchData,
  openBillingSearchModal,
  closeBillingSearchModal,
  setBillingSearchPageData,
  setBillingSearchSelectors,
  resetBillingSearchSelectors,
  setBillingSearchShowTable,
  setBillingSearchFetchData,
  setSelectedBillingSearch,
  setBillingSearchSelectorsSubjects,
  addBillingSearchSubjects,
  selectAllBillingSearch,
  toggleSelectedBillingSearch,
  setBillingSearchSearchValue,
  removeBillingSearchList,
  openBillingInvoiceModal,
  closeBillingInvoiceModal,
  openBillingViewInvoiceModal,
  closeBillingViewInvoiceModal,
  updateSelectedBillingSearchSummery,
  removeSelectedBillingSummery,
  updateBillingSearchInvoice,
} = searchBillingSlice.actions;
export default searchBillingSlice.reducer;
