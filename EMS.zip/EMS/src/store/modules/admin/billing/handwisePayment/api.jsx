import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setBillingSearchData,
  setBillingSearchFetchData,
} from "./slice";

export const adminHandwisePaymentApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getHandwisePayment: builder.query({
      query: ({ query = null }) => `/invoices/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setBillingSearchData(data?.data));
          dispatch(setBillingSearchFetchData(false));
        } catch (error) {
          dispatch(setBillingSearchFetchData(false));
        }
      },
    }),
  }),
});

export const { useGetHandwisePaymentQuery } = adminHandwisePaymentApi;
