import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  schoolInfo: {
    name: "FULKURI ISLAMIC ACADEMY",
    established: "1982",
    badge: "/image/school-badge.png",
    code: 235.91,
    contact: {
      location: "Chapainwabganj-6300",
      email: "Schoolfulkuri@gmail.com",
      phone: "01309124497",
    },
    credentials: {
      totalTeachers: 0,
      totalStudents: 0,
      totalStaffs: 0,
      totalVehicles: 0,
    },
  },
  billsAndPayments: [],
  examResults: {
    total: 0,
    pass: 0,
    fail: 0,
  },
  resident: {
    boys: 0,
    girls: 0,
    total: 0,
  },
  bookInformation: {
    totalBooks: 0,
    booksOverdue: 0,
    issuedToday: "0",
    totalIssuedBooks: 0,
  },
  noticeBoard: [],
  events: [],
};

// Create a slice
const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {
    addNotice: (state, action) => {
      state.noticeBoard.push(action.payload);
    },
  },
});

// Export actions
export const { addNotice } = dashboardSlice.actions;

// Export the reducer for store configuration
export default dashboardSlice.reducer;
