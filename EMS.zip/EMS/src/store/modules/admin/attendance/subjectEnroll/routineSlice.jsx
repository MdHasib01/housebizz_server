import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

// Initial state with preloaded admission data
const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    local_class_id: "",
    group_id: "",
    section_id: "",
    day_id: "",
    period_id: "",
  },
  left_students: [],
  right_students: [],
  selected_left_students: [],
  selected_right_students: [],
  selected_students: [],
  right_search: "",
  left_search: "",
  showTable: false,
  fetchData: false,
};

const EnrollRoutineSlice = createSlice({
  name: "EnrollRoutineSlice",
  initialState,
  reducers: {
    setAllEnrollRoutineData: (state, action) => {
      state.allData = action.payload;
    },
    setEnrollRoutineData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    setSelectedEnrollRoutine: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
    openEnrollRoutineModal: (state) => {
      state.showModal = true;
    },
    closeEnrollRoutineModal: (state) => {
      state.showModal = false;
    },
    removeEnrollStudentList: (state, action) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== action.payload
      );
      state.allData = state.allData.filter(
        (item) => item._id !== action.payload
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
      state.showModal = false;
      state.selectedData = {};
    },
    setEnrollRoutinePageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    setEnrollRoutineSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    setEnrollRoutineSelectorsSubjects: (state, action) => {
      const { index, name, value } = action.payload;
      state.selectors.subjects[index][name] = value;
    },
    addEnrollRoutineSubjects: (state) => {
      state.selectors.subjects.push({
        subject_id: "",
        teacher_id: "",
        start_time: "",
        end_time: "",
      });
    },
    resetEnrollRoutineSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    setEnrollRoutineShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setEnrollRoutineFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
    setSeletedStudents: (state, action) => {
      state.selected_students = action.payload;
    },
    setLeftStudents: (state, action) => {
      const left_students = action.payload.filter(
        (item) =>
          !state.selected_students?.some((student) => student === item?._id)
      );

      const right_students = action.payload.filter((item) =>
        state.selected_students?.some((student) => student === item?._id)
      );
      state.left_students = left_students;
      state.right_students = right_students;
    },
    setAllLeftStudents: (state) => {
      if (
        state.left_students?.length === state.selected_left_students?.length
      ) {
        state.selected_left_students = [];
        return;
      }
      state.selected_left_students = state.left_students;
    },
    setAllRightStudents: (state) => {
      state.selected_right_students = state.right_students;
    },
    toggleLeftStudent: (state, action) => {
      const index = state.selected_left_students.findIndex(
        (item) => item._id === action.payload?._id
      );
      if (index > -1) {
        state.selected_left_students.splice(index, 1);
      } else {
        state.selected_left_students.push(action.payload);
      }
    },
    toggleRightStudent: (state, action) => {
      const index = state.selected_right_students.findIndex(
        (item) => item._id === action.payload?._id
      );
      if (index > -1) {
        state.selected_right_students.splice(index, 1);
      } else {
        state.selected_right_students.push(action.payload);
      }
    },
    moveLeftRightStudent: (state) => {
      state.right_students = [
        ...state.right_students,
        ...state.selected_left_students,
      ];
      state.left_students = state.left_students.filter(
        (item) =>
          !state.selected_left_students.some(
            (selected) => selected._id === item._id
          )
      );
      state.selected_left_students = [];
    },

    moveRightLeftStudent: (state) => {
      state.left_students = [
        ...state.left_students,
        ...state.selected_right_students,
      ];
      state.right_students = state.right_students.filter(
        (item) =>
          !state.selected_right_students.some(
            (selected) => selected._id === item._id
          )
      );
      state.selected_right_students = [];
    },

    setEnrollRoutineLeftSearch: (state, action) => {
      state.left_search = action.payload;
    },
    setEnrollRoutineRightSearch: (state, action) => {
      state.right_search = action.payload;
    },

    resetAllRoutineState: (state) => {
      state.selectors = {
        academic_year: "",
        local_class_id: "",
        group_id: "",
        section_id: "",
        day_id: "",
        period_id: "",
      };
      state.left_students = [];
      state.right_students = [];
      state.selected_left_students = [];
      state.selected_right_students = [];
      state.right_search = "";
      state.left_search = "";
      state.showTable = false;
      state.fetchData = false;
    },
  },
});

export const {
  setEnrollRoutineData,
  openEnrollRoutineModal,
  closeEnrollRoutineModal,
  removeEnrollStudentList,
  setEnrollRoutinePageData,
  setEnrollRoutineSelectors,
  resetEnrollRoutineSelectors,
  setEnrollRoutineShowTable,
  setEnrollRoutineFetchData,
  setSelectedEnrollRoutine,
  setEnrollRoutineSelectorsSubjects,
  addEnrollRoutineSubjects,
  setAllLeftStudents,
  setAllRightStudents,
  toggleLeftStudent,
  toggleRightStudent,
  moveLeftRightStudent,
  moveRightLeftStudent,
  setLeftStudents,
  setEnrollRoutineLeftSearch,
  setEnrollRoutineRightSearch,
  resetAllRoutineState,
  setSeletedStudents,
} = EnrollRoutineSlice.actions;
export default EnrollRoutineSlice.reducer;
