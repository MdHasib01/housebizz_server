import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

// Initial state with preloaded admission data
const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    local_class_id: "",
    group_id: "",
    section_id: "",
    day_id: "",
    period_id: "",
  },
  showTable: false,
  fetchData: false,
};

const EnrollStudentsSlice = createSlice({
  name: "EnrollStudentsSlice",
  initialState,
  reducers: {
    setAllEnrollStudentsData: (state, action) => {
      state.allData = action.payload;
    },
    setEnrollStudentsData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    setSelectedEnrollStudents: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
    openEnrollStudentsModal: (state) => {
      state.showModal = true;
    },
    closeEnrollStudentsModal: (state) => {
      state.showModal = false;
    },
    removeEnrollStudentList: (state, action) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== action.payload
      );
      state.allData = state.allData.filter(
        (item) => item._id !== action.payload
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
      state.showModal = false;
      state.selectedData = {};
    },
    setEnrollStudentsPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    setEnrollStudentsSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    setEnrollStudentsSelectorsSubjects: (state, action) => {
      const { index, name, value } = action.payload;
      state.selectors.subjects[index][name] = value;
    },
    addEnrollStudentsSubjects: (state) => {
      state.selectors.subjects.push({
        subject_id: "",
        teacher_id: "",
        start_time: "",
        end_time: "",
      });
    },
    resetEnrollStudentsSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    setEnrollStudentsShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setEnrollStudentsFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
  },
});

export const {
  setEnrollStudentsData,
  openEnrollStudentsModal,
  closeEnrollStudentsModal,
  removeEnrollStudentList,
  setEnrollStudentsPageData,
  setEnrollStudentsSelectors,
  resetEnrollStudentsSelectors,
  setEnrollStudentsShowTable,
  setEnrollStudentsFetchData,
  setSelectedEnrollStudents,
  setEnrollStudentsSelectorsSubjects,
  addEnrollStudentsSubjects,
} = EnrollStudentsSlice.actions;
export default EnrollStudentsSlice.reducer;
