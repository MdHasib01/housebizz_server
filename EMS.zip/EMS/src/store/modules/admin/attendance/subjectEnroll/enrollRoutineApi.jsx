import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setEnrollRoutineData,
  setEnrollRoutineFetchData,
  setLeftStudents,
  setSeletedStudents,
} from "./routineSlice";

export const enrollRoutineApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getEnrollFilteredRoutine: builder.query({
      query: ({ query = null }) =>
        `/routines/filtered-for-subject-enroll?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setEnrollRoutineData(data?.data));
          dispatch(setEnrollRoutineFetchData(false));
        } catch (error) {
          dispatch(setEnrollRoutineFetchData(false));
        }
      },
    }),
    getEnrollRoutineStudents: builder.query({
      query: ({ query = null }) => `/students/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setLeftStudents(data?.data));
        } catch (error) {}
      },
    }),
    getEnrolledStudents: builder.query({
      query: ({ query = null }) => `/subject-enrolls/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const students = data?.data[0]?.students?.map(
            (student) => student?._id
          );
          dispatch(setSeletedStudents(students));
        } catch (error) {}
      },
    }),
    deleteEnrollRoutine: builder.mutation({
      query: ({ query }) => ({
        url: `/students/delete${query}`,
        method: "DELETE",
      }),
    }),

    addSubjectEnroll: builder.mutation({
      query: (data) => ({
        url: "/subject-enrolls/add-or-update",
        method: "POST",
        body: data,
      }),
    }),
  }),
});

export const {
  useGetEnrollFilteredRoutineQuery,
  useDeleteEnrollRoutineMutation,
  useGetEnrollRoutineStudentsQuery,
  useAddSubjectEnrollMutation,
  useGetEnrolledStudentsQuery,
} = enrollRoutineApi;
