import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setEnrollStudentsData,
  setEnrollStudentsFetchData,
} from "./studentsSlice";

export const enrollStudentApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getEnrollFilteredStudents: builder.query({
      query: ({ query = null }) => `/students/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setEnrollStudentsData(data?.data));
          dispatch(setEnrollStudentsFetchData(false));
        } catch (error) {
          dispatch(setEnrollStudentsFetchData(false));
        }
      },
    }),
    deleteEnrollStudent: builder.mutation({
      query: ({ query }) => ({
        url: `/students/delete${query}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useGetEnrollFilteredStudentsQuery,
  useDeleteEnrollStudentMutation,
} = enrollStudentApi;
