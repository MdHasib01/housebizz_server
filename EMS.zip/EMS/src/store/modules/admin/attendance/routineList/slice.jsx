import { createSlice } from "@reduxjs/toolkit";

const routineListSlice = createSlice({
  name: "routineList",
  initialState: {
    routines: [
      {
        teacherId: 1,
        name: "John Doe",
        period: 1,
        day: "Monday",
        class: "Seven",
        section: "A",
        subject: "Mathematics",
        year: 2024,
      },
      {
        teacherId: 2,
        name: "Jane Smith",
        period: 1,
        day: "Monday",
        class: "Seven",
        section: "A",
        subject: "Science",
        year: 2024,
      },
      {
        teacherId: 3,
        name: "Samuel Green",
        period: 1,
        day: "Tuesday",
        class: "Seven",
        section: "B",
        subject: "Physics",
        year: 2024,
      },
      {
        teacherId: 4,
        name: "Emily Brown",
        period: 1,
        day: "Tuesday",
        class: "Seven",
        section: "B",
        subject: "Chemistry",
        year: 2024,
      },
      {
        teacherId: 5,
        name: "Michael Johnson",
        period: 1,
        day: "Wednesday",
        class: "Seven",
        section: "C",
        subject: "Biology",
        year: 2024,
      },
      {
        teacherId: 6,
        name: "Olivia Davis",
        period: 1,
        day: "Wednesday",
        class: "Seven",
        section: "C",
        subject: "History",
        year: 2024,
      },
    ],
    filteredRoutines: [],
  },
  reducers: {
    filterRoutineList: (state, action) => {
      const { year, class: classFilter, section } = action.payload;
      state.filteredRoutines = state.routines.filter((routine) => {
        return (
          routine.year === year ||
          routine.class.toLowerCase() === classFilter?.toLowerCase() ||
          routine.section.toLowerCase() === section?.toLowerCase()
        );
      });
    },
  },
});

export const { filterRoutineList } = routineListSlice.actions;
export default routineListSlice.reducer;
