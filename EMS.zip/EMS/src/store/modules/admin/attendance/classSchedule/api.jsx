import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setClassScheduleData,
  setClassScheduleFetchData,
  setClassScheduleSelectors,
} from "./slice";

export const adminClassScheduleApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getClassRoutine: builder.query({
      query: ({ query = null }) => `/routines/find${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          const subjects = results?.subjects?.map((subject) => ({
            subject_id: subject?.subject_id?._id,
            teacher_id: subject?.teacher_id?._id,
            start_time: subject?.start_time,
            end_time: subject?.end_time,
          }));
          const selectors = {
            academic_year: results?.academic_year,
            local_class_id: `${results?.local_class_id?.local_class_code}-${results?.local_class_id?._id}`,
            section_id: results?.section_id?._id,
            day_id: results?.day_id?._id,
            period_id: results?.period_id?._id,
            subjects: [...subjects],
          };
          dispatch(setClassScheduleSelectors(selectors));
        } catch (error) {}
      },
    }),
    getClassSchedules: builder.query({
      query: ({ query = null }) => `/routines/filtered${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setClassScheduleData(data?.data));
          dispatch(setClassScheduleFetchData(false));
        } catch (error) {
          dispatch(setClassScheduleFetchData(false));
        }
      },
    }),
    addClassRoutine: builder.mutation({
      query: (data) => ({
        url: "/routines/add",
        method: "POST",
        body: data,
      }),
    }),
    updateClassRoutine: builder.mutation({
      query: ({ data, query }) => ({
        url: `/routines/update${query}`,
        method: "PATCH",
        body: data,
      }),
    }),
    deleteClassRoutine: builder.mutation({
      query: (query) => ({
        url: `routines/delete?${query}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useGetClassSchedulesQuery,
  useAddClassRoutineMutation,
  useDeleteClassRoutineMutation,
  useGetClassRoutineQuery,
  useUpdateClassRoutineMutation,
} = adminClassScheduleApi;
