import { createSlice } from "@reduxjs/toolkit";

// Initial state with preloaded admission data
const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    local_class_id: "",
    group_id: "",
    section_id: "",
    day_id: "",
    period_id: "",
    subjects: [
      {
        subject_id: "",
        teacher_id: "",
        start_time: "",
        end_time: "",
      },
    ],
  },
  showTable: false,
  fetchData: false,
};

const classScheduleSlice = createSlice({
  name: "classScheduleSlice",
  initialState,
  reducers: {
    setAllClassScheduleData: (state, action) => {
      state.allData = action.payload;
    },
    setClassScheduleData: (state, action) => {
      state.dataLists = action.payload;
    },
    setSelectedClassSchedule: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
    openClassScheduleModal: (state) => {
      state.showModal = true;
    },
    closeClassScheduleModal: (state) => {
      state.showModal = false;
    },

    addClassRoutineList: (state, action) => {
      const data = action.payload;
      state.dataLists = [data, ...state.dataLists];
    },
    updateClassRoutineList: (state, action) => {
      state.dataLists = state.dataLists.map((item) =>
        item._id === action.payload?._id ? action.payload : item
      );
    },
    removeClassRoutineList: (state, action) => {
      const routineId = action.payload;
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== routineId
      );
      state.showModal = false;
    },
    setClassScheduleSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    setClassScheduleSelectorsSubjects: (state, action) => {
      const { index, name, value } = action.payload;
      state.selectors.subjects[index][name] = value;
    },
    addClassScheduleSubjects: (state) => {
      state.selectors.subjects.push({
        subject_id: "",
        teacher_id: "",
        start_time: "",
        end_time: "",
      });
    },

    removeClassScheduleSubject: (state, action) => {
      const index = action.payload;
      state.selectors.subjects.splice(index, 1);
    },

    resetClassScheduleSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    resetAddClassScheduleSelectors: (state) => {
      state.selectors = {
        ...state.selectors,
        day_id: "",
        period_id: "",
        subjects: [
          {
            subject_id: "",
            teacher_id: "",
            start_time: "",
            end_time: "",
          },
        ],
      };
    },
    setClassScheduleShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setClassScheduleFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
  },
});

export const {
  setClassScheduleData,
  openClassScheduleModal,
  closeClassScheduleModal,
  removeClassRoutineList,
  setClassScheduleSelectors,
  resetClassScheduleSelectors,
  setClassScheduleShowTable,
  setClassScheduleFetchData,
  setSelectedClassSchedule,
  setClassScheduleSelectorsSubjects,
  addClassScheduleSubjects,
  resetAddClassScheduleSelectors,
  addClassRoutineList,
  updateClassRoutineList,
  removeClassScheduleSubject,
} = classScheduleSlice.actions;
export default classScheduleSlice.reducer;
