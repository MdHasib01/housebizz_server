import { apiSlice } from "@/store/modules/api/apiSlice";

export const adminStudentListApi = apiSlice.injectEndpoints({
  endpoints: (_builder) => ({}),
});

export const {} = adminStudentListApi;
