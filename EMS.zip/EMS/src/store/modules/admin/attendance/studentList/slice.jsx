import { createSlice } from "@reduxjs/toolkit";

const studentListSlice = createSlice({
  name: "studentList",
  initialState: {
    students: [
      {
        id: 1,
        name: "John Doe",
        rollNo: 101,
        enrollStatus: "Enrolled",
        class: 7,
        section: "A",
        subject: "Math",
        year: 2022,
      },
      {
        id: 2,
        name: "Jane Smith",
        rollNo: 102,
        enrollStatus: "Enrolled",
        class: 7,
        section: "A",
        subject: "Science",
        year: 2022,
      },
      {
        id: 3,
        name: "Samuel Green",
        rollNo: 103,
        enrollStatus: "Pending",
        class: 7,
        section: "B",
        subject: "Physics",
        year: 2022,
      },
      {
        id: 4,
        name: "Emily Brown",
        rollNo: 104,
        enrollStatus: "Enrolled",
        class: 7,
        section: "B",
        subject: "Chemistry",
        year: 2022,
      },
      {
        id: 5,
        name: "Michael Johnson",
        rollNo: 105,
        enrollStatus: "Enrolled",
        class: 7,
        section: "C",
        subject: "Biology",
        year: 2022,
      },
      {
        id: 6,
        name: "Olivia Davis",
        rollNo: 106,
        enrollStatus: "Pending",
        class: 7,
        section: "C",
        subject: "History",
        year: 2022,
      },
    ],
    filteredStudents: [],
  },
  reducers: {
    filterStudentList: (state, action) => {
      const { year, class: classFilter, section, subject } = action.payload;
      state.filteredStudents = state.students.filter((student) => {
        return (
          student.year === year ||
          student.class === classFilter ||
          student.section.toLowerCase() === section?.toLowerCase() ||
          student.subject.toLowerCase() === subject?.toLowerCase()
        );
      });
    },
  },
});

export const { filterStudentList } = studentListSlice.actions;
export default studentListSlice.reducer;
