import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setClassAttendanceData,
  setClassAttendanceFetchData,
  setSelectAllAttendance,
} from "./slice";

export const adminClassAttendenceApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getClassAttendance: builder.query({
      query: (query) => ({
        url: `/class-attendances/filtered?${query}`,
        method: "GET",
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setSelectAllAttendance(data.data));
          dispatch(setClassAttendanceFetchData(false));
        } catch (error) {
          dispatch(setClassAttendanceFetchData(false));
        }
      },
    }),
    getClassAttendanceStudents: builder.query({
      query: (query) => ({
        url: `/students/filtered?${query}`,
        method: "GET",
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setClassAttendanceData(data?.data));
          dispatch(setClassAttendanceFetchData(false));
        } catch (error) {
          dispatch(setClassAttendanceFetchData(false));
        }
      },
    }),
  }),
});

export const {
  useGetClassAttendanceQuery,
  useGetClassAttendanceStudentsQuery,
} = adminClassAttendenceApi;
