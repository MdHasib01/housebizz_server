import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

// Initial state with preloaded admission data
export const initialState = {
  attendance: [],
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    local_class_id: "",
    group_id: "",
    section_id: "",
    month: "",
    subject_id: "",
  },
  showTable: false,
  fetchData: false,
  studentDayAttendance: {
    totalPresent: 0,
    totalAbsent: 0,
    totalLeave: 0,
    attendance: [],
  },
};

const classAttendanceSlice = createSlice({
  name: "classAttendanceSlice",
  initialState,
  reducers: {
    setSelectAllAttendance: (state, action) => {
      state.attendance = action.payload;
    },
    setAllClassAttendanceData: (state, action) => {
      state.allData = action.payload;
    },
    setClassAttendanceData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },

    setClassAttendancePageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    setClassAttendanceSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },

    resetClassAttendanceSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    setClassAttendanceShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setClassAttendanceFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
    setStudentDayAttendance: (state, action) => {
      state.studentDayAttendance = action.payload;
    },
  },
});

export const {
  setSelectAllAttendance,
  setAllClassAttendanceData,
  setClassAttendanceData,
  setClassAttendancePageData,
  setClassAttendanceSelectors,
  resetClassAttendanceSelectors,
  setClassAttendanceShowTable,
  setClassAttendanceFetchData,
  setStudentDayAttendance,
} = classAttendanceSlice.actions;
export default classAttendanceSlice.reducer;
