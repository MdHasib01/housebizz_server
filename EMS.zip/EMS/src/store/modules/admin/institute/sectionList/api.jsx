import { apiSlice } from "@/store/modules/api/apiSlice";
import { setAllSectionData, setSectionData, setSectionPageData } from "./slice";

export const adminSectionListApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addSection: builder.mutation({
      query: (data) => ({
        url: "/sections/add",
        method: "POST",
        body: data,
      }),
    }),

    getAllSections: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/sections/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllSectionData(results));
        } catch (error) {}
      },
    }),

    getSections: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/sections/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setSectionData({ data: results, meta: data?.meta }));
          dispatch(setSectionPageData(data?.meta));
        } catch (error) {}
      },
    }),

    updateSection: builder.mutation({
      query: ({ institute_id = "", section_id = "", data }) => ({
        url: `/sections/update?institute_id=${institute_id}&section_id=${section_id}`,
        method: "PATCH",
        body: data,
      }),
    }),

    deleteSection: builder.mutation({
      query: ({ institute_id = "", section_id = "" }) => ({
        url: `/sections/delete?institute_id=${institute_id}&section_id=${section_id}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useAddSectionMutation,
  useGetSectionsQuery,
  useUpdateSectionMutation,
  useDeleteSectionMutation,
  useGetAllSectionsQuery,
} = adminSectionListApi;
