import { apiSlice } from "@/store/modules/api/apiSlice";
import { setAllDayData, setDayData, setDayPageData } from "./slice";

export const adminDayApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addDay: builder.mutation({
      query: (data) => ({
        url: "/days/add",
        method: "POST",
        body: data,
      }),
    }),

    getAllDays: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/days/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllDayData(results));
        } catch (error) {}
      },
    }),

    getDays: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/days/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setDayData({ data: results, meta: data?.meta }));
          dispatch(setDayPageData(data?.meta));
        } catch (error) {}
      },
    }),

    deleteDay: builder.mutation({
      query: ({ institute_id = "", day_id = "" }) => ({
        url: `/days/delete?institute_id=${institute_id}&day_id=${day_id}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useAddDayMutation,
  useGetDaysQuery,
  useDeleteDayMutation,
  useGetAllDaysQuery,
} = adminDayApi;
