import { apiSlice } from "@/store/modules/api/apiSlice";
import { setAllLocalClassShiftData, setShiftData, setShiftPageData } from "./slice";

export const adminSchdeduleShiftApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addShift: builder.mutation({
      query: (data) => ({
        url: "/shifts/add",
        method: "POST",
        body: data,
      }),
    }),

    getShifts: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/shifts/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setShiftData({ data: results, meta: data?.meta }));
          dispatch(setShiftPageData(data?.meta));
        } catch (error) {}
      },
    }),

    getAllLocalShifts: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/shifts/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllLocalClassShiftData(results));
        } catch (error) {}
      },
    }),

    updateShift: builder.mutation({
      query: ({ institute_id = "", shift_id = "", data }) => ({
        url: `/shifts/update?institute_id=${institute_id}&shift_id=${shift_id}`,
        method: "PATCH",
        body: data,
      }),
    }),

    deleteShift: builder.mutation({
      query: ({ institute_id = "", shift_id = "" }) => ({
        url: `/shifts/delete?institute_id=${institute_id}&shift_id=${shift_id}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useAddShiftMutation,
  useGetShiftsQuery,
  useGetAllLocalShiftsQuery,
  useDeleteShiftMutation,
  useUpdateShiftMutation,
} = adminSchdeduleShiftApi;
