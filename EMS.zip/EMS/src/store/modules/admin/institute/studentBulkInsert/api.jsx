import { apiSlice } from "@/store/modules/api/apiSlice";

export const adminStudentBulkApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addBulkStudents: builder.mutation({
      query: (data) => ({
        url: "/students/bulk-add",
        method: "POST",
        body: data,
      }),
    }),
  }),
});

export const { useAddBulkStudentsMutation } = adminStudentBulkApi;
