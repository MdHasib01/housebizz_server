import { filterUndefined, getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    current_group: "",
    current_section: "",
    current_category: "",
    current_class: "",
    religion: "",
    blood_group: "",
    disability: "No",
    gender: "",
    date_of_birth: {
      startDate: null,
      endDate: null,
    },
  },
  showTable: false,
  showCsvUploader: false,
};

const studentBulkInsertSlice = createSlice({
  name: "studentBulkInsertSlice",
  initialState,
  reducers: {
    setAllStudentBulkData: (state, action) => {
      state.allData = action.payload;
    },
    setStudentBulkData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    setSelectedStudentBulk: (state, action) => {
      state.selectedData = action.payload;
    },
    openStudentBulkModal: (state) => {
      state.showModal = true;
    },
    closeStudentBulkModal: (state) => {
      state.showModal = false;
    },
    setStudentBulkPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    setStudentBulkSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },

    resetStudentBulkSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    setStudentBulkShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setStudentBulkShowCsv: (state, action) => {
      state.showCsvUploader = action.payload;
    },
    removeStudentList: (state, action) => {
      const index = action.payload;
      state.allData.splice(index, 1);
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    updateBulkStudent: (state, action) => {
      const { index = 0, dataIndex = 0, ...rest } = action.payload;
      const data = filterUndefined(rest);
      state.allData[index] = { ...state.allData[index], ...data };
      state.dataLists[dataIndex] = { ...state.dataLists[dataIndex], ...data };
      state.selectedData = {};
    },
  },
});

export const {
  setAllStudentBulkData,
  setStudentBulkData,
  setSelectedStudentBulk,
  openStudentBulkModal,
  closeStudentBulkModal,
  setStudentBulkPageData,
  setStudentBulkSelectors,
  resetStudentBulkSelectors,
  setStudentBulkShowTable,
  removeStudentList,
  setStudentBulkShowCsv,
  updateBulkStudent,
} = studentBulkInsertSlice.actions;
export default studentBulkInsertSlice.reducer;
