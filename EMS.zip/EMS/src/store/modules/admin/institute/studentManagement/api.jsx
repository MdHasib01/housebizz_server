import { envConfig } from "@/services";
import { apiSlice } from "@/store/modules/api/apiSlice";
import moment from "moment";
import { exportToExcel } from "react-json-to-excel";
import {
  setSelectedStudentManagement,
  setStudentManagementData,
  setStudentManagementFetchData,
  setStudentManagementImage,
  setStudentManagementSelectors,
} from "./slice";

export const adminStudentManagementApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getStudent: builder.query({
      query: ({ query = null }) => `/students/find?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          const date = moment(results?.date_of_birth).format("YYYY-MM-DD");
          const selectors = {
            academic_year: results?.academic_year,
            current_group: results?.current_group?._id,
            current_section: results?.current_section?._id,
            current_category: results?.current_category?._id,
            current_class: results?.current_class?.local_class_code
              ? `${results?.current_class?.local_class_code}-${results?.current_class?._id}`
              : "",
            religion: results?.religion,
            blood_group: results?.blood_group,
            disability: results?.disability,
            gender: results?.gender,
            date_of_birth: {
              startDate: date,
              endDate: date,
            },
          };
          dispatch(setSelectedStudentManagement(results));
          dispatch(setStudentManagementSelectors(selectors));
          dispatch(setStudentManagementImage({ fileUrl: results?.image }));
        } catch (error) {}
      },
    }),
    getFilteredStudents: builder.query({
      query: ({ query = null }) => `/students/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setStudentManagementData(data?.data));
          dispatch(setStudentManagementFetchData(false));
        } catch (error) {
          dispatch(setStudentManagementFetchData(false));
        }
      },
    }),
    addStudent: builder.mutation({
      query: (data) => ({
        url: "/students/add",
        method: "POST",
        body: data,
      }),
    }),
    updateStudent: builder.mutation({
      query: ({ data, query }) => ({
        url: `/students/update?${query}`,
        method: "PATCH",
        body: data,
      }),
    }),
    deleteStudent: builder.mutation({
      query: (query) => ({
        url: `/students/delete${query}`,
        method: "DELETE",
      }),
    }),
    studentBulkAction: builder.mutation({
      async queryFn(_arg, _queryApi, _extraOptions) {
        const { getState, dispatch } = _queryApi;
        const { auth } = getState()?.auth || {};
        const { students, student_ids } =
          getState()?.adminStudentManagement || {};
        const baseUrl = envConfig.baseUrl;
        const institute_id = auth?.institute?.institute_id;
        try {
          const formData = new FormData();
          formData.append(
            "data",
            JSON.stringify({
              student_ids: [...student_ids],
            })
          );
          if (_arg === "export") {
            exportToExcel(students, "Student List");
          } else {
            const enpoint =
              _arg === "remove" ? `bulk-delete` : `bulk-update-password`;
            const method = _arg === "remove" ? "DELETE" : "PATCH";
            const fetchUrl = `${baseUrl}/students/${enpoint}?institute_id=${institute_id}`;
            const fetchOptions = {
              method: method,
              headers: {
                Authorization: `Bearer ${auth?.token}`,
              },
              body: formData,
            };
            const response = await fetch(fetchUrl, fetchOptions);
            const data = await response.json();
            if (!response.ok) {
              return {
                error: data,
              };
            }
          }

          return {
            data: {},
          };
        } catch (error) {
          return { error: error };
        }
      },
    }),
  }),
});

export const {
  useAddStudentMutation,
  useGetFilteredStudentsQuery,
  useDeleteStudentMutation,
  useGetStudentQuery,
  useUpdateStudentMutation,
  useStudentBulkActionMutation,
} = adminStudentManagementApi;
