import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

// Initial state with preloaded admission data
const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    current_group: "",
    current_section: "",
    current_category: "",
    current_class: "",
    religion: "",
    blood_group: "",
    disability: "No",
    gender: "",
    date_of_birth: {
      startDate: null,
      endDate: null,
    },
  },
  student_ids: [],
  students: [],
  searchValue: "",
  image: {},
  showTable: false,
  fetchData: false,
};

const studentManagementSlice = createSlice({
  name: "studentManagementSlice",
  initialState,
  reducers: {
    setAllStudentManagementData: (state, action) => {
      state.allData = action.payload;
    },
    setStudentManagementData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    setSelectedStudentManagement: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
    openStudentManagementModal: (state) => {
      state.showModal = true;
    },
    closeStudentManagementModal: (state) => {
      state.showModal = false;
    },
    setStudentManagementPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    setStudentManagementSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    setStudentManagementSelectorsSubjects: (state, action) => {
      const { index, name, value } = action.payload;
      state.selectors.subjects[index][name] = value;
    },
    setStudentManagementImage: (state, action) => {
      state.image = action.payload;
    },
    addStudentManagementSubjects: (state) => {
      state.selectors.subjects.push({
        subject_id: "",
        teacher_id: "",
        start_time: "",
        end_time: "",
      });
    },
    resetStudentManagementSelectors: (state) => {
      state.selectors = initialState.selectors;
      state.showTable = false;
      state.fetchData = false;
    },
    setStudentManagementShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setStudentManagementFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
    removeStudentList: (state) => {
      state.allData = state.allData.filter(
        (item) => item?._id !== state.selectedData?._id
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    removeBulkStudentList: (state) => {
      state.allData = state.allData.filter(
        (item) => !state.student_ids.includes(item?._id)
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },
    resetStudentSelection: (state) => {
      state.student_ids = [];
      state.students = [];
    },
    selectAllStudentManagement: (state) => {
      const dataLength = state.dataLists.length;
      const selectedLength = state.student_ids.length;
      if (dataLength === selectedLength) {
        state.student_ids = [];
        state.students = [];
      } else {
        state.students = state.dataLists;
        state.student_ids = state.dataLists.map((item) => item._id);
      }
    },
    toggleSelectedStudentManagement: (state, action) => {
      const index = state.student_ids.findIndex(
        (item) => item === action.payload?._id
      );
      if (index === -1) {
        state.student_ids.push(action.payload?._id);
        state.students.push(action.payload);
      } else {
        state.student_ids.splice(index, 1);
        state.students.splice(index, 1);
      }
    },
    setStudentManagementSearchValue: (state, action) => {
      state.searchValue = action.payload;
      const newData = [...state.allData];
      const data = newData?.filter((item) => {
        if (action.payload?.trim() === "") return true;
        return (
          item?.username
            ?.toLowerCase()
            .startsWith(action.payload?.toLowerCase()) ||
          item?.current_roll_number?.toString()?.startsWith(action.payload) ||
          item?.name_english
            ?.toLowerCase()
            .includes(action.payload?.toLowerCase())
          // item?.mobile_number?.toLowerCase()
          //   .includes(action.payload?.toLowerCase()) ||
          // item?.father_name_english
          //   ?.toLowerCase()
          //   .includes(action.payload?.toLowerCase()) ||
          // item?.father_name_bangla
          //   ?.toLowerCase()
          //   .includes(action.payload?.toLowerCase()) ||
          // item?.mother_name_english
          //   ?.toLowerCase()
          //   .includes(action.payload?.toLowerCase()) ||
          // item?.mother_name_bangla
          //   ?.toLowerCase()
          //   .includes(action.payload?.toLowerCase())
        );
      });
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
      state.dataLists = currentRows;
    },
  },
});

export const {
  setStudentManagementData,
  openStudentManagementModal,
  closeStudentManagementModal,
  setStudentManagementPageData,
  setStudentManagementSelectors,
  resetStudentManagementSelectors,
  setStudentManagementShowTable,
  setStudentManagementFetchData,
  setSelectedStudentManagement,
  setStudentManagementSelectorsSubjects,
  addStudentManagementSubjects,
  selectAllStudentManagement,
  toggleSelectedStudentManagement,
  setStudentManagementSearchValue,
  removeStudentList,
  setStudentManagementImage,
  removeBulkStudentList,
  resetStudentSelection
} = studentManagementSlice.actions;
export default studentManagementSlice.reducer;
