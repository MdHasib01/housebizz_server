import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setAllCategories,
  setCategoryData,
  setCategoryPageData,
} from "./slice";

export const adminCategoryApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addCategory: builder.mutation({
      query: (data) => ({
        url: "/local-categories/add",
        method: "POST",
        body: data,
      }),
    }),
    getAllCategories: builder.query({
      query: ({ institute_id = "", page = 1, limit = 50 }) =>
        `/local-categories/all?institute_id=${institute_id}&page=${page}&limit=${limit}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllCategories(results));
        } catch (error) {}
      },
    }),

    getCategories: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/local-categories/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setCategoryData({ data: results, meta: data?.meta }));
          dispatch(setCategoryPageData(data?.meta));
        } catch (error) {}
      },
    }),

    deleteCategory: builder.mutation({
      query: ({ institute_id = "", local_category_id = "" }) => ({
        url: `/local-categories/delete?institute_id=${institute_id}&local_category_id=${local_category_id}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useAddCategoryMutation,
  useGetCategoriesQuery,
  useDeleteCategoryMutation,
  useGetAllCategoriesQuery,
} = adminCategoryApi;
