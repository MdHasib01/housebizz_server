import { apiSlice } from "@/store/modules/api/apiSlice";
import { setAllLocalClassData, setClassData, setClassPageData } from "./slice";

export const adminClassApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addLocalClass: builder.mutation({
      query: (data) => ({
        url: "/local-classes/add",
        method: "POST",
        body: data,
      }),
    }),

    getClasses: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/local-classes/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setClassData({ data: results, meta: data?.meta }));
          dispatch(setClassPageData(data?.meta));
        } catch (error) {}
      },
    }),

    getAllLocalClasses: builder.query({
      query: ({ institute_id = "", page = 1, limit = 50 }) =>
        `/local-classes/all?institute_id=${institute_id}&page=${page}&limit=${limit}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllLocalClassData(results));
        } catch (error) {}
      },
    }),

    deleteLocalClass: builder.mutation({
      query: ({ institute_id = "", local_class_id = "" }) => ({
        url: `/local-classes/delete?institute_id=${institute_id}&local_class_id=${local_class_id}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useGetAllLocalClassesQuery,
  useAddLocalClassMutation,
  useGetClassesQuery,
  useDeleteLocalClassMutation,
} = adminClassApi;
