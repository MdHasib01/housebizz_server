// Redux Slice
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  status: [
    {
      class: "Six",
      total: 300,
      year: 2024,
      sections: [
        {
          section: "Golap A",
          total: 150,
          categories: [
            { category: "Civil", boys: 30, girls: 29, total: 59 },
            { category: "Half Free", boys: 46, girls: 54, total: 100 },
            { category: "25%", boys: 39, girls: 42, total: 81 },
          ],
        },
        {
          section: "Hasnahena B",
          total: 150,
          categories: [
            { category: "Civil", boys: 32, girls: 31, total: 63 },
            { category: "Half Free", boys: 51, girls: 50, total: 101 },
            { category: "25%", boys: 40, girls: 39, total: 79 },
          ],
        },
      ],
    },
    {
      class: "Seven",
      total: 300,
      year: 2024,
      sections: [
        {
          section: "Golap A",
          total: 150,
          categories: [
            { category: "Civil", boys: 30, girls: 29, total: 59 },
            { category: "Half Free", boys: 46, girls: 54, total: 100 },
            { category: "25%", boys: 39, girls: 42, total: 81 },
          ],
        },
        {
          section: "Hasnahena B",
          total: 150,
          categories: [
            { category: "Civil", boys: 32, girls: 31, total: 63 },
            { category: "Half Free", boys: 51, girls: 50, total: 101 },
            { category: "25%", boys: 40, girls: 39, total: 79 },
          ],
        },
      ],
    },
    {
      class: "Eight",
      total: 300,
      year: 2024,
      sections: [
        {
          section: "Golap A",
          total: 150,
          categories: [
            { category: "Civil", boys: 30, girls: 29, total: 59 },
            { category: "Half Free", boys: 46, girls: 54, total: 100 },
            { category: "25%", boys: 39, girls: 42, total: 81 },
          ],
        },
        {
          section: "Hasnahena B",
          total: 150,
          categories: [
            { category: "Civil", boys: 32, girls: 31, total: 63 },
            { category: "Half Free", boys: 51, girls: 50, total: 101 },
            { category: "25%", boys: 40, girls: 39, total: 79 },
          ],
        },
        {
          section: "Bell C",
          total: 150,
          categories: [
            { category: "Civil", boys: 32, girls: 31, total: 63 },
            { category: "Half Free", boys: 51, girls: 50, total: 101 },
            { category: "25%", boys: 40, girls: 39, total: 79 },
          ],
        },
      ],
    },
    {
      class: "Nine",
      total: 300,
      year: 2024,
      sections: [
        {
          section: "Golap A",
          total: 150,
          categories: [
            { category: "Civil", boys: 30, girls: 29, total: 59 },
            { category: "Half Free", boys: 46, girls: 54, total: 100 },
            { category: "25%", boys: 39, girls: 42, total: 81 },
          ],
        },
        {
          section: "Hasnahena B",
          total: 150,
          categories: [
            { category: "Civil", boys: 32, girls: 31, total: 63 },
            { category: "Half Free", boys: 51, girls: 50, total: 101 },
            { category: "25%", boys: 40, girls: 39, total: 79 },
          ],
        },
      ],
    },
    {
      class: "Ten",
      total: 300,
      year: 2024,
      sections: [
        {
          section: "Golap A",
          total: 150,
          categories: [
            { category: "Civil", boys: 30, girls: 29, total: 59 },
            { category: "Half Free", boys: 46, girls: 54, total: 100 },
            { category: "25%", boys: 39, girls: 42, total: 81 },
          ],
        },
        {
          section: "Hasnahena B",
          total: 150,
          categories: [
            { category: "Civil", boys: 32, girls: 31, total: 63 },
            { category: "Half Free", boys: 51, girls: 50, total: 101 },
            { category: "25%", boys: 40, girls: 39, total: 79 },
          ],
        },
      ],
    },
  ],
  filteredStatus: [],
};

const studentStatusSlice = createSlice({
  name: "studentStatus",
  initialState,
  reducers: {
    filterStatusByYear: (state, action) => {
      state.filteredStatus = state.status.filter(
        (item) => item.year === action.payload.year
      );
    },
  },
});

export const { filterStatusByYear } = studentStatusSlice.actions;
export default studentStatusSlice.reducer;
