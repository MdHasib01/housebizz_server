import {
  envConfig,
  getStudentProccessedData,
  getStudentStatus,
} from "@/services";
import { apiSlice } from "@/store/modules/api/apiSlice";

export const adminStudentStatusApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getStudentStatus: builder.query({
      async queryFn(_arg, _queryApi, _extraOptions, fetchWithBQ) {
        try {
          const { getState } = _queryApi;
          const { auth } = getState()?.auth || {};
          const baseUrl = envConfig.baseUrl;
          const page = 1;
          const limit = 999;

          const urls = [
            `${baseUrl}/students/filtered?institute_id=${auth?.institute?.institute_id}&academic_year=${_arg}`,
            `${baseUrl}/sections/all?institute_id=${auth?.institute?.institute_id}&page=${page}&limit=${limit}`,
            `${baseUrl}/local-categories/all?institute_id=${auth?.institute?.institute_id}&page=${page}&limit=${limit}`,
            `${baseUrl}/local-classes/all?institute_id=${auth?.institute?.institute_id}&page=${page}&limit=${limit}`,
          ];

          const fetchOptions = {
            method: "GET",
            headers: {
              Authorization: `Bearer ${auth?.token}`,
            },
          };

          const [studentRes, sectionRes, categoryRes, classRes] =
            await Promise.all(
              urls.map((url) => fetchWithBQ(url, fetchOptions))
            );

          const { data: students } = studentRes?.data || {};
          const { data: sections } = sectionRes?.data || {};
          const { data: categories } = categoryRes?.data || {};
          const { data: classes } = classRes?.data || {};

          const status = getStudentStatus({
            students,
            sections,
            categories,
            classes,
          });

          const data = getStudentProccessedData([...(status || [])]);

          return {
            data: {
              data: data,
            },
          };
        } catch (error) {
          return { error: error };
        }
      },
    }),
  }),
});

export const { useGetStudentStatusQuery } = adminStudentStatusApi;
