import { apiSlice } from "@/store/modules/api/apiSlice";
import {
  setAllTeacherData,
  setSelectedTeacher,
  setSelectors,
  setTeacherData,
  setTeacherImage,
  setTeacherPageData,
} from "./slice";

export const adminTeacherManagementApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAllTeachers: builder.query({
      query: ({ institute_id }) =>
        `/teachers/filtered?institute_id=${institute_id}&status=available`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllTeacherData(results));
        } catch (error) {}
      },
    }),
    getTeachers: builder.query({
      query: ({ page = 1, limit = 50, institute_id = null }) =>
        `/teachers/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setTeacherData({ data: results, meta: data?.meta }));
          dispatch(setTeacherPageData(data?.meta));
        } catch (error) {}
      },
    }),
    getTeacher: builder.query({
      query: ({ teacher_id = null, institute_id = null }) =>
        `/teachers/find?institute_id=${institute_id}&teacher_id=${teacher_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setSelectedTeacher(results));
          const selectors = {
            gender: results?.gender,
            status: results?.status,
            contract_type: results?.contract_type,
          };
          const image = results?.image;
          dispatch(setSelectors(selectors));
          dispatch(setTeacherImage({ fileUrl: image }));
        } catch (error) {}
      },
    }),
    addTeacher: builder.mutation({
      query: (data) => ({
        url: "/teachers/add",
        method: "POST",
        body: data,
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (error) {}
        // Add loading state management here
      },
    }),
    updateTeacher: builder.mutation({
      query: ({ data, query }) => ({
        url: `/teachers/update/${query}`,
        method: "PATCH",
        body: data,
      }),
    }),
    deleteTeacher: builder.mutation({
      query: ({ query }) => ({
        url: `/teachers/delete/${query}`,
        method: "DELETE",
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (error) {}
        // Add loading state management here
      },
    }),
  }),
});

export const {
  useGetAllTeachersQuery,
  useGetTeachersQuery,
  useAddTeacherMutation,
  useUpdateTeacherMutation,
  useDeleteTeacherMutation,
  useGetTeacherQuery,
} = adminTeacherManagementApi;
