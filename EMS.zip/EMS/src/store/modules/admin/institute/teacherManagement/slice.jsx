import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  image: {},
  selectors: {
    gender: "Male",
    status: "available",
    contract_type: "permanent",
  },
  selectedTeachers: [],
};

const teacherManagementSlice = createSlice({
  name: "teacherManagementSlice",
  initialState,
  reducers: {
    setAllTeacherData: (state, action) => {
      state.allData = action.payload;
    },
    setTeachers: (state, action) => {
      state.dataLists = action.payload;
    },
    setTeacherData: (state, action) => {
      const { data, meta } = action.payload;
      if (meta?.totalPages === 0) {
        return;
      }
      if (meta?.currentPage <= meta?.totalPages) {
        state.data[`page${meta?.currentPage}`] = data;
        state.dataLists = data;
      } else {
        const otherData = state.data[`page${state.pageData.currentPage}`];
        const sliceData = otherData.slice(0, meta?.pageSize);
        const currentPage = meta?.currentPage - meta?.totalPages;
        const page = meta?.currentPage - currentPage;
        state.dataLists = [...sliceData];
        state.pageData.currentPage = page;
        state.pageData.totalPages = meta?.totalPages;
      }
    },
    addTeacher: (state, action) => {
      state.dataLists.push(action.payload);
    },
    setSelectedTeacher: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
    updateSelectedTeacher: (state, action) => {
      const { name, value } = action.payload;
      state.selectedData[name] = value;
    },
    openTeacherModal: (state) => {
      state.showModal = true;
    },
    closeTeacherModal: (state) => {
      state.showModal = false;
    },
    addTeacherList: (state, action) => {
      const { totalPages, pageSize, currentPage } = state.pageData;
      const pageIndex = totalPages === 0 ? 1 : totalPages;
      const pageData = state.data[`page${pageIndex}`] || [];
      const totalPage = totalPages === 0 ? 1 : totalPages;
      if (pageData?.length >= pageSize) {
        state.data[`page${pageIndex + 1}`] = [action.payload];
        state.pageData.totalPages = totalPages + 1;
      } else {
        state.data[`page${pageIndex}`] = [...pageData, action.payload];
      }
      if (totalPage === currentPage) {
        state.dataLists = state.data[`page${pageIndex}`];
      }
      state.selectedData = {};
      state.showModal = false;
      state.selectors = initialState.selectors;
      state.image = {};
    },
    updateTeacherList: (state, action) => {
      state.dataLists = state.dataLists.map((item) => {
        if (item._id === action.payload._id) {
          return {
            ...item,
            ...action.payload,
          };
        }
        return item;
      });
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.selectedData = {};
      state.showModal = false;
      state.selectors = initialState.selectors;
      state.image = {};
    },
    removeTeacherList: (state) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== state.selectedData._id
      );
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.showModal = false;
      state.selectedData = {};
    },

    setTeacherPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        state.dataLists = state.data[`page${action.payload.currentPage}`] || [];
      }
    },
    setSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    resetTeacherSelectors: (state, action) => {
      state.selectors = initialState.selectors;
    },
    setTeacherImage: (state, action) => {
      state.image = action.payload;
    },
    selectAllTeacher: (state) => {
      const dataLength = state.dataLists.length;
      const selectedLength = state.selectedTeachers.length;
      if (dataLength === selectedLength) {
        state.selectedTeachers = [];
      } else {
        state.selectedTeachers = state.dataLists.map((item) => item._id);
      }
    },
    toggleSelectedTeacher: (state, action) => {
      const index = state.selectedTeachers.findIndex(
        (item) => item === action.payload
      );
      if (index === -1) {
        state.selectedTeachers.push(action.payload);
      } else {
        state.selectedTeachers.splice(index, 1);
      }
    },
  },
});

export const {
  setAllTeacherData,
  setSelectedTeacher,
  updateSelectedTeacher,
  setTeachers,
  addTeacher,
  openTeacherModal,
  closeTeacherModal,
  setTeacherData,
  setTeacherPageData,
  updateTeacherList,
  removeTeacherList,
  setSelectors,
  addTeacherList,
  setTeacherImage,
  selectAllTeacher,
  toggleSelectedTeacher,
  resetTeacherSelectors,
} = teacherManagementSlice.actions;
export default teacherManagementSlice.reducer;
