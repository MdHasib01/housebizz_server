import { getPageData } from "@/services";
import { createSlice } from "@reduxjs/toolkit";

// Initial state with preloaded admission data
const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  selectors: {
    academic_year: "",
    class_id: "",
    group_id: "",
    section_id: "",
    current_category: "",
    current_section: "",
    current_academic_year: "",
    current_class: "",
    current_group: "",
  },
  student_ids: [],
  showTable: false,
  fetchData: false,
};

const admitAdmissionSlice = createSlice({
  name: "admitAdmissionSlice",
  initialState,
  reducers: {
    setAdmitStudentData: (state, action) => {
      const data = action.payload;
      state.allData = data;
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
    },

    setSelectedAdmitStudent: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },

    openAdmitStudentModal: (state) => {
      state.showModal = true;
    },
    closeAdmitStudentModal: (state) => {
      state.showModal = false;
    },
    removeAdmitStudentList: (state) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== state.selectedData._id
      );
      state.allData = state.allData.filter(
        (item) => item._id !== state.selectedData._id
      );
      const { totalItems, totalPages, currentRows } = getPageData({
        currentPage: state.pageData.currentPage,
        pageSize: state.pageData.pageSize,
        data: state.allData,
      });
      state.dataLists = currentRows;
      state.pageData.totalItems = totalItems;
      state.pageData.totalPages = totalPages;
      state.showModal = false;
      state.selectedData = {};
    },
    setAdmitStudentPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    setAdmitStudentSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    resetAdmitStudentSelectors: (state) => {
      state.selectors = initialState.selectors;
    },
    resetBulkStudents: (state) => {
      state.allData = state.allData.filter(
        (item) => !state.student_ids.includes(item._id)
      );
      state.student_ids = [];
      state.selectors = {
        ...state.selectors,
        current_section: "",
        current_academic_year: "",
        current_class: "",
        current_group: "",
      };
      const totalItems = state.allData?.length || 1;
      const totalPages = Math.ceil(totalItems / state.pageData.pageSize);
      state.pageData = {
        ...state.pageData,
        currentPage: 1,
        totalItems,
        totalPages,
      };
      const indexOfLastRow =
        state.pageData.currentPage * state.pageData.pageSize;
      const indexOfFirstRow = indexOfLastRow - state.pageData.pageSize;
      state.dataLists = state.allData?.slice(indexOfFirstRow, indexOfLastRow);
      state.showModal = false;
    },
    setAdmitStudentShowTable: (state, action) => {
      state.showTable = action.payload;
    },
    setAdmitStudentFetchData: (state, action) => {
      state.fetchData = action.payload;
    },
    setAllAdmitStudentData: (state, action) => {
      state.allData = action.payload;
    },
    selectAllAdmitStudents: (state) => {
      const dataLength = state.dataLists.length;
      const selectedLength = state.student_ids.length;
      if (dataLength === selectedLength) {
        state.student_ids = [];
      } else {
        state.student_ids = state.dataLists.map((item) => item._id);
      }
    },
    removeUpdatedAdmitStudentList: (state) => {
      if (state.student_ids?.length > 0) {
        state.dataLists = state.dataLists.filter(
          (item) => !state.student_ids.includes(item._id)
        );
        state.student_ids = [];
        const { totalItems, totalPages, currentRows } = getPageData({
          currentPage: state.pageData.currentPage,
          pageSize: state.pageData.pageSize,
          data: state.allData,
        });
        state.dataLists = currentRows;
        state.pageData.totalItems = totalItems;
        state.pageData.totalPages = totalPages;
      }
    },
    toggleAdmitStudent: (state, action) => {
      const index = state.student_ids.findIndex(
        (item) => item === action.payload
      );
      if (index === -1) {
        state.student_ids.push(action.payload);
      } else {
        state.student_ids.splice(index, 1);
      }
    },
  },
});

export const {
  setAdmitStudentData,
  openAdmitStudentModal,
  closeAdmitStudentModal,
  removeAdmitStudentList,
  setAdmitStudentPageData,
  setAdmitStudentSelectors,
  resetAdmitStudentSelectors,
  setAdmitStudentShowTable,
  setAdmitStudentFetchData,
  selectAllAdmitStudents,
  toggleAdmitStudent,
  setSelectedAdmitStudent,
  removeUpdatedAdmitStudentList,
} = admitAdmissionSlice.actions;
export default admitAdmissionSlice.reducer;
