import { apiSlice } from "@/store/modules/api/apiSlice";
import { setAdmitStudentData, setAdmitStudentFetchData } from "./admitSlice";
import { setStudentAdmissionData, setStudentAdmissionPageData } from "./slice";

export const adminAdmitStudentApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAdmitStudentAdmissions: builder.query({
      query: ({ query = null }) => `/students/filtered?${query}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(setAdmitStudentData(data?.data));
          dispatch(setAdmitStudentFetchData(false));
        } catch (error) {
          dispatch(setAdmitStudentFetchData(false));
        }
      },
    }),
    getStudentAdmissions: builder.query({
      query: ({ page = 1, limit = 50, institute_id = null }) =>
        `/students/pending?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(
            setStudentAdmissionData({ data: results, meta: data?.meta })
          );
          dispatch(setStudentAdmissionPageData(data?.meta));
        } catch (error) {}
      },
    }),

    deleteStudentAdmission: builder.mutation({
      query: ({ query, data }) => ({
        url: `/students/delete${query}`,
        method: "DELETE",
        body: data,
      }),
    }),
    studentBulkAdmission: builder.mutation({
      query: ({ query, data }) => ({
        url: `/students/bulk-update${query}`,
        method: "PATCH",
        body: data,
      }),
    }),
  }),
});

export const {
  useGetStudentAdmissionsQuery,
  useDeleteStudentAdmissionMutation,
  useGetAdmitStudentAdmissionsQuery,
  useStudentBulkAdmissionMutation,
} = adminAdmitStudentApi;
