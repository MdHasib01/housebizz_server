import { createSlice } from "@reduxjs/toolkit";

// Initial state with preloaded admission data
const initialState = {
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  // admit student

  selectors: {
    academic_year: "",
    blood_group: "",
    current_category: "",
    current_class: "",
    current_group: "",
    current_section: "",
    date_of_birth: { startDate: null, endDate: null },
    disability: "No",
    gender: "Male",
    religion: "",
  },
  student_ids: [],
};

const admissionSlice = createSlice({
  name: "admission",
  initialState,
  reducers: {
    setAllStudentAdmissionData: (state, action) => {
      state.allData = action.payload;
    },
    setStudentAdmissions: (state, action) => {
      state.dataLists = action.payload;
    },
    setStudentAdmissionData: (state, action) => {
      const { data, meta } = action.payload;
      if (meta?.totalPages === 0) {
        return;
      }
      if (meta?.currentPage <= meta?.totalPages) {
        state.data[`page${meta?.currentPage}`] = data;
        state.dataLists = data;
      } else {
        const otherData = state.data[`page${state.pageData.currentPage}`];
        const sliceData = otherData.slice(0, meta?.pageSize);
        const currentPage = meta?.currentPage - meta?.totalPages;
        const page = meta?.currentPage - currentPage;
        state.dataLists = [...sliceData];
        state.pageData.currentPage = page;
        state.pageData.totalPages = meta?.totalPages;
      }
    },
    addStudentAdmission: (state, action) => {
      state.dataLists.push(action.payload);
    },
    setSelectedStudentAdmission: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },
    updateSelectedStudentAdmission: (state, action) => {
      const { name, value } = action.payload;
      state.selectedData[name] = value;
    },
    openStudentAdmissionModal: (state) => {
      state.showModal = true;
    },
    closeStudentAdmissionModal: (state) => {
      state.showModal = false;
    },
    addStudentAdmissionList: (state, action) => {
      const { totalPages, pageSize, currentPage } = state.pageData;
      const pageIndex = totalPages === 0 ? 1 : totalPages;
      const pageData = state.data[`page${pageIndex}`] || [];
      if (pageData?.length >= pageSize) {
        state.data[`page${pageIndex + 1}`] = [action.payload];
        state.pageData.totalPages = totalPages + 1;
      } else {
        state.data[`page${pageIndex}`] = [...pageData, action.payload];
      }
      if (totalPages === currentPage) {
        state.dataLists = state.data[`page${pageIndex}`];
      }
      state.selectedData = {};
      state.showModal = false;
      state.selectors = initialState.selectors;
      state.image = null;
    },
    updateStudentAdmissionList: (state, action) => {
      state.dataLists = state.dataLists.map((item) => {
        if (item._id === action.payload._id) {
          return {
            ...item,
            ...action.payload,
          };
        }
        return item;
      });
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.selectedData = {};
      state.showModal = false;
      state.selectors = initialState.selectors;
      state.image = null;
    },
    removeStudentAdmissionList: (state) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== state.selectedData._id
      );
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.showModal = false;
      state.selectedData = {};
    },
    setStudentAdmissionPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        state.dataLists = state.data[`page${action.payload.currentPage}`] || [];
      }
    },
    setStudentAdmissionSelectors: (state, action) => {
      state.selectors = { ...state.selectors, ...action.payload };
    },
    resetAdmissionSelectors: (state) => {
      state.selectors = initialState.selectors;
    },
    resetAllAdmissionData: (state) => {
      state.dataLists = [];
      state.data = {};
      state.selectedData = {};
      state.showModal = false;
      state.pageData = initialState.pageData;
      state.selectors = initialState.selectors;
      state.student_ids = [];
    },
  },
});

export const {
  setAllStudentAdmissionData,
  setStudentAdmissions,
  setStudentAdmissionData,
  addStudentAdmission,
  setSelectedStudentAdmission,
  updateSelectedStudentAdmission,
  openStudentAdmissionModal,
  closeStudentAdmissionModal,
  addStudentAdmissionList,
  updateStudentAdmissionList,
  removeStudentAdmissionList,
  setStudentAdmissionPageData,
  setStudentAdmissionSelectors,
  resetAdmissionSelectors,
  resetAllAdmissionData,
} = admissionSlice.actions;
export default admissionSlice.reducer;
