import { apiSlice } from "@/store/modules/api/apiSlice";

export const adminStudentAdmissionApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addStudentAdmission: builder.mutation({
      query: (data) => ({
        url: "/students/add",
        method: "POST",
        body: data,
      }),
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
        } catch (error) {}
        // Add loading state management here
      },
    }),
  }),
});

export const { useAddStudentAdmissionMutation } = adminStudentAdmissionApi;
