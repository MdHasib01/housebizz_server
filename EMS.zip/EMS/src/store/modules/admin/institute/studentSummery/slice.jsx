import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  selectedData: {},
};

const studentSummarySlice = createSlice({
  name: "studentSummary",
  initialState,
  reducers: {
    setSelectedStudentSummary: (state, action) => {
      state.selectedData = action.payload;
    },
  },
});

export const { setSelectedStudentSummary } = studentSummarySlice.actions;
export default studentSummarySlice.reducer;
