import { envConfig, getStudentSummery } from "@/services";
import { apiSlice } from "@/store/modules/api/apiSlice";

export const adminStudentSummeryApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getStudentSummery: builder.query({
      async queryFn(_arg, _queryApi, _extraOptions, fetchWithBQ) {
        try {
          const { getState } = _queryApi;
          const { auth } = getState()?.auth || {};
          const baseUrl = envConfig.baseUrl;
          const page = 1;
          const limit = 99999;

          const urls = [
            `${baseUrl}/students/filtered?institute_id=${auth?.institute?.institute_id}&academic_year=${_arg}`,
            `${baseUrl}/sections/all?institute_id=${auth?.institute?.institute_id}&page=${page}&limit=${limit}`,
          ];

          const fetchOptions = {
            method: "GET",
            headers: {
              Authorization: `Bearer ${auth?.token}`,
            },
          };

          const [studentRes, sectionRes] = await Promise.all(
            urls.map((url) => fetchWithBQ(url, fetchOptions))
          );

          const { data: students } = studentRes?.data || {};
          const { data: sections } = sectionRes?.data || {};

          const data = getStudentSummery({
            students,
            sections,
            session: _arg,
          });

          return {
            data: data,
          };
        } catch (error) {
          return { error: error };
        }
      },
    }),
  }),
});

export const { useGetStudentSummeryQuery } = adminStudentSummeryApi;
