import { apiSlice } from "@/store/modules/api/apiSlice";
import { setAllPeriodData, setPeriodData, setPeriodPageData } from "./slice";

export const adminPeriodApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    addPeriod: builder.mutation({
      query: (data) => ({
        url: "/periods/add",
        method: "POST",
        body: data,
      }),
    }),

    getAllPeriods: builder.query({
      query: ({ institute_id = "", page = 1, limit = 50 }) =>
        `/periods/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setAllPeriodData(results));
        } catch (error) {}
      },
    }),

    getPeriods: builder.query({
      query: ({ page = 1, limit = 50, institute_id = "" }) =>
        `/periods/all?page=${page}&limit=${limit}&institute_id=${institute_id}`,
      async onQueryStarted(_arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          const results = data?.data;
          dispatch(setPeriodData({ data: results, meta: data?.meta }));
          dispatch(setPeriodPageData(data?.meta));
        } catch (error) {}
      },
    }),

    deletePeriod: builder.mutation({
      query: ({ institute_id = "", period_id = "" }) => ({
        url: `/periods/delete?institute_id=${institute_id}&period_id=${period_id}`,
        method: "DELETE",
      }),
    }),
  }),
});

export const {
  useAddPeriodMutation,
  useGetPeriodsQuery,
  useDeletePeriodMutation,
  useGetAllPeriodsQuery,
} = adminPeriodApi;
