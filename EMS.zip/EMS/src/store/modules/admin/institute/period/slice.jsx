import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  periods: [
    { _id: 1, period_name: "Period 1" },
    { _id: 2, period_name: "Period 2" },
    { _id: 3, period_name: "Period 3" },
    { _id: 4, period_name: "Period 4" },
    { _id: 5, period_name: "Period 5" },
    { _id: 6, period_name: "Period 6" },
    { _id: 7, period_name: "Period 7" },
    { _id: 8, period_name: "Period 8" },
    { _id: 9, period_name: "Period 9" },
    { _id: 10, period_name: "Period 10" },
    { _id: 11, period_name: "Period 11" },
  ],
  allData: [],
  dataLists: [],
  data: {},
  selectedData: {},
  showModal: false,
  pageData: {
    totalItems: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 50,
    hasNextPage: false,
    hasPreviousPage: false,
  },
};

const periodSlice = createSlice({
  name: "period",
  initialState,
  reducers: {
    // set all data after fetching

    setAllPeriodData: (state, action) => {
      state.allData = action.payload;
    },

    setPeriodData: (state, action) => {
      const { data, meta } = action.payload;
      if (meta?.totalPages === 0) return;

      if (meta?.currentPage <= meta?.totalPages) {
        state.data[`page${meta?.currentPage}`] = data;
        state.dataLists = data;
      } else {
        const otherData = state.data[`page${state.pageData.currentPage}`];
        const sliceData = otherData.slice(0, meta?.pageSize);
        const currentPage = meta?.currentPage - meta?.totalPages;
        const page = meta?.currentPage - currentPage;
        state.dataLists = [...sliceData];
        state.pageData.currentPage = page;
        state.pageData.totalPages = meta?.totalPages;
      }
    },

    // set data when click on pagination
    setPeriodPageData: (state, action) => {
      state.pageData = { ...state.pageData, ...action.payload };
      const updateKey = Object.keys(action.payload)[0];
      if (updateKey === "currentPage") {
        state.dataLists = state.data[`page${action.payload.currentPage}`] || [];
      }
    },

    // on create new shift add to list
    addPeriodList: (state, action) => {
      const { totalPages, pageSize, currentPage } = state.pageData;
      const pageIndex = totalPages === 0 ? 1 : totalPages;
      const pageData = state.data[`page${pageIndex}`] || [];
      const totalPage = totalPages === 0 ? 1 : totalPages;
      if (pageData?.length >= pageSize) {
        state.data[`page${pageIndex + 1}`] = [action.payload];
        state.pageData.totalPages = totalPages + 1;
      } else state.data[`page${pageIndex}`] = [...pageData, action.payload];

      if (totalPage === currentPage)
        state.dataLists = state.data[`page${pageIndex}`];
    },

    // on delete shift remove from list
    removePeriodList: (state, action) => {
      state.dataLists = state.dataLists.filter(
        (item) => item._id !== action.payload._id
      );
      state.data[`page${state.pageData.currentPage}`] = state.dataLists;
      state.showModal = false;
      state.selectedData = {};
    },

    // set selected shift data
    setSelectedPeriod: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload?.type === "delete") {
        state.showModal = true;
      }
    },

    // close shift modal
    closePeriodModal: (state) => {
      state.showModal = false;
      state.selectedData = {};
    },
  },
});

export const {
  addPeriodList,
  setPeriodData,
  removePeriodList,
  closePeriodModal,
  setSelectedPeriod,
  setPeriodPageData,
  setAllPeriodData,
} = periodSlice.actions;
export default periodSlice.reducer;
