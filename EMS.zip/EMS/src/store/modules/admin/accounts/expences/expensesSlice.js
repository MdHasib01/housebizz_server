import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  expenseData: [
    {
      category: "Civil",
      note: "Exp for civil",
      date: "25-10-2024",
      amount: 500,
    },
    {
      category: "Commerce",
      note: "Exp for Commerce",
      date: "26-10-2024",
      amount: 600,
    },
    {
      category: "Science",
      note: "Exp for Science",
      date: "27-10-2024",
      amount: 700,
    },
    {
      category: "Half Free",
      note: "Exp for Half Free",
      date: "28-10-2024",
      amount: 800,
    },
    {
      category: "25% Free",
      note: "Exp for 25%",
      date: "29-10-2024",
      amount: 900,
    },
  ],
  selectedData: { type: "", item: null },
  showModal: false,
  addExpenseModal: false,
};

const expenseSlice = createSlice({
  name: "expenseSlice",
  initialState,
  reducers: {
    setDepositData: (state, action) => {
      state.depositData = action.payload;
    },
    closeAddExpense: (state) => {
      state.addExpenseModal = false;
    },
    showAddExpense: (state) => {
      state.addExpenseModal = true;
    },
    addExpenseHandler: (state, action) => {
      state.expenseData = [...state.expenseData, action.payload];
    },
    deleteExpenseHandler: (state, action) => {
      const index = state.expenseData.findIndex(
        (item) =>
          item.category === action.payload.category &&
          item.note === action.payload.note &&
          item.date === action.payload.date &&
          item.amount === action.payload.amount
      );
      if (index !== -1) {
        state.expenseData.splice(index, 1);
      }
    },
    closeModalHandler: (state) => {
      state.showModal = false;
    },
    setSelectedData: (state, action) => {
      state.selectedData = action.payload;
      if (action.payload.type === "delete") {
        state.showModal = true;
      } else if (action.payload.type === "update") {
        state.addExpenseModal = true;
      }
    },
    updateExpenseValue: (state, action) => {
      state.selectedData.item = action.payload;
    },
  },
});

export const {
  selectedData,
  updateExpenseValue,
  closeModalHandler,
  showModal,
  closeAddExpense,
  showAddExpense,
  expenseData,
  addExpenseHandler,
  deleteExpenseHandler,
  setSelectedData,
} = expenseSlice.actions;
export default expenseSlice.reducer;
