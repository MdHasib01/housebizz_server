import { configureStore } from "@reduxjs/toolkit";
import adminSlice from "./adminSlice";
import { apiSlice } from "./modules/api/apiSlice";
import authSlice from "./modules/auth/authSlice";
import commonSlice from "./modules/common/slice";
import superAdminSlice from "./superAdminSlice";

export const store = configureStore({
  reducer: {
    [apiSlice.reducerPath]: apiSlice.reducer,
    auth: authSlice,
    common: commonSlice,
    ...adminSlice,
    ...superAdminSlice,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [
          "api/executeQuery/fulfilled",
          "api/executeQuery/rejected",
          "api/executeQuery/pending",
          "serviceSlice/setServiceFiles",
        ],
        ignoredActionPaths: [
          "meta.baseQueryMeta.request",
          "meta.arg.originalArgs.data",
          "meta.baseQueryMeta.response",
          "payload",
          "meta.arg.originalArgs",
          "api.queries",
        ],
        ignoredPaths: [
          "service.files",
          "adminAdmission.selectors.date_of_birth",
          "adminStudentManagement.selectors.date_of_birth",
          "adminStudentBulk.selectors.date_of_birth",
          "adminBulkBilling.selectors.due_date"
        ],
      },
    }).concat(apiSlice.middleware),
});
