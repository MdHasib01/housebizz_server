import classAttendanceSlice from "./modules/admin/attendance/classAttendance/slice";
import classScheduleSlice from "./modules/admin/attendance/classSchedule/slice";
import routineListSlice from "./modules/admin/attendance/routineList/slice";
import studentListSlice from "./modules/admin/attendance/studentList/slice";
import adminSubjectRoutines from "./modules/admin/attendance/subjectEnroll/routineSlice";
import adminSubjectStudents from "./modules/admin/attendance/subjectEnroll/studentsSlice";
import billingConfigSlice from "./modules/admin/billing/billingConfig/slice";
import billingHeadSlice from "./modules/admin/billing/billingHead/slice";
import billingTypesSlice from "./modules/admin/billing/billingTypes/slice";
import cashPaySlice from "./modules/admin/billing/cashPay/slice";
import bulkBillingSlice from "./modules/admin/billing/invoices/bulkBillingSlice";
import customBillingSlice from "./modules/admin/billing/invoices/customBillingSlice";
import individualBillingSlice from "./modules/admin/billing/invoices/individualBillingSlice";
import searchBillingSlice from "./modules/admin/billing/invoices/searchBillingSlice";
import dashboardSlice from "./modules/admin/dashboard/dashboardSlice";
import admitAdmissionSlice from "./modules/admin/institute/admission/admitSlice";
import admissionSlice from "./modules/admin/institute/admission/slice";
import categorySlice from "./modules/admin/institute/category/slice";
import classesSlice from "./modules/admin/institute/class/slice";
import daySlice from "./modules/admin/institute/day/slice";
import periodSlice from "./modules/admin/institute/period/slice";
import scheduleShiftsSlice from "./modules/admin/institute/scheduleShift/slice";
import sectionListSlice from "./modules/admin/institute/sectionList/slice";
import studentBulkInsertSlice from "./modules/admin/institute/studentBulkInsert/slice";
import studentManagementSlice from "./modules/admin/institute/studentManagement/slice";
import studentStatusSlice from "./modules/admin/institute/studentStatus/slice";
import studentSummarySlice from "./modules/admin/institute/studentSummery/slice";
import teacherManagementSlice from "./modules/admin/institute/teacherManagement/slice";
import userManagementSlice from "./modules/admin/institute/userManagement/slice";
import paymentSettingSlice from "./modules/admin/settings/payment/slice";
import smsSettingSlice from "./modules/admin/settings/sms/slice";
import moneyDepositSlice from "./modules/admin/accounts/overview/moneyDepositSlice";
import expenseSlice from "./modules/admin/accounts/expences/expensesSlice";

const adminSlice = {
  adminDashboard: dashboardSlice,
  adminAdmission: admissionSlice,
  adminAdmitAdmission: admitAdmissionSlice,
  adminClassAttendance: classAttendanceSlice,
  adminStudentStatus: studentStatusSlice,
  adminStudentSummary: studentSummarySlice,
  adminStudentBulk: studentBulkInsertSlice,
  adminStudentManagement: studentManagementSlice,
  adminTeacherManagement: teacherManagementSlice,
  adminScheduleShifts: scheduleShiftsSlice,
  adminClasses: classesSlice,
  adminSections: sectionListSlice,
  adminDays: daySlice,
  adminPeriod: periodSlice,
  adminCategory: categorySlice,
  adminUserManagement: userManagementSlice,
  adminClassSchedule: classScheduleSlice,
  adminStudentList: studentListSlice,
  adminRoutineList: routineListSlice,
  adminEnrollStudents: adminSubjectStudents,
  adminEnrollRoutine: adminSubjectRoutines,
  // billing
  adminBillingHead: billingHeadSlice,
  adminBillingTypes: billingTypesSlice,
  adminBillingConfig: billingConfigSlice,
  adminSearchBilling: searchBillingSlice,
  adminIndividualBilling: individualBillingSlice,
  adminBulkBilling: bulkBillingSlice,
  adminCustomBilling: customBillingSlice,
  adminCashPay: cashPaySlice,

  // account
  adminAccountDeposit: moneyDepositSlice,
  adminAccountExpense: expenseSlice,

  // setting
  paymentSetting: paymentSettingSlice,
  smsSetting: smsSettingSlice,
};

export default adminSlice;
