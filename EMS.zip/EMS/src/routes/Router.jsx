import { createBrowserRouter } from "react-router-dom";
import { admin } from "./admin";
import { superAdmin } from "./superAdmin";
import { user } from "./user";

export const routes = createBrowserRouter([
  admin,
  ...user,
  superAdmin,
  {
    path: "*",
    element: (
      <h2 className="font-black py-6 text-3xl text-red-600 text-center">
        Page Not Found!
      </h2>
    ),
  },
]);
