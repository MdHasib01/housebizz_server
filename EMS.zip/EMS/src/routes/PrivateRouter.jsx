import { userRoutes } from "@/services";
import { useSelector } from "react-redux";
import { Navigate, useLocation } from "react-router-dom";

function PrivateRouter({ children }) {
  const { auth } = useSelector((state) => state.auth);
  const location = useLocation();

  // if (auth?.token) {
  return <>{children}</>;
  // }

  // return (
  //   <Navigate to={userRoutes.home.path} state={{ from: location }} replace />
  // );
}

export default PrivateRouter;
