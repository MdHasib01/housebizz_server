import SuperAdminLayout from "@/components/layout/SuperAdminLayout";
import AssignInstitute from "@/pages/admin/superAdmin/administrator/assignInstitute/AssignInstitute";
import AddInstituteManagement from "@/pages/admin/superAdmin/administrator/instituteManagement/AddInstituteManagement";
import InstituteAdmins from "@/pages/admin/superAdmin/administrator/instituteManagement/InstituteAdmins";
import InstituteManagement from "@/pages/admin/superAdmin/administrator/instituteManagement/InstituteManagement";
import UpdateInstituteManagement from "@/pages/admin/superAdmin/administrator/instituteManagement/UpdateInstituteManagement";
import InstituteSettings from "@/pages/admin/superAdmin/administrator/instituteSettings/InstituteSettings";
import RequestedInstitute from "@/pages/admin/superAdmin/administrator/requestedInstitute/RequestedInstitute";
import RequestedInstituteDetails from "@/pages/admin/superAdmin/administrator/requestedInstitute/RequestedInstituteDetails";
import Dashboard from "@/pages/admin/superAdmin/dashboard/Dashboard";
import AddBoardManagement from "@/pages/admin/superAdmin/global/boardManagement/AddBoardManagement";
import BoardManagement from "@/pages/admin/superAdmin/global/boardManagement/BoardManagement";
import AddClassManagement from "@/pages/admin/superAdmin/global/classManagement/AddClassManagement";
import ClassManagement from "@/pages/admin/superAdmin/global/classManagement/ClassManagement";
import ExamType from "@/pages/admin/superAdmin/global/examType/ExamType";
import AddGradingManagement from "@/pages/admin/superAdmin/global/gradingManagement/AddGradingManagement";
import GradingManagement from "@/pages/admin/superAdmin/global/gradingManagement/GradingManagement";
import AddGroupManagement from "@/pages/admin/superAdmin/global/groupManagement/AddGroupManagement";
import GroupManagement from "@/pages/admin/superAdmin/global/groupManagement/GroupManagement";
import AddSessionYear from "@/pages/admin/superAdmin/global/sessionYear/AddSessionYear";
import SessionYear from "@/pages/admin/superAdmin/global/sessionYear/SessionYear";
import AddSubjectManagement from "@/pages/admin/superAdmin/global/subjectManagement/AddSubjectManagement";
import SubjectManagement from "@/pages/admin/superAdmin/global/subjectManagement/SubjectManagement";
import Transactions from "@/pages/admin/superAdmin/transactions/Transactions";
import { superAdminRoutes } from "@/services/routes/superAdmin";
import PrivateRouter from "./PrivateRouter";

const {
  dashboard = {},
  boardManagement = {},
  addBoardManagement = {},
  classManagement = {},
  examType = {},
  gradingManagement = {},
  addGradingManagement = {},
  groupManagement = {},
  sessionYear = {},
  addSessionYear = {},
  subjectManagement = {},
  addSubjectManagement = {},
  transactions = {},
  instituteManagement = {},
  instituteAdmins = {},
  addInstituteManagement = {},
  updateInstituteManagement = {},
  assignInstitute = {},
  instituteSettings = {},
  requestedInstitute = {},
  requestedInstituteDetails = {},
  addClassManagement = {},
  addGroupManagement = {},
} = superAdminRoutes || {};

export const superAdmin = {
  path: "/super-admin",
  element: (
    <PrivateRouter>
      <SuperAdminLayout />
    </PrivateRouter>
  ),
  children: [
    // dashboard
    {
      path: dashboard?.path,
      element: <Dashboard />,
    },
    //global
    {
      path: boardManagement?.path,
      element: <BoardManagement />,
    },
    {
      path: addBoardManagement?.path,
      element: <AddBoardManagement />,
    },
    {
      path: classManagement?.path,
      element: <ClassManagement />,
    },
    {
      path: addClassManagement?.path,
      element: <AddClassManagement />,
    },
    {
      path: examType?.path,
      element: <ExamType />,
    },
    {
      path: gradingManagement?.path,
      element: <GradingManagement />,
    },
    {
      path: addGradingManagement?.path,
      element: <AddGradingManagement />,
    },
    {
      path: groupManagement.path,
      element: <GroupManagement />,
    },
    {
      path: addGroupManagement.path,
      element: <AddGroupManagement />,
    },
    {
      path: sessionYear?.path,
      element: <SessionYear />,
    },
    {
      path: addSessionYear?.path,
      element: <AddSessionYear />,
    },
    {
      path: subjectManagement?.path,
      element: <SubjectManagement />,
    },
    {
      path: addSubjectManagement?.path,
      element: <AddSubjectManagement />,
    },
    // transactions
    {
      path: transactions?.path,
      element: <Transactions />,
    },
    // administrator
    {
      path: instituteManagement?.path,
      element: <InstituteManagement />,
    },
    {
      path: instituteAdmins?.path,
      element: <InstituteAdmins />,
    },
    {
      path: addInstituteManagement?.path,
      element: <AddInstituteManagement />,
    },
    {
      path: updateInstituteManagement?.path,
      element: <UpdateInstituteManagement />,
    },
    {
      path: requestedInstitute?.path,
      element: <RequestedInstitute />,
    },
    {
      path: requestedInstituteDetails?.path,
      element: <RequestedInstituteDetails />,
    },
    {
      path: assignInstitute?.path,
      element: <AssignInstitute />,
    },
    {
      path: instituteSettings?.path,
      element: <InstituteSettings />,
    },
  ],
};
