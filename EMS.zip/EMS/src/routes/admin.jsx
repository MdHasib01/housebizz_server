import AdminLayout from "@/components/layout/AdminLayout";
import ClassAttendance from "@/pages/admin/admin/attendance/classAttendence/ClassAttendance";
import AddRoutine from "@/pages/admin/admin/attendance/classSchedule/AddRoutine";
import ClassSchedule from "@/pages/admin/admin/attendance/classSchedule/ClassSchedule";
import UpdateRoutine from "@/pages/admin/admin/attendance/classSchedule/UpdateRoutine";
import AttendanceReport from "@/pages/admin/admin/attendance/report/AttendanceReport";
import EnrollDetails from "@/pages/admin/admin/attendance/subjectEnroll/EnrollDetails";
import SubjectEnroll from "@/pages/admin/admin/attendance/subjectEnroll/SubjectEnroll";
import BillingConfigList from "@/pages/admin/admin/billing/billingConfig/BillingConfigList";
import BillingConfigUpdate from "@/pages/admin/admin/billing/billingConfig/BillingConfigUpdate";
import AddNewHead from "@/pages/admin/admin/billing/billingHead/AddNewHead";
import HeadManage from "@/pages/admin/admin/billing/billingHead/HeadManage";
import AddBillingType from "@/pages/admin/admin/billing/billingTypes/AddBillingType";
import BillingTypesList from "@/pages/admin/admin/billing/billingTypes/BillingTypesList";
import UpdateBillingType from "@/pages/admin/admin/billing/billingTypes/UpdateBillingType";
import CashPayList from "@/pages/admin/admin/billing/cashPay/CashPayList";
import InvoicesList from "@/pages/admin/admin/billing/invoices/InvoicesList";
import DailyCollections from "@/pages/admin/admin/billing/reports/DailyCollections";
import HeadwisePayment from "@/pages/admin/admin/billing/reports/HeadwisePayment";
import StudentDues from "@/pages/admin/admin/billing/reports/StudentDues";
import StudentLedger from "@/pages/admin/admin/billing/reports/StudentLedger";
import Dashboard from "@/pages/admin/admin/dashboard/Dashboard";
import Admission from "@/pages/admin/admin/institute/admission/Admission";
import AdmitStudents from "@/pages/admin/admin/institute/admission/AdmitStudents";
import CategoryList from "@/pages/admin/admin/institute/category/CategoryList";
import ClassList from "@/pages/admin/admin/institute/class/ClassList";
import DayList from "@/pages/admin/admin/institute/day/DayList";
import PeriodList from "@/pages/admin/admin/institute/period/PeriodList";
import StudentStatus from "@/pages/admin/admin/institute/reports/StudentStatus";
import StudentSummary from "@/pages/admin/admin/institute/reports/StudentSummary";
import AddSection from "@/pages/admin/admin/institute/section/AddSection";
import SectionList from "@/pages/admin/admin/institute/section/SectionList";
import AddShift from "@/pages/admin/admin/institute/shift/AddShift";
import ShiftList from "@/pages/admin/admin/institute/shift/ShiftList";
import AddStudent from "@/pages/admin/admin/institute/students/AddStudent";
import BulkImport from "@/pages/admin/admin/institute/students/BulkImport";
import EditStudent from "@/pages/admin/admin/institute/students/EditStudent";
import StudentManage from "@/pages/admin/admin/institute/students/StudentManage";
import UpdatBulkStudent from "@/pages/admin/admin/institute/students/UpdatBulkStudent";
import AddTeacher from "@/pages/admin/admin/institute/teacher/AddTeacher";
import EditTeacher from "@/pages/admin/admin/institute/teacher/EditTeacher";
import TeacherList from "@/pages/admin/admin/institute/teacher/TeacherList";
import AddUser from "@/pages/admin/admin/institute/userManage/AddUser";
import UserManagementList from "@/pages/admin/admin/institute/userManage/UserManagementList";
import PaymentSetting from "@/pages/admin/admin/settings/PaymentSetting";
import SmsSetting from "@/pages/admin/admin/settings/SmsSetting";
import { adminRoutes } from "@/services";
import PrivateRouter from "./PrivateRouter";
import AccountOerview from "@/pages/admin/admin/accounts/overview/AccountOverview";
import Expenses from "@/pages/admin/admin/accounts/expenses/Expenses";

const {
  dashboard = {},
  institute = {},
  attendance = {},
  billing = {},
  accounts = {},
  settings = {},
} = adminRoutes || {};

export const admin = {
  path: "/admin",
  element: (
    <PrivateRouter>
      <AdminLayout />
    </PrivateRouter>
  ),
  children: [
    // dashboard
    {
      path: dashboard?.path,
      element: <Dashboard />,
    },

    // institute
    {
      path: institute?.admission?.path,
      element: <Admission />,
    },
    {
      path: institute?.admitStudents?.path,
      element: <AdmitStudents />,
    },
    {
      path: institute?.reports?.studentStatus?.path,
      element: <StudentStatus />,
    },
    {
      path: institute?.reports?.studentSummary?.path,
      element: <StudentSummary />,
    },
    {
      path: institute?.students?.management?.path,
      element: <StudentManage />,
    },
    {
      path: institute?.students?.addStudent?.path,
      element: <AddStudent />,
    },
    {
      path: institute?.students?.editStudent?.path,
      element: <EditStudent />,
    },
    {
      path: institute?.students?.bulkImport?.path,
      element: <BulkImport />,
    },
    {
      path: institute?.students?.updateBulkStudent?.path,
      element: <UpdatBulkStudent />,
    },
    {
      path: institute?.teacher?.path,
      element: <TeacherList />,
    },
    {
      path: institute?.teacher?.addTeacher?.path,
      element: <AddTeacher />,
    },
    {
      path: institute?.teacher?.editTeacher?.path,
      element: <EditTeacher />,
    },
    {
      path: institute?.shift?.path,
      element: <ShiftList />,
    },
    {
      path: institute?.shift?.addShift?.path,
      element: <AddShift />,
    },
    {
      path: institute?.class?.path,
      element: <ClassList />,
    },
    {
      path: institute?.section?.path,
      element: <SectionList />,
    },
    {
      path: institute?.section?.addSection?.path,
      element: <AddSection />,
    },
    {
      path: institute?.day?.path,
      element: <DayList />,
    },
    {
      path: institute?.period?.path,
      element: <PeriodList />,
    },
    {
      path: institute?.category?.path,
      element: <CategoryList />,
    },
    {
      path: institute?.userManage?.path,
      element: <UserManagementList />,
    },
    {
      path: institute?.userManage?.addUser?.path,
      element: <AddUser />,
    },

    // attendance
    {
      path: attendance?.classSchedule?.path,
      element: <ClassSchedule />,
    },
    {
      path: attendance?.addRoutine?.path,
      element: <AddRoutine />,
    },
    {
      path: attendance?.updateRoutine?.path,
      element: <UpdateRoutine />,
    },
    {
      path: attendance?.subjectEnroll?.path,
      element: <SubjectEnroll />,
    },
    {
      path: attendance?.attendanceReport?.path,
      element: <AttendanceReport />,
    },
    {
      path: attendance?.report?.classAttendance?.path,
      element: <ClassAttendance />,
    },
    {
      path: attendance?.enrollDetails?.path,
      element: <EnrollDetails />,
    },

    // billing
    {
      path: billing?.billingHead?.path,
      element: <HeadManage />,
    },
    {
      path: billing?.billingHead?.addNewHead?.path,
      element: <AddNewHead />,
    },
    {
      path: billing?.billingTypes?.path,
      element: <BillingTypesList />,
    },
    {
      path: billing?.billingTypes?.addNewType?.path,
      element: <AddBillingType />,
    },
    {
      path: billing?.billingTypes?.updateType?.path,
      element: <UpdateBillingType />,
    },
    {
      path: billing?.billingConfig?.path,
      element: <BillingConfigList />,
    },
    {
      path: billing?.billingConfig?.updateConfig?.path,
      element: <BillingConfigUpdate />,
    },
    {
      path: billing?.invoices?.path,
      element: <InvoicesList />,
    },
    {
      path: billing?.cashPay?.path,
      element: <CashPayList />,
    },
    {
      path: billing?.report?.headwisePayment?.path,
      element: <HeadwisePayment />,
    },
    {
      path: billing?.report?.dailyCollections?.path,
      element: <DailyCollections />,
    },
    {
      path: billing?.report?.studentDues?.path,
      element: <StudentDues />,
    },
    {
      path: billing?.report?.studentLedger?.path,
      element: <StudentLedger />,
    },
    // accounts
    {
      path: accounts?.overview?.path,
      element: <AccountOerview />,
    },
    {
      path: accounts?.expenses?.path,
      element: <Expenses />,
    },
    // settings
    {
      path: settings.payment.path,
      element: <PaymentSetting />,
    },
    {
      path: settings.sms.path,
      element: <SmsSetting />,
    },
  ],
};
