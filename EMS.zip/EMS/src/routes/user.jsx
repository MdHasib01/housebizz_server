import InstituteOnboard from "@/pages/landing/InstituteOnboard";
import Login from "@/pages/landing/Signin";
import StudentAdmission from "@/pages/landing/StudentAdmission";
import { userRoutes } from "@/services";

const { home, instituteOnboard, studemtAdmission } = userRoutes || {};

export const user = [
  {
    path: home.path,
    element: <Login />,
  },
  {
    path: instituteOnboard.path,
    element: <InstituteOnboard />,
  },
  {
    path: studemtAdmission.path,
    element: <StudentAdmission />,
  },
];
