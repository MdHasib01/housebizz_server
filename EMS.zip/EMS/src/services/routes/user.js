export const userRoutes = {
  home: {
    name: "Home",
    path: "/",
  },
  instituteOnboard: {
    name: "Institute Onboard",
    path: "/institute-onboard",
  },
  studemtAdmission: {
    name: "Student Admission",
    path: "/student-admission/:id",
    routePath: "/student-admission",
  },
};
