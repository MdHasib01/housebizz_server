export const adminRoutes = Object.freeze({
  dashboard: {
    name: "Dashboard",
    path: "/admin/dashboard",
  },
  institute: {
    name: "Institute",
    admission: {
      name: "Admission",
      path: "/admin/institute/admission",
    },
    admitStudents: {
      name: "Admit Students",
      path: "/admin/institute/admission/admit-students",
    },
    reports: {
      name: "Reports",
      studentStatus: {
        name: "Student Status",
        path: "/admin/institute/reports/student-status",
      },
      studentSummary: {
        name: "Student Summary",
        path: "/admin/institute/reports/student-summary",
      },
    },
    students: {
      name: "Students",
      management: {
        name: "Student Manage",
        path: "/admin/institute/students/management",
      },
      addStudent: {
        name: "Add Student",
        path: "/admin/institute/students/management/add",
      },
      editStudent: {
        name: "Edit Student",
        path: "/admin/institute/students/management/edit/:id",
        routePath: "/admin/institute/students/management/edit",
      },
      bulkImport: {
        name: "Bulk Import",
        path: "/admin/institute/students/bulk-import",
      },
      updateBulkStudent: {
        name: "Bulk Student Update",
        path: "/admin/institute/students/bulk-import/update",
      },
    },
    teacher: {
      name: "Teacher",
      path: "/admin/institute/teacher",
      addTeacher: {
        name: "Add Teacher",
        path: "/admin/institute/teacher/add-teacher",
      },
      editTeacher: {
        name: "Edit Teacher",
        path: "/admin/institute/teacher/edit-teacher/:id",
        routePath: "/admin/institute/teacher/edit-teacher",
      },
    },
    shift: {
      name: "Shift",
      path: "/admin/institute/shift",
      addShift: {
        name: "Add Shift",
        path: "/admin/institute/shift/add-shift",
      },
    },
    class: {
      name: "Class",
      path: "/admin/institute/class",
    },
    section: {
      name: "Section",
      path: "/admin/institute/section",
      addSection: {
        name: "Add Section",
        path: "/admin/institute/section/add-section",
      },
    },
    day: {
      name: "Day",
      path: "/admin/institute/day",
    },
    period: {
      name: "Period",
      path: "/admin/institute/period",
    },
    category: {
      name: "Category",
      path: "/admin/institute/category",
    },
    userManage: {
      name: "User Manage",
      path: "/admin/institute/user-manage",
      addUser: {
        name: "Add User",
        path: "/admin/institute/user-manage/add-user",
      },
    },
  },
  attendance: {
    name: "Attendance",
    classSchedule: {
      name: "Class Schedule",
      path: "/admin/attendance/class-schedule",
    },
    addRoutine: {
      name: "Add Routine",
      path: "/admin/attendance/class-schedule/add-routine",
    },
    updateRoutine: {
      name: "Update Routine",
      path: "/admin/attendance/class-schedule/update-routine/:id",
      routePath: "/admin/attendance/class-schedule/update-routine",
    },
    subjectEnroll: {
      name: "Subject Enroll",
      path: "/admin/attendance/subject-enroll",
    },
    attendanceReport: {
      name: "Attendance Report",
      path: "/admin/attendance/attendance-report",
    },
    report: {
      name: "Report",
      classAttendance: {
        name: "Class Attendance",
        path: "/admin/attendance/report/class-attendance",
      },
    },
    enrollDetails: {
      name: "Enroll Details",
      path: "/admin/attendance/subject-enroll/enroll-details",
    },
  },
  billing: {
    name: "Billing",
    billingHead: {
      name: "Billing Head",
      path: "/admin/billing/billing-head",
      addNewHead: {
        name: "New Head",
        path: "/admin/billing/billing-head/new-head",
      },
    },
    billingTypes: {
      name: "Billing Types",
      path: "/admin/billing/billing-types",
      addNewType: {
        name: "Add New Type",
        path: "/admin/billing/billing-types/new-type",
      },
      updateType: {
        name: "Update Billing Type",
        path: "/admin/billing/billing-types/update/:billingTypeId",
        routePath: "/admin/billing/billing-types/update",
      },
    },
    billingConfig: {
      name: "Billing Config",
      path: "/admin/billing/billing-config",
      updateConfig: {
        name: "Update Config",
        path: "/admin/billing/billing-config/update/:id",
        routePath: "/admin/billing/billing-config/update",
      },
    },
    invoices: {
      name: "Invoices",
      path: "/admin/billing/invoices",
    },
    cashPay: {
      name: "Cash Pay",
      path: "/admin/billing/cash-pay",
    },
    report: {
      name: "Report",
      headwisePayment: {
        name: "Headwise Payment",
        path: "/admin/billing/report/headwise-payment",
      },
      dailyCollections: {
        name: "Daily Collections",
        path: "/admin/billing/report/daily-collections",
      },
      studentDues: {
        name: "Student Dues",
        path: "/admin/billing/report/student-dues",
      },
      studentLedger: {
        name: "Student Ledger",
        path: "/admin/billing/report/student-ledger",
      },
    },
  },
  settings: {
    name: "Settings",
    payment: {
      name: "Payment",
      path: "/admin/settings/payment",
    },
    sms: {
      name: "SMS Settings",
      path: "/admin/settings/sms",
    },
  },
  accounts: {
    name: "Accounts",
    overview: {
      name: "Overview",
      path: "/admin/accounts/overview",
    },
    expenses: {
      name: "Expenses",
      path: "/admin/accounts/expenses",
    },
    expenseCategory: {
      name: "Expense Category",
      path: "/admin/accounts/expense-category",
    },
  },
});

// FIXME: DEV only. Should to be removed.
// editing routes flow admin.js > src/routes/[subjectRouter in router folder].jsx > navigation (for sidebar navigation)
