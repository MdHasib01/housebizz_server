export const superAdminRoutes = Object.freeze({
  dashboard: {
    name: "Dashboard",
    path: "/super-admin/dashboard",
  },
  boardManagement: {
    name: "Board Management",
    path: "/super-admin/global/board-management",
  },
  addBoardManagement: {
    name: "Add New Board",
    path: "/super-admin/global/board-management/add",
  },
  classManagement: {
    name: "Class Management",
    path: "/super-admin/global/class-management",
  },
  addClassManagement: {
    name: "Add New Class",
    path: "/super-admin/global/class-management/add",
  },
  examType: {
    name: "Exam Type",
    path: "/super-admin/global/exam-type",
  },
  addExamType: {
    name: "Add New Exam Type",
    path: "/super-admin/global/exam-type/add",
  },
  gradingManagement: {
    name: "Grading Management",
    path: "/super-admin/global/grading-management",
  },
  addGradingManagement: {
    name: "Add New Grading",
    path: "/super-admin/global/grading-management/add",
  },
  groupManagement: {
    name: "Group Management",
    path: "/super-admin/global/group-management",
  },
  addGroupManagement: {
    name: "Add New Group",
    path: "/super-admin/global/group-management/add",
  },
  sessionYear: {
    name: "Session/Year",
    path: "/super-admin/global/session-year",
  },
  addSessionYear: {
    name: "Session/Year",
    path: "/super-admin/global/session-year/add",
  },
  subjectManagement: {
    name: "Subject Management",
    path: "/super-admin/global/subject-management",
  },
  addSubjectManagement: {
    name: "Add New Subject",
    path: "/super-admin/global/subject-management/add",
  },
  transactions: {
    name: "Transactions",
    path: "/super-admin/transactions",
  },
  instituteManagement: {
    name: "Institute Management",
    path: "/super-admin/administrator/institute-management",
  },
  instituteAdmins: {
    name: "Institute Admins",
    path: "/super-admin/administrator/institute-management/admins/:id",
    routePath: "/super-admin/administrator/institute-management/admins",
  },
  addInstituteManagement: {
    name: "Add New Institute",
    path: "/super-admin/administrator/institute-management/add",
  },
  updateInstituteManagement: {
    name: "Update Institute",
    path: "/super-admin/administrator/institute-management/update/:id",
    routePath: "/super-admin/administrator/institute-management/update",
  },
  assignInstitute: {
    name: "Assign Institute",
    path: "/super-admin/administrator/assign-institute",
  },
  instituteSettings: {
    name: "Institute Settings",
    path: "/super-admin/administrator/institute-settings",
  },
  requestedInstitute: {
    name: "Requested Institute",
    path: "/super-admin/administrator/requested-institute",
  },
  requestedInstituteDetails: {
    name: "View Institute",
    path: "/super-admin/administrator/requested-institute/:id",
    routePath: "/super-admin/administrator/requested-institute",
  },
});
