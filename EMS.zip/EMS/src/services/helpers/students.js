export const getStudentStatus = ({
  students = [],
  sections = [],
  categories = [],
  classes = [],
}) => {
  if (
    students?.length === 0 ||
    sections?.length === 0 ||
    categories?.length === 0 ||
    classes?.length === 0
  )
    return [];

  const status = classes.map((classItem) => {
    const totalStudent = students.filter(
      (student) =>
        student?.current_class?.local_class_code === classItem?.local_class_code
    ).length;
    const filteredSections = sections.filter(
      (section) =>
        section?.local_class_id?.local_class_code ===
        classItem?.local_class_code
    );
    const studentSections = filteredSections?.map((section) => {
      const totalSectionStudents = students.filter(
        (student) => student?.current_section?._id === section?._id
      ).length;
      const studentCategories = categories.map((category) => {
        const totalBoys = students.filter(
          (student) =>
            student?.current_section?._id === section?._id &&
            student?.current_category?._id === category?._id &&
            student?.gender?.toLowerCase() === "male"
        ).length;
        const totalgirls = students.filter(
          (student) =>
            student?.current_section?._id === section?._id &&
            student?.current_category?._id === category?._id &&
            student?.gender?.toLowerCase() === "female"
        ).length;
        return {
          category: category?.local_category_name,
          boys: totalBoys,
          girls: totalgirls,
          total: totalBoys + totalgirls,
        };
      });
      return {
        section: section?.section_name,
        total: totalSectionStudents,
        categories: studentCategories,
      };
    });
    return {
      class: classItem?.local_class_name,
      total: totalStudent,
      sections: studentSections,
    };
  });

  return status;
};

export const getStudentProccessedData = (data = []) => {
  if (data?.length === 0) return [];

  return data?.flatMap((classItem, _classIndex) => {
    const classRowSpan = classItem?.sections.reduce(
      (sum, section) => sum + section?.categories?.length,
      0
    );
    return classItem?.sections.flatMap((section, sectionIndex) => {
      const sectionRowSpan = section?.categories?.length;

      return section?.categories?.map((category, categoryIndex) => ({
        class:
          categoryIndex === 0 && sectionIndex === 0 ? classItem?.class : null,
        totalStudents: classItem?.total,
        section: categoryIndex === 0 ? section?.section : null,
        category: category?.category,
        boys: category?.boys,
        girls: category?.girls,
        total: category?.total,
        classRowSpan: categoryIndex === 0 ? classRowSpan : null,
        sectionRowSpan: categoryIndex === 0 ? sectionRowSpan : null,
        sectionTotal: categoryIndex === 0 ? section?.total : null,
      }));
    });
  });
};

export const getStudentSummery = ({
  students = [],
  sections = [],
  session,
}) => {
  if (students?.length === 0 || sections?.length === 0) return [];

  const sectionData = sections?.map((section, index) => {
    const totalBoys = students.filter(
      (student) =>
        student?.current_section?._id === section?._id &&
        student?.gender === "male"
    );
    const totalGirls = students.filter(
      (student) =>
        student?.current_section?._id === section?._id &&
        student?.gender === "female"
    );

    return {
      _id: `${section?._id}-${index}`,
      class: section?.local_class_id?.local_class_name,
      class_code: section?.local_class_id?.local_class_code,
      section: section?.section_name,
      session: session,
      version: "Bangla",
      boys: totalBoys?.length,
      girls: totalGirls?.length,
      total: totalBoys?.length + totalGirls?.length,
    };
  });

  return sectionData;
};
