import moment from "moment";

export const bloodGroups = [
  { label: "A+", value: "A+" },
  { label: "B+", value: "B+" },
  { label: "O+", value: "O+" },
  { label: "AB+", value: "AB+" },
  { label: "A-", value: "A-" },
  { label: "B-", value: "B-" },
  { label: "O-", value: "O-" },
  { label: "AB-", value: "AB-" },
];

export const pickerTimeFormat = "h:mm A";

export const months = [
  "jan",
  "feb",
  "mar",
  "apr",
  "may",
  "jun",
  "jul",
  "aug",
  "sep",
  "oct",
  "nov",
  "dec",
];

export const monthOptions = [
  { label: "January", value: "January" },
  { label: "February", value: "February" },
  { label: "March", value: "March" },
  { label: "April", value: "April" },
  { label: "May", value: "May" },
  { label: "June", value: "June" },
  { label: "July", value: "July" },
  { label: "August", value: "August" },
  { label: "September", value: "September" },
  { label: "October", value: "October" },
  { label: "November", value: "November" },
  { label: "December", value: "December" },
];

export const getSerialNumber = ({
  currentPage = 0,
  rowsPerPage = 0,
  index = 0,
}) => {
  const serialNumber =
    currentPage === 1 && index + 1 < 10
      ? "0" + (rowsPerPage * (currentPage - 1) + index + 1)
      : rowsPerPage * (currentPage - 1) + index + 1;
  return serialNumber;
};

export const formattedPhoneNumber = (event) => {
  const value = event.target.value;
  let phoneNumber = value.replace(/\D/g, "");
  let formattedNumber = "";

  for (let i = 0; i < phoneNumber.length; i++) {
    if (i === 3 || i === 6) {
      formattedNumber += "-";
    }
    formattedNumber += phoneNumber[i];
  }

  return formattedNumber;
};

export const formatTime = (date) => {
  if (!date) return "";
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
};

export const format24HourTimeTo12Hour = (time) => {
  if (!time) return "";

  const formattedTime = moment(time, "HH:mm").format("hh:mm A");
  return formattedTime;
};

export const filterUndefined = (obj) => {
  return Object.fromEntries(
    Object.entries(obj).filter(
      ([_, value]) => value !== undefined && value !== null && value !== ""
    )
  );
};

export const getPageData = ({ currentPage, pageSize, data }) => {
  if (
    !currentPage ||
    !pageSize ||
    (!data && !Array.isArray(data) && !data.length)
  )
    return { currentRows: [], totalItems: 0, totalPages: 0 };

  const currentPageRequired = currentPage * pageSize - pageSize;
  let page = data?.length > currentPageRequired ? currentPage : currentPage - 1;

  const newData = [...(data || [])];
  const totalItems = data?.length;
  const totalPages = Math.ceil(totalItems / pageSize);

  const indexOfLastRow = page * pageSize;
  const indexOfFirstRow = indexOfLastRow - pageSize;
  const currentRows = newData?.slice(indexOfFirstRow, indexOfLastRow);
  return { currentRows, totalItems, totalPages };
};

export const getClassCode = (value) => {
  if (value && typeof value === "string") {
    const [_, class_code, class_id] = value?.match(/^(-?\d+)-(.+)$/);
    return [class_code, class_id];
  } else {
    return ["", ""];
  }
};

export const getStringDate = (value) => {
  if (value) {
    const date =
      value.toString().length > 10 ? parseInt(value) / 1000 : parseInt(value);
    const formattedDate = moment.unix(date).format("MMM DD, YYYY");
    return formattedDate;
  } else {
    return "";
  }
};

export const getMonthYearCode = (monthName) => {
  if (!monthName) return "";
  const monthNumber = moment(monthName, "MMMM").format("MM");
  const year = moment().format("YYYY");
  const monthYearCode = `${year}${monthNumber}`;
  return Number(monthYearCode);
};

export const formatYearMonth = (ymInt) => {
  const ymStr = ymInt?.toString()?.padStart(6, "0");
  const year = ymStr?.slice(0, 4);
  const month = ymStr?.slice(4, 6);
  return `${year}-${month}`;
};

export const formatToDateString = (timestampInt) => {
  const ts = timestampInt?.toString()?.padStart(14, "0");
  const year = ts?.slice(0, 4);
  const month = ts?.slice(4, 6);
  const day = ts?.slice(6, 8);
  return `${year}-${month}-${day}`;
};

export const sortYears = (arr = []) => {
  if (!Array.isArray(arr) || arr?.length === 0) return arr;

  return [...arr].sort((a, b) => {
    const startA = a?.global_academic_year?.split("-")[0];
    const startB = b?.global_academic_year?.split("-")[0];

    if (Number(startA) !== Number(startB)) {
      return Number(startA) - Number(startB);
    }

    if (
      a?.global_academic_year?.includes("-") &&
      !b?.global_academic_year?.includes("-")
    ) {
      return 1;
    }
    if (
      !a?.global_academic_year?.includes("-") &&
      b?.global_academic_year?.includes("-")
    ) {
      return -1;
    }

    return 0;
  });
};

export const generateQueryTime = () => {
  const now = new Date();

  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, "0");
  const day = String(now.getUTCDate()).padStart(2, "0");
  const hours = String(now.getUTCHours()).padStart(2, "0");
  const minutes = String(now.getUTCMinutes()).padStart(2, "0");
  const seconds = String(now.getUTCSeconds()).padStart(2, "0");
  const queryTime = `${year}${month}${day}${hours}${minutes}${seconds}`;
  return parseInt(queryTime, 10);
};
