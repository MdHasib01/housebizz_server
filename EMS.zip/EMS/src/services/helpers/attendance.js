import moment from "moment";

export const getMonthDays = ({
  monthName,
  sessionYear = moment().year().toString(),
}) => {
  if (!monthName || !sessionYear) return [];

  const sessionYears = sessionYear.split("-");
  const monthIndex = moment().month(monthName).month();

  const year =
    monthIndex >= 0 && monthIndex <= 5
      ? parseInt(sessionYears[1] || sessionYears[0])
      : parseInt(sessionYears[0]);

  const daysInMonth = moment({ year, month: monthIndex }).daysInMonth();

  const daysArray = [];
  for (let date = 1; date <= daysInMonth; date++) {
    const day = moment({ year, month: monthIndex, date })
      .format("dd")
      .charAt(0);
    daysArray.push({ date, day });
  }
  return daysArray;
};

export const isUnixDateMatch = ({ unix, date }) => {

  function unixToDate(timestamp) {
    const date = new Date(timestamp);
    return date.getDate();
  }

  return unixToDate(unix) === date;

  // return moment.unix(unix).date() === date;
};
