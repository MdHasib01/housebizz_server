export { default as appLogo } from "@/assets/images/app-logo.png";
export { default as checkGreen } from "@/assets/images/check-green.png";
export { default as loginBg } from "@/assets/images/loginBg.png";
export { default as netro } from "@/assets/images/netro.png";
export { default as placeholderProfileImage } from "@/assets/images/placeholder-profile-image.png";
export { default as questionMarkRed } from "@/assets/images/question-mark-red.png";
