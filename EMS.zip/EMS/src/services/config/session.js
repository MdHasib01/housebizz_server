import Cookies from "js-cookie";
import { decryptValue, encryptValue } from "./crypto";

export async function setSession({ name = "pathshala-auth", value }) {
  try {
    const { data, error } = encryptValue(JSON.stringify(value));

    if (error) {
      return { error: error };
    }

    if (!data) {
      return { error: "Encryption failed: Data is null or undefined" };
    }

    Cookies.set(name, data.toString(), { expires: 30 });
    return { error: null };
  } catch (e) {
    return { error: "Error setting session" };
  }
}

export async function getSession(name = "pathshala-auth") {
  try {
    const cookie = Cookies.get(name);

    if (!cookie) {
      return null;
    }

    const { data, error } = decryptValue(cookie);

    if (error) {
      throw new Error(error);
    }

    if (!data) {
      throw new Error("Decryption failed: Data is null or undefined");
    }

    return JSON.parse(data);
  } catch (e) {
    return null;
  }
}

export async function removeSession(name = "pathshala-auth") {
  try {
    Cookies.remove(name);
  } catch (e) {
    return { error: "Error logging out" };
  }
}
