export const envConfig = {
  baseUrl: import.meta.env.VITE_BASE_URL,
  cryptoSecret: import.meta.env.VITE_CRYPTO_SECRET,
};
