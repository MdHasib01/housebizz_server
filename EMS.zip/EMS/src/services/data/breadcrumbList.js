import { superAdminRoutes } from "../routes/superAdmin";

export const superAdminBreads = {
  dashboard: [
    {
      name: "Welcome To Smart Pathshala",
      path: superAdminRoutes.dashboard.path,
    },
  ],
  boardManagement: [
    {
      name: "Global",
      path: superAdminRoutes.boardManagement.path,
    },
    superAdminRoutes.boardManagement,
  ],
  addBoardManagement: [
    {
      name: "Global",
      path: superAdminRoutes.boardManagement.path,
    },
    superAdminRoutes.boardManagement,
    superAdminRoutes.addBoardManagement,
  ],
  classManagement: [
    {
      name: "Global",
      path: superAdminRoutes.classManagement.path,
    },
    superAdminRoutes.classManagement,
  ],
  addClassManagement: [
    {
      name: "Global",
      path: superAdminRoutes.classManagement.path,
    },
    superAdminRoutes.classManagement,
    superAdminRoutes.addClassManagement,
  ],
  examType: [
    {
      name: "Global",
      path: superAdminRoutes.examType.path,
    },
    superAdminRoutes.examType,
  ],
  addExamType: [
    {
      name: "Global",
      path: superAdminRoutes.examType.path,
    },
    superAdminRoutes.examType,
    superAdminRoutes.addExamType,
  ],
  gradingManagement: [
    {
      name: "Global",
      path: superAdminRoutes.gradingManagement.path,
    },
    superAdminRoutes.gradingManagement,
  ],
  addGradingManagement: [
    {
      name: "Global",
      path: superAdminRoutes.gradingManagement.path,
    },
    superAdminRoutes.gradingManagement,
    superAdminRoutes.addGradingManagement,
  ],
  groupManagement: [
    {
      name: "Global",
      path: superAdminRoutes.groupManagement.path,
    },
    superAdminRoutes.groupManagement,
  ],
  addGroupManagement: [
    {
      name: "Global",
      path: superAdminRoutes.groupManagement.path,
    },
    superAdminRoutes.groupManagement,
    superAdminRoutes.addGroupManagement,
  ],
  sessionYear: [
    {
      name: "Global",
      path: superAdminRoutes.sessionYear.path,
    },
    superAdminRoutes.sessionYear,
  ],
  addSessionYear: [
    {
      name: "Global",
      path: superAdminRoutes.sessionYear.path,
    },
    superAdminRoutes.sessionYear,
    superAdminRoutes.addSessionYear,
  ],
  subjectManagement: [
    {
      name: "Global",
      path: superAdminRoutes.subjectManagement.path,
    },
    superAdminRoutes.subjectManagement,
  ],
  addSubjectManagement: [
    {
      name: "Global",
      path: superAdminRoutes.subjectManagement.path,
    },
    superAdminRoutes.subjectManagement,
    superAdminRoutes.addSubjectManagement,
  ],
  transactions: [superAdminRoutes.transactions],
  instituteManagement: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
  ],
  instituteAdmins: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
    superAdminRoutes.instituteAdmins,
  ],
  requestedInstitute: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.requestedInstitute,
  ],
  requestedInstituteDetails: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.requestedInstitute,
    superAdminRoutes.requestedInstituteDetails,
  ],
  addInstituteManagement: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
    superAdminRoutes.addInstituteManagement,
  ],
  updateInstituteManagement: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
    superAdminRoutes.updateInstituteManagement,
  ],
  assignInstitute: [
    {
      name: "Administrator",
      path: superAdminRoutes.assignInstitute.path,
    },
    superAdminRoutes.assignInstitute,
  ],
  instituteSettings: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteSettings.path,
    },
    superAdminRoutes.instituteSettings,
  ],
  requestedInstitute: [
    {
      name: "Administrator",
      path: superAdminRoutes.requestedInstitute.path,
    },
    superAdminRoutes.requestedInstitute,
  ],
};

export const adminBreads = {
  dashboard: [
    {
      name: "Welcome To Smart Pathshala",
      path: superAdminRoutes.dashboard.path,
    },
  ],
  boardManagement: [
    {
      name: "Global",
      path: superAdminRoutes.boardManagement.path,
    },
    superAdminRoutes.boardManagement,
  ],
  addBoardManagement: [
    {
      name: "Global",
      path: superAdminRoutes.boardManagement.path,
    },
    superAdminRoutes.boardManagement,
    superAdminRoutes.addBoardManagement,
  ],
  classManagement: [
    {
      name: "Global",
      path: superAdminRoutes.classManagement.path,
    },
    superAdminRoutes.classManagement,
  ],
  addClassManagement: [
    {
      name: "Global",
      path: superAdminRoutes.classManagement.path,
    },
    superAdminRoutes.classManagement,
    superAdminRoutes.addClassManagement,
  ],
  examType: [
    {
      name: "Global",
      path: superAdminRoutes.examType.path,
    },
    superAdminRoutes.examType,
  ],
  addExamType: [
    {
      name: "Global",
      path: superAdminRoutes.examType.path,
    },
    superAdminRoutes.examType,
    superAdminRoutes.addExamType,
  ],
  gradingManagement: [
    {
      name: "Global",
      path: superAdminRoutes.gradingManagement.path,
    },
    superAdminRoutes.gradingManagement,
  ],
  addGradingManagement: [
    {
      name: "Global",
      path: superAdminRoutes.gradingManagement.path,
    },
    superAdminRoutes.gradingManagement,
    superAdminRoutes.addGradingManagement,
  ],
  groupManagement: [
    {
      name: "Global",
      path: superAdminRoutes.groupManagement.path,
    },
    superAdminRoutes.groupManagement,
  ],
  addGroupManagement: [
    {
      name: "Global",
      path: superAdminRoutes.groupManagement.path,
    },
    superAdminRoutes.groupManagement,
    superAdminRoutes.addGroupManagement,
  ],
  sessionYear: [
    {
      name: "Global",
      path: superAdminRoutes.sessionYear.path,
    },
    superAdminRoutes.sessionYear,
  ],
  addSessionYear: [
    {
      name: "Global",
      path: superAdminRoutes.sessionYear.path,
    },
    superAdminRoutes.sessionYear,
    superAdminRoutes.addSessionYear,
  ],
  subjectManagement: [
    {
      name: "Global",
      path: superAdminRoutes.subjectManagement.path,
    },
    superAdminRoutes.subjectManagement,
  ],
  addSubjectManagement: [
    {
      name: "Global",
      path: superAdminRoutes.subjectManagement.path,
    },
    superAdminRoutes.subjectManagement,
    superAdminRoutes.addSubjectManagement,
  ],
  transactions: [superAdminRoutes.transactions],
  instituteManagement: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
  ],
  instituteAdmins: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
    superAdminRoutes.instituteAdmins,
  ],
  requestedInstitute: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.requestedInstitute,
  ],
  requestedInstituteDetails: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.requestedInstitute,
    superAdminRoutes.requestedInstituteDetails,
  ],
  addInstituteManagement: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
    superAdminRoutes.addInstituteManagement,
  ],
  updateInstituteManagement: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteManagement.path,
    },
    superAdminRoutes.instituteManagement,
    superAdminRoutes.updateInstituteManagement,
  ],
  assignInstitute: [
    {
      name: "Administrator",
      path: superAdminRoutes.assignInstitute.path,
    },
    superAdminRoutes.assignInstitute,
  ],
  instituteSettings: [
    {
      name: "Administrator",
      path: superAdminRoutes.instituteSettings.path,
    },
    superAdminRoutes.instituteSettings,
  ],
  requestedInstitute: [
    {
      name: "Administrator",
      path: superAdminRoutes.requestedInstitute.path,
    },
    superAdminRoutes.requestedInstitute,
  ],
};
