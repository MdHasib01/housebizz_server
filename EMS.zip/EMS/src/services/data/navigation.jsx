import {
  DashboardIcon,
  FrontHandIcon,
  GlobeIcon,
  LocationCityIcon,
  PaymentIcon,
  ReceptIcon,
  SettingIcon,
  TextSnippetIcon,
  AccountsIcon,
} from "@/services/assets/svgs";
import colors from "../config/colors";
import { adminRoutes } from "../routes";
import { superAdminRoutes } from "../routes/superAdmin";

export const adminNavigationData = {
  dashboard: {
    title: "Dashboard",
    icon: <DashboardIcon className={"h-5 w-5"} />,
    activeIcon: (
      <DashboardIcon className={"h-5 w-5"} color={colors.main[500]} />
    ),
    activeSegment: "dashboard",
    link: adminRoutes.dashboard.path,
  },
  institute: {
    title: "Institute",
    icon: <LocationCityIcon className={"h-5 w-5"} />,
    activeIcon: (
      <LocationCityIcon className={"h-5 w-5"} color={colors.main[500]} />
    ),
    activeSegment: "admin/institute",
    subMenu: [
      {
        title: adminRoutes.institute.admission.name,
        link: adminRoutes.institute.admission.path,
      },
      {
        title: "Reports",
        activeSegment: "institute/reports",
        subMenu: [
          {
            title: adminRoutes.institute.reports.studentStatus.name,
            link: adminRoutes.institute.reports.studentStatus.path,
          },
          {
            title: adminRoutes.institute.reports.studentSummary.name,
            link: adminRoutes.institute.reports.studentSummary.path,
          },
        ],
      },
      {
        title: "Students",
        activeSegment: "institute/students",
        subMenu: [
          {
            title: adminRoutes.institute.students.management.name,
            link: adminRoutes.institute.students.management.path,
          },
          {
            title: adminRoutes.institute.students.bulkImport.name,
            link: adminRoutes.institute.students.bulkImport.path,
          },
        ],
      },
      {
        title: adminRoutes.institute.teacher.name,
        link: adminRoutes.institute.teacher.path,
      },
      {
        title: adminRoutes.institute.shift.name,
        link: adminRoutes.institute.shift.path,
      },
      {
        title: adminRoutes.institute.class.name,
        link: adminRoutes.institute.class.path,
      },
      {
        title: adminRoutes.institute.section.name,
        link: adminRoutes.institute.section.path,
      },
      {
        title: adminRoutes.institute.day.name,
        link: adminRoutes.institute.day.path,
      },
      {
        title: adminRoutes.institute.period.name,
        link: adminRoutes.institute.period.path,
      },
      {
        title: adminRoutes.institute.category.name,
        link: adminRoutes.institute.category.path,
      },
      // {
      //   title: "Promotion",
      //   subMenu: [
      //     {
      //       title: "Result Wise",
      //       link: adminRoutes.dashboard.path,
      //     },
      //     {
      //       title: "Class Wise",
      //       link: adminRoutes.dashboard.path,
      //     },
      //   ],
      // },
      {
        title: adminRoutes.institute.userManage.name,
        link: adminRoutes.institute.userManage.path,
      },
    ],
  },
  attendance: {
    title: "Attendance",
    icon: <FrontHandIcon className={"h-5 w-5"} />,
    activeIcon: (
      <FrontHandIcon className={"h-5 w-5"} color={colors.main[500]} />
    ),
    activeSegment: "admin/attendance",
    subMenu: [
      {
        title: adminRoutes.attendance.classSchedule.name,
        link: adminRoutes.attendance.classSchedule.path,
      },
      {
        title: adminRoutes.attendance.subjectEnroll.name,
        link: adminRoutes.attendance.subjectEnroll.path,
      },
      // {
      //   title: adminRoutes.attendance.attendanceReport.name,
      //   link: adminRoutes.attendance.attendanceReport.path,
      // },
      {
        title: "Report",
        activeSegment: "attendance/report",
        subMenu: [
          {
            title: adminRoutes.attendance.report.classAttendance.name,
            link: adminRoutes.attendance.report.classAttendance.path,
          },
        ],
      },
    ],
  },
  examination: {
    title: "Examination",
    icon: <TextSnippetIcon className={"h-5 w-5"} />,
    activeIcon: (
      <TextSnippetIcon className={"h-5 w-5"} color={colors.main[500]} />
    ),
    activeSegment: "admin/examination",
    subMenu: [
      {
        title: "Optional Subject",
        link: "/examination/optional-subject",
      },
      {
        title: "Exam Type",
        link: "/examination/exam-type",
      },
      {
        title: "Exam Head",
        link: "/examination/exam-head",
      },
      {
        title: "Exam Config",
        link: "/examination/exam-config",
      },
      {
        title: "Grading",
        link: "/examination/grading",
      },
      {
        title: "Examinations",
        link: "/examination/examinations",
      },
      {
        title: "Exam Result",
        link: "/examination/exam-result",
      },
      {
        title: "Tabulations",
        link: "/examination/tabulations",
      },
      {
        title: "Transcript",
        link: "/examination/transcript",
      },
    ],
  },
  billing: {
    title: "Billing",
    icon: <PaymentIcon className={"h-5 w-5"} />,
    activeIcon: <PaymentIcon className={"h-5 w-5"} color={colors.main[500]} />,
    activeSegment: "admin/billing",
    subMenu: [
      {
        title: adminRoutes.billing.billingHead.name,
        link: adminRoutes.billing.billingHead.path,
      },
      {
        title: adminRoutes.billing.billingTypes.name,
        link: adminRoutes.billing.billingTypes.path,
      },
      {
        title: adminRoutes.billing.billingConfig.name,
        link: adminRoutes.billing.billingConfig.path,
      },
      {
        title: adminRoutes.billing.invoices.name,
        link: adminRoutes.billing.invoices.path,
      },
      {
        title: adminRoutes.billing.cashPay.name,
        link: adminRoutes.billing.cashPay.path,
      },

      {
        title: adminRoutes.billing.report.name,
        activeSegment: "billing/report",
        subMenu: [
          {
            title: adminRoutes.billing.report.headwisePayment.name,
            link: adminRoutes.billing.report.headwisePayment.path,
          },

          {
            title: adminRoutes.billing.report.dailyCollections.name,
            link: adminRoutes.billing.report.dailyCollections.path,
          },

          {
            title: adminRoutes.billing.report.studentDues.name,
            link: adminRoutes.billing.report.studentDues.path,
          },

          {
            title: adminRoutes.billing.report.studentLedger.name,
            link: adminRoutes.billing.report.studentLedger.path,
          },
        ],
      },
    ],
  },
  accounts: {
    title: "Accounts",
    icon: <AccountsIcon className={"h-5 w-5"} />,
    activeIcon: <AccountsIcon className={"h-5 w-5"} color={colors.main[500]} />,
    activeSegment: "accounts",
    subMenu: [
      {
        title: adminRoutes.accounts.overview.name,
        link: adminRoutes.accounts.overview.path,
      },
      {
        title: adminRoutes.accounts.expenses.name,
        link: adminRoutes.accounts.expenses.path,
      },
      {
        title: adminRoutes.accounts.expenseCategory.name,
        link: adminRoutes.accounts.expenseCategory.path,
      },
    ],
  },
  settings: {
    title: "Settings",
    icon: <SettingIcon className={"h-5 w-5"} />,
    activeIcon: <SettingIcon className={"h-5 w-5"} color={colors.main[500]} />,
    activeSegment: "admin/settings",
    subMenu: [
      {
        title: adminRoutes.settings.payment.name,
        link: adminRoutes.settings.payment.path,
      },
      {
        title: adminRoutes.settings.sms.name,
        link: adminRoutes.settings.sms.path,
      },
    ],
  },
};

export const superAdminNavigationData = {
  dashboard: {
    title: "Dashboard",
    icon: <DashboardIcon className={"h-5 w-5"} />,
    activeIcon: (
      <DashboardIcon className={"h-5 w-5"} color={colors.main[500]} />
    ),
    activeSegment: "dashboard",
    link: superAdminRoutes.dashboard.path,
  },
  global: {
    title: "Global",
    icon: <GlobeIcon className={"h-5 w-5"} />,
    activeIcon: <GlobeIcon className={"h-5 w-5"} color={colors.main[500]} />,
    activeSegment: "global",
    subMenu: [
      {
        title: superAdminRoutes.boardManagement.name,
        link: superAdminRoutes.boardManagement.path,
      },
      {
        title: superAdminRoutes.classManagement.name,
        link: superAdminRoutes.classManagement.path,
      },
      {
        title: superAdminRoutes.subjectManagement.name,
        link: superAdminRoutes.subjectManagement.path,
      },
      {
        title: superAdminRoutes.groupManagement.name,
        link: superAdminRoutes.groupManagement.path,
      },
      {
        title: superAdminRoutes.gradingManagement.name,
        link: superAdminRoutes.gradingManagement.path,
      },
      {
        title: superAdminRoutes.examType.name,
        link: superAdminRoutes.examType.path,
      },
      {
        title: superAdminRoutes.sessionYear.name,
        link: superAdminRoutes.sessionYear.path,
      },
    ],
  },
  transactions: {
    title: "Transactions",
    icon: <ReceptIcon className={"h-5 w-5"} />,
    activeIcon: <ReceptIcon className={"h-5 w-5"} color={colors.main[500]} />,
    activeSegment: "transactions",
    link: superAdminRoutes.transactions.path,
  },
  administrator: {
    title: "Administrator",
    icon: <SettingIcon className={"h-5 w-5"} />,
    activeIcon: <SettingIcon className={"h-5 w-5"} color={colors.main[500]} />,
    activeSegment: "administrator",
    subMenu: [
      {
        title: superAdminRoutes.instituteManagement.name,
        link: superAdminRoutes.instituteManagement.path,
      },
      {
        title: superAdminRoutes.requestedInstitute.name,
        link: superAdminRoutes.requestedInstitute.path,
      },
      // {
      //   title: superAdminRoutes.assignInstitute.name,
      //   link: superAdminRoutes.assignInstitute.path,
      // },
      // {
      //   title: superAdminRoutes.instituteSettings.name,
      //   link: superAdminRoutes.instituteSettings.path,
      // },
    ],
  },
};
