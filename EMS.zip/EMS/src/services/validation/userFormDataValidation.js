import { z } from "zod";

export const addUserFormSchema = z.object({
  userType: z.string().min(1, "User Type is required"),
  mobile: z
    .string()
    .regex(/^\d{10,15}$/, "Mobile No. must be between 10 and 15 digits"),
});
