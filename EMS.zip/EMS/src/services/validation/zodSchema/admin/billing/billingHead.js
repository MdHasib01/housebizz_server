import { z } from "zod";

export const biliingHeadSchema = z.object({
  head_id: z.number(),
  head_title: z.string().min(1),
  status: z.string().min(1),
});
