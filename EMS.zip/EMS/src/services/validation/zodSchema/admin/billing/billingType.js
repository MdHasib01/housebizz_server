import { z } from "zod";

export const billingTypeSchema = z.object({
    institute_id: z.string().min(1, { message: "Institute ID is required." }),
    billing_type: z.string().min(1, { message: "Billing type is required." }),
    academic_year: z.string().min(1, { message: "Academic year is required." }),
    local_class_id: z.string().min(1, { message: "Local class ID is required." }),
    category_id: z.string().min(1, { message: "Category ID is required." }),
    group_id: z.string().optional(),
    assigned_heads: z.array(
        z.object({
            billing_head_id: z.string().min(1, { message: "Billing Head ID is required." }),
        })
    ).min(1, { message: "At least one assigned head is required." }),
});
