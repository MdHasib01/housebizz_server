import { z } from "zod";

export const scheduleSchema = z.object({
  day_id: z.string().min(1, "Day ID is required"),
  period_id: z.string().min(1, "Period ID is required"),
  subjects: z
    .array(
      z.object({
        subject_id: z.string().min(1, "Subject ID is required"),
        teacher_id: z.string().min(1, "Teacher ID is required"),
        start_time: z.string().min(1, "Start time is required"),
        end_time: z.string().min(1, "End time is required"),
      })
    )
    .min(1, "At least one subject is required"),
});
