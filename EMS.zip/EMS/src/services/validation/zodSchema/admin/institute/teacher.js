import { z } from "zod";

export const teacherSchema = z.object({
  teacher_index: z
    .number()
    .int()
    .positive("Teacher index must be a positive integer"),
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().optional(),
  gender: z.enum(["Male", "Female", "Others"]),
  nid_number: z.string().min(1, "NID number is required"),
  mobile_number: z.string().min(1, "Invalid mobile number format"),
  phone_number: z.string().optional(),
  status: z.enum(["available", "left", "rusticated", "pending"]),
  contract_type: z.enum(["permanent", "contract", "guest"]).optional(),
  highest_qualification: z
    .string()
    .min(1, "Highest qualification is required")
    .or(z.literal(""))
    .optional(),
  other_qualification: z.string().optional(),
  subject_specialization: z
    .string()
    .min(1, "Subject specialization is required")
    .or(z.literal(""))
    .optional(),
  present_address_line: z
    .string()
    .min(1, "Present address is required")
    .or(z.literal(""))
    .optional(),
  present_district: z
    .string()
    .min(1, "Present district is required")
    .or(z.literal(""))
    .optional(),
  present_upozilla: z
    .string()
    .min(1, "Present upozilla is required")
    .or(z.literal(""))
    .optional(),
  present_post_office: z
    .string()
    .min(1, "Present post office is required")
    .or(z.literal(""))
    .optional(),
  present_post_code: z
    .string()
    .regex(/^[0-9]{4}$/, "Invalid post code format")
    .or(z.literal(""))
    .optional(),
  permanent_address_line: z
    .string()
    .min(1, "Permanent address is required")
    .or(z.literal(""))
    .optional(),
  permanent_district: z
    .string()
    .min(1, "Permanent district is required")
    .or(z.literal(""))
    .optional(),
  permanent_upozilla: z
    .string()
    .min(1, "Permanent upozilla is required")
    .or(z.literal(""))
    .optional(),
  permanent_post_office: z
    .string()
    .min(1, "Permanent post office is required")
    .or(z.literal(""))
    .optional(),
  permanent_post_code: z
    .string()
    .regex(/^[0-9]{4}$/, "Invalid post code format")
    .or(z.literal(""))
    .optional(),
  email: z.string().email("Invalid email format").or(z.literal("")).optional(),
  tax_identification_number: z
    .string()
    .min(1, "TIN is required")
    .or(z.literal(""))
    .optional(),
  role: z
    .enum(["teacher", "assistant_teacher", "head_teacher", "admin"])
    .optional(),
});
