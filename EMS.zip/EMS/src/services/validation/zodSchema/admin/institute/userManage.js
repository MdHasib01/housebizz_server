import { z } from "zod";

export const userManageSchema = z.object({
  mobile_number: z
    .string()
    .regex(/^01[3-9][0-9]{8}$/, "Invalid mobile number format"),
  role: z.enum(["institute_admin"]),
});
