import { z } from "zod";

export const studentAdmissionSchema = z.object({
  name_english: z.string().min(1, "Name is required"),
  name_bangla: z.string().optional(),
  mobile_number: z.string().min(1, "Mobile number is required"),
  gender: z.string().min(1, "Gender is required"),
  date_of_birth: z.string().optional(),
  birth_certificate_number: z.string().optional(),
  email: z.string().optional(),
  nationality: z.string().optional(),
  religion: z.string().min(1, "Religion is required"),
  blood_group: z.string().optional(),
  disability: z.string().optional(),
  //academic info
  academic_year: z.string().min(1, "Academic year is required"),
  current_class: z.string().min(1, "Current class is required"),
  current_section: z.string().min(1, "Current section is required"),
  current_group: z.string().optional(),
  current_category: z.string().min(1, "Current category is required"),
  current_roll_number: z.number().optional(),
  //previous academic info
  previous_insitute_name: z.string().optional(),
  previous_class: z.string().optional(),
  previous_result: z.string().optional(),
  //father info
  father_name_english: z.string().min(1, "Father name is required"),
  father_name_bangla: z.string().optional(),
  father_mobile_number: z.string().optional(),
  father_nid_number: z.string().optional(),
  father_profession: z.string().optional(),
  //mother info
  mother_name_english: z.string().optional(),
  mother_name_bangla: z.string().optional(),
  mother_mobile_number: z.string().optional(),
  mother_nid_number: z.string().optional(),
  mother_profession: z.string().optional(),
  //guardian info
  guardian_name_english: z.string().optional(),
  guardian_name_bangla: z.string().optional(),
  guardian_mobile_number: z.string().optional(),
  guardian_nid_number: z.string().optional(),
  guardian_profession: z.string().optional(),
  //address info
  present_address_line: z.string().optional(),
  present_address_district: z.string().optional(),
  present_address_upozilla: z.string().optional(),
  present_address_post_office: z.string().optional(),
  present_address_post_code: z.string().optional(),
  permanent_address_line: z.string().optional(),
  permanent_address_district: z.string().optional(),
  permanent_address_upozilla: z.string().optional(),
  permanent_address_post_office: z.string().optional(),
  permanent_address_post_code: z.string().optional(),
  //transaction fields
  transaction_id: z.string().optional(),
  //image
  image: z.string().optional(),
  //extra
  password: z.string().optional(),
  //meta
  role: z.string().optional(),
  status: z.string().optional(),
});

export const studentAddSchema = z.object({
  name_english: z.string().min(1, "Name is required"),
  name_bangla: z.string().optional(),
  mobile_number: z.string().min(1, "Mobile number is required"),
  gender: z.string().min(1, "Gender is required"),
  date_of_birth: z.string().optional(),
  birth_certificate_number: z.string().optional(),
  email: z.string().optional(),
  nationality: z.string().optional(),
  religion: z.string().min(1, "Religion is required"),
  blood_group: z.string().optional(),
  disability: z.string().optional(),

  //father info
  father_name_english: z.string().min(1, "Father name is required"),
  father_name_bangla: z.string().optional(),
  father_mobile_number: z.string().optional(),
  father_nid_number: z.string().optional(),
  father_profession: z.string().optional(),
  //mother info
  mother_name_english: z.string().optional(),
  mother_name_bangla: z.string().optional(),
  mother_mobile_number: z.string().optional(),
  mother_nid_number: z.string().optional(),
  mother_profession: z.string().optional(),

  //address info
  present_address_line: z.string().optional(),
  present_address_district: z.string().optional(),
  present_address_upozilla: z.string().optional(),
  present_address_post_office: z.string().optional(),
  present_address_post_code: z.string().optional(),
  permanent_address_line: z.string().optional(),
  permanent_address_district: z.string().optional(),
  permanent_address_upozilla: z.string().optional(),
  permanent_address_post_office: z.string().optional(),
  permanent_address_post_code: z.string().optional(),

  //academic info
  academic_year: z.string().min(1, "Academic year is required"),
  current_class: z.string().min(1, "Current class is required"),
  current_section: z.string().min(1, "Current section is required"),
  current_category: z.string().min(1, "Current category is required"),
});
