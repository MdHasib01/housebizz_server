import { z } from "zod";

export const sectionSchema = z.object({
  institute_id: z.string().nonempty("Institute ID is required"),
  local_class_id: z.string().nonempty("Class ID is required"),
  shift_id: z.string().nonempty("Shift ID is required"),
  section_name: z.string().nonempty("Section name is required"),
  section_capacity: z
    .number({
      required_error: "Section capacity is required",
      invalid_type_error: "Section capacity must be a number",
    })
    .min(1, "Section capacity must be at least 1"),
});
