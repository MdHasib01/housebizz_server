import moment from "moment";
import { z } from "zod";

export const shiftSchema = z
  .object({
    institute_id: z.string().nonempty("Institute ID is required"),
    name: z.string().nonempty("Name is required"),
    start_time: z.string().nonempty("Start time is required"),
    end_time: z.string().nonempty("End time is required"),
  })
  .refine(
    (data) => {
      const startTime = moment(data.start_time, "hh:mm A");
      const endTime = moment(data.end_time, "hh:mm A");
      return startTime.isBefore(endTime);
    },
    {
      message: "End time must be after start time",
      path: ["end_time"],
    }
  );
