import { z } from "zod";

export const boardSchema = z.object({
  global_board_name: z.string().min(1, "Board name is required"),
  global_board_code: z.number().min(1, "Board code is required"),
});
