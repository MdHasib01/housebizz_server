import z from "zod";

export const gradeSchema = z.object({
  global_grade_name: z.string().min(1, "Grade name is required"),
  global_grade_point: z.number().min(0, "Grade point must be positive"),
  global_grade_lowest_mark: z.number().min(0, "Lowest mark must be positive"),
  global_grade_highest_mark: z
    .number()
    .min(0, "Highest mark must be positive")
    .max(100, "Highest mark must be 100 or less"),
});
