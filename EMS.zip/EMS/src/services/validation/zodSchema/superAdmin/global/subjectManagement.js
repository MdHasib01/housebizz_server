import { z } from "zod";

export const subjectSchema = z.object({
  global_board_id: z.string().min(1, "Board is required"),
  global_class_id: z.string().min(1, "Class is required"),
  global_subject_name: z.string().min(1, "Subject name is required"),
  global_subject_code: z.string().min(1, "Subject code is required"),
  global_subject_order: z.number().min(1, "Subject order is required"),
});
