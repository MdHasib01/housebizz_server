import { z } from "zod";

const instituteSchema = z.object({
  institute_name: z.string().min(1, "Institute name is required"),
  institute_short_name: z.string().min(1, "Short name is required"),
  eiin_number: z.number().min("EIIN number is required"),
  estd_code: z.string().min(1, "ESTD code is required"),
  board_institute_code: z.string().min(1, "Board institute code is required"),
  institute_email: z.string().email("Invalid email format"),
  institute_telephone: z.string().min(3, "Invalid telephone number"),
  institute_mobilephone: z.string().min(3, "Invalid mobile phone number"),
  total_students: z
    .number()
    .int()
    .min(1, "Total students is required")
    .positive("Total students must be a positive number"),
  institute_address: z.string().min(1, "Address is required"),
  institute_postal_code: z.string().regex(/^\d{4,6}$/, "Invalid postal code"),
  institute_type: z.string().min(1, "Institute type is required"),
  institute_board_id: z.string().min(1, "Board is required"),
  institute_post_office: z.string().min(1, "Post office name is required"),
  institute_upazilla: z.string().min(1, "Upazilla is required"),
  institute_district: z.string().min(1, "District is required"),
});

export default instituteSchema;
