export const checkValidation = (response) => {
  if (response?.success) {
    return {
      isError: false,
      error: null,
      data: response.data,
    };
  } else {
    const formatErrors = (errors) => {
      return Object.fromEntries(
        Object.entries(errors).map(([key, value]) => {
          if (value?._errors?.length) {
            return [key, value._errors[0]];
          } else if (typeof value === "object") {
            return [key, formatErrors(value)];
          } else {
            return [key, "Invalid value"];
          }
        })
      );
    };

    return {
      isError: true,
      error: formatErrors(response?.error?.format()),
      data: null,
    };
  }
};
