import { z } from "zod";

export const addStudentFormSchema = z.object({
  // Basic Information
  fullnameEng: z.string().min(1, "Full Name (In English) is required."),
  fullnameBng: z.string().min(1, "Full Name (In Bangla) is required."),
  mobileNo: z.string().regex(/^\d{10,15}$/, "Enter a valid mobile number."),
  gender: z.string().min(1, "Gender is required."),
  dob: z.date({
    required_error: "Date of Birth is required.",
  }),
  birthCertificateNo: z.string().optional(),
  email: z.string().email("Enter a valid email address."),
  nationality: z.string().min(1, "Nationality is required."),
  religion: z.string().min(1, "Religion is required."),
  bloodGroup: z.string().min(1, "Blood Group is required."),
  disability: z.string().min(1, "Disability status is required."),

  // Father's Information
  fatherFullnameEng: z
    .string()
    .min(1, "Father's Full Name (In English) is required."),
  fatherFullnameBng: z
    .string()
    .min(1, "Father's Full Name (In Bangla) is required."),
  fatherMobileNo: z
    .string()
    .regex(/^\d{10,15}$/, "Enter a valid mobile number."),
  fatherNid: z.string().regex(/^\d+$/, "Enter a valid NID."),
  fatherProfession: z.string().min(1, "Father's Profession is required."),

  // Mother's Information
  motherFullnameEng: z
    .string()
    .min(1, "Mother's Full Name (In English) is required."),
  motherFullnameBng: z
    .string()
    .min(1, "Mother's Full Name (In Bangla) is required."),
  motherMobileNo: z
    .string()
    .regex(/^\d{10,15}$/, "Enter a valid mobile number."),
  motherNid: z.string().regex(/^\d+$/, "Enter a valid NID."),
  motherProfession: z.string().min(1, "Mother's Profession is required."),

  // Present Address Information
  presentAddressLine: z.string().min(1, "Present Address Line is required."),
  district: z.string().min(1, "District is required."),
  presentUpazilla: z.string().min(1, "Upazilla is required."),
  presentPostOffice: z.string().min(1, "Post Office is required."),
  presentPostCode: z.string().regex(/^\d+$/, "Enter a valid Post Code."),

  // Permanent Address Information
  permanentAddressLine: z
    .string()
    .min(1, "Permanent Address Line is required."),
  permanentUpazilla: z.string().min(1, "Upazilla is required."),
  permanentPostOffice: z.string().min(1, "Post Office is required."),
  permanentPostCode: z.string().regex(/^\d+$/, "Enter a valid Post Code."),
});

export const editStudentFormSchema = z.object({
  fullname: z.string().nonempty("Full Name is required"),
  roll: z.number().positive("Roll must be a positive number"),
  mobileNo: z
    .string()
    .regex(/^\d{10,15}$/, "Mobile No. must be between 10 and 15 digits"),
  gender: z.enum(["Male", "Female", "Others"], "Gender is required"),
  email: z.string().email("Invalid email address"),
  religion: z.enum(["Islam", "Christian"], "Religion is required"),
  dob: z.string().nonempty("Date of Birth is required"),
  bloodGroup: z.string().nonempty("Blood Group is required"),
  nationality: z.enum(
    ["Bangladeshi", "Non-Bangladeshi"],
    "Nationality is required"
  ),
  fourthSubjectCode: z.string().optional(),

  presentAddressLine: z.string().nonempty("Present Address Line is required"),
  district: z.string().nonempty("District is required"),
  presentUpazilla: z.string().nonempty("Present Upazilla is required"),
  presentPostOffice: z.string().nonempty("Present Post Office is required"),
  presentPostCode: z.string().nonempty("Present Post Code is required"),

  fatherFullname: z.string().nonempty("Father's Full Name is required"),
  fatherMobileNo: z
    .string()
    .regex(/^\d{10,15}$/, "Mobile No. must be between 10 and 15 digits"),
  fatherProfession: z.string().nonempty("Father's Profession is required"),

  motherFullname: z.string().nonempty("Mother's Full Name is required"),
  motherMobileNo: z
    .string()
    .regex(/^\d{10,15}$/, "Mobile No. must be between 10 and 15 digits"),
  motherProfession: z.string().nonempty("Mother's Profession is required"),
});
