export const validatePaymentSetting = (data) => {
  const {
    bkash_merchant_wallet_number,
    bkash_payment_is_active,
    rocket_merchant_wallet_number,
    rocket_payment_is_active,
    nagad_merchant_wallet_number,
    nagad_payment_is_active,
  } = data || {};

  if (
    !bkash_payment_is_active &&
    !rocket_payment_is_active &&
    !nagad_payment_is_active
  ) {
    return "At least one payment method should be active";
  }
  if (bkash_payment_is_active && !bkash_merchant_wallet_number) {
    return "BKash Merchant Wallet No is required";
  }
  if (rocket_payment_is_active && !rocket_merchant_wallet_number) {
    return "Rocket Merchant Wallet No is required";
  }
  if (nagad_payment_is_active && !nagad_merchant_wallet_number) {
    return "Nagad Merchant Wallet No is required";
  }
  return null;
};
