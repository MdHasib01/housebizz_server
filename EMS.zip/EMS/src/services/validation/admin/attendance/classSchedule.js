export const checkClassScheduleFilter = (data) => {
  if (!data.academic_year) return "Please select academic year";
  if (!data.local_class_id) return "Please select class";
  if (!data.section_id) return "Please select section";
  return null;
};
