import { z } from "zod";

export const studentSchema = z.object({
  entity_type: z.literal("student"),
  institute_id: z.string().min(1),
  name_english: z.string().min(1),
  name_bangla: z.string().min(1),
  mobile_number: z.string().regex(/^\d{10,15}$/),
  gender: z.enum(["Male", "Female", "Others"]),
  date_of_birth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  birth_certificate_number: z.string().optional(),
  nationality: z.string().min(1),
  religion: z.enum(["islam", "hinduism", "christianity", "buddhism", "other"]),
  blood_group: z.string().optional(),
  disability: z.string().min(1),
  academic_year: z.string().regex(/^\d{4}$/),
  current_class: z.string().min(1),
  father_name_english: z.string().min(1),
  father_name_bangla: z.string().min(1),
  mother_name_english: z.string().min(1),
  mother_name_bangla: z.string().min(1),
  transaction_id: z.string().min(1),
  image: z.string().optional(),
});
