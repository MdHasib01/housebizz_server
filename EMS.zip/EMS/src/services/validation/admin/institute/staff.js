export const validateShift = (values) => {
    if (!values.name) return "Shift Name is required";
    if (!values.start_time) return "Start date is required";
    if (!values.end_time) return "Start date is required";

    // Convert times to total minutes for accurate comparison
    const [startHour, startMinute] = values.start_time.split(":").map(Number);
    const [endHour, endMinute] = values.end_time.split(":").map(Number);

    const startTotalMinutes = startHour * 60 + startMinute;
    const endTotalMinutes = endHour * 60 + endMinute;

    if (endTotalMinutes <= startTotalMinutes)
        return "End time must be after start time";

    return null;
};  