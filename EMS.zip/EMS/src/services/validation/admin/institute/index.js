export * from "./studentAdmission";
export * from "./teacher";
export * from "./staff";