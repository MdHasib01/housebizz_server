export const validateSection = (values) => {
  if (!values.institute_id) return "Institute ID is required";
  if (!values.local_class_id) return "Local Class ID is required";
  if (!values.section_name) return "Section name is required";
  if (!values.section_capacity) return "Section capacity is required";
  if (!values.shift_id) return "Shift ID is required";

  return null;
};
