export const validateBillingHeadManagement = (data) => {
  if (!data.head_id) return "Head Title is required";
  if (!data.head_title) return "Head Title is required";
  if (!data.status) return "Status is required";
  return null;
};
