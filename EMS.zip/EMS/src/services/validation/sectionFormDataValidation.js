import { z } from "zod";

export const addSectionFormSchema = z.object({
  className: z
    .string({
      required_error: "Class is required",
    })
    .min(1, "Please select a class"),

  group: z
    .string({
      required_error: "Group is required",
    })
    .min(1, "Please select a group"),

  shift: z
    .string({
      required_error: "Shift is required",
    })
    .min(1, "Please select a shift"),

  section: z
    .string({
      required_error: "Section name is required",
    })
    .min(1, "Section name cannot be empty")
    .max(50, "Section name cannot exceed 50 characters")
    .regex(
      /^[A-Za-z0-9\s-]+$/,
      "Section name can only contain letters, numbers, spaces and hyphens"
    ),

  capacity: z.string({
    required_error: "Capacity is required",
  }),
});
