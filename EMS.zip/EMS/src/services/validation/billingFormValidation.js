import { z } from "zod";

export const addBillingTypeFormSchema = z.object({
  category: z.string().min(1, "Category is required"),
  year: z.string().min(1, "Year is required"),
  class: z.string().min(1, "Class is required"),
  billingType: z.string().min(1, "Billing Type is required"),
});
