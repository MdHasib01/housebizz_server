export const validateGradingManagement = (values) => {
  if (!values.global_grade_name) return "Grade Name is required";
  if (!values.global_grade_point) return "Grade point is required";
  if (!values.global_grade_lowest_mark) return "Grade lowest mark is required";
  if (!values.global_grade_highest_mark)
    return "Grade highest mark is required";
  if (values.global_grade_highest_mark > 100)
    return "Highest mark must be 100 or less";
  if (values.global_grade_point < 1) return "Grade point must be positive";
  if (values.global_grade_lowest_mark < 1)
    return "Lowest mark must be positive";
  if (values.global_grade_highest_mark < 1)
    return "Highest mark must be positive";
};
