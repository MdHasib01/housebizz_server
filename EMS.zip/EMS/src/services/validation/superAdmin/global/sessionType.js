export const validateSessionYear = (values) => {
  if (!values.institute_type) return "Institute type is required";
  if (!values.global_academic_year) return "Academic year is required";
};
