export const validateClassManagement = (values) => {
  if (!values.global_class_name) return "Class Name is required";
  if (!values.global_class_code) return "Class Code is required";
};
