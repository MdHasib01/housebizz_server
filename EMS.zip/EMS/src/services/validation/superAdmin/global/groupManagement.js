export const validateGroupManagement = (values) => {
  if (!values.global_class_id) return "Class Name is required";
  if (!values.global_group_name) return "Class Code is required";
};
