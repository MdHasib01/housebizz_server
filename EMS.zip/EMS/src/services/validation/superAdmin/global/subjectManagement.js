export const validateSubjectManagement = (values) => {
  if (!values.global_board_id) return "Board is required";
  if (!values.global_class_id) return "Class is required";
  if (!values.global_subject_name) return "Subject name is required";
  if (!values.global_subject_code) return "Subject code is required";
  if (!values.global_subject_order) return "Subject order is required";
};
