export const validateBoardManagement = (values) => {
  if (!values.global_board_name) return "Board Name is required";
  if (!values.global_board_code) return "Board Code is required";
};
