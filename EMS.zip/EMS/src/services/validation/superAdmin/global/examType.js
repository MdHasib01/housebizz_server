export const validateExamType = (values) => {
  if (!values.global_exam_type_name) return "Exam Type is required";
};
