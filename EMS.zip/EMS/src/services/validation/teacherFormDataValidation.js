import { optional, z } from "zod";

// Define the form schema using Zod
export const addTeacherFormSchema = z.object({
  // Teacher Information
  teacherIndex: z.string().optional(),
  instituteId: z.number(),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  gender: z.enum(["Male", "Female", "Others"], {
    required_error: "Please select a gender",
  }),
  nid: z.string().min(10, "NID must be at least 10 characters"),
  mobileNo: z
    .string()
    .min(11, "Mobile number must be 11 digits")
    .max(11, "Mobile number must be 11 digits")
    .regex(/^01\d{9}$/, "Must be a valid Bangladeshi number"),
  status: z.string().optional().optional(),

  // Contact Type
  contactType: z.string().optional(),

  // Education Qualification
  highestQualification: z.string().optional(),
  otherQualification: z.string().optional(),
  subjectSpeciality: z.string().optional(),

  // Present Address
  presentAddressLine: z.string().optional(),
  presentDistrict: z.string().optional(),
  presentUpazilla: z.string().optional(),
  presentPostOffice: z.string().optional(),
  presentPostCode: z.string().optional(),

  // Permanent Address
  permanentAddressLine: z.string().optional(),
  permanentDistrict: z.string().optional(),
  permanentUpazilla: z.string().optional(),
  permanentPostOffice: z.string().optional(),
  permanentPostCode: z.string().optional(),

  // Other Information
  email: z.string().optional(),
  phoneNo: z.string().optional(),
  tin: z.string().optional(),
});

export const editTeacherFormSchema = z.object({
  firstName: z.string().min(1, "First Name is required"),
  lastName: z.string().min(1, "Last Name is required"),
  gender: z.enum(["Male", "Female", "Others"], {
    required_error: "Gender is required",
  }),
  nid: z.string().min(1, "NID is required"),
  mobileNo: z.string().min(1, "Mobile Number is required"),
  status: z.enum(["AVAILABLE", "UNAVAILABLE"]).optional(),
  contactType: z.enum(["PERMANENT", "TEMPORARY"]).optional(),

  highestQualification: z.string().optional(),
  otherQualification: z.string().optional(),
  subjectSpeciality: z.string().optional(),

  presentAddressLine: z.string().optional(),
  district: z.string().optional(),
  presentUpazilla: z.string().optional(),
  presentPostOffice: z.string().optional(),
  presentPostCode: z.string().optional(),

  permanentAddressLine: z.string().optional(),
  permanentDistrict: z.string().optional(),
  permanentUpazilla: z.string().optional(),
  permanentPostOffice: z.string().optional(),
  permanentPostCode: z.string().optional(),
});
