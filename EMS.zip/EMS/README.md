![smart pathshala image](./src/assets/images/app-logo.png)

# `Smart PathShala`

- how to run on local server

```bash
npm i
npm run dev
```

`Style Notes:`

- classNames containing `_` are custom classes defined in css files. for example `flex_center`, `absolute_center`
